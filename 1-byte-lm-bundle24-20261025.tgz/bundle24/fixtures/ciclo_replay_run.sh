#!/bin/bash
# REPLAY v2 (autorizado main 13:25). R = master_mix 2x480 seq_R; E = dst3b_train
# 239+241 seq_E (misma exposicion DST, mismo orden). Base comun clon etapa0,
# lr 0.003 seed 7, curriculo declarado -master-prev sub500. Tope 90s wall TOTAL
# (incl gens/score/retencion); guarda bloque R>24.2s E>5s = PARAR; proyeccion
# elapsed+est>90 = PARAR; primer fallo = PARAR; SIN retries.
set -e; cd /tmp/blm
PREV=c8ee772eb1d2dfe4c2ea8ffc38d991f07750309d449eff53f82d63af3476b355
TSTART=$SECONDS
mkdir -p ciclo_replay
adamsha() { python3 -c "
import json,hashlib
d=json.load(open('$1'))
print(hashlib.sha256(json.dumps(d.get('adam'),sort_keys=True).encode()).hexdigest()[:16], hashlib.sha256(str(d.get('samp')).encode()).hexdigest()[:16])"; }
bloque() { # ARM K PASOS CORPUS MANIFEST SEQ CKIN CKOUT PREVFLAG GUARDA TO EST
  local A=$1 K=$2 PASOS=$3 MA=$4 MF=$5 SQ=$6 IN=$7 OUT=$8 PF=$9 GU=${10} TO=${11} EST=${12}
  local INSHA; INSHA=$(sha256sum "$IN" | cut -c1-12)
  local KEY="${A}${K}_${INSHA}"
  local LED="ciclo_replay/ledger_$KEY"
  if [ -e "$LED" ]; then
    local ST; ST=$(cut -d' ' -f1 "$LED")
    [ "$ST" = completed ] && { echo "LEDGER $KEY ya completada"; return 0; }
    echo "LEDGER $KEY estado=$ST: recuperacion manual; NO reejecuta"; exit 3
  fi
  local el=$((SECONDS-TSTART))
  if awk "BEGIN{exit !($el+$EST>90)}"; then echo "PARADA proyeccion ${el}s+${EST} > 90s"; exit 5; fi
  echo "running $(date -Is)" > "$LED.tmp"; mv "$LED.tmp" "$LED"
  trap 'if [ -n "${LED:-}" ]; then echo "failed $(date -Is)" > "$LED.tmp"; mv "$LED.tmp" "$LED"; fi' ERR
  local t0=$SECONDS
  timeout -k 2 $TO ./mz d1gru -mode train-pairs -corpus "$MA" -val dst3b_dev.txt \
    -in "$IN" -out "$OUT" -steps $PASOS -lr 0.003 -seed 7 \
    -master "$MA" -manifest "$MF" -seq "$SQ" $PF 2>&1 | grep -E 'FIN|RECHAZO|DECLARADO|seq predefinida'
  local dt=$((SECONDS-t0))
  { echo "adam_rng_antes: $(adamsha "$IN")"; echo "adam_rng_despues: $(adamsha "$OUT")"; } >> ciclo_replay/adam_$A$K.txt
  if awk "BEGIN{exit !($dt>$GU)}"; then
    echo "failed $(date -Is) GUARDA bloque ${dt}s > ${GU}s" > "$LED.tmp"; mv "$LED.tmp" "$LED"
    echo "PARADA: bloque $A$K ${dt}s > ${GU}s"; exit 4
  fi
  echo "completed $(date -Is) segundos=$dt" > "$LED.tmp"; mv "$LED.tmp" "$LED"
  echo "OK bloque $A$K ${dt}s (${PASOS} pasos)"
}
evalu() { # CK NOMBRE
  timeout -k 2 10 ./mz d1gru -mode genpairs -in "$1" -corpus dst3b_dev.txt -n 16 -temp 0 > ciclo_replay/gendev_$2.txt 2>/dev/null
  timeout -k 2 10 ./mz d1gru -mode genpairs -in "$1" -corpus dst3b_train.txt -n 16 -temp 0 > ciclo_replay/gentrain_$2.txt 2>/dev/null
  echo "== $2 dev24: $(python3 ciclo3b_score.py dst3b_dev.txt ciclo_replay/gendev_$2.txt | tr -d '\n ')"
  echo "== $2 train96: $(python3 ciclo3b_score.py dst3b_train.txt ciclo_replay/gentrain_$2.txt | tr -d '\n ')"
}
evalu ciclo1_etapa0.json base
# R: 2x480 sobre master_mix con seq_R
cp ciclo1_etapa0.json ciclo_replay/ck_R0.json
bloque R 1 480 replay/master_mix.txt replay/man_mix.txt replay/seq_R.txt ciclo_replay/ck_R0.json ciclo_replay/ck_R1.json "-master-prev $PREV" 24.2 26 24.2
evalu ciclo_replay/ck_R1.json R1
bloque R 2 480 replay/master_mix.txt replay/man_mix.txt replay/seq_R.txt ciclo_replay/ck_R1.json ciclo_replay/ck_R2.json "" 24.2 26 24.2
evalu ciclo_replay/ck_R2.json R2
# E: 239+241 sobre dst3b_train con seq_E (misma exposicion DST mismo orden)
cp ciclo1_etapa0.json ciclo_replay/ck_E0.json
bloque E 1 239 dst3b_train.txt replay/man_train.txt replay/seq_E.txt ciclo_replay/ck_E0.json ciclo_replay/ck_E1.json "-master-prev $PREV" 5 7 5
evalu ciclo_replay/ck_E1.json E1
bloque E 2 241 dst3b_train.txt replay/man_train.txt replay/seq_E.txt ciclo_replay/ck_E1.json ciclo_replay/ck_E2.json "" 5 7 5
evalu ciclo_replay/ck_E2.json E2
# retencion (primario): bpb heldout100
for CK in ciclo1_etapa0 ciclo_replay/ck_R2 ciclo_replay/ck_E2; do
  N=$(basename $CK)
  timeout -k 2 10 ./mz d1gru -mode scorepairs -in $CK.json -corpus ciclo1_heldout100.txt 2>/dev/null | awk -v n=$N '$1=="SCORE"{s+=$3;c++} END{printf "retencion %s bpb=%.6f (%d pares)\n", n, s/c, c}'
done
echo "WALL TOTAL: $((SECONDS-TSTART))s (tope 90s)"
