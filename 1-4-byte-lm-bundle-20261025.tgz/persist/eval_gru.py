import subprocess, re

MZ = "/tmp/blm/mz"; MODEL = "/tmp/blm/blm_gru1.json"
PROMPTS = ["Que es un agujero negro?","Cual es la capital de Francia?","Que es la amistad?",
 "Como se hace una tortilla de patatas?","Que es AlphaZero?","Hola, como estas?",
 "Cuentame un chiste.","Que tiempo hace hoy?","Quien eres?","Explicame que es un bucle while."]

def gen(prompt, seed=42, temp=0.8):
    r = subprocess.run([MZ,"d1gru","-mode","gen","-in",MODEL,"-prompt","U: "+prompt+"\nA:",
                        "-n","280","-temp",str(temp),"-seed",str(seed)],
                       capture_output=True, text=True, timeout=120)
    return r.stdout.strip()

def words(t): return set(w for w in re.findall(r"[a-záéíóúñ]{4,}", t.lower()))
STOP = {"para","como","pero","esto","esta","este","sobre","porque","cuando","donde","tiene","tener","hacer","puede","entre","desde","hasta","tambien","ahora","solo","cada","muy","mas","los","las","una","unos","unas","que","con","del","por","son","ser","hay","sin","sus","les","fue","han","era","ese","esa","eso","asi","aqui","todo","toda","otro","otra","bien","sido","debe","forma","parte","caso","cosa","cosas","vez","veces","algo","nada","siempre","nunca","hace","mismo","misma","tanto","cuanto","cual","cuales","quien","quienes"}
def relevance(q,a):
    qw = words(q)-STOP
    return len(qw & words(a))/len(qw) if qw else 0.0

a = gen(PROMPTS[0]); b = gen(PROMPTS[0])
print("determinismo misma pregunta+seed:", "identicas" if a==b else "DISTINTAS(!!)")
outs=[]
for p in PROMPTS:
    o = gen(p); outs.append(o)
    print(f"\nU: {p}\nA: {o[:200]}")
print(f"\nrespuestas distintas: {len(set(outs))}/10")
rels=[relevance(p,o) for p,o in zip(PROMPTS,outs)]
print("relevancia(solape,debil):", " ".join(f"{r:.2f}" for r in rels), "media=%.3f"%(sum(rels)/len(rels)))
ok_utf=0
for o in outs:
    try: o.encode('latin1').decode('utf-8'); ok_utf+=1
    except: pass
