# CICLO-1 v2 — ERRATA DE ETIQUETAS + RECONCILIACION DE PROMPTS (2026-10-25 11:43)
No se retoca NADA archivado (crudo, muestras, capturas, bundle18). Solo se corrige la
interpretacion y se documenta.

## Errata 1: etiqueta "bpb_val=" en cabeceras gen2
La cabecera que imprime el binario ("[gru 2400 pasos, bpb_val=3.0496, DEC2 cebado
corregido]") muestra el campo bpb guardado EN EL CHECKPOINT, que para etapa0/e4/u4 es la
bpb medida sobre sub500 = TRAIN, NO sobre val. Toda aparicion de "bpb_val" en salidas
gen2 de este experimento debe leerse como "bpb_sub500_train". La captura TUI
tui_ciclo1_gen.png queda con esa errata de etiqueta: NO es una metrica de validacion.
Metricas nunca entrenadas correctas: heldout100 E=3.2114 U=3.1847; error100 E=3.3328
U=3.7003 (con la circularidad declarada de error100).

## Reconciliacion 2: procedencia de los 10 prompts de generacion
- Fuente: val.txt = val_estricto del protocolo (sha256 3fb6435fcd4d…).
- Regla fijada: primeras 10 lineas 'U: ' de val.txt en orden de val (fijado pre-run;
  ciclo1_gen_prompts.txt sha256 821949eab56a…).
- Verificado por contenido (grep exacto): los 10/10 prompts PERTENECEN a
  ciclo1_heldout100.txt (sha256 65e3897d160f…; primeros 100 de val por orden).
  Es decir: prompts_gen10 = heldout100[1..10]. Como heldout100 NUNCA entra en ningun
  corpus, los prompts de generacion son NUNCA entrenados. Declarado: no son un corte
  independiente de val, son un subconjunto del heldout.
- Contaminacion con train: 0/10 prompts aparecen en ciclo1_sub500.txt
  (sha256 c8ee772eb1d2…; master train fijo). Solape heldout100 vs sub500: 0 pares.
- Conclusion: generacion evaluada sobre prompts nunca entrenados; la seleccion de
  prompts no uso perdidas (orden de fichero fijo). Sin descontaminacion pendiente.
