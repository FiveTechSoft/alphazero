# FASE 2 — PROTOCOLO EJECUTABLE v3 (NO LANZADO; listo para autorizacion de piloto). 2026-10-25 11:51.
# Controlador de optimizacion META. NO es RSI demostrado: pocos intentos = PILOTO.

## 1. Datos, roles CERRADOS (congelados)
- TRAIN = ciclo1_sub500.txt (sha c8ee772eb1d2…): entrenar + seleccionar practica. Nunca validacion.
- error100 (sha 7b46d7df9d3b…): diagnostico circular declarado. Ni seleccion ni validacion.
- DEV100 = ciclo1_heldout100.txt (sha 65e3897d160f…): META-validacion de desarrollo
  (selector theta + rollback). NO es evaluacion independiente. Declarado: contiene
  94 claves unicas en 100 pares (val.txt es redundante).
- FINAL100 v3 = ciclo1_final100.txt (sha cec57930278c…d6f4): EXAMEN FINAL. INACCESIBLE
  al selector/rollback (guarda en codigo + test; sha congelado en meta2FinalSHA).
- Funcion de contaminacion CONGELADA (la metrica ya usada): clave(U) = primeros 40
  chars de los tokens [a-z0-9]+ del U en minusculas, unidos con espacio. strip solo
  no bastaba (acentos/puntuacion): corregido. Construccion FINAL100: orden de val.txt,
  excluye por clave: duplicados internos (7), recurrencias en DEV (113), colisiones
  con sub500 (2), con TRAIN TOTAL train.txt (2) y con gen_prompts (0) → 100 pares,
  verificado: ∩dev=0, ∩sub500=0, ∩trainTOTAL=0, ∩gen10=0. Misma pregunta con otra
  respuesta = contaminacion (clave solo del U). PROXY declarado: prefijo-40 alfanum;
  parafrasis con otra redaccion no se detectan; no se afirma "virgen" mas alla de
  esta funcion y de que la base elegida (ver §2) solo entreno sub500.

## 2. Base y brazos a IGUAL PRESUPUESTO (estructural, en codigo)
- BASE elegible: ciclo1_etapa0.json (linea DESDE CERO, solo ha visto sub500).
  EXCLUIDOS gru2b y cualquier modelo antiguo (entrenaron ~6973 pares de train.txt:
  fuga declarada, no se usan).
- 4 brazos x 3 evals = 12 (EvalsPorBrazo=3 en codigo; test de igualdad estructural).
  Cada eval: clonacion EXACTA byte a byte del MISMO checkpoint base (pesos+Adam+RNG,
  sha verificado; prohibido reset accidental) + scoring features + 1 bloque 480p.
- Brazo META (regla congelada exacta): e1 theta=(1,0,0,0); e2 = clip(e1+N4(0,0.5))
  seed 5001; e3 = clip(mejor_dev(e1,e2)+N4(0,0.5)) seed 5002; desempate: la MAS
  TEMPRANA. Seeds contabilizadas.
- Brazo RANDOM (control que aisla aprendizaje de exploracion): e_k uniforme en caja
  [-2,2]^4, seeds 6001..6003, independientes.
- Brazo UNIFORME: theta=0, replicaciones con semillas de entrenamiento 7001..7003
  (estiman varianza, no seleccionan).
- Brazo TOPLOSS-EXTERNO: controlador CICLO-1 (top-100 loss x5), replicaciones
  8001..8003. top-loss NO es punto exacto de la familia (medido: 72/100 con
  theta=[2,0,0,0]); va EXTERNO, declarado.
- Ganador por brazo: argmin DEV100; desempate: mas temprana.

## 3. Features (sin consultar FINAL100)
loss = bpb del par bajo el modelo actual (pool TRAIN), z-score con media/std del
pool registradas en manifiesto; novedad = 1/(1+veces seleccionado); recencia =
ciclos desde ultima seleccion normalizada; longitud = bytes respuesta, z-score.

## 4. Cierre: UNA evaluacion terminal bloqueada
Al final se puntua EL MISMO FINAL100 sobre 5 checkpoints (BASE + ganador de cada
brazo) EN UN UNICO EVENTO BLOQUEADO que cierra el experimento. Sin feedback despues.
La diferencia en DEV100 es senal de seleccion, NUNCA se reporta como resultado.
Criterio F2 (congelado, metrica correcta = FINAL100):
- F2-C1: META_ganador supera en FINAL100 a RANDOM, UNIFORME y TOPLOSS por >=0.05
  cada uno, Y no empeora a BASE en >0.05. Si no: negativo declarado.

## 5. Coste total (medido preflight, sin entrenar)
- Scoring: 1.43 s/100 pares (medido 11:50, checkpoint archivado); pool 500 ~= 8 s
  (medido CICLO-1); bloque 480p = 34 s (medido CICLO-1).
- 12 evals x (8+34) = 504 s; 13 dev scorings = 18.6 s; terminal 5x1.43 = 7.2 s;
  generacion final + TUI ~30 s. TOTAL ~= 560 s <= tope 600 s. CONGELADO: si el
  preflight real del primer bloque difiere >10%, se reparte de nuevo (3->2 evals
  por brazo, igualdad mantenida) y se informa antes de lanzar; nunca se escala
  en silencio.

## 6. Implementacion y fixtures (listas; CERO entrenamiento incurrido)
meta2.go: Features/Theta+caja/selecciona/clonaExacto(sha)/rollbackElige(desempate
temprana)/guardaFinal/presupuesto/plan congelado/metaTheta/randomTheta.
Fixtures 9/9 PASS: particiones cerradas (archivos reales, funcion de contaminacion
congelada), clonacion byte-exacta, seleccion determinista + caja, brecha
top-loss/familia (72/100), rollback + desempate, FINAL inaccesible, guarda de
presupuesto, igualdad estructural de brazos, reglas META/RANDOM congeladas.
Suite completa con regresiones anteriores: 20/20 + 2 nuevas = pendiente recuento
final en arranque (13 + 9 meta2 = 22 tests).
