#!/bin/bash
echo "== ESCALERA-L fase 0 (archivado) =="
echo "504 pares repite/invierte L4, 3 exposiciones c/u (3024 steps), base etapa0, replay 50/50."
echo "train exact por bloque: 0,0,1,0,0,1 /504; 0 exactos NO es 'no ajusta':"
echo "pos_ok train 0.11 vs control 0.045 (ajuste parcial); bpb_val_resp 3.76->2.91."
echo "PRIMARIO heldL48: 0/48 (convencion >=16 no alcanzada); heldLong48 0/48."
echo "HELD pos_ok 0.042 vs control 0.108: transferencia NO observada bajo este protocolo."
echo "Natural bpb 3.80->3.38 sin deterioro medido; wall 86s; RSS max 24MiB; 0 fallos."
echo "Cambios no aislados (L, gen-n 12, operandos): descriptivo, sin causalidad. Ni habla ni RSI."
