# ESCALERA-L fase 0 — Resultados (2026-10-25)

Protocolo: ESCALERAL_PROTOCOLO_v1.md (v1.2, SHAs completos). Autorización main 14:22 (3 exposiciones TOTAL, 3024 steps = 6×504, tope 300s wall, 35s/bloque, RSS<900MiB, CPU local, main/champion intactos, FINAL-2 cerrado, sin adopción). INFORME DESCRIPTIVO (cambio real no aislado: longitud + gen -n 12 + conjunto de operandos distinto a dst4..6).

## Ejecución
- Base: etapa0 sha256 51dcbe4b6e3832c840332f0ebe29c9b93def23a99ab4deb29354c2e3b9cb1e19 (steps=480). NO desde C6.
- 6 bloques × 504 steps, seq_comp7 (sha 07e29a3e...e36df), cursor 0→3024 verificado EN CALIENTE por bloque (steps==480+504k, seq_pos==504k, seq_sha completo, adam.t==steps, adam m/v presentes): PASS los 6 bloques.
- Wall total: 86s (15s + 71s), bajo el tope 300s. Duración por bloque 12-13s (< 35s). RSSMAX ≤ 24 MiB (< 900 MiB). Ledgers: 6/6 completed. Cero fallos; ninguna parada activada.
- Cadena final post-hoc: ck_E6 steps=3504, seq_pos=3024, seq_sha 07e29a3e..., adam.t=3504.

## Resultados (oráculo dst6_score.py, tabla congelada ampliada dst7; gen -n 12, temp 0)
| bloque | train504 | heldL48 (PRIMARIO) | heldLong48 | bpb natural heldout100 |
|---|---|---|---|---|
| E1 | 0/504 | 0/48 | 0/48 | 3.7965 |
| E2 | 0/504 | 0/48 | 0/48 | 3.6093 |
| E3 | 1/504 | 0/48 | 0/48 | 3.5148 |
| E4 | 0/504 | 0/48 | 0/48 | 3.4561 |
| E5 | 0/504 | 0/48 | 0/48 | 3.4268 |
| E6 | 1/504 | 0/48 | 0/48 | 3.3751 |

- PRIMARIO final E6 heldL48 = 0/48. Convención predeclarada >= 16 NO alcanzada: señal negativa bajo esta convención (no "prueba" de imposibilidad).
- Natural: bpb mejora 3.80 → 3.38 durante el run; no se observa deterioro medido.
- bpb_val_resp (heldL48 respuestas): 3.76 → 2.91; gap de condicionamiento 0.06 → 1.90 (crece: el modelo usa el prompt, sin acertar el target).

## Cercanía (cercania6.py, control permutado por (op,longitud), semilla 20261025, descriptivo)
- TRAIN504 E6: pos_ok real 0.1105 vs ctrl 0.0453; prefijo 0.1071 vs 0.0298; lev_norm 0.8512 vs 0.9353 → por encima del control en pares ENTRENADOS (ajuste parcial), pero exacto ~0/504 (1/504 por oráculo en E3/E6).
- HELDL48 E6: pos_ok real 0.0417 vs ctrl 0.1083; lev 0.8705 vs 0.9222 → NO por encima del control en no-expuestos.
- Cortes por op y longitud sin diferencias que cambien la lectura.

## Lectura (descriptiva, sin causalidad)
Con 3 exposiciones por par (3024 steps), el ajuste a los 504 pares entrenados es parcial (métricas de posición/prefijo por encima del control permutado) pero sin aciertos exactos salvo 1/504 puntual, y la transferencia a operandos no expuestos de la MISMA longitud (L4) es 0/48, igual que a longitudes mayores (0/48). Patrón consistente con los 4 experimentos previos (dst4/dst5/dst6): la señal de transferencia no aparece bajo ninguno de los protocolos probados. La longitud L4 por sí sola no cambió el resultado; NO se puede afirmar que la longitud fuera la barrera (cambian también gen-n y el conjunto de operandos).

## Artefactos
ciclo_esc/ck_E0..E6.json, ledger_S7C1..6, gentrain/genheldL/genheldG_E1..E6.txt, run_b1.log, run_b2_6.log; protocolo v1.2; scorer dst6_score.py (tabla ampliada); cercania6.py.
