# Análisis gap_condicionamiento ESCALERA-L (2026-10-25) — DESCRIPTIVO, sobre logs/gens existentes, sin nuevas sondas

## 1. Definición exacta (fuente: blmgru_main.go L196-209 + blmgru.go pairLoss L935-956)
- bpb_val_resp = media sobre los 48 pares heldL de pairLoss(prompt_verdadero, respuesta): pérdida teacher-forced (prefijo GOLD) de los bytes de la respuesta, en bits/byte. Cobertura: bytes 2..N de la respuesta + '\n' (pairLoss legada EXCLUYE el primer byte de la respuesta; el prompt se alimenta byte a byte sin puntuar).
- bpb_val_resp_pregunta_barajada = mismas 48 respuestas, cada una con el prompt de OTRO par del mismo conjunto val elegido por permutación aleatoria fija (semilla = seed del run + 22 = 29, determinista y declarada).
- gap = barajada − real, bits/byte. Mismo clon (el checkpoint del bloque), mismos targets, misma cobertura en ambos brazos; la permutación conserva la distribución de ops/longitudes del conjunto.
- AMBOS brazos son teacher-forced. El gap NO mide decodificación greedy.

## 2. Qué significa el crecimiento 0.06 → 1.90
El modelo usa el prompt verdadero para reducir la pérdida teacher-forced de los bytes 2+ de la respuesta. Es señal medida real de condicionamiento a nivel de loss. NO contradice "no alcanzó exactitud en este run" (1/504 train, 0/48 held): miden cosas distintas (loss con prefijo gold vs producción autoregresiva exacta).

## 3. Separación teacher-forced vs greedy (mismo clon, mismos targets, gens ya archivadas)
- Teacher-forced: gap 1.90 bits/byte en E6 (arriba).
- Greedy autoregresivo (genpairs temp 0, -n 12): exacto 0/48 held, 1/504 train en E6.

## 4. Localización del primer error (gens existentes vs referencia)
- TRAIN504 E6: diverge en el byte 1 en 383/504 (76.0%); diverge después en 120/504 (posición del 1er error: mediana 1, min 1, max 3 — es decir, byte 2-3); exacto 1/504.
- HELDL48 E6: diverge en byte 1 en 38/48 (79.2%); después en 10/48 (1er error: mediana 1, max 2); exacto 0/48.
- HELDLONG48 E6: byte 1 en 42/48 (87.5%); después en 6/48; exacto 0/48.
- Longitudes de salida: 502/504 producen 4 bytes en train (48/48 en heldL): la longitud L4 sí se reproduce; el contenido no.

## 5. Lectura (hipótesis etiquetadas, no hechos)
- El fallo greedy es INMEDIATO (byte 1-2 de respuestas de 4 bytes), no deriva acumulada por cadenas largas: la exposure-bias clásica (errores que crecen con la longitud del decode) NO es el patrón observado aquí.
- Matiz de cobertura: el gap excluye por construcción el byte 1 de la respuesta, que es exactamente donde el decode greedy falla más (hipótesis compatible: el condicionamiento medido ayuda a los bytes 2+ dado prefijo gold, pero el modelo no produce el byte 1 correcto desde su propio estado). Comprobarlo exigiría una métrica de primer byte (pairLossFull existe en el binario) = sonda NUEVA no aprobada; NO ejecutada.
- Nada de esto permite concluir ausencia de arquitectura inductiva; solo sitúa el fallo observable de este run.
