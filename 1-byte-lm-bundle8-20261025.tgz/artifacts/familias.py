import re,sys
pref=sys.argv[1]  # ej rep8
asig={}
lines=open(pref+'_train.txt').read().strip().split('\n')
for i in range(0,len(lines),2):
    m=re.match(r'U: (codigo|color) de (\w+)\?', lines[i])
    a=re.match(r'A: el (codigo|color) de (\w+) es ([\w]+)\.', lines[i+1])
    if m and a: asig.setdefault(m.group(2),{})[m.group(1)]=a.group(3)
T={'p3':('sabes el codigo de %s?','me dices el color de %s?'),
   'p4':('que codigo tiene %s?','de que color es %s?'),
   'p5':('podrias decirme el codigo de %s?','podrias decirme el color de %s?'),
   'p7':('tienes el codigo de %s?','conoces el color de %s?')}
for fam,(qc,qcol) in T.items():
    with open('%s_%s.txt'%(pref,fam),'w') as f:
        for o,d in asig.items():
            f.write('U: '+qc%o+'\nA: el codigo de %s es %s.\n'%(o,d['codigo']))
            f.write('U: '+qcol%o+'\nA: el color de %s es %s.\n'%(o,d['color']))
print('familias p3/p4/p5/p7 escritas para',pref,'(',len(asig),'entidades )')
