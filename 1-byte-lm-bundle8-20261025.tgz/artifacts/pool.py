import subprocess, random, sys
# pool.py <familia_file> <modelo_base> <seedpool> -> escribe <fam>_from<tag>_poolA.txt (filtrado) y reporta cobertura
fam=sys.argv[1]; base=sys.argv[2]; tag=sys.argv[3]; seed0=int(sys.argv[4])
random.seed(seed0)
lines=open(fam).read().strip().split('\n')
pairs=[(lines[i][3:],lines[i+1][3:]) for i in range(0,len(lines),2)]
pool=[]
for q,a in pairs:
    for s in range(1,9):
        r=subprocess.run(['/tmp/blm/mz','d1gru','-mode','gen','-in',base,
            '-prompt','U: '+q+'\nA: ','-n','60','-temp','1.0','-seed',str(seed0+s)],
            capture_output=True,text=True,timeout=30)
        out=r.stdout.strip(); pool.append((q,a,out,out==a))
hits=[p for p in pool if p[3]]
cov=len(set(q for q,_,_,ok in pool if ok))
outf='%s_poolA_%s.txt'%(fam.replace('.txt',''),tag)
with open(outf,'w') as f:
    for q,a,out,_ in hits: f.write('U: '+q+'\nA: '+out+'\n')
with open(outf.replace('poolA','poolFULL'),'w') as f:
    for q,a,out,_ in pool: f.write('U: '+q+'\nA: '+out+'\n')
print('%s desde %s: ok=%d/%d cobertura=%d/%d -> %s'%(fam,base,len(hits),len(pool),cov,len(pairs),outf))
