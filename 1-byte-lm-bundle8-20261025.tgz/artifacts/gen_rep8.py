import random, sys
# Tarea sintetica composicional: N entidades, cada una con codigo y color.
# Train: frase P1. Held-out: parafrasis P2 (mismas entidades) + entidades NUEVAS (combinaciones nuevas).
# Contrastivo: misma plantilla, entidad distinta -> controla que usa la entidad, no la plantilla.
N = int(sys.argv[1]); seed = int(sys.argv[2])
rng = random.Random(seed)
objs = rng.sample(["lapiz","mesa","silla","libro","casa","arbol","coche","reloj","puerta","ventana",
 "gato","perro","flor","nube","rio","monte","playa","bosque","calle","plaza",
 "tren","avion","barco","llave","carta","mapa","foto","radio","tele","lampara",
 "copa","plato","tenedor","cuchillo","vaso","botella","caja","bolsa","saco","tubo",
 "cable","motor","rueda","freno","farol","puente","torre","muro","techo","suelo"], N)
colores = ["rojo","azul","verde","blanco","negro","gris","rosa","marron","celeste","dorado"]
asig = {}
for o in objs:
    asig[o] = (rng.randint(100,999), rng.choice(colores))
train, held = [], []
for o,(c,col) in asig.items():
    # P1 train
    train.append(f"U: codigo de {o}?\nA: el codigo de {o} es {c}.")
    train.append(f"U: color de {o}?\nA: el color de {o} es {col}.")
    # P2 held-out (parafrasis)
    held.append(f"U: cual es el codigo de {o}?\nA: el codigo de {o} es {c}.")
    held.append(f"U: dime el color de {o}\nA: el color de {o} es {col}.")
open(f"/tmp/blm/rep8_train.txt","w").write("\n".join(train)+"\n")
open(f"/tmp/blm/rep8_held.txt","w").write("\n".join(held)+"\n")
print(f"{len(train)} train, {len(held)} held, {N} entidades")
