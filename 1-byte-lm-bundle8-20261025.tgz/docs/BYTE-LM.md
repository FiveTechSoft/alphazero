# BYTE-LM (rama exp/byte-lm) — protocolo congelado v1 (2026-10-25)

Modulo EXPERIMENTAL de lenguaje byte a byte. NO es AlphaZero ni mejora del
motor matematico. Rama separada; main e integracion v3 publicada intactas.

## Naturaleza honesta
- Entrenamiento SUPERVISADO sobre corpus de dialogo. NO es RSI ni automejora:
  los cambios de arquitectura/pasos los elegimos nosotros.
- El contexto de K bytes (16 o 32) es una limitacion dura: el modelo no ve
  la conversacion completa, solo los ultimos K bytes. No seguir hilos largos
  es esperable; no se presentara completado de texto como conversacion.
- BPB (bits por byte) mide ajuste estadistico, NO calidad conversacional.
  Mejor BPB no implica conversar mejor; la evidencia visible desde la TUI
  real de OpenCode es el criterio funcional.

## Corpus y licencia
- OpenAssistant oasst2: https://huggingface.co/datasets/OpenAssistant/oasst2
  Licencia Apache-2.0 (ficha del dataset, verificada 2026-10-25).
- Subconjunto lang=es, pares prompter->assistant, review_result!=False,
  no borrados, no sinteticos, longitudes 10..300 (U) y 20..600 (A).
- OpenSubtitles/OPUS DESCARTADO: terminos de licencia ambiguos para corpus
  derivado/redistribucion.
- Particion POR HILO (raiz de la conversacion, no por par; evita fuga de la
  misma conversacion entre particiones), FNV-1a(raiz) mod 10:
  0=test, 1=val, resto=train. Reproducible.
  train 6973 pares (2595324 B) / val 846 (314763 B) / test 678 (249230 B).
  8497 pares, 3348 hilos raiz.

## Prompts de evaluacion congelados (no vistos: ausentes verbatim de train
por grep -F; los temas pueden existir en el corpus)
1. Que es un agujero negro?
2. Cual es la capital de Francia?
3. Que es la amistad?
4. Como se hace una tortilla de patatas?
5. Que es AlphaZero?
6. Hola, como estas?
7. Cuentame un chiste.
8. Que tiempo hace hoy?
9. Quien eres?
10. Explicame que es un bucle while.

## Criterios congelados de conservar / rollback
- val = seleccion de candidato; test = se informa UNA vez por candidato
  seleccionado, no se optimiza reiteradamente.
- Conservar candidato solo si: (a) BPB val mejora respecto al candidato
  anterior, Y (b) las muestras visibles desde la TUI real mejoran a juicio
  humano (main/Anto), Y (c) no hay regresion: ruta matematica intacta y
  comportamiento publicado sin -blm byte-identico.
- Memorizacion: se reporta longest-common-substring y solape de 8-gramas
  de palabras contra train por generacion. grep-ausencia NO es prueba de
  no memorizacion (metrica debil, solo descontaminacion de prompts).
- Si la conversacion no mejora con presupuesto razonable, se reporta el
  limite y se PARA el escalado; no series cada vez mayores.

## Ciclo M1 (completado 2026-10-25) — medido
- Modelo: byte-MLP K=16, D=32, H=128 (~106k params), Adam propio, seed fija.
- 12000 pasos (~2 min CPU): BPB train 2.79, heldout 2.67 (piso unigram 4.65,
  azar 8.0). Split antiguo por PAR (M1; reemplazado por split por hilo).
- Resultado: aprende estadistica del espanol; NO conversa. Capturas TUI
  reales antes (0 pasos: bytes aleatorios) / despues (12000: pseudo-espanol).




## Ciclo G2/G2b + control positivo (2026-10-25) — aprendizaje por pares, ablacion medida
- G2: entrenamiento por PARES U->A (estado cebado con la pregunta, perdida SOLO
  en la respuesta: alineacion train/inferencia; secuencia cap 512B conservando
  la pregunta entera, se trunca la respuesta si excede). GRU 43k, 6000 pasos,
  4m56s, RSS 23 MiB. Metrica de seleccion: bpb_val_resp (respuesta dada
  pregunta verdadera) = 2.7821.
- Ablacion de condicionamiento (instrumento): misma respuesta, pregunta
  barajada, 300 pares val. G1 (ventanas): gap = -0.0000. G2: gap = 0.0018.
  G2b (+6000 pasos reanudados, 12000 totales verificados): bpb_val_resp=2.6686,
  gap = 0.0007. Sin intervalos de confianza: se reporta como "sin senal
  convincente de condicionamiento en estos ensayos", NO como inexistencia
  probada. Capacidad/pasos como cuello es HIPOTESIS; persistencia de estado,
  truncado, calidad de pares y optimizacion siguen abiertos.
- CONTROL POSITIVO (diagnostico etiquetado, NO exito conversacional): 4 pares
  sinteticos (codigo alfa/beta, color cielo/mar), 3000 pasos: bpb_resp=0.0007,
  barajada=0.9302, gap=0.9295 -> la ruta de aprendizaje condicional y el
  instrumento (gap) FUNCIONAN mecanicamente. Generacion TUI real: "color del
  cielo?" -> "el cielo es azul." exacto (captura blm_tui_posctl.png); en CLI
  2/4 exactos y confusiones documentadas (alfa/beta, temp 0.5).
- Desalineaciones encontradas y corregidas: d1serve usaba "A:" sin espacio
  (entrenamiento con "A: "); checkpoint G2b etiquetaba 6000 sin acumular la
  reanudacion (corregido a 12000, reanudacion verificada por log).

### Desalineacion "A:"/"A: " y re-evaluacion (2026-10-25, sin reentrenar)
- El entrenamiento por pares usa el marcador "A: " (con espacio); la generacion
  CLI y d1serve usaban "A:" (sin espacio) hasta la correccion de este ciclo.
- Muestras PRE-correccion (no alineadas): G1 7/10 distintas, relevancia 0.000;
  C4c 10/10 distintas (MLP, con su propia salvedad: su entrenamiento
  condicionado NO incluia el marcador "A:" en el contexto).
- Muestras POST-correccion (alineadas, mismos checkpoints, sin reentrenar):
  G1 2/10 distintas (atractor aun mas fuerte), relevancia 0.000; G2b 8/10
  distintas, relevancia 0.000. Las perdidas/condgap NO se vieron afectadas
  (pairLoss ya usaba "A: "). Conclusion general (sin conversacion) no cambia;
  los numeros de diversidad de muestras si, y quedan etiquetados por version.
- Capturas TUI reales: blm_tui_g2b.png (negativo, 12000 pasos),
  blm_tui_posctl.png (control positivo, 3000 pasos, memorizacion etiquetada).


### Barrido intermedio sintetico (2026-10-25, UNA semilla, SIN intervalos — no generalizar)
- Tarea: N entidades con codigo (100-999) y color; train frase P1, held-out
  parafrasis P2 (mismas entidades). Control contrastivo: misma plantilla,
  entidad distinta. GRU 43k, 6000 pasos cada punto, lr 0.003, seed 11.
- N=8: gap=0.4549; P1 codigo 8/8 color 8/8; P2 codigo 6/8 color 1/8.
- N=16: gap=0.2824; P1 10/16 y 11/16; P2 3/16 y 0/16.
- N=32: gap=0.9045 (NO monotono vs N=16 — ruido de una semilla); P1 9/32 y
  14/32; P2 5/32 y 8/32.
- N=50: gap=-0.0014; P1 3/50 y 12/50; P2 0/50 y 0/50.
- Lectura acotada: la senal de condicionamiento existe con pocos pares y se
  degrada al crecer N; la generalizacion a parafrasis es debil en todos los
  puntos (mejor 6/8 codigos con N=8). NO separa capacidad de optimizacion:
  falta multi-semilla, intervalos y control de pasos/H. Punto de ruptura
  util como banco de pruebas barato (~35 s por punto).

## Ciclo G1 (2026-10-25) — byte-GRU pequeno, medido, NEGATIVO en conversacion
- Por que: cerrado el escalado MLP, se prueba arquitectura con ESTADO recurrente
  (la pregunta vive en h, sin ventana que la expulse). Cambio de arquitectura,
  no escalado ciego.
- Guardias ANTES de cargar: gradient check por diferencias finitas, 36 muestras
  no cero, 9 familias, T=64 pasos por las 3 puertas. Primer intento FALLO con
  factor constante 44.36 = T*ln2 (backward en nats vs perdida en bits media):
  bug real, corregido (dlogits /(T*ln2)) y re-verificado: peor err_rel 5.5e-04
  (criterio <1e-3), err_abs ~1e-10. Coste medido: 10.76 ms/paso (ventana 64B,
  H=64 D=32, 43.456 params), RSS pico 17-20 MiB bajo guard.sh.
- Entrenamiento acotado: 12000 pasos, 1m59s, ventanas T=64 sobre train (split
  por hilo). bpb_val=2.7250 (300 ventanas fijas de 64B, estado inicial cero;
  no comparable al milimetro con layouts de ventana deslizante ni condicionado).
- Generacion (estado cebado con TODOS los bytes del prompt; seed=42, temp=0.8):
  determinismo byte-identico; 7/10 respuestas distintas — 4 preguntas caen en
  el MISMO atraccion verbatim ("2. 1. En pancial..."), es decir el estado
  olvida la pregunta a los pocos bytes: evidencia de retencion insuficiente.
  Relevancia (solape, debil) = 0.000 en las 10.
- Conclusion: GRU 43k aprende estadistica (bpb baja de 8.0 a ~2.7) pero NO
  conversa; tampoco retiene la pregunta operativamente. Negativo honesto con
  captura TUI real (blm_tui_gru.png, OpenCode 1.19.4, etiqueta "inferencia
  entrenada", sha256 checkpoint 69d25f8520322722).
- d1serve: nuevo flag -blmgru (checkpoint GRU, preferente sobre -blm), carga
  verificada por curl.

## Ciclo C4c (2026-10-25) — condicionamiento explicito, medido, NEGATIVO en conversacion
- Motivacion: la hipotesis "K16 borra la pregunta" NO se vende como causal sin
  ablacion; se implementa condicionamiento EXPLICITO en vez de K64 como
  "persistencia" (K64 tambien desliza la pregunta fuera con suficientes bytes).
- Implementacion (blm.go generateCond / ctxCond, blm_main.go modo train-pairs):
  contexto = 32B cola FIJA de la pregunta (TRUNCAMIENTO: preguntas >32B pierden
  su inicio; NO es persistencia completa del enunciado) + 32B cola reciente de
  la generacion. Entrenamiento por pares U/A con el MISMO layout. d1serve elige
  generateCond automaticamente cuando el checkpoint tiene K=64.
- Recursos: 12000 pasos, 4m19s, guard.sh (400s/900MiB; RSS pico 37 MiB).
- Metricas: bpb_corpus_cond 3.2149, bpb_val_cond 3.3310. NO comparables con el
  layout de ventana pura (C3 2.6731): la regla del controlador por bpb NO es
  aplicable entre layouts; no se ejecuto keep/rollback. champion.json sigue=C3.
- Evidencia entre preguntas (seed=42, temp=0.8, 280B, 10 prompts congelados):
  10/10 respuestas distintas = DEPENDENCIA DEL INPUT (trivialmente cierta al
  incluir la pregunta en el contexto; NO prueba uso semantico ni causa aislada,
  y en d1serve la seed deriva del hash del texto). Determinismo: misma
  pregunta+seed -> salida byte-identica.
- Relevancia (solape de palabras, indicador DEBIL): 0.000 en las 10. No prueba
  relevancia "nula" universal; solo que no hay solape lexico.
- Conclusion: condicionamiento persistente real pero INSUFICIENTE a esta
  escala: la hipotesis K16 queda refutada como explicacion suficiente.
- ESCALADO MLP CERRADO (M1/C2/C3/C4c sin conversacion). El OBJETIVO sigue
  abierto: siguiente via pequena fundada = recurrente/atencion con prueba
  minima de coste/gradientes antes de cualquier entrenamiento mayor. Cambiar
  arquitectura no es escalado ciego; no entrenar grande por inercia.
- Coste: las cifras de minutos son mediciones puntuales en esta maquina
  (estimaciones), no benchmarks.

## Ciclos C2/C3 (2026-10-25) — medidos, decision del controlador
- Split por HILO activo (train 6973 / val 846 / test 678). Protocolo v1.
- C1r campeon base: K16/D32/H128, 12000 pasos: val 2.7473.
- C2 (K32/D32/H192, 12500 pasos): val 2.9437 -> ROLLBACK (peor).
- C3 (C1r+12k, 24000 pasos): val 2.6731 -> CONSERVAR (regla fija: BPB val
  mejora Y relevancia no peor Y UTF-8 ok). TEST informado una vez: 2.5917
  (train 2.4963). Sin señal de sobreajuste.
- COHERENCIA: relevancia (solape palabras contenido) = 0.0 en C1r/C2/C3.
  Mejora estadistica SI; coherencia conversacional NO. Indicadores
  limitados: solape no verifica semantica; LCS<=16B/8gram 0.0 no prueban
  no-memorizacion. Temperatura 0.8 constante en comparaciones.
- Controlador: controller.py + controller_log.jsonl (decisiones ROLLBACK C2,
  CONSERVAR C3). Controlador programado != modelo que aprende; rollback
  automatico != automejora conseguida.
- Conclusion: MLP de contexto corto no alcanza coherencia ligada a la
  pregunta. No escalar a ciegas; proxima decision de enfoque con evidencia.

## Notas de regimen (2026-10-25, correcciones main)
- El test de C3 (2.5917) YA ESTA USADO: no es test intacto para selecciones
  posteriores. Proximas selecciones usan val; para nuevo test final se
  creara particion fresca o se rotara, declarado.
- Sin afirmar ausencia garantizada de sobreajuste por 3 BPBs.
- Sin extrapolar una muestra a "relevancia semantica cero universal": el
  indicador de solape es limitado y solo describe estas 10 preguntas.
- Coherencia futura: evaluacion independiente (no solape de palabras),
  muestras no preseleccionadas, criterio externo fijo.
- Decision del controlador EFECTIVA en OpenCode: d1serve -blmauto
  champion.json sirve el modelo que el controlador conserva; la TUI muestra
  los pasos del campeon vigente (metadata separada del contenido).
- Persistencia compacta: bundle unico + manifiesto sha256 (ver /tmp/blm/persist).

## Ciclo ReST-EM microdominio (2026-10-25, 07:44-07:52 CET)

Arquitectura UNICA de todo el ciclo y del barrido: GRU a nivel byte, d=32, H=96, T=64, softmax 256.
Conteo real de parametros: E 256x32=8192; Wz/Wr/Wn 3x(96x128)=36864; Bz/Br/Bn 288; Wo 256x96=24576; Bo 256. TOTAL=70.176 params.
NO comparar con otras escalas (ni MLP previo ni modelos ajenos) como factor unico; ninguna comparacion 43k aplica aqui.

Protocolo (recompensa verificable, control igualado, separado del bootstrap):
- Base: blm_gru_sweep8.json (6000 pasos, solo frase P1, dataset semilla 7).
- Cobertura primero: P1 saturada (95%) -> conjunto de trabajo P3 (parafrasis nunca entrenada; cobertura 53-62%, 10/16 preguntas). Filtro real, no vacio.
- Brazo A: 74 candidatos auto-generados FILTRADOS por recompensa binaria (match exacto codigo/color) + 32 replay P1.
- Brazo B (control): 74 candidatos del MISMO pool SIN filtrar (58% correctos) + 32 replay P1.
- Computo: pool compartido (128 gens ~2s); scoring solo en A (128 comparaciones, <1ms; es el factor manipulado: etiquetas de recompensa); entrenamiento 2000 pasos/13s ambos. El filtrado cambia la distribucion: es la intervencion, declarada.

Resultados (match exacto, temp 0.3 semilla 1, P1/P3/P2; base=16/10/7):
  A post: 16/16/7 (inicial), reps 16/14/8, 16/16/2, 16/11/7
  B post: 8/5/2   (inicial), reps 15/10/2, 14/9/7,  9/6/5

Lectura acotada (NO causal universal; n=3 reps, dataset semilla unica, 16 preguntas):
- Compatible con ventaja del filtro en P3 EN ESTA MUESTRA (A>B en 3/3 reps).
- Brazo B degrada pre->post en esta muestra (P1 16->9-15; P3 10->6-10): autoentrenarse sin filtrar refuerza errores propios.
- Sin mejora demostrada sobre baseline P2 con mismo decoding (base 7/16; A 7/8/2/7; B 2/2/7/5). P2 apartada del entrenamiento del ciclo, NO test virgen (ya evaluada en el barrido).
- Replay necesario SOLO probado en este setup (sin replay P1 cae a 10-11/16 en ambos brazos).
- Esto es microdominio con recompensa EXTERNA binaria y plantillas de atributos: NO conversacion, NO RSI, NO promesa de criterio conversacional.

Evidencia TUI (OpenCode 1.19.4, capturas directas):
- blm_tui_ra_base_p3.png: base 6000 pasos, "sabes el codigo de ventana?" -> "el codigo de casa es 346." (fallo)
- blm_tui_ra_a2_p3.png: A2 8000 pasos, misma pregunta -> "el codigo de ventana es 159." (correcto)
- blm_tui_ra_a2_p2fallo.png: A2 8000 pasos, "cual es el codigo de coche?" (P2) -> "el codigo de libro es 528." (fallo de transferencia)

Artefactos: /tmp/blm/{restem_A,restem_B,restem_A2,restem_B2,ra*,rb*,ra2_*,rb2_*}.txt, blm_gru_{restemA2,restemB2,rA1..3,rB1..3}.json, logs restem_*/tra*/trb*, evals eval3.py/evalreps.py/restem_gen3.py/restem_rep.py/dump_q.py.

## Experimento bootstrap multifrase (2026-10-25, 07:52-07:57 CET)

Pregunta: diversidad de superficie en bootstrap, ¿induce transferencia a frase apartada? Mismo presupuesto exacto: GRU d32/H96/T64 (70.176 params), 6000 pasos, semilla 11, dataset semilla 7.
- Baseline: corpus P1 (32 lineas) -> P1 16/16, P3 10/16, P2 7/16 (match exacto, temp 0.3 semilla 1).
- Multifrase: corpus P1+P3 (64 lineas) -> P1 15/16, P3 15/16, P2 11/16. gap_condicionamiento 0.3999.
Lectura acotada: P2 mejora 7->11/16 con mismo computo EN ESTA MUESTRA (1 semilla entrenamiento, 16 preguntas, sin intervalos). Senal direccional compatible con que la diversidad de superficie ayuda a transferir; no concluyente, requiere reps. NO conversacion; plantillas de atributos.
Evidencia TUI (OpenCode 1.19.4): blm_tui_mf_base_fallo.png (baseline P1-only, "dime el color de motor" -> "el color de vaso es rosa." FALLO; decodificacion servidor TUI difiere de CLI, fallo en ambas), blm_tui_mf_p1p3_ok.png (multifrase, misma pregunta -> "el color de motor es rosa." CORRECTO), blm_tui_mf_p1p3_fallo.png (multifrase, "cual es el codigo de ventana?" -> "el codigo de vaso es 664." FALLO remanente, 5/16 P2 siguen fallando).
Artefactos: /tmp/blm/sweep8_p1p3.txt, p1p3_train.log, blm_gru_p1p3.json.
Nota historica: mensajes de commit antiguos etiquetaban el GRU como "43k"; el conteo real es 70.176 params (ver seccion ciclo ReST-EM). Rectificado.

## ReST-EM iterado + reps multifrase + test final P6 (2026-10-25, 07:58-08:07 CET)

Cambio de protocolo: decodificacion CANONICA unificada TUI=CLI (temp 0.3, semilla FNV-1a de la pregunta, n=280; d1serve actualizado de 0.8 a 0.3). Las tablas anteriores (temp 0.3 semilla fija 1) quedan sustituidas.

Reps pareadas multifrase (6000 pasos ambos brazos, 36-39s, corpus 791B vs 1750B = la intervencion):
  s11: P2 8->11 | s21: 9->5 | s31: 7->15 | s41: 14->13 (P1-solo -> P1+P3)
  Media P2: 9.5 -> 11.0. INESTABLE entre semillas: la mejora multifrase no se sostiene; solo es estable dominar la familia entrenada (trivial).

ReST-EM iterado (base=multifrase s11; R1=P4, R2=P5; brazo A filtrado por recompensa exacta, brazo B sin filtrar del pool de su propia trayectoria; replay P1+P3; 2000 pasos/ronda, 13-14s; coberturas: P4 5/16 (23 pares), P5 A1 14/16 B1 14/16):
  pre/post (canon): P4 base 4 -> A1 7 / B1 2; P5 base 11 -> A2 16 / B2 13; P1/P3 sin regresion en ambos brazos (replay).
  TEST FINAL P6 (familia NUEVA predefinida y congelada antes de las rondas, evaluada UNA vez):
  base 11/16, A2-filtrado 14/16, B2-sinfiltrar 16/16.
  => Ambos brazos mejoran sobre base; el control SIN filtrar SUPERA al filtrado en el test fresco. La ventaja del filtro vista en el ciclo anterior sobre familias repetidamente observadas NO replica en test virgen: era ruido/seleccion. Limite demostrado EN ESTAS PRUEBAS: a esta escala (70.176 params, 8 entidades, n=16), ni el filtrado por recompensa ni la diversidad de superficie producen transferencia fiable a familias nuevas; la varianza entre semillas domina. No es una afirmacion universal.
Evidencia TUI (canon): blm_tui_it_a2_p6.png (A2 10000 pasos, "me podrias decir el color de vaso?" -> "el color de mapa es rojo." FALLO) y blm_tui_it_b2_p6.png (B2 10000 pasos, misma -> "el color de vaso es rosa." CORRECTO): la inversion filtro<control visible en TUI real.
Artefactos: ceval.py, iter{4,5}_*, blm_gru_{p1,p1p3}_s{21,31,41}.json, blm_gru_it{A1,A2,B1,B2}.json, sweep8_p{4,5,6_FINAL_TEST}.txt, logs mf_*/iter*_.

## Replicacion acotada del ciclo (dataset semilla 8, test P7 congelado) (2026-10-25, 08:09-08:13 CET)

Decision predeclarada que informa: ¿el filtrado por recompensa aporta sobre autoentrenamiento sin filtrar (mismo computo, replay incluido) en test fresco? Regla: filtro gana solo si vence en 2/2 datasets independientes; si no, adoptar sin-filtrar+replay o cerrar la linea a esta escala. Presupuesto: UNA replicacion.

Protocolo identico al ciclo 1: bootstrap P1+P3 6000 pasos (semilla 11, dataset semilla 8, entidades y asignaciones NUEVAS), R1=P4 (cobertura 5/16, filtro 27 pares), R2=P5 (pools 96%/95%: filtro casi vacuo esta vez, declarado), 2000 pasos/ronda, replay, brazo B desde su propia trayectoria en R2. Test final P7 ("tienes el codigo de X?"/"conoces el color de X?") congelado antes de las rondas, evaluado UNA vez. Decoding canon (temp 0.3, FNV-1a, n=280).

Resultados:
  Familias trabajadas: P4 base 4 -> A1 8 / B1 4; P5 ya saturada en base (16/16). No-regresion: brazo A mantiene 16/16 P1/P3; B2 DEGRADA a 13/16 P1/P3/P5 (a pesar del replay).
  TEST FINAL P7: base 8/16, A2-filtrado 8/16, B2-sinfiltrar 12/16.

Lectura cruzada (2 datasets independientes, tests frescos predefinidos, una evaluacion):
  Ciclo 1 (semilla 7, P6): base 11, A2 14, B2 16 -> B > A > base
  Ciclo 2 (semilla 8, P7): base 8,  A2 8,  B2 12 -> B > A = base
  => El filtro NO vence en 2/2 (0/2). DECISION adoptada: a esta escala el filtrado por recompensa no aporta sobre sin-filtrar+replay en test fresco; se cierra la linea filtro-vs-sin-filtro en el microdominio de 8 entidades. B2 gano el test fresco en ambos ciclos pero regreso en familias entrenadas en ciclo 2: patron inconsistente, n=2, sin afirmacion universal. La transferencia a familias nuevas quedo cerca del ruido de base en ambos ciclos para el brazo filtrado.
Evidencia TUI (canon): blm_tui_rep8_a2_p7.png (A2, "tienes el codigo de rio?" -> "el color de rio es celeste." FALLO por confusion de atributo) y blm_tui_rep8_b2_p7.png (B2, misma -> "el codigo de rio es 353." CORRECTO).
Artefactos: gen_rep8.py, familias.py, pool.py, rep8_*.txt, blm_gru_rep8_*.json, rep8_*.log.
