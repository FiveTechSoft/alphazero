#!/bin/bash
# COPIA-ALGORITMICA v2 (autorizado por main 14:12): clon BASE etapa0, replay 50/50
# (504 dst6 + 504 nat), 6 bloques x 504 = 3024, seq_comp6 sha16 07e29a3e3c8ef87c.
# Tope 300s wall; guarda bloque >35s; proyeccion +40>300 PARA; primer fallo PARA;
# sin retries; RSS<900MiB medido. Gen -n 24 fijado. Eval 6 bloques sin corte;
# primario = C6 heldL48 (convencion >=16/<=4). Oraculo dst6_score.py (hash+semantica v2).
set -e; cd /tmp/blm
PREV=c8ee772eb1d2dfe4c2ea8ffc38d991f07750309d449eff53f82d63af3476b355
TSTART=$SECONDS
mkdir -p ciclo_alg
runmz() {
  local tag=$1; shift
  python3 - "$tag" "$@" <<'PYEOF'
import subprocess, resource, sys
tag, args = sys.argv[1], sys.argv[2:]
r = subprocess.run(["./mz"]+args)
kb = resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
print(f"RSSMAX {tag} {kb} KiB")
sys.exit(r.returncode)
PYEOF
}
bloque() { # K CKIN CKOUT PREVFLAG
  local K=$1 IN=$2 OUT=$3 PF=$4
  local INSHA; INSHA=$(sha256sum "$IN" | cut -c1-12)
  local KEY="S6C${K}_${INSHA}"; local LED="ciclo_alg/ledger_$KEY"
  if [ -e "$LED" ]; then
    local ST; ST=$(cut -d' ' -f1 "$LED")
    [ "$ST" = completed ] && { echo "LEDGER $KEY ya completada"; return 0; }
    echo "LEDGER $KEY estado=$ST: recuperacion manual; NO reejecuta"; exit 3
  fi
  local el=$((SECONDS-TSTART))
  if [ $((el+40)) -gt 300 ]; then echo "PARADA proyeccion ${el}s+40 > 300s"; exit 5; fi
  echo "running $(date -Is)" > "$LED.tmp"; mv "$LED.tmp" "$LED"
  trap 'if [ -n "${LED:-}" ]; then echo "failed $(date -Is)" > "$LED.tmp"; mv "$LED.tmp" "$LED"; fi' ERR
  local t0=$SECONDS
  runmz A$K d1gru -mode train-pairs -corpus replay/master_mix6.txt -val dst6_heldL48.txt \
    -in "$IN" -out "$OUT" -steps 504 -lr 0.003 -seed 7 \
    -master replay/master_mix6.txt -manifest replay/man_mix6.txt -seq replay/seq_comp6.txt $PF 2>&1 | grep -E 'FIN|RECHAZO|seq predefinida|RSSMAX'
  local dt=$((SECONDS-t0))
  if [ $dt -gt 35 ]; then
    echo "failed $(date -Is) GUARDA bloque ${dt}s > 35s" > "$LED.tmp"; mv "$LED.tmp" "$LED"
    echo "PARADA: bloque A$K ${dt}s > 35s"; exit 4
  fi
  echo "completed $(date -Is) segundos=$dt" > "$LED.tmp"; mv "$LED.tmp" "$LED"
  echo "OK bloque A$K ${dt}s"
}
evalu() { # CK NOMBRE
  timeout -k 2 20 ./mz d1gru -mode genpairs -in "$1" -corpus dst6_train504.txt -n 24 -temp 0 > ciclo_alg/gentrain_$2.txt 2>/dev/null
  timeout -k 2 20 ./mz d1gru -mode genpairs -in "$1" -corpus dst6_heldL48.txt -n 24 -temp 0 > ciclo_alg/genheldL_$2.txt 2>/dev/null
  timeout -k 2 20 ./mz d1gru -mode genpairs -in "$1" -corpus dst6_heldLong48.txt -n 24 -temp 0 > ciclo_alg/genheldG_$2.txt 2>/dev/null
  timeout -k 2 20 ./mz d1gru -mode genpairs -in "$1" -corpus dst6_nw16_24.txt -n 24 -temp 0 > ciclo_alg/gennw_$2.txt 2>/dev/null
  local TT; TT=$(python3 dst6_score.py dst6_train504.txt ciclo_alg/gentrain_$2.txt | python3 -c "import json,sys;print(json.load(sys.stdin)['exact_total'])")
  local HL; HL=$(python3 dst6_score.py dst6_heldL48.txt ciclo_alg/genheldL_$2.txt | python3 -c "import json,sys;print(json.load(sys.stdin)['exact_total'])")
  local HG; HG=$(python3 dst6_score.py dst6_heldLong48.txt ciclo_alg/genheldG_$2.txt | python3 -c "import json,sys;print(json.load(sys.stdin)['exact_total'])")
  local NW; NW=$(python3 dst6_score.py dst6_nw16_24.txt ciclo_alg/gennw_$2.txt | python3 -c "import json,sys;print(json.load(sys.stdin)['exact_total'])")
  local RT; RT=$(timeout -k 2 10 ./mz d1gru -mode scorepairs -in "$1" -corpus ciclo1_heldout100.txt 2>/dev/null | awk '$1=="SCORE"{s+=$3;c++} END{printf "%.6f", s/c}')
  echo "== $2 train504=$TT heldL48=$HL heldLong48=$HG nw16=$NW bpb_heldout=$RT"
}
cp ciclo1_etapa0.json ciclo_alg/ck_A0.json
for K in 1 2 3 4 5 6; do
  P=$((K-1)); PF=""; [ $K = 1 ] && PF="-master-prev $PREV"
  bloque $K ciclo_alg/ck_A${P}.json ciclo_alg/ck_A${K}.json "$PF"
  evalu ciclo_alg/ck_A${K}.json A$K
done
echo "WALL COPIAALG: $((SECONDS-TSTART))s (tope 300s)"
