# COPIA-ALGORÍTMICA v2 — Resultados (2026-10-25)

Ejecutado según COPIAALG_PROTOCOLO_v2.md + adendo v2.1 (autorizado 14:12). Diagnóstico; no producto ni RSI. Verificación pre-run PASS: seq 3024 (cada índice 3× total, 1×/ciclo), manifest identidad 1008, master 504 dst6 únicos + 504 nat (sub500 + 4 primeros repetidos, declarado).

## Incidente declarado (sin reentrenar, sin alterar historial)
La primera pasada entrenó A1 (13s) y PARÓ en la evaluación: dst6_score.py tenía un bug de parseo (patrón con prefijo ya recortado; misma clase de error que cercania v1). Los tests unitarios previos eran VACÍOS en el camino feliz (no pasaban por la CLI del scorer; el negativo "pasaba" por la razón equivocada). Corregido y verificado por CLI: positivo manual 6/6, rechazo por semántica, rechazo por sha fuera de tabla. A1 NO se reentrenó (ledger completed); la evaluación se reanudó sobre el checkpoint archivado. Entrenamiento: una sola vez por bloque. Este es el tercer fallo de oráculo/parseo de la fase; queda auditado.

## Resultados (exact match, oráculo dst6 v2 con verificación hash+semántica)

| bloque | train504 | heldL48 (primario) | heldLong48 | nw16_24 | bpb heldout natural |
|---|---|---|---|---|---|
| A1 | 0/504 | 0/48 | 0/48 | 0/24 | 3.6690 |
| A2 | 0/504 | 0/48 | 0/48 | 0/24 | 3.5283 |
| A3 | 0/504 | 0/48 | 0/48 | 0/24 | 3.4277 |
| A4 | 0/504 | 0/48 | 0/48 | 0/24 | 3.3506 |
| A5 | 0/504 | 0/48 | 0/48 | 0/24 | 3.3280 |
| A6 (primario) | 0/504 | 0/48 | 0/48 | 0/24 | 3.2651 |

## CERCANIA v1.1 (offline, control permutado por (op,longitud), semilla 20261025, descriptivo)
- train504 A6: lev 0.851 vs 0.935 ctrl; pos_ok 0.110 vs 0.045; prefijo 0.107 vs 0.030. Señal PEQUEÑA de acercamiento a los targets propios (no exacto en ninguno). largo_ok BAJA con los bloques: 47/504 (A1) → 30/504 (A6).
- heldL48 A6: lev 0.871 vs 0.922; pos_ok 0.042 vs 0.108 (real PEOR); prefijo 0.021 vs 0.083 (real peor). largo_ok 3/48.
- heldLong48 A6: lev 0.862 vs 0.907; largo_ok 0/48. nw16_24 A6: lev 0.867 vs 0.885; largo_ok 0/24.
- Distribución de longitudes de salida (A6, train): concentrada en 6-10 chars (mediana 7-8) con operandos de 8-13; el modelo no reproduce la longitud del operando. Desglose por op y longitud en ciclo_alg/cercania6.txt.

## Ejecución y guardas
6/6 ledgers completed (A1 vía recuperación declarada); bloques 12-14s (guarda 35s); wall 78s (tope 300s; la proyección del benchmark fue conservadora: 13s/bloque medido vs 30s estimado, los pasos naturales son más baratos); RSS máx 26,0 MiB; 0 retries de training; main/champion intactos; FINAL-2 no tocado; sin adopción.

## Lectura (criterio predeclarado: ≥16/48 sí / ≤4 no; convención, cuentas exactas)
- Primario A6 heldL48 = 0/48 → NO se mide transferencia a operandos no expuestos ni siquiera a longitud entrenada.
- Con operandos únicos y 3 exposiciones, el ajuste exacto de train también es 0/504: el régimen que memorizaba pares repetidos (dst4/5: 25/84, 45/84) no produce aquí ni memorización exacta ni comportamiento de copia; solo una deriva pequeña de cercanía en train (lev 0.85 vs 0.94 control) y salidas tipo texto de 6-10 chars.
- bpb heldout natural 3.669→3.265: sin deterioro medido (mejora descriptiva continuada del replay).
- NO se concluye "imposible copiar" en general: una base, una semilla, 3024 pasos, este tamaño de modelo. Solo cuentas.
