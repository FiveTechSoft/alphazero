# REPLAY PROTOCOLO v2 (propuesta, SIN entrenamiento autorizado aun)
# Estabilidad: UNA intervencion (intercalar train natural) sobre CICLO-3b
# SINGLETONS. Control de base de estabilidad; NO mecanismo RSI, NO habla.

## 1. Pregunta y diseno (corregido tras NOTRAIN v1)
Pregunta: intercalar datos naturales reduce el olvido medido al anadir DST?
- R = 960 pasos (2 bloques x 480) sobre master_mix 192 pares (96 DST + 96
  naturales sub500 file-order), secuencia PREDEFINIDA seq_R congelada
  (480 slots DST + 480 naturales, cada par exactamente 5x, shuffle seed
  20261025, sha en replay_meta).
- E = SOLO DST, 480 pasos (2 bloques: 239 y 241) con seq_E = la subsecuencia
  DST de seq_R EN EL MISMO ORDEN: recibe EXACTAMENTE los mismos ejemplos DST.
  Control IGUAL EXPOSICIONES DST, NO igual compute (updates 960 vs 480,
  declarado). R vs E aisla intercalar natural vs no hacerlo, desde estados
  base identicos. D (3b, archivado) es CONTEXTO, no aislamiento.
- v1 descartado: relleno con respuestas falsas puede causar dano activo por
  contradiccion (no es dilucion neutral).
- Paridad predefinida ANTES de resultados: lr 0.003, seed 7, base comun
  (clon etapa0 Adam/RNG fiel, curriculo declarado -master-prev), mismas
  evaluaciones.

## 2. Mecanica: -seq (nuevo, fixture PASS)
Flag -seq <fichero>: indice por paso predefinido; NO consume el RNG del
sampler (corriente RNG identica entre brazos; verificado en fixture:
estados sampler iguales con seq distintas, avance historico sin seq).
Sin bypass de persistencia: todo pasa por master+manifiesto verificados y
checkpoint con Adam/RNG reales. El manifest identidad de cada corpus sigue
verificando expansion byte a byte.

## 3. Criterio falsable predeterminado (medido en ESTA poblacion natural)
- Primario: dano_X = bpb_heldout100(X_final) - bpb_heldout100(base).
  Si dano_E - dano_R >= 0.5: efecto del intercalado natural MEDIDO en esta
  poblacion y escala. Si < 0.5: "sin efecto material detectado a esta
  escala" — NO equivalencia, NO causa identificada (retirada la lectura
  "R~=E => dilucion" de v1).
- Secundario (tradeoff, sin adopcion): exact train96/dev24 por bloque y por
  op en R y E (greedy gen2, oraculo offline); bpb_val dev.
- Nada se adopta pase lo que pase. Ni habla ni RSI.

## 4. Fixtures (8/8 PASS, replay_check.py)
mix 96+96 file-order; seq_R 960 pasos 480/480 con 5x por par; seq_E =
subsecuencia DST mismo orden; rangos validos; paridad por bloque (E_k =
slots DST de R_k, tamanos 239/241 declarados); naturales replay 0 colisiones
proxy vs heldout100/final100 viejo/FINAL-2 (conjuntos REALES); naturales =
subconjunto declarado sub500 train; mix sin colisiones internas.
ERRATA relacionada: los chequeos de colisiones de dst_check/dst3b_check
apuntaban a rutas inexistentes con guarda silenciosa (fixture vacuo). Ya
corregidos a conjuntos reales (4057 claves) y re-verificados: 0 colisiones
reales en los 7 ficheros DST. Affects bundles 22/23 (declarado ahi tambien
como nota pendiente; las CONCLUSIONES se mantienen tras re-verificacion).

## 5. Coste (fundado en mediciones, estimacion declarada)
- Medido: bloque 480p natural (371B mediana) = 43s; bloque 480p DST (43B) =
  1-2s (6 bloques 3b). Mixto 50/50 estimado ~22s/bloque (interpolacion
  declarada, NO medido). R = 2x22s ~= 44s; E = 2x~1s. Evals: genpairs
  train96+dev24 x5 ck (~1s c/u) + scoring + retencion x3 ~= 15s.
  ESTIMACION TOTAL ~62s wall. TOPE declarado: 90s wall.
- Reglas congeladas: bloque R > 24.2s (est+10%) = PARAR Y REPORTAR; bloque
  E > 5s = PARAR; proyeccion antes de cada bloque (elapsed+est_siguiente >
  90) = PARAR; primer fallo = PARAR; sin retries. CPU~=wall es estimacion.
- N=2 bloques (no 3): el primario es retencion a 960 pasos; la trayectoria
  de produccion queda secundaria con 2 puntos. Presupuesto realista, sin
  proyeccion contradictoria con el tope.

## 6. Encaje
Piso de estabilidad para cualquier ciclo de mejora por medicion: anadir sin
destruir, medido. No aplaza la etapa conversacional: cuantifica un cuello
(+4.7 bpb) que esa etapa tambien sufriria.
