#!/bin/bash
# Fixture extremo a extremo de reanudacion seq por tramos (binario real):
# F1: 6+6 con -in == 12 continuo (mismo ck final byte a byte)
# F2: tramo2 loguea cursor=6 y no repite (cubierto por F1 byte-identico)
# F3: seq distinta al reanudar => RECHAZO
set -u
D=$(mktemp -d); MZ=/tmp/blm/mz
for i in 0 1 2 3 4 5 6 7; do printf 'U: q%d\nA: r%d\n' $i $i; done > $D/c.txt
cp $D/c.txt $D/v.txt
printf '0\n1\n2\n3\n4\n5\n6\n7\n0\n1\n2\n3\n' > $D/seq12.txt
printf '7\n6\n5\n4\n3\n2\n1\n0\n7\n6\n5\n4\n' > $D/seq12b.txt
run() { $MZ d1gru -mode train-pairs -corpus $D/c.txt -val $D/v.txt -d 4 -hh 8 -steps $1 -seq $2 ${3:+-in $3} -out $4 2>$5; }
run 12 $D/seq12.txt "" $D/cont.json $D/log_cont
run 6 $D/seq12.txt "" $D/t1.json $D/log_t1 || { echo 'FALLO tramo1'; exit 1; }
run 6 $D/seq12.txt $D/t1.json $D/t2.json $D/log_t2 || { echo 'FALLO tramo2'; exit 1; }
grep -q 'cursor inicio=6' $D/log_t2 && echo 'PASS cursor tramo2 = 6' || { echo 'FALLO cursor log'; cat $D/log_t2; exit 1; }
[ "$(sha256sum < $D/cont.json)" = "$(sha256sum < $D/t2.json)" ] && echo 'PASS 6+6 == 12 continuo (byte-identico)' || { echo 'FALLO: tramos divergen'; exit 1; }
run 6 $D/seq12b.txt $D/t1.json $D/t3.json $D/log_t3 2>/dev/null && { echo 'FALLO: seq distinta no rechazada'; exit 1; }
grep -q 'RECHAZO seq' $D/log_t3 && echo 'PASS seq distinta rechazada al reanudar' || { echo 'FALLO motivo rechazo'; cat $D/log_t3; exit 1; }
rm -rf $D
echo 'FIXTURE TRAMOS 3/3 PASS'
