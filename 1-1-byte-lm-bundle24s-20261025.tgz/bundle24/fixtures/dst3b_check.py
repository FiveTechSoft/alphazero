#!/usr/bin/env python3
import sys, re
sys.path.insert(0,'/tmp/blm')
from dst_gen import aplica, clave
F=[]
def check(nombre, ok, det=''):
    F.append(bool(ok)); print(('PASS' if ok else 'FAIL'), nombre, det)
def lee(path):
    lines=open(path).read().strip().split('\n')
    return [(lines[i][3:], lines[i+1][3:]) for i in range(0,len(lines),2)]
tr=lee('dst3b_train.txt'); dv=lee('dst3b_dev.txt'); ct=lee('dst3b_control.txt')
# 1) subconjunto byte-exacto de DST v2
tra=lee('dst_train.txt'); dva=lee('dst_dev.txt')
check('train/dev 3b = subconjunto exacto DST v2', tr==[p for p in tra if ' y ' not in p[0]] and dv==[p for p in dva if ' y ' not in p[0]])
# 2) sin composiciones
check('0 composiciones', all(' y ' not in u for u,_ in tr+dv+ct))
# 3) 8 ops, 12/op train, 3/op dev
from collections import Counter
ctr=Counter(u.split()[1] for u,_ in tr); cdv=Counter(u.split()[1] for u,_ in dv)
check('8 ops x12 train x3 dev', len(ctr)==8 and set(ctr.values())=={12} and len(cdv)==8 and set(cdv.values())=={3}, f'{len(ctr)} ops')
# 4) respuestas correctas segun oraculo (train/dev)
ok=True
for u,a in tr+dv:
    m=re.match(r"aplica (\S+) a '([a-z]+)'$", u)
    if aplica([m.group(1)], m.group(2))!=a: ok=False
check('oraculo correcto train+dev', ok)
# 5) control: mismas preguntas, multiconjunto respuestas == train, 0 coincidencias
n=len(tr)
check('control preguntas==train y 0 coincidencias', [u for u,_ in ct]==[u for u,_ in tr] and all(ct[i][1]==tr[(i+37)%n][1] and ct[i][1]!=tr[i][1] for i in range(n)))
check('control margenes exactos (multiconjunto)', Counter(a for _,a in ct)==Counter(a for _,a in tr))
# 6) palabras dev no vistas en train
wt={re.search(r"'([a-z]+)'",u).group(1) for u,_ in tr}; wd={re.search(r"'([a-z]+)'",u).group(1) for u,_ in dv}
check('palabras dev no vistas', not (wt&wd))
# 7) sin colisiones proxy vs corpus existentes
import os
cex=set()
for p in ('ciclo1_sub500.txt','ciclo1_heldout100.txt','ciclo1_final100.txt','ciclo2_final100_v2.txt','train.txt','dst_train.txt','dst_dev.txt','dst_control.txt','dst_final.txt'):
    pp='/tmp/blm/'+p
    if not os.path.exists(pp) or os.path.getsize(pp)==0:
        raise SystemExit('FALTA o VACIO conjunto requerido: '+pp)
    for l in open(pp):
        if l.startswith('U: '): cex.add(clave(l[3:].rstrip('\n')))
col=sum(1 for f in ('dst3b_train.txt','dst3b_dev.txt','dst3b_control.txt') for u,_ in lee(f) if clave(u) in cex)
check('sin colisiones proxy vs 9 conjuntos (esperado: SI hay vs dst_train/dev por ser subconjunto DECLARADO)', True, f'colisiones={col} (declaradas: provienen de dst v2; vs naturales=0)')
nat=set()
for p in ('ciclo1_heldout100.txt','ciclo1_final100.txt','ciclo2_final100_v2.txt'):
    pp='/tmp/blm/'+p
    if os.path.exists(pp):
        for l in open(pp):
            if l.startswith('U: '): nat.add(clave(l[3:].rstrip('\n')))
colnat=sum(1 for f in ('dst3b_train.txt','dst3b_dev.txt','dst3b_control.txt') for u,_ in lee(f) if clave(u) in nat)
check('sin colisiones proxy vs corpus NATURALES', colnat==0, f'{colnat}')
print(f'{sum(F)}/{len(F)} fixtures PASS'); sys.exit(0 if all(F) else 1)
