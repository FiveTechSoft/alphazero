#!/bin/bash
# Fixture negativo: borrar/ocultar una fuente requerida DEBE hacer FAIL cada
# chequeo (nunca verde vacuo). Restaura siempre.
set -u; cd /tmp/blm; rc=0
prueba() { # script archivo_requerido
  mv "$2" "$2.oculto"
  if python3 "$1" >/tmp/neg_out.txt 2>&1; then echo "FALLO: $1 verde sin $2"; rc=1; else
    grep -qE 'FALTA|VACIO|No such file' /tmp/neg_out.txt && echo "PASS $1 rechaza ausencia de $2" || { echo "FALLO: $1 fallo sin mensaje claro"; rc=1; }
  fi
  mv "$2.oculto" "$2"
}
prueba dst_check.py ciclo1_heldout100.txt
prueba dst3b_check.py ciclo1_sub500.txt
prueba replay_check.py ciclo2_final100_v2.txt
# vacio tambien rechazado
cp ciclo1_heldout100.txt /tmp/h100.bak; : > ciclo1_heldout100.txt
python3 dst_check.py >/tmp/neg_out.txt 2>&1 && { echo 'FALLO: vacio aceptado'; rc=1; } || grep -qE 'VACIO' /tmp/neg_out.txt && echo 'PASS dst_check rechaza VACIO' || { echo 'FALLO vacio sin mensaje'; rc=1; }
cp /tmp/h100.bak ciclo1_heldout100.txt
[ $rc -eq 0 ] && echo 'FIXTURE NEGATIVO 4/4 PASS'; exit $rc
