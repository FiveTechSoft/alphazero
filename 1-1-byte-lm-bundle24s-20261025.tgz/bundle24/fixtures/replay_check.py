#!/usr/bin/env python3
# Fixtures REPLAY v2 (8/8 antes de cualquier carga)
import re, sys
sys.path.insert(0,'/tmp/blm')
from dst_gen import clave
F=[]
def check(nombre, ok, det=''):
    F.append(bool(ok)); print(('PASS' if ok else 'FAIL'), nombre, det)
def lee(path):
    lines=open(path).read().strip().split('\n')
    return [(lines[i][3:], lines[i+1][3:]) for i in range(0,len(lines),2)]
mix=lee('replay/master_mix.txt'); dst=lee('dst3b_train.txt'); nat=lee('ciclo1_sub500.txt')[:96]
seqR=[int(l) for l in open('replay/seq_R.txt')]; seqE=[int(l) for l in open('replay/seq_E.txt')]
check('maestro_mix = 96 DST + 96 naturales file-order', mix[:96]==dst and mix[96:]==nat)
from collections import Counter
c=Counter(seqR)
check('seq_R: 960 pasos, 480 DST + 480 nat, cada par 5x', len(seqR)==960 and sum(1 for i in seqR if i<96)==480 and set(c.values())=={5} and len(c)==192)
check('seq_E = subsecuencia DST de seq_R mismo orden', seqE==[i for i in seqR if i<96] and len(seqE)==480)
check('rangos validos', all(0<=i<192 for i in seqR) and all(0<=i<96 for i in seqE))
# bloques alineados: E bloque k = slots DST de R bloque k (tamanos 239/241 declarados)
bR=[seqR[:480],seqR[480:]]
nE=[sum(1 for i in b if i<96) for b in bR]
bE=[seqE[:nE[0]],seqE[nE[0]:]]
check('paridad por bloque (E_k = DST de R_k)', all(bE[k]==[i for i in bR[k] if i<96] for k in (0,1)) and len(bE[1])==nE[1],
      f'E pasos por bloque: {nE} (declarados)')
# naturales replay: 0 colisiones proxy vs dev/heldout/finales
def claves(path):
    s=set()
    for l in open(path):
        if l.startswith('U: '): s.add(clave(l[3:].rstrip('\n')))
    return s
proh=set()
for p in ('ciclo1_heldout100.txt','ciclo1_final100.txt','ciclo2_final100_v2.txt'):
    import os as _os
    if not _os.path.exists(p) or _os.path.getsize(p)==0: raise SystemExit('FALTA o VACIO '+p)
    proh|=claves(p)
col=sum(1 for u,_ in nat if clave(u) in proh)
check('naturales replay: 0 colisiones proxy vs dev/heldout/finales', col==0, f'{col}')
# naturales replay SON subconjunto declarado de sub500 (train natural)
sub=claves('ciclo1_sub500.txt')
check('naturales replay = subconjunto declarado sub500 train', all(clave(u) in sub for u,_ in nat))
# DST no pisa naturales dentro del mix
check('mix sin colisiones internas DST/natural', not {clave(u) for u,_ in dst} & {clave(u) for u,_ in nat})
print(f'{sum(F)}/{len(F)} fixtures PASS'); sys.exit(0 if all(F) else 1)
