# REPLAY v2 — RESULTADOS (medido, 1 seed, sin adopcion)
# Pregunta: intercalar datos naturales reduce el olvido medido al anadir DST?
# R = 960 pasos (2x480) 50% DST + 50% natural (misma secuencia congelada,
# sha seq_R 5c5d8598051623c1). E = 480 pasos SOLO DST (239+241, subsecuencia
# DST de seq_R mismo orden, sha seq_E 164c3f0be1f366ab). Control IGUAL
# EXPOSICIONES DST; updates 960 vs 480 (declarado, no igual compute).
# Base comun: clon etapa0 (Adam/RNG fiel, curriculo declarado). lr 0.003 seed 7.

## Primario (retencion, bpb heldout100 natural, menor = mejor)
- base:   3.861856
- R2:     3.632655   dano_R = -0.229201 (SIN olvido medido; mejora leve)
- E2:     6.321310   dano_E = +2.459454
- dano_E - dano_R = 2.688655 >= 0.5 -> SUPERA el umbral predeclarado:
  efecto del intercalado natural MEDIDO en esta poblacion y escala (1 seed).
  No es equivalencia, no es habla, no es RSI, no promociona nada.
- Contexto (NO aislamiento): D = brazo A de 3b (1440 pasos DST puros sin
  replay) termino en bpb heldout 8.5510. E2 (480 pasos DST) = 6.3213.

## Secundario (produccion, oraculo offline, greedy)
- exact train96 y dev24 = 0 en TODOS los brazos y bloques (base, R1, R2,
  E1, E2). A esta escala de pasos ningun brazo produce; en 3b hicieron
  falta ~1440 pasos DST puros para 15/96 train (0/24 dev).
- bpb_val dev24 por bloque: base -- | R1 3.9626, R2 4.0288 | E1 3.9732,
  E2 3.8585.

## Coste (medido, wall)
- Bloques R: 11s y 12s (guarda 24.2s). Bloques E: 1s y 1s (guarda 5s).
- WALL TOTAL 31s (tope 90s), incluye gens/scoring/retencion. 4 bloques,
  0 fallos, 0 reintentos; ledger exactly-once 4/4 completed.
- Nota coste: el bloque mixto 50/50 midio ~11-12s, por DEBAJO de la
  interpolacion predeclarada de ~22s (estimacion conservadora errada;
  declarado). CPU~=wall es estimacion, no medido.

## Fidelidad de reanudacion seq (verificada)
- Cursor/sha viajan en checkpoint: R1 seq_pos=480 -> R2 arranca cursor=480
  y termina seq_pos=960 (seq agotada exacta). E1 239 -> E2 cursor=239 ->
  seq_pos=480. steps heredados NUNCA posicionan la secuencia.
- Fixture tramos 3/3 PASS: 6+6 pasos reanudado == 12 continuos byte a byte
  (checkpoint final identico); seq distinta al reanudar = RECHAZO.
- RNG sampler: corriente identica entre brazos (sha c439a0d0e5af72cb en
  todos los cortes); con -seq el sampler no avanza (declarado).
- Suite Go completa verde (95s, 0 FAIL) tras los cambios -seq, ANTES de
  entrenar. Fixtures datos: dst 9/9, dst3b 9/9, replay 8/8, negativo 4/4.

## Encaje
Piso de estabilidad medido: intercalar natural evito el olvido EN ESTA
POBLACION (1 seed, 43456 params). No resuelve produccion (0 exact en todas
las condiciones a 480-960 pasos). Nada se adopta.
