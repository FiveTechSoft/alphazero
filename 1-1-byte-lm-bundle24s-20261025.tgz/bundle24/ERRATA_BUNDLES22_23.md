# ERRATA (adendo) — fixtures de colisiones vacuos en bundles 22 y 23
# NO reescribe evidencia; complementa.
En bundle22 (commit 28ed136) y bundle23 (commit 4225e42), el fixture
"sin colisiones proxy" de dst_check.py y dst3b_check.py apuntaba a rutas
piloto/* INEXISTENTES protegidas con una guarda silenciosa (os.path.exists):
el conjunto de referencia quedaba VACIO y el fixture pasaba sin comprobar
nada. La verificacion vacia NO repara el test original: se declara aqui.
Re-verificacion posterior con los conjuntos REALES (ciclo1_sub500.txt,
ciclo1_heldout100.txt, ciclo1_final100.txt, ciclo2_final100_v2.txt,
train.txt; 4057 claves): 0 colisiones reales en los 7 ficheros DST y en los
naturales del replay. Las conclusiones publicadas se mantienen, pero el
fixture verde original no era evidencia.
Reparacion (bundle24): los chequeos RECHAZAN archivo ausente o vacio;
fixture negativo 4/4 PASS (borrar/vaciar fuente requerida => FAIL con
mensaje claro). Conteos y hashes en replay_meta.json y logs.
