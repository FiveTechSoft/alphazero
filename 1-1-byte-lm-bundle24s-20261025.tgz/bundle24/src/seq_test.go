package main

import "testing"

// Fixture -seq: la secuencia predefinida se sigue EXACTAMENTE y NO consume
// el RNG del sampler (paridad de corriente RNG entre brazos).
func TestIndicePasoSeq(t *testing.T) {
	seq := []int{5, 0, 3, 3, 1}
	for s, esp := range seq {
		if got := indicePaso(nil, seq, 0, s, 10); got != esp {
			t.Fatalf("paso %d: %d != %d", s, got, esp)
		}
	}
	// RNG intacto tras pasos con seq: dos brazos con seq distinta terminan
	// con el MISMO estado de sampler
	r1 := &sm64{s: 42}
	r2 := &sm64{s: 42}
	for s := 0; s < 8; s++ {
		indicePaso(r1, seq, 0, s%len(seq), 10)
		indicePaso(r2, []int{9, 9, 9}, 0, s%3, 10)
	}
	if r1.s != r2.s {
		t.Fatalf("RNG sampler diverge con seq: %d vs %d", r1.s, r2.s)
	}
	// sin seq: comportamiento historico (avanza)
	r3 := &sm64{s: 42}
	_ = indicePaso(r3, nil, 0, 0, 10)
	if r3.s == 42 {
		t.Fatal("sin seq el RNG debe avanzar (comportamiento historico)")
	}
}

// Fixture cursor: con seqBase>0 la secuencia REANUDA sin repetir ni
// reiniciar (tramos 480+480 / 239+241 usan el cursor del checkpoint).
func TestIndicePasoCursor(t *testing.T) {
	seq := []int{0, 1, 2, 3, 4, 5, 6, 7}
	// tramo 1: base 0, pasos 0..2 -> 0,1,2
	for s, esp := range []int{0, 1, 2} {
		if got := indicePaso(nil, seq, 0, s, 8); got != esp {
			t.Fatalf("tramo1 paso %d: %d != %d", s, got, esp)
		}
	}
	// tramo 2: base 3, pasos 0..4 -> 3,4,5,6,7 (sin repetir 0..2)
	for s, esp := range []int{3, 4, 5, 6, 7} {
		if got := indicePaso(nil, seq, 3, s, 8); got != esp {
			t.Fatalf("tramo2 paso %d: %d != %d (repeticion o reinicio)", s, got, esp)
		}
	}
}

// Fixture persistencia cursor: SeqSHA/SeqPos sobreviven guardar+cargar.
func TestSeqCursorPersiste(t *testing.T) {
	g := NewGRU(7, 4, 8)
	st := g.newAdam()
	rng := &sm64{s: 28}
	g.pendingSeqSHA = "abc123"
	g.pendingSeqPos = 239
	p := t.TempDir() + "/ck.json"
	if err := g.SaveGRU(p, 239, 1.0, st, rng.s, "corpus", 7, 0.003, "proto"); err != nil {
		t.Fatal(err)
	}
	g2, _, _, err := LoadGRUFull(p)
	if err != nil {
		t.Fatal(err)
	}
	if g2.lastCkpt.SeqSHA != "abc123" || g2.lastCkpt.SeqPos != 239 {
		t.Fatalf("cursor no persistio: %+v", g2.lastCkpt)
	}
	// checkpoint antiguo (sin seq) carga con campos vacios: cursor 0 declarado
	g.pendingSeqSHA = ""
	g.pendingSeqPos = 0
	if err := g.SaveGRU(p, 10, 1.0, st, rng.s, "corpus", 7, 0.003, "proto"); err != nil {
		t.Fatal(err)
	}
	g3, _, _, err := LoadGRUFull(p)
	if err != nil {
		t.Fatal(err)
	}
	if g3.lastCkpt.SeqSHA != "" || g3.lastCkpt.SeqPos != 0 {
		t.Fatalf("checkpoint sin seq debe cargar cursor vacio: %+v", g3.lastCkpt)
	}
}
