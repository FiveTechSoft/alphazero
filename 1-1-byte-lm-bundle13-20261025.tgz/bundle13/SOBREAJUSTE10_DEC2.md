# SOBREAJUSTE-10 / DEC2 — addendum CONGELADO antes de ejecutar (2026-10-25 09:29 CET)

Tras SOBREAJUSTE-10: C1 cumplido (bpb 0.0066 << 0.8), C2 estricto 0/10 con patron
sistematico (pierde primeros bytes y luego continua literal: "stoy bien...", "l valor...").
Evidencia de codigo (solo lectura): generateGRU ceba con todo el prompt y vuelve a
alimentar el ULTIMO byte del prompt antes del primer muestreo; el entrenamiento
(trainSeqMask, lossFrom=len(prompt)-1) puntua el primer byte de respuesta desde el
 estado tras el prompt completo. Sospecha concreta de desajuste de cebado en decoding.

## Addendum (sin entrenamiento nuevo; checkpoint diagnostico YA existente)
- Mismo checkpoint blm_gru_overfit10.json (no se re-entrena nada; servicio intacto).
- Decoding corregido gen2: el primer byte se muestrea del estado tras el prompt completo
  (sin realimentar el ultimo byte). Ruta gen2 SOLO diagnostica; generateGRU del servicio NO se toca.
- Mismas 10 prompts, temp=0.05, seed=7, n=200. Mismos criterios C2 (ratio>=0.8 en >=8/10).
- Lectura declarada: si DEC2 recupera >=8/10, la sospecha de cebado queda confirmada
  experimentalmente en este control y el fallo de generacion se atribuye a decoding,
  no a aprendizaje. Si no, la sospecha se documenta como no confirmada.
