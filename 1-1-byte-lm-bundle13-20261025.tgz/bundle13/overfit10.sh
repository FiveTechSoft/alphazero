#!/bin/bash
# SOBREAJUSTE-10 (protocolo congelado SOBREAJUSTE10_PROTOCOLO.md) - via /blm-overfit10
cd /tmp/blm || exit 1
echo "SOBREAJUSTE10 protocolo: SOBREAJUSTE10_PROTOCOLO.md congelado 09:26"
timeout -k 2 380 ./mz d1gru -mode train-pairs -corpus overfit10_corpus.txt -val overfit10_val.txt -out blm_gru_overfit10.json -steps 3000 -lr 0.003 -seed 7 2>/dev/null | grep '^FIN'
python3 - <<'PY'
import subprocess
pairs=[]
lines=[l.rstrip('\n') for l in open('overfit10_pairs.txt') if l.strip()]
for i in range(0,len(lines)-1,2): pairs.append((lines[i][3:],lines[i+1][3:]))
ok=0
for i,(q,ref) in enumerate(pairs):
    p=subprocess.run(['./mz','d1gru','-mode','gen','-in','blm_gru_overfit10.json','-prompt',f'U: {q}\nA: ','-n','200','-temp','0.05','-seed','7'],capture_output=True,text=True,timeout=60)
    gen=p.stdout.strip()
    n=min(100,len(gen),len(ref)); n=max(n,1)
    ratio=sum(1 for a,b in zip(gen[:n],ref[:n]) if a==b)/n
    ok+= ratio>=0.8
    print(f"REF {i}: {ref[:110]}")
    print(f"GEN {i}: ratio={ratio:.2f} {gen[:110]}")
print(f"C1 ajuste: ver linea FIN (bpb sobre los 10 pares; criterio <0.8)")
print(f"C2 recuperacion: {ok}/10 con ratio>=0.8 (criterio >=8/10)")
PY
echo "FIN_SOBREAJUSTE10"
