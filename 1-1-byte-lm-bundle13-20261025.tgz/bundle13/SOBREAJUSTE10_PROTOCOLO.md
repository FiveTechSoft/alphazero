# SOBREAJUSTE-10 — protocolo CONGELADO antes de ejecutar (2026-10-25 09:26 CET)

Comprobación discriminativa pequeña (autorizada por main 09:25): separar si esta ruta
APRENDE y RECUPERA ejemplos sencillos de si falla al generar. No busca conversación ni
respuestas programadas. Rama/artefacto DIAGNOSTICO separado; nunca promoción; servicio
y champion intactos. Sin cerrar causalidad desde train≈val del modelo grande.

## Setup (todo fijado antes)
- Datos: 10 pares mas cortos de train.txt (criterio: minimizar CPU; indices en
  overfit10_idx.txt: 3563,5484,5408,6970,5908,5576,2793,2074,962,2362; 36-45 bytes/par),
  corpus = esos 10 pares duplicados x20 (overfit10_corpus.txt), val = los mismos 10.
- Modelo: GRU NUEVO desde cero, misma config d=32/H=64/T=64 (43.456 params), seed=7,
  lr=0.003, steps=3000 (preflight MEDIDO: 100 pasos=0.7s -> 3000 pasos ~21s << guardia 420s).
- Artefacto: blm_gru_overfit10.json (diagnostico; NO se sirve, NO se promueve).
- Recuperacion: argmax aproximado temp=0.05, seed=7, n=200, formato "U: q\nA: " (identico al servicio).

## Criterios fijados ANTES de resultados
- C1 ajuste: bpb final sobre los 10 pares < 0.8 (memorizacion en perdida).
- C2 recuperacion: ratio de prefijo exacto vs respuesta entrenada >= 0.8 en >= 8 de 10.
- Lectura declarada de antemano:
  C1 y C2  -> la ruta aprende y recupera: el 0/90 previo es de escala/datos, no de pipeline.
  C1 y noC2 -> baja la perdida pero no recupera al generar: sospecha en decoding/cebado,
               documentada SIN afirmar bug.
  noC1     -> no ajusta ni 10 pares: limite de optimizacion/capacidad de este setup, documentado.

## Capturas: TUI real; texto generado archivado identico; bytes UTF-8 INVALIDOS escapados
## explicitamente como \xNN si aparecen (etiquetado); terminal bajo locale UTF-8.
