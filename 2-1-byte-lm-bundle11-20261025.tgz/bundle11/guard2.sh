#!/bin/bash
# guard2.sh TIMEOUT_SEC RSS_LIMIT_MIB OUTFILE cmd args...
# guard.sh original + TERCERA CAPA: reaper duro desacoplado que aplica SIGKILL al grupo del
# worker a los lim+10s SIEMPRE (cota TOTAL real, aunque el supervisor se atasque o el TERM del
# timeout interno quede diferido por bash con hijo en foreground). Mismo contrato: sidecar
# <out>.status, kill de grupo, residuales contados. Limites heredados: overshoot entre sondeos;
# procesos que crean sesion propia escapan; SIGKILL al supervisor deja solo esta cota total.
lim=$1; rl=$2; out=$3; shift 3
P=${GUARD_PROC:-/proc}
pgid=0
members() { pgrep -g "$pgid" 2>/dev/null; }
killgroup() { [ "$pgid" -gt 0 ] && kill -KILL -- "-$pgid" 2>/dev/null; }
trap 'killgroup; kill -KILL -- -$reaper 2>/dev/null; sleep 0.3; ST="status=SUPERVISOR_SIGNAL residual_procs=$(members | wc -l)"; echo "$ST"; echo "$ST" >> "$out.status"; exit 143' TERM INT HUP
trap 'killgroup; kill -KILL -- -$reaper 2>/dev/null' EXIT
setsid timeout -k 3 $((lim+5)) "$@" > "$out" 2>&1 &
pid=$!; pgid=$pid; start=$(date +%s); pk=0; why=exit; zero=0
# TERCERA CAPA: reaper duro (sesion propia). Seguridad: (a) al disparar VERIFICA IDENTIDAD
# (el lider $pid sigue existiendo y su cmdline contiene el comando original) antes de matar el
# grupo, para no matar un PGID reutilizado; (b) el supervisor lo cancela matando el GRUPO del
# reaper (bash+sleep), no solo el bash; (c) registra su desenlace en $out.reaper.
setsid bash -c '
  sleep '"$((lim+10))"'
  if [ -r /proc/'"$pid"'/cmdline ] && tr "\0" " " < /proc/'"$pid"'/cmdline | grep -qF "'"$*"'"; then
    kill -KILL -- -'"$pgid"' 2>/dev/null
    echo "REAPER fired $(date +%s)" >> "'"$out"'.reaper"
  else
    echo "REAPER skip-identidad $(date +%s)" >> "'"$out"'.reaper"
  fi' &
reaper=$!
while kill -0 $pid 2>/dev/null; do
  tot=0; seen=0
  for p in $(members); do r=$(awk '/VmRSS/{print $2}' "$P/$p/status" 2>/dev/null); if [ -n "$r" ]; then tot=$((tot+r)); seen=1; fi; done
  [ $tot -gt $pk ] && pk=$tot
  if [ $seen -eq 0 ]; then zero=$((zero+1)); else zero=0; fi
  if [ $zero -ge 5 ]; then why=SAMPLER_FAILED; break; fi
  if [ $((tot/1024)) -gt $rl ]; then why=RSS_LIMIT; break; fi
  if [ $(( $(date +%s) - start )) -ge $lim ]; then why=TIMEOUT; break; fi
  sleep 0.1
done
left_before=$(members | wc -l)
killgroup
wait $pid 2>/dev/null; rc=$?
kill -KILL -- -$reaper 2>/dev/null  # grupo del reaper: bash+sleep, auto-retirada completa
sleep 0.3
left=$(members | wc -l)
[ $why = exit ] && [ $left_before -ge 1 ] && why=exit_with_descendants_killed
ST="status=$why rc=$rc peakRSS_MiB=$((pk/1024)) elapsed_s=$(( $(date +%s) - start )) descendants_alive_at_exit=$left_before residual_procs=$left"
echo "$ST"
echo "$ST" >> "$out.status"
[ $left -eq 0 ] || exit 99
