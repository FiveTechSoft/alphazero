# CURRICULO-1 — protocolo V2 CONGELADO (2026-10-25 09:00 CET, antes de cualquier resultado; sustituye v1)

Sustituye al v1 tras su fallo de presupuesto (sin resultados; ver CURRICULO1_ERRATA_V2.md).
HIPOTESIS, UMBRALES Y DECISION SIN CAMBIOS respecto a v1; cambian instrumento de medida y cotas,
declarados aqui ANTES de lanzar. PENDIENTE DE VISTO BUENO (no hay reintento automatico).

CAMBIOS INSTRUMENTALES (todos verificados en caso pequeno):
1. Todas las metricas PRE/POST por scorepairs (perdida de respuesta con pregunta verdadera,
   MISMA llamada pairLoss que condgap/FIN: dominio, mascara y normalizacion identicos).
   Equivalencia verificada: scorepairs(val300)=2.6686 == condgap bpb_resp_verdadera=2.6686.
2. Subconjunto de ajuste: PRIMEROS 300 pares de val.txt (fichero val300.txt congelado). NO es una
   muestra nueva: es EXACTAMENTE el subconjunto que evalua FIN desde G1 (secuencial, cnt<300), asi
   TODOS los bpb_val historicos (2.6686 base incluido) son comparables. Sesgo de posicion: existe
   y se declara; se prefiere comparabilidad con la serie historica.
3. Retencion R: 190 pares (no 200): la regla congelada v1 "cada 33 no-E desde el 7" produce 190
   pares disponibles del pool no-E (6273); el fichero curriculo_retencion.txt ES la suite congelada.
4. Bug v1 corregido: la extraccion de PRE_VAL buscaba 'bpb_val=' en stdout, pero condgap lo emite
   por stderr: habria dejado la metrica vacia y roto la decision. Encontrado por el caso pequeno.
5. Cada fase mz bajo timeout interno propio (timeout -k 2 380) + guardia guard2.sh con TERCERA
   CAPA: reaper duro a lim+10 => COTA TOTAL REAL <=430s aunque el supervisor se atasque (hueco
   observado: TERM diferido por bash con hijo en foreground; reparacion probada con worker
   sintetico que ignora TERM: parada a los 20s, residuales 0, señal al supervisor y salida normal
   tambien probadas; ver GUARDIA2_REPARACION.md).
6. Presupuesto con PREFLIGHT MEDIDO: scoring 59 pares/s (FASE1 ~120s), condgap/scorepairs 300
   pares ~9s/5s, brazo 150 pasos ~35s (tasa medida en humo 10 pasos), FASE5 ~17s => total ~220s.
   Si el preflight real difiere >20%, NO lanzar y reportar (sin reintento ciego).

SIN CAMBIOS: E=700 (mayor perdida en train, indicador estadistico no semantico), correccion =
respuesta humana del MISMO par (duplicacion x3), brazo B control uniforme (mismo -in/pasos/lr/
seed/H/T/batch, volumen declarado en bytes), steps=150, lr=0.003, seed=7, base blm_gru2b (H64,
12000 pasos). DECISION AUTOMATICA: PROMOVER A solo si ajuste_val300 mejora >0.001 Y retencion_R
no regresa >0.010; si no, ROLLBACK y candidatos como diagnostico. Champion MLP c3 intocable.
Lanzamiento DESDE TUI (/blm-curriculum), capturas antes/despues. Negativos se reportan igual.
