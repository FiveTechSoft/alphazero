#!/bin/bash
# CURRICULO-1 v2 — ensayo unico congelado (ver CURRICULO1_PROTOCOLO_V2.md)
cd /tmp/blm || exit 1
MZ="timeout -k 2 380 ./mz"
echo "FASE0 protocolo: CURRICULO1_PROTOCOLO.md congelado 08:46"
echo "FASE1 scorepairs train (6973 pares) sobre blm_gru2b"
$MZ d1gru -mode scorepairs -in blm_gru2b.json -corpus train.txt > cur_scores.txt 2>/dev/null || { echo "ABORT scorepairs rc=$?"; exit 1; }
wc -l < cur_scores.txt | xargs echo "pares puntuados:"
python3 - <<'PY'
lines=[l.split() for l in open('cur_scores.txt') if l.startswith('SCORE')]
sc=[(int(i),float(v)) for _,i,v in lines]
sc.sort(key=lambda t:-t[1])
E=set(i for i,_ in sc[:700])
noE=[i for i,_ in sorted(sc) if i not in E]
pairs=[l.rstrip('\n') for l in open('train.txt')]
assert len(pairs)%2==0
def getpair(i): return pairs[2*i], pairs[2*i+1]
# retencion: cada 33 no-E desde el 7 -> 200
R=noE[7::33][:200]
with open('curriculo_retencion.txt','w') as f:
    for i in R:
        u,a=getpair(i); f.write(u+'\n'+a+'\n')
# corpus A: train + E x3
with open('cur_corpusA.txt','w') as f:
    f.writelines(l+'\n' for l in pairs)
    for i in sorted(E):
        u,a=getpair(i)
        for _ in range(3): f.write(u+'\n'+a+'\n')
# corpus B: train + 2100 no-E (round-robin determinista)
import itertools
with open('cur_corpusB.txt','w') as f:
    f.writelines(l+'\n' for l in pairs)
    for i in itertools.islice(itertools.cycle(noE),2100):
        u,a=getpair(i); f.write(u+'\n'+a+'\n')
with open('cur_E.txt','w') as f: f.write('\n'.join(map(str,sorted(E))))
print('E=700 R=%d corpusA_extra=2100 corpusB_extra=2100'%len(R))
PY
echo "bytes corpus: train=$(stat -c%s train.txt) A=$(stat -c%s cur_corpusA.txt) B=$(stat -c%s cur_corpusB.txt)"
echo "FASE2 metricas PRE (base blm_gru2b)"
PRE_VAL=$($MZ d1gru -mode scorepairs -in blm_gru2b.json -corpus val300.txt 2>/dev/null | awk '/^SCORE/{s+=$3;n++}END{printf "%.6f", s/n}')
PRE_R=$($MZ d1gru -mode scorepairs -in blm_gru2b.json -corpus curriculo_retencion.txt 2>/dev/null | awk '/^SCORE/{s+=$3;n++}END{printf "%.6f", s/n}')
echo "PRE ajuste_val=$PRE_VAL retencion_R=$PRE_R"
echo "FASE3 brazo A curriculum (150 pasos)"
T0=$(date +%s)
$MZ d1gru -mode train-pairs -in blm_gru2b.json -corpus cur_corpusA.txt -val val.txt -steps 150 -lr 0.003 -seed 7 -out blm_gru_curA.json 2>/dev/null | grep '^FIN'
T1=$(date +%s); echo "wallA=$((T1-T0))s"
echo "FASE4 brazo B control (150 pasos)"
T0=$(date +%s)
$MZ d1gru -mode train-pairs -in blm_gru2b.json -corpus cur_corpusB.txt -val val.txt -steps 150 -lr 0.003 -seed 7 -out blm_gru_curB.json 2>/dev/null | grep '^FIN'
T1=$(date +%s); echo "wallB=$((T1-T0))s"
echo "FASE5 metricas POST + retencion"
POST_R_A=$($MZ d1gru -mode scorepairs -in blm_gru_curA.json -corpus curriculo_retencion.txt 2>/dev/null | awk '/^SCORE/{s+=$3;n++}END{printf "%.6f", s/n}')
POST_R_B=$($MZ d1gru -mode scorepairs -in blm_gru_curB.json -corpus curriculo_retencion.txt 2>/dev/null | awk '/^SCORE/{s+=$3;n++}END{printf "%.6f", s/n}')
POST_VAL_A=$(python3 -c "import json;print(json.load(open('blm_gru_curA.json'))['bpb_val'])")
POST_VAL_B=$(python3 -c "import json;print(json.load(open('blm_gru_curB.json'))['bpb_val'])")
echo "POST_A ajuste_val=$POST_VAL_A retencion_R=$POST_R_A"
echo "POST_B ajuste_val=$POST_VAL_B retencion_R=$POST_R_B"
python3 - "$PRE_VAL" "$PRE_R" "$POST_VAL_A" "$POST_R_A" "$POST_VAL_B" "$POST_R_B" <<'PY'
import sys
pre_v,pre_r,a_v,a_r,b_v,b_r=map(float,sys.argv[1:7])
d_aj=pre_v-a_v; d_ret=a_r-pre_r
print(f"DELTAS A: ajuste={d_aj:+.4f} (mejora si < -0.001 en bpb => d>0.001) retencion={d_ret:+.4f} (regresa si >+0.010)")
print(f"DELTAS B(control): ajuste={pre_v-b_v:+.4f} retencion={b_r-pre_r:+.4f}")
if d_aj>0.001 and d_ret<=0.010:
    import shutil; shutil.copy('blm_gru_curA.json','blm_gru_curriculo1_promoted.json')
    print("DECISION: PROMOVER A (ambos criterios cumplidos; champion MLP c3 intacto)")
else:
    print("DECISION: ROLLBACK (criterios no cumplidos; A y B archivados como diagnostico; modelo servido sin cambios)")
PY
echo "FIN_CURRICULO1"
