# CURRICULO-1 V2 — resultado (2026-10-25, ~09:04-09:07 CET)

Ensayo único reintentado bajo protocolo congelado V2 (CURRICULO1_PROTOCOLO_V2.md),
autorización de un solo reintento. Lanzado y observado desde TUI OpenCode real
(capturas tui_cur2_antes.png / tui_cur2_despues.png).

## Cierre del gate (V1 falló por presupuesto; V2 cumplió)
- sidecar: status=exit rc=0 peakRSS_MiB=22 elapsed_s=160 descendants_alive_at_exit=0 residual_procs=0
- 160s <= 420s (presupuesto) y <= 336s (80% preflight estimado ~200s). Sin timeout, sin kill.
- Reaper: auto-retirado en salida normal (sin proceso, sin fichero .reaper) — comportamiento S1 verificado.
- Residuales tras el ensayo: ninguno (curriculo/train-pairs/guard2-420). Servidor d1serve con
  guarda propia de 600s, retirada programada ~09:13 (intencional, no residual).
- champion.json intacto -> blm_c3.json (MLP K16/D32/H128, 24000 pasos). Promoción NO toca champion.

## Métricas (scorepairs; ajuste = val300.txt congelado, retención = R=190 congelado)
- PRE (base blm_gru2b): ajuste=2.668562  retencion=2.447138
- POST A (curriculum):  ajuste=2.647289  retencion=2.427327
- POST B (control uniforme): ajuste=2.663769  retencion=2.434860
- DELTA A: ajuste +0.0213 (mejora; umbral >0.001) | retención -0.0198 (mejora; sin regresión)
- DELTA B: ajuste +0.0048 | retención -0.0123
- wallA=16s wallB=18s; gap_condicionamiento (diagnóstico): A=0.0009 B=0.0004

## DECISIÓN: PROMOVER A
Ambos criterios cumplidos (mejora ajuste >0.001 y regresión retención <=0.010).
A mejora el ajuste ~4.4x más que el control uniforme B (0.0213 vs 0.0048).
blm_gru_curriculo1_promoted.json = copia exacta de blm_gru_curA.json
(sha256 2394078e8989b8822178b6214d87cc4f0b2453ac8a68021226c4d3cf2a41d05a).
Champion MLP c3 intacto; B nunca se promueve.

## Lectura honesta (límites declarados)
- Bootstrap supervisado declarado: NO es RSI ni auto-mejora autónoma; el criterio keep/rollback
  es fijo y auditable, no aprendido por el modelo.
- E=700 seleccionado por pérdida estadística (indicador, no semántica); ajuste sobre val300
  tiene sesgo posicional declarado (primeros 300); métricas de byte-entropía, no de conversación.
- Una semilla (7), sin intervalos: señal de un ensayo, no efecto universal. B también mejora
  algo el ajuste (+0.0048): parte del efecto es "más datos", la ventaja específica del
  curriculum es la diferencia A-B (~+0.0165).
- Mejora de retención en ambos brazos sugiere regularización por datos nuevos; no se afirma causalidad.
- Errata menor: la línea FASE0 del log rotula "CURRICULO1_PROTOCOLO.md" (v1); el protocolo
  vigente congelado es el V2 (cabecera del script correcta). Etiqueta sin efecto en ejecución.
- La causa del estancamiento de 437s en FASE2 de V1 sigue sin cerrarse; ahora acotada por
  reaper (lim+10) y las mismas métricas midieron 9s/16s/18s en V2.
