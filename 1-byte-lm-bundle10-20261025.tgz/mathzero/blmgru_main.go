package main

// blmgru_main.go — harness d1gru: SOLO prueba de ruta (gradient check, coste,
// humo). No es un hito de conversacion ni de autonomia.
import (
	"strings"
	"flag"
	"fmt"
	"math"
	"math/rand"
	"os"
	"time"
)

func init() {
	if len(os.Args) > 1 && os.Args[1] == "d1gru" {
		RunGRU(os.Args[2:])
		os.Exit(0)
	}
}

func RunGRU(args []string) {
	fs := flag.NewFlagSet("d1gru", flag.ExitOnError)
	mode := fs.String("mode", "gradcheck", "gradcheck|cost|smoke")
	d := fs.Int("d", 32, "embedding")
	hh := fs.Int("hh", 64, "ocultas")
	seed := fs.Int64("seed", 20261025, "semilla")
	corpus := fs.String("corpus", "/tmp/blm/train.txt", "corpus")
	steps := fs.Int("steps", 300, "pasos humo")
	lr := fs.Float64("lr", 0.003, "lr Adam")
	tlen := fs.Int("t", 64, "longitud ventana BPTT")
	val := fs.String("val", "/tmp/blm/val.txt", "corpus val")
	in := fs.String("in", "", "checkpoint entrada (gen)")
	out := fs.String("out", "/tmp/blm_gru.json", "checkpoint salida (train)")
	prompt := fs.String("prompt", "U: Hola\nA:", "prompt gen")
	n := fs.Int("n", 280, "bytes a generar")
	temp := fs.Float64("temp", 0.8, "temperatura")
	fs.Parse(args)

	raw, err := os.ReadFile(*corpus)
	if err != nil {
		panic(err)
	}
	g := NewGRU(*seed, *d, *hh)

	switch *mode {
	case "train-pairs":
		// G2: aprendizaje de PARES U->A. El estado se ceba con la pregunta
		// (como en inferencia) y la perdida SOLO puntua la respuesta.
		// Secuencia capada: se conserva la pregunta entera y se trunca la
		// respuesta si excede (documentado).
		pairs := parseUAPairs(string(raw))
		valPairs := func() [][2]string {
			v, err := os.ReadFile(*val)
			if err != nil {
				panic(err)
			}
			return parseUAPairs(string(v))
		}()
		if *in != "" {
			g2, st0, _, err := LoadGRU(*in)
			if err != nil {
				panic(err)
			}
			g = g2
			fmt.Fprintf(os.Stderr, "[reanudando GRU %d pasos previos]\n", st0)
		}
		gr := g.newGrads()
		st := g.newAdam()
		r := rand.New(rand.NewSource(*seed + 21))
		t0 := time.Now()
		capSeq := 512
		for s := 0; s < *steps; s++ {
			pr := pairs[r.Intn(len(pairs))]
			prompt := []byte("U: " + pr[0] + "\nA: ")
			ans := []byte(pr[1] + "\n")
			if len(prompt)+len(ans) > capSeq {
				if len(ans) > capSeq-len(prompt) {
					ans = ans[:capSeq-len(prompt)]
				}
			}
			if len(prompt)+len(ans) < 4 {
				continue
			}
			seq := append(append([]byte(nil), prompt...), ans...)
			loss, _ := g.trainSeqMask(seq, len(prompt)-1, gr)
			g.adamApply(st, *lr, gr)
			if (s+1)%1000 == 0 {
				fmt.Printf("paso %d bpb_resp_lote=%.4f t=%s\n", s+1, loss, time.Since(t0).Round(time.Second))
			}
		}
		// val: perdida de respuesta con pregunta VERDADERA (metrica de seleccion)
		acc, cnt := 0.0, 0
		for i := 0; i < len(valPairs) && cnt < 300; i++ {
			acc += g.pairLoss([]byte("U: "+valPairs[i][0]+"\nA: "), []byte(valPairs[i][1]+"\n"))
			cnt++
		}
		bpbv := acc / float64(cnt)
		// ABLACION MEDIDA de condicionamiento: misma respuesta, pregunta BARAJADA
		rg := rand.New(rand.NewSource(*seed + 22))
		accS := 0.0
		for i := 0; i < cnt; i++ {
			j := rg.Intn(len(valPairs))
			accS += g.pairLoss([]byte("U: "+valPairs[j][0]+"\nA: "), []byte(valPairs[i][1]+"\n"))
		}
		bpbS := accS / float64(cnt)
		fmt.Printf("FIN steps=%d bpb_val_resp=%.4f bpb_val_resp_pregunta_barajada=%.4f gap_condicionamiento=%.4f (%d pares) duracion=%s\n",
			*steps, bpbv, bpbS, bpbS-bpbv, cnt, time.Since(t0).Round(time.Second))
		if bpbS-bpbv > 0.05 {
			fmt.Println("CONDICIONAMIENTO: real (la pregunta reduce la perdida de la respuesta)")
		} else {
			fmt.Println("CONDICIONAMIENTO: no detectado a esta escala (el modelo ignora operativamente la pregunta)")
		}
		totalSteps := *steps
		if *in != "" {
			_, st0, _, _ := LoadGRU(*in)
			totalSteps += st0 // acumular pasos previos en la etiqueta (reanudacion real)
		}
		if err := g.SaveGRU(*out, totalSteps, bpbv); err != nil {
			panic(err)
		}
	case "scorepairs":
		// Perdida POR PAR de un corpus con un checkpoint dado (-in obligatorio).
		// Uso: deteccion de pares dificiles (alta perdida) para curriculum
		// supervisado. Indicador ESTADISTICO de ajuste, no error semantico.
		if *in == "" {
			panic("scorepairs requiere -in checkpoint")
		}
		g2, st0, _, err := LoadGRU(*in)
		if err != nil {
			panic(err)
		}
		fmt.Fprintf(os.Stderr, "[scorepairs gru %d pasos cargado]\n", st0)
		pairs := parseUAPairs(string(raw))
		for i, pr := range pairs {
			l := g2.pairLoss([]byte("U: "+pr[0]+"\nA: "), []byte(pr[1]+"\n"))
			fmt.Printf("SCORE %d %.6f\n", i, l)
		}
	case "condgap":
		// Solo la ablacion sobre un checkpoint existente.
		g2, steps, bpbv, err := LoadGRU(*in)
		if err != nil {
			panic(err)
		}
		fmt.Fprintf(os.Stderr, "[gru %d pasos cargado, bpb_val=%.4f]\n", steps, bpbv)
		valPairs := func() [][2]string {
			v, err := os.ReadFile(*val)
			if err != nil {
				panic(err)
			}
			return parseUAPairs(string(v))
		}()
		rg := rand.New(rand.NewSource(*seed + 22))
		cnt := 0
		accT, accS := 0.0, 0.0
		for i := 0; i < len(valPairs) && cnt < 300; i++ {
			j := rg.Intn(len(valPairs))
			accT += g2.pairLoss([]byte("U: "+valPairs[i][0]+"\nA: "), []byte(valPairs[i][1]+"\n"))
			accS += g2.pairLoss([]byte("U: "+valPairs[j][0]+"\nA: "), []byte(valPairs[i][1]+"\n"))
			cnt++
		}
		fmt.Printf("CONDGAP bpb_resp_verdadera=%.4f bpb_resp_barajada=%.4f gap=%.4f (%d pares val)\n",
			accT/float64(cnt), accS/float64(cnt), (accS-accT)/float64(cnt), cnt)
	case "train":
		// Entrenamiento acotado (protocolo congelado: split por hilo ya hecho
		// en los ficheros; val = seleccion; NO toca test). Ventanas aleatorias.
		valRaw, err := os.ReadFile(*val)
		if err != nil {
			panic(err)
		}
		gr := g.newGrads()
		st := g.newAdam()
		r := rand.New(rand.NewSource(*seed + 11))
		t0 := time.Now()
		for s := 0; s < *steps; s++ {
			off := r.Intn(len(raw) - *tlen - 2)
			loss := g.trainSeq(raw[off:off+*tlen+1], gr)
			g.adamApply(st, *lr, gr)
			if (s+1)%1000 == 0 {
				fmt.Printf("paso %d bpb_lote=%.4f t=%s\n", s+1, loss, time.Since(t0).Round(time.Second))
			}
		}
		// val: media sobre ventanas fijas no solapadas del principio de val
		acc, cnt := 0.0, 0
		for off := 0; off+*tlen+1 < len(valRaw) && cnt < 300; off += *tlen + 1 {
			l, _ := g.seqLoss(valRaw[off : off+*tlen+1])
			acc += l
			cnt++
		}
		bpbv := acc / float64(cnt)
		fmt.Printf("FIN steps=%d bpb_val=%.4f (%d ventanas) duracion=%s\n", *steps, bpbv, cnt, time.Since(t0).Round(time.Second))
		if err := g.SaveGRU(*out, *steps, bpbv); err != nil {
			panic(err)
		}
	case "gen":
		g2, steps, bpbv, err := LoadGRU(*in)
		if err != nil {
			panic(err)
		}
		fmt.Fprintf(os.Stderr, "[gru %d pasos, bpb_val=%.4f]\n", steps, bpbv)
		fmt.Printf("%s\n", g2.generateGRU(*prompt, *n, *temp, *seed))
	case "gradcheck":
		// Gradient check por diferencias finitas, ventana fija con T pasos
		// (el backward atraviesa todas las puertas en cada paso). Muestras
		// POR FAMILIA de parametros, varias por familia, preferentemente con
		// gradiente analitico NO cero. Criterio ANTES de cualquier carga:
		// err_rel < 1e-3 en todas las muestras; si no, NO se entrena nada.
		seq := raw[:*tlen+1]
		gr := g.newGrads()
		loss := g.trainSeq(seq, gr)
		an := g.gradFlat(gr)
		acc := g.flatAccess()
		// limites de cada familia en el orden plano de flatAccess/gradFlat
		type fam struct {
			name string
			lo   int
			hi   int
		}
		szE, szW, szWo, H, D := 256*(*d), (*hh)*((*hh)+(*d)), 256*(*hh), *hh, *d
		_ = H
		_ = D
		o := 0
		fams := []fam{}
		add := func(name string, n int) {
			fams = append(fams, fam{name, o, o + n})
			o += n
		}
		add("E", szE)
		add("Wz", szW)
		add("Wr", szW)
		add("Wn", szW)
		add("Bz", *hh)
		add("Br", *hh)
		add("Bn", *hh)
		add("Wo", szWo)
		add("Bo", 256)
		fmt.Printf("loss ventana=%.6f params=%d (T=%d pasos, familias=%d)\n", loss, len(acc), len(seq)-1, len(fams))
		eps := 1e-5
		rg := rand.New(rand.NewSource(*seed + 3))
		worst := 0.0
		nonzero := 0
		total := 0
		for _, f := range fams {
			// hasta 4 muestras por familia con |grad analitico| no trivial
			got := 0
			for try := 0; try < 40 && got < 4; try++ {
				i := f.lo + rg.Intn(f.hi-f.lo)
				if math.Abs(an[i]) < 1e-7 {
					continue
				}
				got++
				total++
				nonzero++
				acc[i](+eps, true)
				lp, _ := g.seqLoss(seq)
				acc[i](-2*eps, true)
				lm, _ := g.seqLoss(seq)
				acc[i](+eps, true) // restaurar
				num := (lp - lm) / (2 * eps)
				absErr := math.Abs(num - an[i])
				den := math.Max(1e-8, math.Abs(num)+math.Abs(an[i]))
				rel := absErr / den
				if rel > worst {
					worst = rel
				}
				fmt.Printf("%s[%d] analitico=%.6e numerico=%.6e err_abs=%.3e err_rel=%.3e\n", f.name, i-f.lo, an[i], num, absErr, rel)
			}
			if got == 0 {
				fmt.Printf("%s: sin muestras con gradiente no trivial en 40 intentos (se reporta, no se oculta)\n", f.name)
			}
		}
		verdict := "OK"
		if worst > 1e-3 || nonzero == 0 {
			verdict = "FALLO: no entrenar hasta corregir backward"
		}
		fmt.Printf("GRADCHECK muestras=%d peor_err_rel=%.3e criterio=err_rel<1e-3 -> %s\n", total, worst, verdict)

	case "cost":
		// Coste por paso BPTT (ms) con ventana t sobre datos reales.
		gr := g.newGrads()
		st := g.newAdam()
		seq := raw[:*tlen+1]
		t0 := time.Now()
		n := 50
		for i := 0; i < n; i++ {
			g.trainSeq(seq, gr)
			g.adamApply(st, *lr, gr)
		}
		el := time.Since(t0)
		fmt.Printf("coste/paso=%.2f ms (ventana=%d bytes, H=%d D=%d, %d pasos)\n",
			float64(el.Milliseconds())/float64(n), *tlen, *hh, *d, n)

	case "smoke":
		// Humo: muestra SOLO que la perdida baja con pasos. No afirma nada mas.
		gr := g.newGrads()
		st := g.newAdam()
		r := rand.New(rand.NewSource(*seed + 7))
		t0 := time.Now()
		for s := 0; s < *steps; s++ {
			off := r.Intn(len(raw) - *tlen - 2)
			loss := g.trainSeq(raw[off:off+*tlen+1], gr)
			g.adamApply(st, *lr, gr)
			if (s+1)%50 == 0 {
				fmt.Printf("paso %d bpb_lote=%.4f t=%s\n", s+1, loss, time.Since(t0).Round(time.Second))
			}
		}
		l0, _ := NewGRU(*seed, *d, *hh).seqLoss(raw[len(raw)-2000 : len(raw)-1000])
		l1, _ := g.seqLoss(raw[len(raw)-2000 : len(raw)-1000])
		fmt.Printf("SMOKE bpb_fija_inicial=%.4f bpb_fija_tras_%d_pasos=%.4f duracion=%s (NO es evidencia de conversacion)\n",
			l0, *steps, l1, time.Since(t0).Round(time.Second))
	}
}

// parseUAPairs: extrae pares (pregunta, respuesta) de lineas "U: "/"A: ".
func parseUAPairs(txt string) [][2]string {
	var out [][2]string
	var u string
	have := false
	for _, ln := range strings.Split(txt, "\n") {
		if strings.HasPrefix(ln, "U: ") {
			u = strings.TrimPrefix(ln, "U: ")
			have = true
		} else if strings.HasPrefix(ln, "A: ") && have {
			out = append(out, [2]string{u, strings.TrimPrefix(ln, "A: ")})
			have = false
		}
	}
	return out
}
