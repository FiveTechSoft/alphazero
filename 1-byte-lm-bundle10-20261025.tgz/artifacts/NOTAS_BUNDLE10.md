# Bundle 10 (2026-10-25 ~09:00 CET) — rotulacion AlphaZero + CURRICULO-1 (fallo v1 + errata v2)

## Rotulacion (correccion Anto 08:46)
El producto es AlphaZero. d1serve: prefijos visibles "[AlphaZero - componente lenguaje experimental
(byte-MLP|byte-GRU), ...]"; config/opencode.json: "AlphaZero (local)" / "AlphaZero - lenguaje
experimental"; docs/BYTE-LM.md lleva nota de rotulacion. BYTE-LM queda como nombre interno
historico del componente y la rama (sin rename de archivos/ramas). El nombre NO cambia
arquitectura ni capacidades; no es RSI ni generalizacion.

## Codigo
- mathzero/blmgru_main.go: nuevo modo scorepairs (perdida por par con -in; base del curriculum).
- mathzero/d1serve_main.go: /blm-curriculum (admision: dedupe 10min + lock O_EXCL + doble pgrep,
  guardia desacoplada, sidecar), /blm-train-status amplia con seccion [curriculum], -blmdir
  portable, dedupe estable 10min en /blm-train, /blm-train-stop.

## CURRICULO-1 (ensayo UNICO autorizado, curriculum adaptativo SUPERVISADO, no RSI)
- artifacts/CURRICULO1_PROTOCOLO.md: protocolo congelado ANTES de resultados.
- Resultado v1: FALLO DE PRESUPUESTO (gate incumplido), sin POST/decision: ver
  artifacts/tui_curriculo.log + .status (TIMEOUT 556s rc=137 residuales 0) y
  artifacts/CURRICULO1_ERRATA_V2.md (redimensionado propuesto, pendiente de visto bueno).
- artifacts/cur_scores.txt (perdida por par, base de E), cur_E.txt (700 pares),
  curriculo_retencion.txt (R 190 pares), curriculo.sh (guion v1 congelado).
- Capturas: tui_cur_antes.png (lanzamiento desde TUI + rechazo del reenvio auxiliar),
  tui_rtA.png/tui_rtB.png (ruta train: lanzamiento/status final/parada/replay).
- Los corpus A/B derivados NO se incluyen (3,3MB c/u, regenerables con curriculo.sh desde
  train.txt + cur_E.txt).
