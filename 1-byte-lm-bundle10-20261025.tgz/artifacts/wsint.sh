#!/bin/bash
echo "WS start $(date +%s.%N)" >> /tmp/blm/wsint_marks.txt
trap 'echo "WS TERM-atrapado $(date +%s.%N)" >> /tmp/blm/wsint_marks.txt' TERM
sleep 600 &  # descendiente de fondo
sleep 600    # foreground: bash difiere el trap de TERM hasta que termine
echo "WS fin_natural $(date +%s.%N)" >> /tmp/blm/wsint_marks.txt
