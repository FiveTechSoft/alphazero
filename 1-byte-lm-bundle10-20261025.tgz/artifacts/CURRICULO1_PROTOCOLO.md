# CURRICULO-1 — protocolo CONGELADO (2026-10-25 08:46 CET, antes de cualquier resultado)

ENSAYO UNICO de curriculum adaptativo SUPERVISADO. NO es el modelo corrigiendose solo; NO es RSI:
la deteccion de "dificil" es una metrica estadistica programada y la correccion es la respuesta
humana ya existente en el mismo par de train. Autorizacion: 1 ensayo, presupuesto total <=420s.

- Base: blm_gru2b.json (H=64, 43.456 params, 12000 pasos, bpb_val=2.6686).
- Errores: scorepairs sobre train.txt (6973 pares); E = 700 pares de MAYOR perdida de respuesta
  (indicador estadistico de ajuste, no error semantico). Solo TRAIN; val nunca entra al entrenamiento.
- Correccion: respuesta humana del MISMO par (re-muestreo ponderado por duplicacion x3 de E).
- Retencion (suite congelada R): 200 pares de train FUERA de E, seleccion determinista (cada 33
  indices no-E desde el 7), guardada en curriculo_retencion.txt ANTES del ensayo.
- Brazo A (curriculum): corpus_A = train.txt + E duplicado x3 (2100 pares extra).
- Brazo B (control uniforme): corpus_B = train.txt + 2100 pares no-E duplicados (mismo conteo;
  bytes reportados). Mismo -in, pasos, lr, semilla, H, T, batch=1 => igual computo; wall time reportado.
- Hiper: -in blm_gru2b.json, steps=150, lr=0.003, seed=7 (ambos brazos).
- Metricas (mismo codigo, pre sobre base y post por brazo):
  * AJUSTE: bpb_val_resp (300 pares val; metrica de ajuste estadistico, NO coherencia).
  * RETENCION (separada): bpb_resp sobre R.
- DECISION AUTOMATICA: PROMOVER solo si (ajuste_A mejora >0.001 respecto a la base) Y
  (retencion_A no regresa >0.010). Si no: ROLLBACK y candidato archivado como diagnostico.
  Promover = copia a blm_gru_curriculo1_promoted.json como modelo de TRABAJO; el champion MLP
  (blm_c3) NO se toca en ningun caso. El brazo B nunca se promueve (es control).
- Negativos se reportan igual que positivos. Si la guardia corta por tiempo: resultado solo
  observacional, gate incumplido documentado, sin reintento ciego.
