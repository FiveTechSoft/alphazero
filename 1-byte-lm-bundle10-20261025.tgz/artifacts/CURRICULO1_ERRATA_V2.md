# CURRICULO-1 — errata v2 (2026-10-25 08:57 CET): redimensionado tras fallo de presupuesto

FALLO v1 (observacional, sin resultado): condgap sobre val para la metrica PRE tardo >400s
(presupuestado ~30s por error mio); TERM a los 425s mato al bash y dejo mz huerfano hasta el
kill de grupo a los 556s (rc=137, residuales 0). Sin POST/deltas/decision. Hueco TERM-huerfano
confirmado en la practica.

ERRATA (misma hipotesis, mismos umbrales y decision congelados; solo cambia el COMO de medir):
- Todas las metricas PRE/POST por scorepairs acotado (mismo pairLoss): 300 primeros pares val
  (= lo que evalua FIN) y R (190 pares). condgap fuera del ensayo.
- Cada fase mz con timeout interno propio (timeout -k 2 380): ningun huerfano sobrevive al bash.
- Estimacion con tasas medidas: total ~230s < 420s (guardia). E=700/R=190/pasos=150/seed=7 intactos.
- Lanzamiento pendiente de visto bueno del coordinador (fallo de gate => no reintento automatico).
