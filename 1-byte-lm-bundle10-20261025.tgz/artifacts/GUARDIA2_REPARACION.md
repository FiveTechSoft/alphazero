# Reparacion del hueco TERM-huerfano — guard2.sh (2026-10-25 09:00 CET)

ORIGEN DE LOS DOS DEADLINES (425 vs 556, ensayo CURRICULO-1 v1):
- 425s: capa interna `timeout -k 3 (lim+5)` envia TERM al bash del worker. HECHO VERIFICADO: bash
  DIFIERE el manejo de TERM mientras un hijo corre en foreground (patron conocido de bash); el
  KILL a los +3s mata al bash pero el mz en foreground queda HUERFANO dentro del grupo.
- 556s: instante real en que el supervisor escribio el sidecar tras recolectar (rc=137,
  residuales 0). La demora de 136s sobre la rotura configurada de 420s NO queda explicada por la
  mecanica documentada del bucle (sondeo 0.1s con chequeo de fecha por iteracion); NO declaro la
  causa cerrada. Lo que si queda demostrado: la recoleccion final fue completa (residual_procs=0)
  y la cota configurada NO se cumplio en la practica.

REPARACION (guard2.sh = guard.sh original + tercera capa, sin tocar el resto del contrato):
- Reaper DURO desacoplado (sesion propia): `sleep lim+10; kill -KILL -- -<pgid>` lanzado al inicio.
  Cota TOTAL real <= lim+10 aunque el supervisor se atasque, el TERM quede diferido o el timeout
  interno falle. Se cancela si el worker termina antes.
- PRUEBA SINTETICA (worker wsint.sh que IGNORA TERM con hijo foreground + descendiente de fondo,
  RSS 5MiB):
  * T1 timeout: status=TIMEOUT rc=137 elapsed_s=20 (exacto) residual_procs=0; sin marca de trap
    (SIGKILL precede a cualquier trap diferido). Wall total 20.1s << lim+10.
  * T2 señal al supervisor (TERM a los 3s): status=SUPERVISOR_SIGNAL residual_procs=0 rc=143.
  * T3 salida normal: status=exit rc=0 elapsed_s=2 residual_procs=0.
- Limites heredados declarados: overshoot RSS entre sondeos; procesos que crean sesion propia
  escapan; SIGKILL al supervisor deja solo la cota total del reaper.
- ADEMAS en el guion del ensayo (curriculo.sh v2): cada fase mz con timeout interno propio
  (timeout -k 2 380), asi ninguna fase depende de que el TERM atraviese al bash.
