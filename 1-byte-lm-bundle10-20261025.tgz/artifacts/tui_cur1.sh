#!/bin/bash
DISP=:98
rm -f /tmp/tui_cur_antes.png /tmp/blm/tui_curriculo.lock /tmp/blm/tui_curriculo_served.json /tmp/blm/tui_curriculo.log /tmp/blm/tui_curriculo.log.status
bash /tmp/blm/guard.sh 900 900 /tmp/blm/srv_cur.log /tmp/blm/mz d1serve -port 8101 -blmgru /tmp/blm/blm_gru2b.json -guard /tmp/blm/guard.sh >/dev/null 2>&1 &
Xvfb $DISP -screen 0 1280x900x24 >/dev/null 2>&1 &
sleep 2
DISPLAY=$DISP xfce4-terminal --geometry=140x42 --title=BLM-CUR -e 'bash -c "cd /tmp/octest2 && ./node_modules/.bin/opencode; echo; echo SESION TERMINADA; sleep 1200"' >/dev/null 2>&1 &
sleep 14
DISPLAY=$DISP xdotool search --name "BLM-CUR" windowactivate --sync 2>/dev/null
LC_ALL=C.utf8 DISPLAY=$DISP xdotool type --delay 25 --clearmodifiers '/blm-curriculum '
DISPLAY=$DISP xdotool key Return
sleep 6
DISPLAY=$DISP scrot /tmp/tui_cur_antes.png
echo CUR_LANZADO
