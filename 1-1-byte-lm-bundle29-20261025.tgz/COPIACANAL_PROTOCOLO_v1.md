# COPIACANAL v1 — Protocolo (propuesta, SIN autorización de training aún)

## Motivación (basada en datos medidos, no hipótesis libre)
En COMPOSICION v1 (bundle27) y CERCANIA v1.1 (bundle28):
- COPIA train 5/10 exacto, pos_ok 0.89 en salidas de largo correcto: el canal identidad se aprende PARCIALMENTE en palabras practicadas.
- COPIA held 0/2, newword 0/4: no transfiere a palabras no practicadas (n pequeña, declarado).
- DUPLICA train 0/10 exacto y 0/10 largo correcto: el modelo no reproduce ni la LONGITUD del operando; emite el inicio de la palabra (prefijo 2.8/8).
- Sonda CROSS24 (experimento 3b): respuestas lookup-like (otras respuestas train / otras palabras).
Lectura: antes de medir reglas de letras, el canal "reproducir el operando" (identidad, duplicar, invertir — sin conocimiento de letras) no transfiere. Si el canal no transfiere, ninguna regla puede componer. Este experimento lo mide AISLADO.

## Diseño
- dst5: 3 operaciones de manipulación pura del operando (COPIA, DUPLICA, INVIERTE — ninguna requiere sustitución de letras) × 40 palabras nuevas de 4 letras (disjuntas de dst4, dst3b y todos los conjuntos prohibidos; fixture PASS).
- train 84 = 28 palabras × 3 ops (sha16 e4f92cfdba3f2462); held18 = 6 palabras × 3 (b875e4dd36b518f1); newword18 = 6 × 3 (5a1a0f746703dd2c). Celdas Y palabras reservadas ANTES de entrenar.
- Solapes medidos pre-run: 0 targets held/nw presentes como target train, 0 equivalencias entre ops (ninguna palabra palíndroma/degenerada), 0 colisiones reales (clave proxy) vs sub500/heldout100/finales/dst4.
- Misma receta que COMPOSICION v1 (84 DST + 84 naturales sub500, replay 50/50, 6 bloques ×504 = 3024, seq congelada): master_mix5 sha16 20f7faac70f3cb12, man_mix5 sha16 e5481633fdc5f0f9, seq_comp5 sha16 7e77523dfdabb6a4. DECLARADO: la secuencia de ÍNDICES es byte-idéntica a la de COMPOSICION v1 (mismo generador, mismas semillas, misma estructura 84+84); el contenido expuesto difiere vía master_mix5. Misma receta ≠ mismo régimen estricto (experimento nuevo, no control causal vs dst4 ni 3b).

## Criterio predeclarado (convención no validada estadísticamente; cuentas exactas)
- Primario bloque 6, held18: ≥6/18 transferencia de canal medida / ≤2 no / 3-5 ambiguo. Los 6 bloques se evalúan sin corte; trayectoria descriptiva.
- Secundario descriptivo: largo correcto en DUPLICA held (¿reproduce longitud doble?), exacto COPIA held/nw, CERCANIA v1.1 post-run sobre gens archivadas.
- Un acierto en celda reservada NO prueba regla abstracta: con 0 targets compartidos y 0 equivalencias (fixture), un acierto no viene de recuperación literal del target, pero sesgo y azar siguen abiertos; por eso el criterio es de cuentas.

## Coste y guardas
Idénticas a COMPOSICION v1 medido: ~90s wall estimado, tope 180s; guarda bloque >15s; proyección +15>180 PARA; primer fallo PARA, sin retries; RSS <900 MiB (medido 25 MiB en dst4); ledgers; main/champion intactos; FINAL-2 cerrado; sin adopción. Captura OpenCode local con comando archivado; bundle público sin proveniencia interna.

## Estado
TODO preparado y congelado (datasets + fixtures PASS + seq + receta). NO se ejecuta training sin autorización de alcance.

## Adendo v1.1 (correcciones del canal principal, aplicadas ANTES del run; datos intactos)
1. Estructura real del diseño: train = 28 palabras × 3 ops = 84 con TODAS las ops en cada palabra; held18 = 6 palabras × 3 y newword18 = otras 6 × 3 reservan AMBOS PALABRAS NUEVAS. No existe celda (op,w) ausente con w vista en este train. Por tanto NO hay dos exámenes distintos ("celdas" vs "palabras"): held18 es el primario (palabras nuevas, lote 1) y newword18 es secundario (otro lote de desarrollo). Ninguno prueba composición sobre operandos vistos.
2. Se retira el encuadre "si el canal no transfiere, ninguna regla puede componer", "mide AISLADO" y "falla ANTES de la regla": no justificado. Lo medido es descriptivo: fallo de copia y de transformación en este régimen; hay múltiples cambios de dataset entre experimentos y ningún aislamiento causal.
3. Estos experimentos son diagnósticos del motor de aprendizaje básico desde cero, no el producto final ni RSI.
4. El oráculo (dst4_score/cercanía) solo EVALÚA generaciones archivadas; nunca alimenta respuestas en inferencia.
