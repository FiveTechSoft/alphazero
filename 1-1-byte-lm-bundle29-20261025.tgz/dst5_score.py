#!/usr/bin/env python3
# exact match POR OPERACION para dst5: COPIA=identidad, DUPLICA=repeticion palabra (w+w),
# INVIERTE=reverso. DECLARADO: dst5 'DUPLICA' NO es la DUPLICA de dst_gen (duplicado por
# caracter); es una op sintetica local de dst5. Uso: dst5_score.py PARES GENS
import sys, re, json
def ap(op,w):
    if op=='COPIA': return w
    if op=='DUPLICA': return w+w
    if op=='INVIERTE': return w[::-1]
    raise ValueError(op)
pares=open(sys.argv[1]).read().strip().split('\n')
gens=[l.rstrip('\n') for l in open(sys.argv[2])]
n=len(pares)//2; assert len(gens)==n, (len(gens),n)
per={}
for i in range(n):
    u=pares[2*i][3:]; m=re.match(r"aplica (\S+) a '([a-z]+)'$", u)
    op,w=m.group(1),m.group(2)
    t=pares[2*i+1][3:]
    assert ap(op,w)==t, (op,w,t)  # oraculo consistente con dataset
    per.setdefault(op,[0,0]); per[op][1]+=1
    if gens[i].strip()==t: per[op][0]+=1
tot_ok=sum(v[0] for v in per.values())
print(json.dumps({'exact_total':f'{tot_ok}/{n}','por_op':{k:f'{v[0]}/{v[1]}' for k,v in sorted(per.items())}}))
