import subprocess, json, re, sys

MZ = "/tmp/blm/mz"
MODEL = "/tmp/blm/blm_c4c.json"
PROMPTS = [
 "Que es un agujero negro?","Cual es la capital de Francia?","Que es la amistad?",
 "Como se hace una tortilla de patatas?","Que es AlphaZero?","Hola, como estas?",
 "Cuentame un chiste.","Que tiempo hace hoy?","Quien eres?","Explicame que es un bucle while."]

def gen(prompt, seed=42, temp=0.8, cond=True):
    args = [MZ, "d1blm", "-mode", "gen", "-in", MODEL, "-prompt", "U: "+prompt+"\nA:",
            "-n", "280", "-temp", str(temp), "-seed", str(seed)]
    if cond: args.append("-cond")
    r = subprocess.run(args, capture_output=True, text=True, timeout=120)
    return r.stdout.strip()

def words(t):
    return set(w for w in re.findall(r"[a-záéíóúñ]{4,}", t.lower()))

STOP = {"para","como","pero","esto","esta","este","sobre","porque","cuando","donde","tiene","tener","hacer","puede","entre","desde","hasta","tambien","ahora","solo","cada","muy","mas","los","las","una","unas","unos","que","con","del","por","son","ser","hay","sin","sus","les","fue","han","era","ese","esa","eso","asi","aqui","alli","todo","toda","todos","todas","otro","otra","bien","sido","debe","deben","forma","parte","caso","cosa","cosas","vez","veces","algo","nada","siempre","nunca","hace","hacer","mismo","misma","tanto","cuanto","cual","cuales","quien","quienes","cuyo","cuya"}

def relevance(q, a):
    qw = words(q) - STOP
    aw = words(a)
    if not qw: return 0.0
    return len(qw & aw) / len(qw)

print("== determinismo (misma pregunta, misma semilla, 2 veces) ==")
a = gen(PROMPTS[0]); b = gen(PROMPTS[0])
print("identicas:", a == b)

print("\n== evidencia ENTRE preguntas (misma semilla=42, temp=0.8, mismo decoding) ==")
outs = []
for p in PROMPTS:
    o = gen(p)
    outs.append(o)
    print(f"\nU: {p}\nA: {o[:220]}")
distinct = len(set(outs))
print(f"\nrespuestas distintas: {distinct}/10")

print("\n== relevancia (solape de palabras, indicador DEBIL, no prueba semantica) ==")
rels = [relevance(p, o) for p, o in zip(PROMPTS, outs)]
for p, r in zip(PROMPTS, rels): print(f"  {r:.2f}  {p}")
print(f"media: {sum(rels)/len(rels):.3f}")
