import json, gzip, os
msgs = {}
with gzip.open('oasst2.jsonl.gz','rt',encoding='utf-8') as f:
    for line in f:
        m = json.loads(line)
        msgs[m['message_id']] = m
def root(mid):
    seen = set()
    while msgs[mid].get('parent_id') and msgs[mid]['parent_id'] not in seen:
        seen.add(mid)
        mid = msgs[mid]['parent_id']
        if mid not in msgs: break
    return mid
def clean(t): return ' '.join(t.split())
pairs = []
for m in msgs.values():
    if m.get('lang')!='es' or m.get('role')!='assistant': continue
    if m.get('deleted') or m.get('review_result') is False or m.get('synthetic'): continue
    p = msgs.get(m.get('parent_id') or '')
    if not p or p.get('role')!='prompter' or p.get('lang')!='es': continue
    u, a = clean(p['text']), clean(m['text'])
    if not (10<=len(u)<=300) or not (20<=len(a)<=600): continue
    pairs.append((root(p['message_id']), u, a))
def fnv(s):
    h=2166136261
    for b in s.encode(): h=((h^b)*16777619)&0xFFFFFFFF
    return h
pairs.sort(key=lambda pa: fnv(pa[0]+pa[1]+pa[2]))
train, val, test = [], [], []
for r,u,a in pairs:
    b = fnv(r) % 10
    (test if b==0 else val if b==1 else train).append((u,a))
for name, lst in (('train',train),('val',val),('test',test)):
    with open(f'{name}.txt','w',encoding='utf-8') as f:
        for u,a in lst: f.write(f"U: {u}\nA: {a}\n")
    print(name, len(lst), os.path.getsize(f'{name}.txt'))
roots = len(set(r for r,_,_ in pairs))
print('pares:', len(pairs), 'hilos raiz:', roots)
