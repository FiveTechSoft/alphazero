# Controlador autonomo de ciclos BYTE-LM: reglas FIJAS y auditables.
# No autocalifica salidas: usa metricas objetivas externas (BPB val,
# relevancia pregunta-respuesta por solape de palabras contenido, validez
# UTF-8, memorizacion por subcadenas). Regla conservar/rollback prefijada.
import json, subprocess, re, sys, os, datetime

MZ = './mz'
PROMPTS = ["Que es un agujero negro?","Cual es la capital de Francia?","Que es la amistad?",
"Como se hace una tortilla de patatas?","Que es AlphaZero?","Hola, como estas?",
"Cuentame un chiste.","Que tiempo hace hoy?","Quien eres?","Explicame que es un bucle while."]
STOP = set("el la los las un una unos unas de del en y o a que es son por para con se su al lo como mas pero sus le ya o este esta entre cuando todo esta sobre tambien me hasta hay donde porque muy sin sobre este si no te mi tu eso eso".split())

def gen(model, prompt, n=180, temp=0.8):
    r = subprocess.run([MZ,'d1blm','-mode','gen','-in',model,'-prompt',f'U: {prompt}\nA:','-n',str(n),'-temp',str(temp),'-seed','7'],capture_output=True,timeout=60)
    return r.stdout.decode('utf-8',errors='replace').strip()

def bpb(model, data):
    r = subprocess.run([MZ,'d1blm','-mode','eval','-in',model,'-corpus','train.txt','-heldout',data,'-seed','20261025'],capture_output=True,text=True,timeout=300)
    m = re.search(r'bpb_heldout=([\d.]+)', r.stdout)
    return float(m.group(1))

def cwords(s):
    return set(w for w in re.findall(r'[a-zA-ZñÑáéíóúÁÉÍÓÚüÜ]{3,}', s.lower()) if w not in STOP)

def relevance(prompt, answer):
    q, a = cwords(prompt), cwords(answer)
    return len(q & a) / max(1, len(q))

def utf8_ok(s):
    try: s.encode('utf-8').decode('utf-8'); return True
    except: return False

train_txt = open('train.txt',encoding='utf-8').read()
train_shingles = set(re.findall(r'\S+(?: \S+){7}', train_txt.lower()))
def mem_metrics(gen_text):
    g = gen_text.lower()
    sh = re.findall(r'\S+(?: \S+){7}', g)
    sh_hit = sum(1 for x in sh if x in train_shingles)
    # longest common substring (binaria sobre longitud)
    def has(k):
        return any(g[i:i+k] in train_txt.lower() for i in range(len(g)-k+1)) if k <= len(g) else False
    lo, hi = 0, min(len(g), 400)
    while lo < hi:
        mid = (lo+hi+1)//2
        if has(mid): lo = mid
        else: hi = mid-1
    return {'8gram_hit_frac': round(sh_hit/max(1,len(sh)),3), 'lcs_bytes': lo}

def evaluate(model):
    gens = {p: gen(model,p) for p in PROMPTS}
    rel = [relevance(p,a) for p,a in gens.items()]
    mem = {p: mem_metrics(a) for p,a in gens.items()}
    return {
      'bpb_val': bpb(model,'val.txt'),
      'relevance_mean': round(sum(rel)/len(rel),4),
      'utf8_all_ok': all(utf8_ok(a) for a in gens.values()),
      'mem_max_lcs': max(m['lcs_bytes'] for m in mem.values()),
      'mem_8gram_max': max(m['8gram_hit_frac'] for m in mem.values()),
      'gens': gens,
    }

def decide(champ, cand, champ_m, cand_m):
    # Regla prefijada: conservar solo si BPB val mejora Y relevancia no empeora Y utf8 ok
    keep = cand_m['bpb_val'] < champ_m['bpb_val'] - 1e-4 and cand_m['relevance_mean'] >= champ_m['relevance_mean'] - 0.01 and cand_m['utf8_all_ok']
    return keep

def log(entry):
    entry['ts'] = datetime.datetime.now().isoformat()
    with open('controller_log.jsonl','a',encoding='utf-8') as f:
        f.write(json.dumps(entry,ensure_ascii=False)+'\n')

if __name__ == '__main__':
    champ = json.load(open('champion.json'))
    cand = sys.argv[1]
    champ_m = evaluate(champ['path'])
    cand_m = evaluate(cand)
    keep = decide(champ['path'], cand, champ_m, cand_m)
    log({'event':'ciclo','campeon':champ['path'],'candidato':cand,
         'metricas_campeon':{k:v for k,v in champ_m.items() if k!='gens'},
         'metricas_candidato':{k:v for k,v in cand_m.items() if k!='gens'},
         'decision':'CONSERVAR' if keep else 'ROLLBACK','regla':'bpb_val mejora Y relevancia no peor Y utf8 ok'})
    if keep:
        json.dump({'path':cand,'arch':None,'steps':None,'bpb_val':cand_m['bpb_val']}, open('champion.json','w'))
    print('DECISION:', 'CONSERVAR' if keep else 'ROLLBACK')
    print('campeon:', {k:v for k,v in champ_m.items() if k!='gens'})
    print('candidato:', {k:v for k,v in cand_m.items() if k!='gens'})
    json.dump({'campeon':champ_m['gens'],'candidato':cand_m['gens']}, open('last_gens.json','w'), ensure_ascii=False, indent=1)
