# COPIA-ALGORÍTMICA v2 — Protocolo (PREP congelada; SIN autorización de full training)

Sustituye a v1 (descartada antes de cualquier ejecución). Cambios por correcciones: nombres de op semánticos únicos, doble held (misma longitud + longitud reservada), tests unitarios MANUALES, coste medido por micro-benchmark, presupuesto de generación fijado.

## Motivación (de la evidencia integrada; sin "memorización imposible" ni "transfiere por necesidad")
En dst3b, dst4 y dst5 (3024 pasos, misma receta, misma base): ajuste a pares practicados crece (12/96, 25/84, 45/84) y transferencia a operandos nuevos = 0 en todos los cortes (0/24, 0/24, 0/36, 0/18, 0/18), sin estructura parcial medida (cercanía). En ese régimen memorizar es suficiente para train: no discrimina memorizar de aprender. Este diseño usa 504 operandos ÚNICOS (cada par visto 3×, espacio 26^8+): una coincidencia literal train/examen queda excluida por fixture (0 operandos compartidos). DECLARADO: un espacio grande NO descarta sesgos ni heurísticas parciales; un acierto en operandos no expuestos no prueba "regla general"; un fallo en longitudes nuevas tampoco separa causas sin el held de misma longitud (por eso hay DOS helds).
Escenario nuevo: operandos 8-16 chars (más largo y más difícil que 4); NO es control causal vs los experimentos de 4 chars.

## Diseño congelado
- Ops (nombres semánticos únicos, sin colisión con dst_gen): "repite '<w>'" (identidad) e "invierte '<w>'" (reverso). Superficie nueva tipo instrucción, deliberada y declarada. Alfabeto: a-z ASCII solamente; UTF-8/no-ASCII FUERA de alcance.
- dst6_train504.txt sha16 78e82f6ea0c4e880: 504 pares ÚNICOS, longitudes 8-13 (42/op/longitud).
- dst6_heldL48.txt sha16 128540e950a61778: operandos NUEVOS, mismas longitudes 8-13. PRIMARIO (operandos no expuestos, longitud entrenada).
- dst6_heldLong48.txt sha16 963c27bd3af4b9d7: longitudes 14-15. Secundario A (extrapolación de longitud).
- dst6_nw16_24.txt sha16 039b6318739494fa: longitud 16. Secundario B.
- Fixtures PASS: 0 operandos compartidos entre los 4 conjuntos (6 comparaciones); rangos estrictos; 0 colisiones reales (clave proxy) vs sub500/heldout100/finales; oráculo dst6_score.py con 6/6 tests unitarios MANUALES (esperados escritos a mano para L8..L16 ambas ops) + RECHAZO de dataset inconsistente (no auto-test generado por el mismo código).
- Receta: master_mix6 sha16 8f712dea58dab4ea = 504 dst6 + 504 naturales (sub500 completo + 4 primeros repetidos, DECLARADO); replay 50/50; seq_comp6 sha16 07e29a3e3c8ef87c = 3 ciclos completos de 1008 índices (cada par exactamente 3×, sin repetición intra-ciclo; semillas 20261025/26/27; índices idénticos a la seq anterior de 1008, contenido distinto vía master). Corpus/master/seq por fichero con hash; cursor seq en checkpoint con rechazo si sha difiere; sin bypass.
- Presupuesto de generación: -n 24 (16 chars de salida + margen + EOS), fijado antes del run.

## Criterio predeclarado (convención no validada; cuentas exactas)
- Primario bloque 6, heldL48: ≥16/48 transferencia medida a operandos no expuestos (misma longitud) / ≤4 no / 5-15 ambiguo.
- Secundarios descriptivos: heldLong48 y nw16_24 (extrapolación de longitud; un negativo aquí con primario positivo = copia aprendida sin extrapolación de longitud; ambos negativos = sin transferencia medida); exacto por longitud y por op; largo correcto; CERCANIA v1.1 offline; bpb heldout natural.
- Ningún resultado prueba "algoritmo general": operandos del mismo generador y alfabeto; reportar cuentas.

## Coste MEDIDO por micro-benchmark acotado (prep autorizada, 24 pasos, no full train)
- Train 24 pasos con operandos largos: 1.44s wall → ~60ms/paso (vs ~26ms/paso en los de 4 chars; ~2.3×, no lineal, declarado).
- Gen 24 pares L16 con -n 24: 69ms.
- Proyección: 6 bloques ×504 ≈ 181s + evaluaciones ≈ 50s → ~235s.
- GUARDAS FALSABLES: tope 300s wall total; guarda bloque >35s PARA; proyección elapsed+40>300 PARA; primer fallo PARA; sin retries; RSS <900MiB medido por bloque; ledgers; 6 bloques evaluados sin corte por acierto; primario = bloque 6 (sin elegir máximo post-hoc); main/champion intactos; FINAL-2 cerrado; sin adopción; captura OpenCode local; bundle público proyecto único.

## Estado
PREP completa y congelada (datasets, fixtures, tests manuales, master, seq, benchmark). NO se ejecuta full training sin autorización de alcance.

## Adendo v2.1 (aclaraciones de revisión, ANTES del run; datos intactos)
1. Exposiciones: 504 operandos ÚNICOS (un par por operando, 1 op asignada por operando); cada par expuesto 3× EN TOTAL (1× por ciclo × 3 ciclos de la seq). NO es muestreo sin repetición global ni aprendizaje stream/online. (Nota previa corregida: es 1×/ciclo, 3× total — verificado en manifest/seq abajo.)
2. Corrección: la comparación "misma pasada 3024 dst3b 12/96" era inexacta: 12/96 se midió a 2880 pasos (seq_R2880), no 3024. Comparación histórica descriptiva, no misma receta estricta.
3. Ambigüedad de nombres: "repite" (identidad, dst6) NO es la "DUPLICA" de dst5 (repetición de palabra 2×) ni la de dst_gen (duplicado por carácter). Ejemplos MANUALES fijados: "repite 'abcdefgh'" → "abcdefgh"; "invierte 'abcdefgh'" → "hgfedcba"; "invierte 'abcdefghijklmnop'" → "ponmlkjihgfedcba". El oráculo dst6_score.py RECHAZA cualquier fichero de pares cuyo sha16 no esté en la tabla v2 congelada o cuya semántica no coincida (assert por fila).
4. Cercanía post-run reporta fallos desglosados por op y por longitud.
5. Un primario positivo NO concluye "copia general"; un patrón "heldL sí / longitudes no" NO es causal: solo cuentas.
