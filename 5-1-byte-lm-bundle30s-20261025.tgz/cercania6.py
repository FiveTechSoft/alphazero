#!/usr/bin/env python3
# CERCANIA v1.1 para dst6: metricas congeladas; cortes por op Y por longitud;
# control permutado dentro de (op,longitud), semilla 20261025, DESCRIPTIVO.
import re, sys, json, random
def lev(a,b):
    m,n=len(a),len(b); d=list(range(n+1))
    for i in range(1,m+1):
        p,d=d,[i]+[0]*n
        for j in range(1,n+1): d[j]=min(p[j]+1,d[j-1]+1,p[j-1]+(a[i-1]!=b[j-1]))
    return d[n]
def prefijo(a,b):
    k=0
    for x,y in zip(a,b):
        if x!=y: break
        k+=1
    return k
def pares(path):
    ls=open(path).read().strip().split('\n'); out=[]
    for i in range(0,len(ls),2):
        m=re.match(r"U: (repite|invierte) '([a-z]+)'$", ls[i])
        out.append((m.group(1),m.group(2),ls[i+1][3:]))
    return out
def metricas(gens, targets):
    n=len(gens); ex=sum(g.strip()==t for g,t in zip(gens,targets))
    largo=sum(len(g.strip())==len(t) for g,t in zip(gens,targets))
    lv=sum(lev(g.strip(),t)/len(t) for g,t in zip(gens,targets))/n
    ok=[sum(1 for i in range(len(t)) if g.strip()[i]==t[i])/len(t) for g,t in zip(gens,targets) if len(g.strip())==len(t)]
    pos=sum(ok)/len(ok) if ok else None
    pf=sum(prefijo(g.strip(),t) for g,t in zip(gens,targets))/n
    return dict(n=n, exacto=ex, largo_ok=largo, lev_norm=round(lv,4), pos_ok=(round(pos,4) if pos is not None else None), n_pos=len(ok), prefijo=round(pf,4))
def control(it, rng):
    tg=[t for _,_,t in it]; perm=[None]*len(it)
    grupos={}
    for i,(op,w,_) in enumerate(it): grupos.setdefault((op,len(w)),[]).append(i)
    for k,idx in grupos.items():
        sh=idx[:]; rng.shuffle(sh)
        intentos=0
        while any(a==b for a,b in zip(idx,sh)) and len(idx)>1 and intentos<50: rng.shuffle(sh); intentos+=1
        for a,b in zip(idx,sh): perm[a]=tg[b]
    return perm
def run(nombre, path, genpref):
    it=pares(path); rng=random.Random(20261025)
    print(f"### {nombre} (n={len(it)})")
    for b in range(1,7):
        gens=[l.rstrip('\n') for l in open(f'ciclo_alg/{genpref}_A{b}.txt')]
        assert len(gens)==len(it), (b,len(gens),len(it))
        tg=[t for _,_,t in it]
        print(f"A{b} real: {json.dumps(metricas(gens,tg),ensure_ascii=False)}")
        print(f"A{b} ctrl: {json.dumps(metricas(gens,control(it,rng)),ensure_ascii=False)}")
    gens=[l.rstrip('\n') for l in open(f'ciclo_alg/{genpref}_A6.txt')]
    print(f"-- A6 por op ({nombre}):")
    for op in ('repite','invierte'):
        idx=[i for i,(o,_,_) in enumerate(it) if o==op]
        print(f"  {op} n={len(idx)}: {json.dumps(metricas([gens[i] for i in idx],[it[i][2] for i in idx]),ensure_ascii=False)}")
    print(f"-- A6 por longitud ({nombre}):")
    for L in sorted({len(w) for _,w,_ in it}):
        idx=[i for i,(_,w,_) in enumerate(it) if len(w)==L]
        print(f"  L{L} n={len(idx)}: {json.dumps(metricas([gens[i] for i in idx],[it[i][2] for i in idx]),ensure_ascii=False)}")
run('TRAIN504','dst6_train504.txt','gentrain')
run('HELDL48','dst6_heldL48.txt','genheldL')
run('HELDLONG48','dst6_heldLong48.txt','genheldG')
run('NW16_24','dst6_nw16_24.txt','gennw')
