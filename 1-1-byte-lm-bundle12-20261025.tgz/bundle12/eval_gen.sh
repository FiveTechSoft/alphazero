#!/bin/bash
# EVAL-GEN-1 (protocolo congelado EVALGEN1_PROTOCOLO.md) - lanzado via /blm-eval-gen
cd /tmp/blm || exit 1
echo "EVALGEN1 protocolo: EVALGEN1_PROTOCOLO.md congelado 09:16"
python3 /tmp/blm/eval_gen.py
