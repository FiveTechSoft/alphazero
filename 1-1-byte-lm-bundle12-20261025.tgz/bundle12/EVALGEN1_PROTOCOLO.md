# EVAL-GEN-1 — protocolo CONGELADO antes de generar (2026-10-25 09:16 CET)

Evaluación de GENERACIÓN pareada. No es entrenamiento. Autorizada como evaluación
rutinaria. Ninguna métrica de este protocolo es BPB ni se presenta como conversación/RSI.

## Modelos (checkpoints fijos, diagnosticos GRU; champion MLP c3 NO participa)
- base = blm_gru2b.json (12000 pasos; es el checkpoint que sirve d1serve — estado declarado)
- A = blm_gru_curA.json (curriculum, = promoted; copia diagnostica, NO adoptada por el servicio)
- B = blm_gru_curB.json (control uniforme)

## Prompts (fijadas ANTES de generar; no preseleccionadas por resultado)
- 30 preguntas de val.txt (conjunto de validacion, nunca entrenado): pares idx 3,31,59,...
  (offset 3, stride 28, reproducible). Fichero congelado: evalgen_prompts.txt
  (columnas: n, idx_val, pregunta, respuesta_referencia).
- Casos NO reducidos a un acierto: se archivan y reportan las 30x3=90 respuestas completas.

## Decoding identico para los tres modelos (pareado por prompt)
- mz blmgru gen -prompt "U: <pregunta>\nA: " -n 280 -temp 0.3 -seed (1000+n)
- Misma semilla por prompt en los tres modelos; n, temp y formato iguales (formato
  alineado con train-pairs, "A: " con espacio, como el decoding del servicio).

## Criterios (separados entre si y separados de BPB)
1. coherencia (texto gramatical/legible)
2. responde-a-la-pregunta (trata lo preguntado)
3. retencion semantica (sentido preservado vs respuesta de referencia)
- Juicio humano/agente sobre muestras CIEGAS: muestras_ciegas.md presenta por prompt
  las 3 respuestas en orden permutado con semilla fija; la clave (clave_ciega.txt) se
  revela solo tras la inspeccion. Main inspecciona muestras; no se pasa test runner a Anto.
- Indicadores mecanicos (longitud en bytes, solape de palabras con la referencia) se
  computan como indicadores DEBILES declarados, no como prueba semantica.

## Cotas y archivo
- Cada generacion bajo timeout -k 2 30; total bajo guard2.sh 420 900 con sidecar.
- Archivo completo: eval_gen/ (90 respuestas, manifiesto con sha256, muestras TUI reales
  incluyendo fallos, log y sidecar).
- Sin escalar corpus ni nuevos ciclos hasta cerrar esta evaluacion.
