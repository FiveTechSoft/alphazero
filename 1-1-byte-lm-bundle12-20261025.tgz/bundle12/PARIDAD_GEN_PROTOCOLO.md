# PARIDAD-GEN — comprobación pequeña CONGELADA antes de ejecutar (2026-10-25 09:23 CET)
Sin entrenamiento. No busca bug: verifica que la ruta pesos/encoding/decoding funciona
contra un control conocido (memorización de train), para interpretar el 0/90 como
negativo funcional real y no como pipeline roto. La hipótesis de pipeline/tokenizer fue
RETIRADA por el evaluador; esto es verificación, no diagnóstico previo.

## P1 identidad de pesos (ya medida, se declara): promoted == curA (sha256 2394078e...d05a).
   Parámetros leídos DEL CHECKPOINT (campo h): d=32/H=64/T=64 = 43.456 params (base/A/B).
## P2 control conocido (memorización train): pares train.txt idx 0,1,2 (fijos, declarados);
   modelo base; temp=0.05 (argmax aproximado; temp=0 no soportado: división por cero);
   seed=7; n=200; formato "U: q\nA: ".
   CRITERIO FIJADO: ruta OK si el prefijo generado coincide con la respuesta entrenada
   (ratio de bytes exactos del prefijo común / 100 primeros bytes) >= 0.5 en >=2 de 3.
   Si no: se documenta sospecha de pipeline SIN afirmar bug.
## P3 paridad de formato: el formato servido es idéntico al usado en EVAL-GEN-1 (declarado).
