# EVAL-GEN-1 — juicios ciegos (reportados por main, 2026-10-25 09:21-09:22 CET)

- Evaluador ciego (agent-01M5S2B3TPBC89GFC262Z6XKDV), 30 prompts x 3 respuestas, SIN clave: 0/90 calificadas como conversacion coherente, pertinente o correccion verificable. Sin ranking entre modelos. Juicios FIJADOS antes de revelar la clave.
- Union clave+juicios tras fijacion: 0/30 para CADA modelo base/A/B; sin ranking. Clave revelada solo a main tras fijarse los juicios; NO revelada al evaluador.
- La referencia humana se etiqueta como CORRECCION PUNTUAL, NO retencion longitudinal.
- El evaluador propuso y RETIRO la hipotesis de tokenizer/pipeline roto y una "afirmacion estadistica": no se toma como diagnostico.
- Lectura: la evaluacion SI informa un negativo funcional (no consigue lenguaje aunque mejora BPB); no declara la metrica inutil.
