# HIP-B — LIMITACIONES DEL PAQUETE DE JUICIO (2026-10-25)
- El resultado HIP-B es DESVIADO: trayectoria troceada 480+960+960 (Adam reiniciado por
  bloque, RNG de muestreo distinto por bloque), no el run continuo de 2400 pasos congelado.
  Los juicios describen SOLO las 180 respuestas de esa trayectoria (y paso0/gru2b como
  controles); no son confirmatorios del protocolo original ni de la escala en general.
- Juicios fijados ANTES de revelar la clave (orden temporal declarado); clave adjunta tras
  fijado, permutation seed 4242.
- Ambiguedad conservada: 9 respuestas en posicion R1 con juicio ambiguo entre C0 y C1;
  los conteos de la tabla usan el juicio fijado, la ambiguedad queda registrada aqui.
- 6 juicios P1 corresponden a eco lexico generico (no tematico): ambiguos, NO exitos.
- Exito funcional (C2 y P2): 0/180. Correccion puntual: no aplica (sin contenido
  recuperable con formulacion unica).
- Juicio cualitativo: sin inferencias de causa, capacidad, bug o arquitectura.
