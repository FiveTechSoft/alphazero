# Informe interno - revision semantica ciega HIP-B (muestras b/c, gen2)

Revision semantica de las 180 respuestas anonimizadas del archivo adjunto (60 prompts x 3 posiciones).
Evaluacion ciega: sin buscar la clave, sin conocer resultados previos. Juicios fijados antes de cualquier revelado de clave.
Alcance: solo este documento. Sin inferencias sobre causas, capacidad, bugs, estadisticas ni arquitectura.

## Criterio aplicado (fijado previamente)

- C0: sin sentido. Incluye salida binaria/mojibake no legible y texto sin ningun fragmento entendible.
- C1: fragmentos locales entendibles (sintagmas de 2-4 palabras con sentido aislado) sin respuesta coherente global.
- C2: respuesta coherente global.
- P0: sin relacion con el prompt.
- P1: eco lexico o vinculacion parcial, sin respuesta util. Criterio operativo: presencia de un token del prompt (lexema identico o variante flexiva clara) reutilizado en la respuesta, aunque sea vocabulario generico de asistente. Los casos P1 por eco generico (no tematico) se marcan como ambiguos.
- P2: responde la pregunta.
- Exito funcional = C2 y P2.
- Correccion puntual: solo con contenido verificable y formulacion unica valida; no se evalua retencion longitudinal.

## Resultado global (n=180)

| Escala | 0 | 1 | 2 |
|---|---|---|---|
| C (coherencia) | 61 | 119 | 0 |
| P (pertinencia) | 174 | 6 | 0 |

Exito funcional (C2 y P2): 0 de 180 (0 en cada posicion).
Correccion puntual: no aplica en ningun caso. Ninguna respuesta contiene afirmacion verificable con formulacion unica valida que corregir.

## Conteos por posicion

Posicion 1 (n=60): C0=22, C1=38, C2=0 | P0=55, P1=5, P2=0 | exito funcional=0
Posicion 2 (n=60): C0=16, C1=44, C2=0 | P0=60, P1=0, P2=0 | exito funcional=0
Posicion 3 (n=60): C0=23, C1=37, C2=0 | P0=59, P1=1, P2=0 | exito funcional=0

Nota descriptiva: cada una de las 60 secciones contiene exactamente una respuesta C0 por mojibake/binaria; las otras dos son texto seudoespanol C1 (salvo C19-R1, ver ambiguos). No se infiere causa.

## Casos con puntuacion no nula distintos de C1/P0 (para revisar)

Los unicos casos por encima del patron base (C1/P0) son 6 casos P1, todos con C1. Extractos:

1. B5-R3. Prompt: "Hola, bienvenido/a a Open Assistant. En que te puedo ayudar?"
   Extracto: "Que puedes preguntas en algunas mas por la actualidad de la pregunta de la contina..."
   Eco: marco interrogativo "Que puedes..." sobre "En que te puedo...". Eco debil, generico. Ambiguo.

2. B6-R1. Prompt: "Hola, bienvenido/a a Open Assistant. En que te puedo ayudar?"
   Extracto: "No te ayudarte a la contradada que el temacion de la bien a la funcion de la pregunta..."
   Eco: "ayudarte" verbatim del prompt. Token generico. Ambiguo.

3. B9-R1. Prompt: "Gracias por la aclaracion"
   Extracto: "Har a talo de la cartosa de la gracia de la malejar la esto..."
   Eco: "gracia" por "Gracias" (mismo lexema). Ambiguo.

4. B11-R1. Prompt: "Hola Giovanna Day! En que puedo ayudarte hoy?"
   Extracto: "...de la programacion de la prover que te ayudarte alguna de la problema..."
   Eco: "ayudarte" verbatim del prompt. Token generico. Ambiguo.

5. B30-R1. Prompt: "Gracias por tu respuesta."
   Extracto: "Si tienes algo mas para el arcias de la mas tema de la internos de la persona de la preciente a la respuesta de la recomiento..."
   Eco: "respuesta" verbatim del prompt. Ambiguo.

6. C4-R1. Prompt: "...que otra informacion necesitas para ser mas especifico?..."
   Extracto: "...la compresa de la sisten en la pregunta de la sigle de la versica de actual de la informacion de lo que es el problema..."
   Eco: "informacion" verbatim del prompt (texto identico al de B4-R1, donde no hay eco). Ambiguo.

No hay ningun caso P2 ni C2. No hay otros casos no nulos: el resto es C0/P0 (61) o C1/P0 (113).

## Casos de criterio ambiguo

1. C19-R1: "Muenta hadia!" (prompt: "Es us buen punto"). Asignado C0 (sin fragmento local entendible). Lectura alternativa C1 si se acepta "Muenta" como deformacion de "Cuenta"; no verificable, se mantiene C0. Si se contara C1, Posicion 1 quedaria C0=21/C1=39. P0 en cualquier caso.
2. Los 6 casos P1 anteriores: el eco es de vocabulario generico de asistente (ayudarte, gracia, respuesta, informacion), no de tokens tematicos del prompt. Con un criterio estricto de eco tematico serian P0 y P quedaria P0=180. Decision fijada: P1 con marca de ambiguo, para que el revisor decida.
3. C13-R1: "...de estuenta de la hablida de estar..." (prompt: "...un peine que habla"). "hablida" es deformacion posible de "habla"; no verificable como token, mantenido P0.
4. C18-R3: "1 - Chacia de la Ghat-GP- Chas" (prompt: "Cual es la mejor forma de estudiar?"). Contiene token deformado reconocible ("Ghat-GP") que no procede del prompt; sin vinculacion con la pregunta. C1, P0.
5. C26-R2: "Si te problema de la programacion de luz..." (prompt: "Crees que vivimos en una simulacion?..."). "programacion" tiene vinculacion tematica lejana con "simulacion" pero no es eco lexico ni aporta respuesta util; mantenido P0.
6. C7-R1: "1. CAL/100 gra de estuentar..." (prompt: IA y trabajo de programadores). Formato de enumeracion sin contenido; "CAL/100" no es contenido verificable. C1, P0.
7. C28-R1: "El 20202/2023002/203/203 % de la terto..." (prompt: codigo JS que imprime "banana"). Numeros sin vinculacion con el codigo; no verificables. C1, P0.

## Ejemplos representativos

- C0 binario/mojibake (61 casos): B1-R2 comienza con bytes no imprimibles y caracteres de reemplazo (�), sin contenido textual. Variante corta: B28-R2 y C28-R3 son solo "�" (1-2 caracteres); B4-R2 y C4-R2: "S�8��"; B13-R2 y C13-R3: "a��+��..." seguido de "Ļ6Z".
- C1 seudoespanol generico (113 casos): B1-R1: "No ha necesitas preguntas se como es un tienes es un como es estabre de la problema de la como el como de la promeston de la partividad de la consegra de la redicion..." Sintagmas locales entendibles ("de la informacion", "es un problema") sin coherencia global ni contenido tematico.
- C1 con formato de lista: C16-R3 ("1 - Chacial y que tado de estras..."), C27-R1 ("1 - Chacias a prosente..."), C7-R1 ("1. CAL/100 gra...").
- P1 por eco: ver los 6 casos anteriores.

## Notas descriptivas (sin inferencia)

- Muchas respuestas C1 y varias C0 se repiten verbatim entre secciones B y C con prompts distintos (p. ej. B2-R1 = C2-R2; B4-R1 = C4-R1; B17-R1 = C17-R1; B30-R1 = C30-R2; B1-R2 = C1-R3; B14-R2 = C14-R1; B29-R1 = C29-R1). La cabecera del archivo indica "orden permutado por prompt, semilla fija". Se reporta solo como hecho observable, relevante si la revision posterior compara por prompt.
- Ninguna respuesta contiene datos facticos (cifras, fechas, nombres propios correctos) salvo los fragmentos anomalos ya citados (C7-R1, C18-R3, C28-R1), ninguno verificable.

## Tabla completa (180 respuestas)

Leyenda: G = C0 binario/mojibake; W = C1 seudoespanol; * = P1 (eco, ambiguo); ** = C19-R1 C0 ambiguo. Todo lo no marcado es P0.

| Seccion | R1 | R2 | R3 |
|---|---|---|---|
| B1 | W | G | W |
| B2 | W | W | G |
| B3 | G | W | W |
| B4 | W | G | W |
| B5 | G | W | W* |
| B6 | W* | W | G |
| B7 | W | W | G |
| B8 | G | W | W |
| B9 | W* | W | G |
| B10 | W | W | G |
| B11 | W* | W | G |
| B12 | W | W | G |
| B13 | W | G | W |
| B14 | W | G | W |
| B15 | W | G | W |
| B16 | G | W | W |
| B17 | W | W | G |
| B18 | W | W | G |
| B19 | G | W | W |
| B20 | G | W | W |
| B21 | G | W | W |
| B22 | G | W | W |
| B23 | W | W | G |
| B24 | G | W | W |
| B25 | G | W | W |
| B26 | W | W | G |
| B27 | W | G | W |
| B28 | W | G | W |
| B29 | G | W | W |
| B30 | W* | G | W |
| C1 | W | W | G |
| C2 | G | W | W |
| C3 | W | G | W |
| C4 | W* | G | W |
| C5 | W | W | G |
| C6 | G | W | W |
| C7 | W | W | G |
| C8 | W | G | W |
| C9 | G | W | W |
| C10 | W | W | G |
| C11 | W | W | G |
| C12 | W | W | G |
| C13 | W | W | G |
| C14 | G | W | W |
| C15 | W | G | W |
| C16 | G | W | W |
| C17 | W | G | W |
| C18 | G | W | W |
| C19 | ** | W | G |
| C20 | W | G | W |
| C21 | G | W | W |
| C22 | W | G | W |
| C23 | W | G | W |
| C24 | G | W | W |
| C25 | G | W | W |
| C26 | W | W | G |
| C27 | W | W | G |
| C28 | W | W | G |
| C29 | G | W | W |
| C30 | W | W | G |
