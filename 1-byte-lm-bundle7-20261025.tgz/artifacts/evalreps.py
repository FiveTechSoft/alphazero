import subprocess
def acc(model, fname):
    lines=open(fname).read().strip().split('\n')
    ok=0;n=0
    for i in range(0,len(lines),2):
        q=lines[i][3:]; a=lines[i+1][3:]
        r=subprocess.run(['/tmp/blm/mz','d1gru','-mode','gen','-in',model,
            '-prompt','U: '+q+'\nA: ','-n','60','-temp','0.3','-seed','1'],
            capture_output=True,text=True,timeout=30)
        ok+=r.stdout.strip()==a.strip(); n+=1
    return ok
print('modelo   P1    P3    P2')
for R in [1,2,3]:
    for arm in ['A','B']:
        m='blm_gru_r%s%d.json'%(arm,R)
        print('rep%d-%s   %2d/16 %2d/16 %2d/16'%(R,arm,acc(m,'sweep8_train.txt'),acc(m,'sweep8_p3.txt'),acc(m,'sweep8_held.txt')))
