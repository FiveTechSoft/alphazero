import subprocess, random, re, sys
roundnum=sys.argv[1]; base=sys.argv[2]
random.seed(900+int(roundnum))
TEMPLATES={'4':[('que codigo tiene %s?','el codigo de %s es %s.'),('de que color es %s?','el color de %s es %s.')],
           '5':[('podrias decirme el codigo de %s?','el codigo de %s es %s.'),('podrias decirme el color de %s?','el color de %s es %s.')]}
asig={}
lines=open('sweep8_train.txt').read().strip().split('\n')
for i in range(0,len(lines),2):
    m=re.match(r'U: (codigo|color) de (\w+)\?', lines[i])
    a=re.match(r'A: el (codigo|color) de (\w+) es ([\w]+)\.', lines[i+1])
    if m and a: asig.setdefault(m.group(2),{})[m.group(1)]=a.group(3)
qs=[]
for o,d in asig.items():
    for t,(qt,at) in enumerate(TEMPLATES[roundnum]):
        if t==0: qs.append((qt%o, at%(o,d['codigo'])))
        else: qs.append((qt%o, at%(o,d['color'])))
def fnv(s):
    h=2166136261
    for b in s.encode(): h=((h^b)*16777619)&0xFFFFFFFF
    return h
K=8; pool=[]
for q,a in qs:
    for s in range(1,K+1):
        r=subprocess.run(['/tmp/blm/mz','d1gru','-mode','gen','-in',base,
            '-prompt','U: '+q+'\nA: ','-n','60','-temp','1.0','-seed',str(int(roundnum)*10000+s)],
            capture_output=True,text=True,timeout=30)
        out=r.stdout.strip(); pool.append((q,a,out,out==a))
hits=[p for p in pool if p[3]]
cov=len(set(q for q,_,_,ok in pool if ok))
ctrl=random.sample(pool,len(hits))
def w(fn,rows):
    with open(fn,'w') as f:
        for q,a,out,_ in rows: f.write('U: '+q+'\nA: '+out+'\n')
w('iter%s_A.txt'%roundnum,hits); w('iter%s_B.txt'%roundnum,ctrl)
with open('sweep8_p%s.txt'%roundnum,'w') as f:
    for q,a in qs: f.write('U: '+q+'\nA: '+a+'\n')
print('ronda%s base=%s pool_ok=%d/%d cobertura=%d/16 brazo=%d'%(roundnum,base,len(hits),len(pool),cov,len(hits)))
