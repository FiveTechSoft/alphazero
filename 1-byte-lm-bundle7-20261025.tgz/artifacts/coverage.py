import subprocess, sys, re
model, K, temp = sys.argv[1], int(sys.argv[2]), float(sys.argv[3])
pairs=[]
lines=open('sweep8_held.txt').read().strip().split('\n')
for i in range(0,len(lines),2):
    q=lines[i][3:]; a=lines[i+1][3:]
    pairs.append((q,a))
hits=0; tot=0; detail=[]
for q,a in pairs:
    got=False
    for s in range(1,K+1):
        r=subprocess.run(['/tmp/blm/mz','d1gru','-mode','gen','-in',model,
            '-prompt','U: '+q+'\nA: ','-n','60','-temp',str(temp),'-seed',str(s)],
            capture_output=True,text=True,timeout=30)
        out=r.stdout.strip()
        if out==a.strip(): got=True; break
    hits+=got; tot+=1
    detail.append(('HIT ' if got else 'miss ')+q+' -> esperado: '+a)
print('modelo=%s K=%d temp=%.1f cobertura=%d/%d (%.1f%%)'%(model,K,temp,hits,tot,100.0*hits/tot))
for d in detail: print(d)
