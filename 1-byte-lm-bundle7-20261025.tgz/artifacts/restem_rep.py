import subprocess, random, re, sys
rep=int(sys.argv[1])
random.seed(700+rep)
asig={}
lines=open('sweep8_train.txt').read().strip().split('\n')
for i in range(0,len(lines),2):
    m=re.match(r'U: (codigo|color) de (\w+)\?', lines[i])
    a=re.match(r'A: el (codigo|color) de (\w+) es ([\w]+)\.', lines[i+1])
    if m and a: asig.setdefault(m.group(2),{})[m.group(1)]=a.group(3)
p3=[]
for o,d in asig.items():
    p3.append(('sabes el codigo de %s?'%o,'el codigo de %s es %s.'%(o,d['codigo'])))
    p3.append(('me dices el color de %s?'%o,'el color de %s es %s.'%(o,d['color'])))
K=8; pool=[]
for q,a in p3:
    for s in range(1,K+1):
        r=subprocess.run(['/tmp/blm/mz','d1gru','-mode','gen','-in','blm_gru_sweep8.json',
            '-prompt','U: '+q+'\nA: ','-n','60','-temp','1.0','-seed',str(rep*1000+s)],
            capture_output=True,text=True,timeout=30)
        out=r.stdout.strip(); pool.append((q,a,out,out==a))
hits=[p for p in pool if p[3]]
cov=len(set(q for q,_,_,ok in pool if ok))
ctrl=random.sample(pool,len(hits))
def w(fn,rows):
    with open(fn,'w') as f:
        for q,a,out,_ in rows: f.write('U: '+q+'\nA: '+out+'\n')
w('ra%d.txt'%rep,hits); w('rb%d.txt'%rep,ctrl)
print('rep%d pool_ok=%d/%d cov=%d/16 brazo=%d'%(rep,len(hits),len(pool),cov,len(hits)))
