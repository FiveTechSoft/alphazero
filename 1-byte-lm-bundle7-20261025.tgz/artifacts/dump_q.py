import subprocess,sys
model=sys.argv[1]; fname=sys.argv[2]
lines=open(fname).read().strip().split('\n')
for i in range(0,len(lines),2):
    q=lines[i][3:]; a=lines[i+1][3:]
    r=subprocess.run(['/tmp/blm/mz','d1gru','-mode','gen','-in',model,
        '-prompt','U: '+q+'\nA: ','-n','60','-temp','0.3','-seed','1'],
        capture_output=True,text=True,timeout=30)
    out=r.stdout.strip()
    print(('OK ' if out==a.strip() else 'XX ')+q+' => '+out+'   [gold: '+a.strip()+']')
