import subprocess,sys
def fnv(s):
    h=2166136261
    for b in s.encode(): h=((h^b)*16777619)&0xFFFFFFFF
    return h
def gen(model,q):
    r=subprocess.run(['/tmp/blm/mz','d1gru','-mode','gen','-in',model,
        '-prompt','U: '+q+'\nA: ','-n','280','-temp','0.3','-seed',str(fnv(q))],
        capture_output=True,text=True,timeout=30)
    return r.stdout.strip()
def acc(model, fname):
    lines=open(fname).read().strip().split('\n')
    ok=0;n=0
    for i in range(0,len(lines),2):
        ok+=gen(model,lines[i][3:])==lines[i+1][3:].strip(); n+=1
    return ok,n
if __name__=='__main__':
    for m in sys.argv[1:]:
        r=[acc(m,f)[0] for f in ['sweep8_train.txt','sweep8_p3.txt','sweep8_held.txt']]
        print('%-24s P1=%2d/16 P3=%2d/16 P2=%2d/16'%(m,r[0],r[1],r[2]))
