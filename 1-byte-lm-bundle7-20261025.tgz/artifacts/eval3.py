import subprocess
def acc(model, fname):
    lines=open(fname).read().strip().split('\n')
    ok=0; n=0
    for i in range(0,len(lines),2):
        q=lines[i][3:]; a=lines[i+1][3:]
        r=subprocess.run(['/tmp/blm/mz','d1gru','-mode','gen','-in',model,
            '-prompt','U: '+q+'\nA: ','-n','60','-temp','0.3','-seed','1'],
            capture_output=True,text=True,timeout=30)
        ok+= r.stdout.strip()==a.strip(); n+=1
    return '%d/%d'%(ok,n)
print('modelo            P1(train)  P3(trabajo)  P2(apartado)')
for m,tag in [('blm_gru_sweep8.json','base'),('blm_gru_restemA.json','A-filtrado'),('blm_gru_restemB.json','B-sinfiltrar'),('blm_gru_restemA2.json','A2-replay'),('blm_gru_restemB2.json','B2-replay')]:
    print('%-16s  %-9s  %-11s  %-9s  [%s]'%(tag,acc(m,'sweep8_train.txt'),acc(m,'sweep8_p3.txt'),acc(m,'sweep8_held.txt'),m))
