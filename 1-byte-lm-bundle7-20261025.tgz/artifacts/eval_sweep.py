import subprocess, sys, random
M = sys.argv[1]; N = int(sys.argv[2]); seed = int(sys.argv[3])
rng = random.Random(seed)
objs = rng.sample(["lapiz","mesa","silla","libro","casa","arbol","coche","reloj","puerta","ventana",
 "gato","perro","flor","nube","rio","monte","playa","bosque","calle","plaza",
 "tren","avion","barco","llave","carta","mapa","foto","radio","tele","lampara",
 "copa","plato","tenedor","cuchillo","vaso","botella","caja","bolsa","saco","tubo",
 "cable","motor","rueda","freno","farol","puente","torre","muro","techo","suelo"], N)
colores = ["rojo","azul","verde","blanco","negro","gris","rosa","marron","celeste","dorado"]
asig = {o:(rng.randint(100,999), rng.choice(colores)) for o in objs}
def gen(q):
    r = subprocess.run(["/tmp/blm/mz","d1gru","-mode","gen","-in",M,"-prompt",f"U: {q}\nA: ",
                        "-n","60","-temp","0.3","-seed","1"], capture_output=True, text=True, timeout=60)
    return r.stdout.strip()
okP1c=okP1col=okP2c=okP2col=0
for o,(c,col) in asig.items():
    if str(c) in gen(f"codigo de {o}?"): okP1c+=1
    if col in gen(f"color de {o}?"): okP1col+=1
    if str(c) in gen(f"cual es el codigo de {o}?"): okP2c+=1
    if col in gen(f"dime el color de {o}"): okP2col+=1
print(f"memorizacion P1: codigo {okP1c}/{N}, color {okP1col}/{N}")
print(f"parafrasis P2 (APARTADA): codigo {okP2c}/{N}, color {okP2col}/{N}")
