#!/usr/bin/env python3
# gen_evalconf4.py — evalconf4 FRESCO para E7 (L4/L5/L6/L7, 48 c/u).
# Regla v3 IDENTICA: 24 por operador por longitud; unicos globales; skip
# determinista si colision con prior o usados. Exclusion: operandos Y reversos
# vs TODAS las superficies previas (evalconf v1/v2/v3) y corpus de training
# (replay/master_mix*.txt). Palindromos skip. Letras repetidas declaradas, no filtradas.
import random, re, json, hashlib, glob, os
used=set()
for f in glob.glob('evalconf*_48.txt') + glob.glob('replay/master_mix*.txt'):
    for ln in open(f):
        m=re.search(r"(?:repite|invierte) '([a-z]+)'", ln)
        if m: used.add(m.group(1)); used.add(m.group(1)[::-1])
print('superficies previas excluidas (op+reverso):', len(used))
SEED=20261102
res={}
for L in (4,5,6,7):
    rng=random.Random(SEED+L)
    got={'repite':[], 'invierte':[]}
    skips=0
    while len(got['repite'])<24 or len(got['invierte'])<24:
        w=''.join(rng.choice('abcdefghijklmnopqrstuvwxyz') for _ in range(L))
        if w in used or w==w[::-1]: skips+=1; continue
        used.add(w); used.add(w[::-1])
        op='repite' if len(got['repite'])<=len(got['invierte']) else 'invierte'
        if len(got[op])<24: got[op].append(w)
        else: skips+=1
    lines=[]
    for op in ('repite','invierte'):
        for w in got[op]:
            t=w if op=='repite' else w[::-1]
            lines.append(f"U: {op} '{w}'"); lines.append(f"A: {t}")
    fn=f'evalconf4_L{L}_48.txt'
    open(fn,'w').write('\n'.join(lines)+'\n')
    h=hashlib.sha256(open(fn,'rb').read()).hexdigest()
    reps=sum(1 for w in got['repite']+got['invierte'] if len(set(w))<len(w))
    res[fn]={'sha256':h,'pares':48,'repite':24,'invierte':24,'palindromos':[],'con_letras_repetidas':reps,'skips':skips}
    print(fn, h[:16], 'reps:',reps,'skips:',skips)
# manifiesto v4: registra ANTES de cualquier generacion de modelo sobre estos ficheros
man=json.load(open('evalconf_MANIFIESTO.json'))
man['archivos'].update(res)
man['version']=4
man['nota']='v4: +4 ficheros evalconf4 (E7 DISENO, fresh incl L7 descriptivo); semanticas del oraculo INALTERADAS; registro ANTES de cualquier generacion'
man['seed_e4']=SEED
json.dump(man,open('evalconf_MANIFIESTO.json','w'),indent=1)
print('manifiesto v4:', len(man['archivos']),'ficheros')
