#!/bin/bash
# Asserts en caliente con EXPECTED EXPLICITOS (inyectados por cycle.sh).
# Base: steps/seq_pos. Si EXPECT_SEQSHA/EXPECT_SEQEXTPREV definidos (produccion),
# verifica ademas: seq_sha, seq_ext_prev persistido, adam.t, copy.t, esquema copy
# completo y estado GRU fiel (shapes). ckpt_version=2.
set -e
python3 - <<'PYEOF'
import json, os
c=json.load(open(os.environ['ASSERT_CK']))
es=int(os.environ['EXPECT_STEPS']); ep=int(os.environ['EXPECT_SEQPOS'])
assert c.get('steps')==es, ('steps', c.get('steps'), es)
assert c.get('seq_pos')==ep, ('seq_pos', c.get('seq_pos'), ep)
if os.environ.get('EXPECT_SEQSHA'):
    assert c.get('seq_sha')==os.environ['EXPECT_SEQSHA'], ('seq_sha', c.get('seq_sha'))
    assert c.get('seq_ext_prev')==os.environ['EXPECT_SEQEXTPREV'], ('seq_ext_prev', c.get('seq_ext_prev'))
    assert c.get('ckpt_version')==2, 'ckpt_version'
    a=c.get('adam'); assert isinstance(a,dict) and a.get('t')==es, ('adam.t', a and a.get('t'))
    assert isinstance(a.get('m'),list) and len(a['m'])==9 and isinstance(a.get('v'),list) and len(a['v'])==9, 'adam m/v'
    cp=c.get('copy'); assert isinstance(cp,dict), 'seccion copy'
    assert cp.get('t')==ep, ('copy.t', cp and cp.get('t'))
    for key in ('wq','wk','mwq','vwq','mwk','vwk'):
        assert len(cp[key])==64 and len(cp[key][0])==64, key
    assert len(cp['wg'])==128, 'wg'
    for key in ('bg','mwg','vwg','mbg','vbg'):
        assert key in cp, ('copy schema incompleto', key)
    # estado GRU fiel (shapes fijos d=32 h=64)
    for key,n,m in (('wr',64,96),('wz',64,96),('wn',64,96),('wo',256,64)):
        assert len(c[key])==n and len(c[key][0])==m, ('gru',key)
    assert len(c['e'])==256 and len(c['e'][0])==32, 'embedding'
    for key,n in (('br',64),('bz',64),('bn',64),('bo',256)):
        assert len(c[key])==n, ('bias',key)
    assert c.get('d')==32 and c.get('h')==64, ('d/h', c.get('d'), c.get('h'))
PYEOF
