#!/bin/bash
# cycle.sh — composicion de ciclo de N bloques sobre engine.sh (misma semantica
# que E6, con los 5 defectos cerrados). SIN training real aqui: el trainer se
# inyecta como $TRAINER (comando), lo que permite fixtures con stub.
# Uso: cycle.sh run KINI KFIN | cycle.sh resume K | cycle.sh status
set -e; set -o pipefail
HERE=$(cd "$(dirname "$0")" && pwd)
. "$HERE/engine.sh"
CFG=$BLM_ROOT/cycle.env
[ -e "$CFG" ] || { echo "ENGINE-ERROR: falta $CFG" >&2; exit 70; }
. "$CFG"   # BASENUM STEPS0 SEQPOS0 BLOCKS S PER SEQ SEQPREV CORPUS CAPBLK CAPTOTAL TRAINER...

usage() { echo "uso: cycle.sh run KINI KFIN | resume K --token TOKEN --from train|assert|eval | status" >&2; exit 70; }
[ $# -ge 1 ] || usage
CMD=$1

ck_name() { printf 'ck_A%d.json' $((BASENUM + $1)); }   # naming correcto para K>=4 (A90..A94)

preflight() { # hashes + prefijo seq byte-exacto (cold prefix)
  [ "$(sha256sum "$CORPUS" | cut -d' ' -f1)" = "$CORPUSSHA" ] || { echo "ENGINE-ERROR corpus sha" >&2; exit 10; }
  [ "$(sha256sum "$SEQ" | cut -d' ' -f1)" = "$SEQSHA" ] || { echo "ENGINE-ERROR seq sha" >&2; exit 10; }
  head -"$SEQPOS0" "$SEQ" | cmp -s - "$SEQPREV" || { echo "ENGINE-ERROR seq prefijo != prev byte-exacto" >&2; exit 10; }
}

base_once() { # BASE0 una sola vez, marcador atomico condicionado a evidencia
  [ -e "$BLM_ROOT/.iv0" ] || date +%s > "$BLM_ROOT/.iv0"
  [ -e "$ST/base.marker" ] && return 0
  if [ "${1:-}" = require_done ]; then
    echo "ENGINE-ERROR: BASE0 requerido ya medido (run con KINI>1)" >&2; exit 20
  fi
  case "$(st_get base 0)" in
    none|failed) st_commit base 0 running;;
    *) echo "ENGINE-ERROR base en estado '$(st_get base 0)'" >&2; exit 20;;
  esac
  run_logged base0 $EVAL_BASE || { st_commit base 0 failed; para 50 "base0 (k0) fallo eval"; }
  # evidencia antes de marcador
  if ! { [ -s "$LOGS/base0.log" ] && grep -q . "$BLM_ROOT/resultados.txt" 2>/dev/null; }; then
    st_commit base 0 failed; para 50 "BASE0 sin evidencia; marcador NO escrito"
  fi
  echo "base0_ok $(date -Is)" > "$ST/base.marker.tmp"; mv "$ST/base.marker.tmp" "$ST/base.marker"
  st_transition base 0 running done
}

block() { # K attempt [token] — estados: none→train_running→train_committed→assert_ok→eval_ok
  local K=$1 A=$2 TOK=${3:-}
  local U=k$K
  local OUT=$BLM_ROOT/checkpoints/$(ck_name $K)
  local PREV
  if [ $K -eq 1 ]; then PREV=$BASECK; else PREV=$BLM_ROOT/checkpoints/$(ck_name $((K-1))); fi
  [ -e "$PREV" ] || { echo "ENGINE-ERROR PREV ausente: $PREV" >&2; exit 20; }
  local PSHA=$(sha256sum "$PREV" | cut -d' ' -f1)
  # presupuesto: proyeccion FUNDADA en bloques medidos (avg+18s margen, default 36)
  [ -e "$BLM_ROOT/.iv0" ] || date +%s > "$BLM_ROOT/.iv0"
  local EL=$(( $(date +%s) - $(cat "$BLM_ROOT/.iv0") ))
  local AVG
  AVG=$(awk -F= '/^segundos=/{s+=$2;c++} END{print (c>0)? int(s/c)+18 : 36}' "$BLM_ROOT/.blocktimes" 2>/dev/null || true)
  AVG=${AVG:-36}
  local REST=$(( (BLOCKS-K+1)*AVG ))
  [ $((EL+REST)) -gt ${CAPTOTAL:-300} ] && para 5 "proyeccion fundada ${EL}s+${REST}s(avg=${AVG}) > ${CAPTOTAL:-300}s"
  local T0=$SECONDS
  st_transition $U $A none train_running "parent_ck_sha256=$PSHA${TOK:+ scope_token=$TOK}"
  run_logged train_k$K $TRAINER -in "$PREV" -out "$OUT" -steps $S || {
    if [ -e "$OUT" ]; then
      # crash/fallo con checkpoint PRESENTE: ambiguo (updates comprometidos?) — NO auto-resume
      para 31 "k$K a$A train fallo CON ck presente (sha=$(sha256sum "$OUT" | cut -c1-16)): estado train_running preservado, AMBIGUO, resume manual requiere alcance"
    else
      st_commit $U $A failed "failed_stage=train train_committed=0 parent_ck_sha256=$PSHA"
      para 30 "k$K a$A train fallo sin ck (reentrenable con token de alcance)"
    fi
  }
  st_transition $U $A train_running train_committed "ck_sha256=$(sha256sum "$OUT" | cut -d' ' -f1) train_committed=1"
  ASSERT_CK="$OUT" EXPECT_STEPS=$((STEPS0 + S*K)) EXPECT_SEQPOS=$((SEQPOS0 + S*K)) \
    EXPECT_SEQSHA="${SEQEXTPREV:+${SEQSHA:-}}" EXPECT_SEQEXTPREV="${SEQEXTPREV:-}" \
    bash "$HERE/assert_ck.sh" || { st_commit $U $A failed "failed_stage=assert train_committed=1 ck_sha256=$(sha256sum "$OUT" | cut -d' ' -f1)"; para 40 "k$K a$A asserts (ck comprometido? resume manual, NUNCA reentrenar)"; }
  local DT=$((SECONDS-T0))
  echo "segundos=$DT" >> "$BLM_ROOT/.blocktimes"
  [ $DT -gt ${CAPBLK:-40} ] && { st_commit $U $A failed "failed_stage=cap_bloque train_committed=1 ck_sha256=$(sha256sum "$OUT" | cut -d' ' -f1)"; para 4 "bloque k$K ${DT}s > ${CAPBLK:-40}s cap"; }
  st_transition $U $A train_committed assert_ok
  run_logged eval_k$K $EVAL_BLOCK "$OUT" k$K || { st_commit $U $A failed "failed_stage=eval train_committed=1 ck_sha256=$(sha256sum "$OUT" | cut -d' ' -f1)"; para 50 "k$K a$A eval (reanudable SOLO eval, sin reentrenar)"; }
  st_transition $U $A assert_ok eval_ok "${TOK:+scope_token=$TOK}"
}

completion_report() { # completion por ESTADO REAL, nunca por rango
  local ok=1 K
  for K in $(seq 1 $BLOCKS); do
    if [ "$(st_get k$K 1)" = eval_ok ] || [ "$(st_get k$K 2)" = eval_ok ]; then :; else ok=0; break; fi
  done
  if [ $ok = 1 ]; then echo "CICLO COMPLETO ($BLOCKS bloques, corte=$(ck_name $BLOCKS))"
  else echo "ciclo INCOMPLETO (estado real en $ST/)"; fi
}

case "$CMD" in
  run)
    KINI=${2:?}; KFIN=${3:?}
    [ "$KINI" -ge 1 ] && [ "$KFIN" -le "$BLOCKS" ] && [ "$KINI" -le "$KFIN" ] || usage
    preflight
    if [ "$KINI" -gt 1 ]; then base_once require_done; else base_once; fi
    for K in $(seq "$KINI" "$KFIN"); do block $K 1; done
    completion_report
    ;;
  resume)
    K=${2:?}; shift 2
    TOKEN=""; FROM=""
    while [ $# -gt 0 ]; do
      case "$1" in
        --token) TOKEN=${2:?}; shift 2;;
        --from) FROM=${2:?}; shift 2;;
        *) usage;;
      esac
    done
    # El motor NUNCA concede reintentos automaticos: cada resume exige token de
    # alcance explicito (en produccion lo emite main; el fixture lo simula).
    [ -n "$TOKEN" ] || { echo "ENGINE-ERROR resume exige --token de alcance explicito" >&2; exit 60; }
    case "$FROM" in train|assert|eval) ;; *) echo "ENGINE-ERROR resume exige --from train|assert|eval" >&2; exit 70;; esac
    [ "$K" -ge 1 ] && [ "$K" -le "$BLOCKS" ] || usage
    [ -e "$ST/base.marker" ] || { echo "ENGINE-ERROR resume sin BASE0" >&2; exit 20; }
    cur=$(st_get k$K 1)
    case "$cur" in
      train_running)
        echo "ENGINE-ERROR resume k$K: attempt1 train_running = crash AMBIGUO (updates comprometidos?). NO auto-resume: escalar alcance" >&2; exit 60;;
      failed) ;;
      *) echo "ENGINE-ERROR resume k$K: attempt1 en '$cur' (exige train_running|failed)" >&2; exit 20;;
    esac
    grep -qE "k$K( |$)" "$BLM_ROOT/PARADAS.txt" 2>/dev/null || { echo "ENGINE-ERROR resume k$K sin PARADA registrada" >&2; exit 20; }
    [ "$(st_get k$K 2)" = none ] || { echo "ENGINE-ERROR k$K: ya existe attempt2 (sin 2o retry)" >&2; exit 20; }
    NOTE1=$(tail -1 "$ST/k$K.a1.phase")
    OUT=$BLM_ROOT/checkpoints/$(ck_name $K)
    case "$FROM" in
      train)
        echo "$NOTE1" | grep -q "failed_stage=train" || { echo "ENGINE-ERROR --from train exige attempt1 failed_stage=train (hay: $NOTE1)" >&2; exit 20; }
        echo "$NOTE1" | grep -q "train_committed=0" || { echo "ENGINE-ERROR --from train exige train_committed=0" >&2; exit 20; }
        [ ! -e "$OUT" ] || { echo "ENGINE-ERROR --from train con ck presente: AMBIGUO, escalar" >&2; exit 60; }
        preflight
        block $K 2 "$TOKEN"
        ;;
      assert|eval)
        echo "$NOTE1" | grep -q "failed_stage=$FROM" || { echo "ENGINE-ERROR --from $FROM exige attempt1 failed_stage=$FROM (hay: $NOTE1)" >&2; exit 20; }
        echo "$NOTE1" | grep -q "train_committed=1" || { echo "ENGINE-ERROR --from $FROM exige train_committed=1" >&2; exit 20; }
        [ -e "$OUT" ] || { echo "ENGINE-ERROR --from $FROM sin ck presente" >&2; exit 20; }
        rec=$(echo "$NOTE1" | grep -o 'ck_sha256=[0-9a-f]*' | cut -d= -f2)
        now=$(sha256sum "$OUT" | cut -d' ' -f1)
        [ "$rec" = "$now" ] || { echo "ENGINE-ERROR ck cambio desde el fallo (rec=${rec:0:12} now=${now:0:12}): escalar" >&2; exit 20; }
        preflight
        # NUNCA reentrenar: solo se re-ejecuta la etapa fallida sobre el MISMO ck
        st_transition k$K 2 none resume_$FROM "scope_token=$TOKEN desde=$FROM ck_sha256=$now (sin reentrenar)"
        if [ "$FROM" = assert ]; then
          ASSERT_CK="$OUT" EXPECT_STEPS=$((STEPS0 + S*K)) EXPECT_SEQPOS=$((SEQPOS0 + S*K)) \
            bash "$HERE/assert_ck.sh" || { st_commit k$K 2 failed "failed_stage=assert train_committed=1 ck_sha256=$now"; para 40 "k$K a2 re-assert sobre MISMO ck"; }
          st_transition k$K 2 resume_assert assert_ok
        fi
        run_logged eval_k$K $EVAL_BLOCK "$OUT" k$K || { st_commit k$K 2 failed "failed_stage=eval train_committed=1 ck_sha256=$now"; para 50 "k$K a2 eval"; }
        if [ "$FROM" = assert ]; then st_transition k$K 2 assert_ok eval_ok "scope_token=$TOKEN"
        else st_transition k$K 2 resume_eval eval_ok "scope_token=$TOKEN"; fi
        ;;
    esac
    # resto del rango con attempt 1
    for K2 in $(seq $((K+1)) $BLOCKS); do block $K2 1; done
    completion_report
    ;;
  status)
    for K in $(seq 1 $BLOCKS); do echo "k$K: a1=$(st_get k$K 1) a2=$(st_get k$K 2)"; done
    echo "base: $(st_get base 0) marker=$([ -e "$ST/base.marker" ] && echo si || echo no)"
    ;;
  *) usage;;
esac
