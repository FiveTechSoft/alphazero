#!/bin/bash
# Suite de fixtures SIN training real (stub). Aislamiento: ROOT propio + FIXTURE=1
# + verificacion de hashes del arbol real antes/despues.
set -u
H=$(cd "$(dirname "$0")" && pwd)
R=$H/t/root
PASS=0; FAILN=0
ok()   { PASS=$((PASS+1)); echo "PASS: $1"; }
bad()  { FAILN=$((FAILN+1)); echo "FAIL: $1"; }
chk()  { local d=$1; shift; if "$@" >/dev/null 2>&1; then ok "$d"; else bad "$d"; fi; }
chk_no() { local d=$1; shift; if "$@" >/dev/null 2>&1; then bad "$d"; else ok "$d"; fi; }

( cd /tmp/blm && find ciclo_e5 ciclo_e6 ciclo_conf2 replay pack38 -type f 2>/dev/null | sort | xargs sha256sum ) > /tmp/shas_pre_h2.txt

setup_root() { # $1=dir
  rm -rf "$1"; mkdir -p "$1"/{state,logs,checkpoints}
  ( cd "$1" && seq 1 10080 > seq9 && head -6048 seq9 > seq8 && echo data > master )
  local MSHA=$(sha256sum "$1"/master | cut -d' ' -f1)
  local SSHA=$(sha256sum "$1"/seq9 | cut -d' ' -f1)
  cat > "$1"/cycle.env <<ENVEOF
BLM_ROOT=$1
BASENUM=86
STEPS0=100
SEQPOS0=6048
BLOCKS=8
S=10
SEQ=$1/seq9
SEQPREV=$1/seq8
CORPUS=$1/master
CORPUSSHA=$MSHA
SEQSHA=$SSHA
BASECK=$1/checkpoints/ck_A86.json
TRAINER="bash $H/t/stub_train.sh"
EVAL_BASE="bash $H/t/stub_eval.sh $1 base0"
EVAL_BLOCK="bash $H/t/stub_eval.sh $1"
ENVEOF
  echo '{"steps":100,"seq_pos":6048}' > "$1"/checkpoints/ck_A86.json
}

mkdir -p $H/t
cat > $H/t/stub_train.sh <<'STUB1'
#!/bin/bash
while [ $# -gt 0 ]; do case "$1" in -in) IN=$2;; -out) OUT=$2;; -steps) S=$2;; esac; shift 2; done
N=$(basename "$OUT" .json); N=${N#ck_A}; K=$((N-86))
[ -n "${TRAINCOUNT:-}" ] && echo "TRAIN A$N" >> "$TRAINCOUNT"
if [ "${STUB_FAIL:-}" = "$K" ]; then echo "panic: runtime error: index out of range" >&2; exit 2; fi
python3 -c "
import json
c=json.load(open('$IN'))
s=$S
bad=${STUB_BADSHA:-0}
json.dump({'steps': c['steps']+s+bad, 'seq_pos': c['seq_pos']+s}, open('$OUT','w'))
print(f'FIN steps={s} duracion=0s')"
if [ "${STUB_FAILWRITE:-}" = "$K" ]; then echo "panic: post-commit crash" >&2; exit 2; fi
STUB1
cat > $H/t/stub_eval.sh <<'STUB2'
#!/bin/bash
[ -n "${EVALCOUNT:-}" ] && echo "EVAL $2" >> "$EVALCOUNT"
[ "${STUB_EVALFAIL:-0}" = 1 ] && exit 7
echo "$2 medido=ok" >> "$1/resultados.txt"
echo "FIN eval $2 ok"
STUB2
chmod +x $H/t/stub_train.sh $H/t/stub_eval.sh

export FIXTURE=1 BLM_ROOT_REAL=/tmp/blm

echo "=== F1 run completo 1-8 ==="
setup_root $R
( export BLM_ROOT=$R; bash $H/cycle.sh run 1 8 ) > $H/t/f1.out 2>&1
chk "run 1-8 exit 0" test $? -eq 0
chk "existe ck_A90 (K=4)" test -e $R/checkpoints/ck_A90.json
chk "existe ck_A94 (K=8)" test -e $R/checkpoints/ck_A94.json
chk_no "NO existe ck_A810" test -e $R/checkpoints/ck_A810.json
chk "completion COMPLETO" grep -q "CICLO COMPLETO (8 bloques" $H/t/f1.out
if python3 -c "import json; c=json.load(open('$R/checkpoints/ck_A94.json')); assert c['steps']==180 and c['seq_pos']==6128"; then ok "ck_A94 metadata exacta"; else bad "ck_A94 metadata"; fi

echo "=== F2 completion por estado real en rango parcial ==="
setup_root $R
( export BLM_ROOT=$R; bash $H/cycle.sh run 1 2 >/dev/null 2>&1 && bash $H/cycle.sh run 3 5 ) > $H/t/f2.out 2>&1
chk "rango [3,5] NO dice COMPLETO" bash -c "! grep -q 'CICLO COMPLETO' $H/t/f2.out"
chk "rango [3,5] dice INCOMPLETO" grep -q "ciclo INCOMPLETO" $H/t/f2.out
( export BLM_ROOT=$R; bash $H/cycle.sh run 6 8 ) >> $H/t/f2.out 2>&1
chk "tras [6,8] dice COMPLETO" grep -q "CICLO COMPLETO" $H/t/f2.out

echo "=== F3 BASE0: fallo sin marcador; KINI>1 sin marker ==="
setup_root $R
STUB_EVALFAIL=1 bash -c "export BLM_ROOT=$R; bash $H/cycle.sh run 1 1" >/dev/null 2>&1
chk_no "BASE0 fallo -> sin marker" test -e $R/state/base.marker
chk "BASE0 fallo -> PARADA registrada" grep -q "base0" $R/PARADAS.txt
setup_root $R
( export BLM_ROOT=$R; bash $H/cycle.sh run 1 1 >/dev/null 2>&1 )
rm $R/state/base.marker
( export BLM_ROOT=$R; bash $H/cycle.sh run 3 3 ) >/dev/null 2>&1
chk "KINI>1 sin marker -> exit != 0" test $? -ne 0

echo "=== F4 crash train k3 + resume unico ==="
setup_root $R
( export BLM_ROOT=$R; bash $H/cycle.sh run 1 2 >/dev/null 2>&1 )
STUB_FAIL=3 bash -c "export BLM_ROOT=$R; bash $H/cycle.sh run 3 8" >/dev/null 2>&1
chk "crash k3 -> PARADA k3" grep -qE "k3 " $R/PARADAS.txt
chk "crash k3 -> log captura panic" grep -q "panic: runtime error" $R/logs/train_k3.log
chk "crash k3 -> PIPESTATUS anotado" grep -q "PIPESTATUS cmd=2" $R/logs/train_k3.log
chk "estado k3.a1=failed" bash -c "[ \"$(head -1 $R/state/k3.a1.phase)\" = failed ]"
chk_no "sin ck_A89 tras crash" test -e $R/checkpoints/ck_A89.json
chk "journal a1: failed_stage=train train_committed=0" bash -c "tail -1 $R/state/k3.a1.phase | grep -q 'failed_stage=train train_committed=0'"
( export BLM_ROOT=$R; bash $H/cycle.sh resume 3 ) >/dev/null 2>&1
chk "resume SIN token -> exit 60" test $? -eq 60
( export BLM_ROOT=$R; bash $H/cycle.sh resume 3 --token FIX-T3 --from eval ) >/dev/null 2>&1
chk "--from eval en fallo train -> rechazado" test $? -eq 20
( export BLM_ROOT=$R; bash $H/cycle.sh resume 3 --token FIX-T3 --from train ) > $H/t/f4.out 2>&1
chk "resume k3 exit 0 y completa" grep -q "CICLO COMPLETO" $H/t/f4.out
chk "k3.a2=eval_ok" bash -c "[ \"$(head -1 $R/state/k3.a2.phase)\" = eval_ok ]"
chk "k3.a1 preservado (failed)" bash -c "[ \"$(head -1 $R/state/k3.a1.phase)\" = failed ]"
chk "token journalado en a2" bash -c "grep -q 'scope_token=FIX-T3' $R/state/k3.a2.phase"
( export BLM_ROOT=$R; bash $H/cycle.sh resume 3 --token FIX-T3b --from train ) >/dev/null 2>&1
chk "segundo resume k3 rechazado" test $? -ne 0
setup_root $R
( export BLM_ROOT=$R; bash $H/cycle.sh run 1 2 >/dev/null 2>&1 )
( export BLM_ROOT=$R; bash $H/cycle.sh resume 2 --token FIX-X --from eval ) >/dev/null 2>&1
chk "resume k2 en eval_ok rechazado" test $? -ne 0

echo "=== F5 aislamiento + prefijo frio ==="
( export BLM_ROOT=/tmp/blm; bash $H/cycle.sh status ) >/dev/null 2>&1
chk "FIXTURE=1 con ROOT real -> exit 90" test $? -eq 90
setup_root $R
( export BLM_ROOT=$R; bash $H/cycle.sh run 1 1 >/dev/null 2>&1 )
echo corrupto >> $R/seq8
( export BLM_ROOT=$R; bash $H/cycle.sh run 2 2 ) >/dev/null 2>&1
chk "prefijo seq roto -> exit 10" test $? -eq 10

echo "=== F6 asserts pillan metadata corrupta ==="
setup_root $R
( export BLM_ROOT=$R; bash $H/cycle.sh run 1 1 >/dev/null 2>&1 )
STUB_BADSHA=1 bash -c "export BLM_ROOT=$R; bash $H/cycle.sh run 2 2" >/dev/null 2>&1
chk "metadata corrupta -> exit 40 (asserts)" test $? -eq 40
chk "PARADA asserts registrada" grep -q "k2 a1 asserts" $R/PARADAS.txt

echo "=== F7 eval_fail -> resume SOLO eval, SIN reentrenar ==="
setup_root $R
( export BLM_ROOT=$R TRAINCOUNT=$R/counts.txt; bash $H/cycle.sh run 1 2 >/dev/null 2>&1 )
TRAINCOUNT=$R/counts.txt STUB_EVALFAIL=1 bash -c "export BLM_ROOT=$R TRAINCOUNT=$R/counts.txt; bash $H/cycle.sh run 3 3" >/dev/null 2>&1
chk "eval fail -> exit 50" test $? -eq 50
chk "journal a1: failed_stage=eval train_committed=1" bash -c "tail -1 $R/state/k3.a1.phase | grep -q 'failed_stage=eval train_committed=1'"
( export BLM_ROOT=$R TRAINCOUNT=$R/counts.txt; bash $H/cycle.sh resume 3 --token FIX-E3 --from eval ) > $H/t/f7.out 2>&1
chk "resume eval completa ciclo" grep -q "CICLO COMPLETO" $H/t/f7.out
chk "k3 NO reentrenado (1 solo TRAIN A89)" bash -c "[ \"$(grep -c 'TRAIN A89' $R/counts.txt)\" = 1 ]"
chk "k3.a2=eval_ok via resume" bash -c "[ \"$(head -1 $R/state/k3.a2.phase)\" = eval_ok ]"

echo "=== F8 assert_fail -> resume --from assert NUNCA reentrena ==="
setup_root $R
( export BLM_ROOT=$R TRAINCOUNT=$R/counts.txt; bash $H/cycle.sh run 1 1 >/dev/null 2>&1 )
TRAINCOUNT=$R/counts.txt STUB_BADSHA=1 bash -c "export BLM_ROOT=$R TRAINCOUNT=$R/counts.txt; bash $H/cycle.sh run 2 2" >/dev/null 2>&1
chk "assert fail -> exit 40" test $? -eq 40
chk "journal a1: failed_stage=assert" bash -c "tail -1 $R/state/k2.a1.phase | grep -q 'failed_stage=assert train_committed=1'"
( export BLM_ROOT=$R TRAINCOUNT=$R/counts.txt; bash $H/cycle.sh resume 2 --token FIX-A2 --from assert ) >/dev/null 2>&1
chk "re-assert sobre MISMO ck vuelve a fallar (exit 40)" test $? -eq 40
chk "k2 NO reentrenado (1 solo TRAIN A88)" bash -c "[ \"$(grep -c 'TRAIN A88' $R/counts.txt)\" = 1 ]"

echo "=== F9 crash train CON ck presente = AMBIGUO, sin auto-resume ==="
setup_root $R
( export BLM_ROOT=$R; bash $H/cycle.sh run 1 3 >/dev/null 2>&1 )
STUB_FAILWRITE=4 bash -c "export BLM_ROOT=$R; bash $H/cycle.sh run 4 4" >/dev/null 2>&1
chk "crash post-commit -> exit 31" test $? -eq 31
chk "estado k4.a1 preservado train_running" bash -c "[ \"$(head -1 $R/state/k4.a1.phase)\" = train_running ]"
( export BLM_ROOT=$R; bash $H/cycle.sh resume 4 --token FIX-C4 --from train ) >/dev/null 2>&1
chk "resume de train_running RECHAZADO (exit 60)" test $? -eq 60

echo "=== F10 tee/disk failure NO pasa como exito ==="
setup_root $R
chmod a-w $R/logs
( export BLM_ROOT=$R; bash $H/cycle.sh run 1 1 ) >$H/t/f10.out 2>&1
RC=$?; chmod u+w $R/logs
chk "tee falla -> exit != 0" test $RC -ne 0
chk "tee falla -> ENGINE-ERROR tee/log" grep -q "tee/log fallo" $H/t/f10.out
chk_no "tee falla -> BASE0 sin marker" test -e $R/state/base.marker

echo "=== F11 symlink a produccion canonicalizado -> exit 90 ==="
ln -sf /tmp/blm $H/t/linkreal
( export BLM_ROOT=$H/t/linkreal; bash $H/cycle.sh status ) >/dev/null 2>&1
chk "ROOT symlink a real -> exit 90" test $? -eq 90

echo "=== F12 ROOT no escribible -> exit 90 ==="
setup_root $R
chmod a-w $R
( export BLM_ROOT=$R; bash $H/cycle.sh status ) >/dev/null 2>&1
RC=$?; chmod u+w $R
chk "ROOT no escribible -> exit 90" test $RC -eq 90

echo "=== RESUMEN: $PASS pass, $FAILN fail ==="
( cd /tmp/blm && find ciclo_e5 ciclo_e6 ciclo_conf2 replay pack38 -type f 2>/dev/null | sort | xargs sha256sum ) > /tmp/shas_post_h2.txt
if cmp -s /tmp/shas_pre_h2.txt /tmp/shas_post_h2.txt; then echo "AISLAMIENTO OK: produccion intacta"; else echo "FAIL AISLAMIENTO"; FAILN=$((FAILN+1)); fi
exit $([ $FAILN = 0 ] && echo 0 || echo 1)
