#!/bin/bash
# engine.sh — motor minimo de estado explicito para ciclos de entrenamiento.
# Sin logica de dominio: transiciones de fase con precondicion, escritura
# atomica, logging completo (stdout+stderr+PIPESTATUS), codigos de salida por clase.
# Requiere: BLM_ROOT (directorio del ciclo; el fixture DEBE usar otro distinto
# del real y este motor lo verifica via BLM_ROOT_REAL si esta definido).
set -e; set -o pipefail

: "${BLM_ROOT:?define BLM_ROOT}"
BLM_ROOT=$(readlink -f "$BLM_ROOT")   # canonicaliza (symlink a produccion no se cuela)
if [ -n "${BLM_ROOT_REAL:-}" ]; then
  REAL=$(readlink -f "$BLM_ROOT_REAL")
  if [ "$BLM_ROOT" = "$REAL" ] && [ "${FIXTURE:-0}" = 1 ]; then
    echo "ENGINE-ERROR: FIXTURE=1 con BLM_ROOT canonical == real ($BLM_ROOT)" >&2; exit 90
  fi
fi
[ -w "$BLM_ROOT" ] || { echo "ENGINE-ERROR: BLM_ROOT no escribible ($BLM_ROOT)" >&2; exit 90; }
ST=$BLM_ROOT/state
LOGS=$BLM_ROOT/logs
mkdir -p "$ST" "$LOGS"

# Codigos de salida por clase (nunca ambiguos):
#  10 preflight/datos   20 precondicion de estado   30 train   40 assert
#  50 eval/gen/score    60 cap/presupuesto          70 uso/args  90 aislamiento

st_get() { # unit attempt -> imprime fase actual o "none"
  local f="$ST/$1.a$2.phase"
  [ -e "$f" ] && head -1 "$f" || echo none
}
st_expect() { # unit attempt fase_esperada
  local cur; cur=$(st_get "$1" "$2")
  [ "$cur" = "$3" ] || { echo "ENGINE-ERROR estado $1.a$2: esperaba '$3', hay '$cur'" >&2; exit 20; }
}
st_commit() { # unit attempt fase_nueva [nota] — transicion atomica tmp+mv
  { echo "$3"; [ -n "${4:-}" ] && echo "$4"; } > "$ST/$1.a$2.phase.tmp"
  mv "$ST/$1.a$2.phase.tmp" "$ST/$1.a$2.phase"
}
st_transition() { # unit attempt from to [nota]
  st_expect "$1" "$2" "$3"
  st_commit "$1" "$2" "$4" "${5:-}"
}

para() { # clase msg — registra parada y sale con codigo de clase
  local code=$1; shift
  echo "PARADA $(date -Is) $*" >> "$BLM_ROOT/PARADAS.txt"
  echo "PARADA: $*" >&2
  exit "$code"
}

run_logged() { # tag comando... — captura COMPLETA stdout+stderr, PIPESTATUS y presencia de salida
  local tag=$1; shift
  local log="$LOGS/$tag.log"
  set +e
  "$@" 2>&1 | tee "$log" | grep -E "${LOG_GREP:-.}" 
  local ps=("${PIPESTATUS[@]}")
  set -e
  echo "PIPESTATUS cmd=${ps[0]} tee=${ps[1]} grep=${ps[2]}" >> "$log"
  [ "${ps[1]}" = 0 ] || { echo "ENGINE-ERROR tee/log fallo ($tag, tee=${ps[1]}): logging NO garantizado, no se clasifica como exito" >&2; return 35; }
  [ "${ps[0]}" = 0 ] || { echo "ENGINE-ERROR comando fallo ($tag, exit=${ps[0]}); causa en $log" >&2; return 30; }
  [ "${ps[2]}" = 0 ] || { echo "ENGINE-ERROR salida sin lineas esperadas ($tag); ver $log" >&2; return 30; }
}
