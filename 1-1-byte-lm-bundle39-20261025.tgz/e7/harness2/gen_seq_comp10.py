#!/usr/bin/env python3
# gen_seq_comp10.py (v2 corregida) — seq_comp10 = PREFIJO seq9[:6048] VERBATIM
# (historia prev8, cursor 6048, via de reanudacion fiel ya probada) + segmento
# NUEVO de 4032 indices en 8 bloques de 504 con cuotas balanceadas:
#   por bloque: 126 natural + 63 por cada op-L DST (repite/invierte x L4/L5/L6)
#   cada par exactamente 2 exposiciones en el segmento; NINGUN par repetido
#   dentro de un bloque (ventana 63 < periodo 252; natural 126 < 504).
# Mismo master_mix9, mismas exposiciones totales por clase que E6. UNICO cambio: orden.
# SIN reset de seq_pos: cursor 6048; Adam/RNG/steps6528/copy6048 preservados; sin head nuevo.
import random, json, hashlib, re, collections
ls=open('replay/master_mix9.txt').read().split('\n')
pairs=[]
for i in range(0,len(ls)-1,2):
    m=re.match(r"U: (repite|invierte) '([a-z]+)'",ls[i])
    pairs.append((m.group(1),len(m.group(2))) if m else ('natural',0))
seq9=[int(l) for l in open('replay/seq_comp9.txt')]
prefix=seq9[:6048]
by=collections.defaultdict(list)
for idx,p in enumerate(pairs): by[p].append(idx)
SEED=20261101
seg=[]
for b in range(8):
    blk=[]
    nat=by[('natural',0)]
    rng=random.Random(SEED); p0=nat[:]; rng.shuffle(p0)
    blk+= [p0[(126*b+k) % 1008] for k in range(126)] if False else []
    # natural: lista doble, ventana [126b,126b+126)
    dbl=p0+p0
    blk+=dbl[126*b:126*b+126]
    for ci,c in enumerate([('repite',4),('invierte',4),('repite',5),('invierte',5),('repite',6),('invierte',6)]):
        rng=random.Random(SEED+1+ci); pp=by[c][:]; rng.shuffle(pp)
        d=pp+pp
        blk+=d[63*b:63*b+63]
    assert len(blk)==504, len(blk)
    assert len(set(blk))==len(blk), 'par repetido dentro de bloque'
    rb=random.Random(SEED+100+b); rb.shuffle(blk)
    seg+=blk
# verificaciones
expo=collections.Counter(seg)
assert all(v==2 for v in expo.values()) and len(expo)==2016, 'expos por par != 2'
tot=collections.Counter(pairs[i] for i in seg)
esperado={('natural',0):1008,('repite',4):504,('invierte',4):504,('repite',5):504,('invierte',5):504,('repite',6):504,('invierte',6):504}
assert dict(tot)==esperado, tot
for b in range(8):
    c=collections.Counter(pairs[i] for i in seg[b*504:(b+1)*504])
    assert c[('natural',0)]==126
    for cl in esperado:
        if cl[0]!='natural': assert c[cl]==63, (b,cl,c[cl])
# compatibilidad de cursor: indices del segmento dentro de mix9; prefijo verbatim
assert max(seg)<=2015 and min(seg)>=0
out=prefix+seg
assert len(out)==10080 and out[:6048]==prefix
open('replay/seq_comp10.txt','w').write(''.join(f"{i}\n" for i in out))
open('replay/seq8_prefijo6048.txt','w').write(''.join(f"{i}\n" for i in prefix))
h=hashlib.sha256(open('replay/seq_comp10.txt','rb').read()).hexdigest()
hp=hashlib.sha256(open('replay/seq8_prefijo6048.txt','rb').read()).hexdigest()
meta={'fichero':'replay/seq_comp10.txt','sha256':h,'lineas':10080,
 'prefijo':'seq9[:6048] VERBATIM (replay/seq8_prefijo6048.txt sha256 '+hp+'); cursor arranca en 6048; Adam/RNG/steps6528/copy6048 preservados; SIN head/semilla injertada',
 'segmento_nuevo':'indices [6048:10080], 8 bloques x 504','expos_por_par_segmento':2,
 'cuota_bloque':'126 natural + 63 por op-L DST (repite/invierte x L4/L5/L6); sin par repetido dentro de bloque',
 'totales_clase_segmento':{str(k):v for k,v in esperado.items()},
 'seed':SEED,'cambio_unico':'ORDEN del segmento nuevo vs seq9[6048:10080] de E6 (mismo master, mismas exposiciones)',
 'control':'trayectoria E6 archivada (seq_comp9, segmento verificado por tabla de exposicion real)'}
json.dump(meta,open('replay/seq_comp10_meta.json','w'),indent=1)
print('seq_comp10 v2 OK sha16',h[:16],'prefijo sha16',hp[:16])
print('bloque0:',dict(collections.Counter(pairs[i] for i in seg[:504])))
