#!/bin/bash
# eval_e7.sh CK TAG - forma evalu() de E6 con evalconf4 (fresh E7) + clasificador
# por caso + eos. n=12 temp=0 SIN truncar salidas, sin filtros correctores.
set -e
D=/tmp/blm; O=$D/ciclo_e7; CK=$1; TAG=$2
MZ=$D/mzab_v3; CH="-copyhead learn -copyseed 7"
cd $D
timeout -k 2 40 $MZ d1gru -mode genpairs -in "$CK" -corpus dst7_train504.txt -n 12 -temp 0 $CH > $O/gentrain_$TAG.txt 2>/dev/null
timeout -k 2 40 $MZ d1gru -mode genpairs -in "$CK" -corpus dst7_heldL48.txt -n 12 -temp 0 $CH > $O/genheldL_$TAG.txt 2>/dev/null
timeout -k 2 40 $MZ d1gru -mode genpairs -in "$CK" -corpus dst7_heldLong48.txt -n 12 -temp 0 $CH > $O/genheldLong_$TAG.txt 2>/dev/null
for L in 4 5 6 7; do
  timeout -k 2 40 $MZ d1gru -mode genpairs -in "$CK" -corpus evalconf4_L${L}_48.txt -n 12 -temp 0 $CH > $O/genec4_L${L}_$TAG.txt 2>/dev/null
done
TT=$(python3 dst6_score.py dst7_train504.txt $O/gentrain_$TAG.txt | python3 -c 'import json,sys; print(json.load(sys.stdin)["exact_total"])')
HL=$(python3 dst6_score.py dst7_heldL48.txt $O/genheldL_$TAG.txt | python3 -c 'import json,sys; print(json.load(sys.stdin)["exact_total"])')
HG=$(python3 dst6_score.py dst7_heldLong48.txt $O/genheldLong_$TAG.txt | python3 -c 'import json,sys; print(json.load(sys.stdin)["exact_total"])')
E4=$(python3 evalconf_score.py evalconf4_L4_48.txt $O/genec4_L4_$TAG.txt)
E5=$(python3 evalconf_score.py evalconf4_L5_48.txt $O/genec4_L5_$TAG.txt)
E6=$(python3 evalconf_score.py evalconf4_L6_48.txt $O/genec4_L6_$TAG.txt)
E7=$(python3 evalconf_score.py evalconf4_L7_48.txt $O/genec4_L7_$TAG.txt)
RT=$(timeout -k 2 30 $MZ d1gru -mode scorepairs -in "$CK" -corpus ciclo1_heldout100.txt $CH 2>/dev/null | awk '$1=="SCORE"{s+=$3;c++} END{printf "%.6f", s/c}')
[ -n "$RT" ] || { echo "PARADA-E7: bpb heldout $TAG vacio" >&2; exit 8; }
echo "== $TAG train504=$TT heldL48=$HL heldLong48=$HG bpb=$RT ec4L4=$E4 ec4L5=$E5 ec4L6=$E6 ec4L7=$E7"
echo "$TAG train504=$TT heldL48=$HL heldLong48=$HG bpb=$RT ec4L4=$E4 ec4L5=$E5 ec4L6=$E6 ec4L7=$E7" | tee -a $O/resultados_E7.txt >> $O/resultados.txt
for L in 4 5 6 7; do
  python3 eos_analisis.py evalconf4_L${L}_48.txt $O/genec4_L${L}_$TAG.txt "$TAG-EOS-L$L" >> $O/eos_E7.txt
  python3 harness2/evalconf_classify.py evalconf4_L${L}_48.txt $O/genec4_L${L}_$TAG.txt > $O/clase_${TAG}_L${L}.json
done
