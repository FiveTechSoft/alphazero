# ALIAS checkpoints E7 (naming normal printf, directorio ciclo_e7/checkpoints/)
# Identificacion por SHA completo; alias A87..A94 SOLO locales de este ciclo.
# FINAL8 = ck_A94: steps 10560, seq_pos 10080 (6528+4032 / 6048+4032 desde ck_A86).
ck_A87  sha256=2746a7048ccc76e3168797f3fcd7466507c2babfbf23ab596dc0486ec9da5d71  steps=7032  seq_pos=6552
ck_A88  sha256=9d622aac711efb1b6a30ed252f35ec0f4bd9b0e84c5b3e874df0d016b29edca7  steps=7536  seq_pos=7056
ck_A89  sha256=b858216059d24fc45c01c269050ba6e14f58e5a438a77873ec9e94a65dd921b6  steps=8040  seq_pos=7560
ck_A90  sha256=e10327f6b09c174d199149771343c60a3f165deb5467a557580283b0e5436195  steps=8544  seq_pos=8064
ck_A91  sha256=b2cb69840ddde707cb8bf57b504de0630de683b776a4ae5098a8373e9186b291  steps=9048  seq_pos=8568
ck_A92  sha256=d0c7a4a05f0784d49dc99f633aec333283341f1e2f58a509697aaff51c6d4319  steps=9552  seq_pos=9072
ck_A93  sha256=c664fc2d7ef81962a1f606111c630be11ab81082c7f8b88ba638cc50bfd84fbd  steps=10056  seq_pos=9576
ck_A94  sha256=555e1fc374c9c4ea540eed59e1d1a678bc8efdb01e8939d0d688674394391e5c  steps=10560  seq_pos=10080
