#!/bin/bash
# trainer_e7.sh - adapta la interfaz harness2 (-in -out -steps) a la invocacion
# EXACTA de E6 (mismos flags, mismo binario). K se deriva del nombre de salida.
set -e; set -o pipefail
D=/tmp/blm
while [ $# -gt 0 ]; do case "$1" in -in) IN=$2;; -out) OUT=$2;; -steps) S=$2;; esac; shift 2; done
N=$(basename "$OUT" .json); N=${N#ck_A}; K=$((N-86))
BINSHA=77d01528f9bb2f1eba0c7afaa4c914bcabd5d6f8b8deb642b1d59651481bf75d
[ "$(sha256sum $D/mzab_v3 | cut -d' ' -f1)" = "$BINSHA" ] || { echo "PARADA-E7: binario sha mismatch" >&2; exit 10; }
MIX8PREV=9fc4b760a2bcda9b405abf04f003536d6d27b2d7570f0e20ab29533cfa39baa3
SEQ8PREV=e7278e1061f7ef8c26965893e33bf8e1569f9479dab61c26541772979e0f7e76
PF=(); [ $K = 1 ] && PF=(-master-prev "$MIX8PREV" -seq-ext-prev "$SEQ8PREV")
cd $D
python3 - "E7$K" "$IN" "$OUT" "$S" "${PF[@]}" <<'RUNMZ'
import subprocess, resource, sys
tag, IN, OUT, S = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
args=["./mzab_v3","d1gru","-mode","train-pairs",
 "-corpus","replay/master_mix9.txt","-val","dst7_heldL48.txt",
 "-in",IN,"-out",OUT,"-steps",S,"-lr","0.003","-seed","7",
 "-master","replay/master_mix9.txt","-manifest","replay/man_mix9.txt",
 "-seq","replay/seq_comp10.txt"] + sys.argv[5:] + ["-copyhead","learn","-copyseed","7"]
r=subprocess.run(args)
kb=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
print(f"RSSMAX {tag} {kb} KiB")
if kb>921600: print(f"PARADA-E7: RSS {kb} KiB > 900MiB en {tag}"); sys.exit(11)
sys.exit(r.returncode)
RUNMZ
