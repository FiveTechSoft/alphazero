# PROTOCOLO E7 — brazo de orden balanceado (seq_comp10) desde ck_A86
## Objetivo
Comprobar si un orden de practica balanceado por bloque mantiene L5 y natural al
introducir L6, donde el orden secuenciado del ciclo E6 no lo hizo (criterios
FINAL8 predeclarados, identicos en forma a E6).
## Diseno
- UN brazo, 4032 updates (8 bloques x 504) desde ck_A86 PRESERVADO (sha256
  3b07a67ce51e55f22f414c0be0ef5749156ef3eb5afdeb96b5e912e7a1671a19), sin reset
  Adam/GRU/copy/RNG, mismo binario que E6 (mzab_v3 sha256 77d01528f9bb2f1e...).
- Mismo master_mix9 (2016 pares: 504 natural + 252x6 DST), mismas exposiciones
  totales por clase (2 por par). UNICO cambio: el orden del segmento nuevo.
- seq_comp10.txt (sha256 5230e4b038c9c13b07a2f3acfeb6b59ed5c2ffd39835a4978ddcad8295e45825):
  prefijo seq9[:6048] VERBATIM (byte-exacto, cursor 6048 preservado) + segmento
  nuevo [6048:10080] con 126 natural + 63 por op-L DST por bloque de 504; cada
  par exactamente 2 exposiciones; ningun par repetido dentro de un bloque.
  Seeds declaradas (replay/seq_comp10_meta.json).
- Control: trayectoria E6 archivada (misma base/updates/exposiciones, orden
  secuenciado medido en la tabla de exposicion real incluida en RESULTADOS_E7).
  Comparabilidad adicional: evalconf3 (los sets de E6) medidos en el corte E7.
- Evaluacion fresca: evalconf4 L4-L7 (48 c/u), seed 20261102, regla v3, exclusion
  operandos+reversos vs 4991 superficies previas, manifiesto v4 ANTES de gens.
- Inferencia: gen n=12 temp=0, salidas SIN truncar, sin filtros correctores.
  EOS = proxy por longitud de output (newline emitida), no logits.
- Clasificador por caso predeclarado: exact / dup1B / contenido_desplazado /
  truncada / otra.
## Criterios FINAL8 (predeclarados, veredicto SOLO en el corte)
ec4_L6 exact >= 40/48 y length_correct >= 40/48; ec4_L4 >= 40/48; ec4_L5 >= 40/48;
natural heldout100 bpb delta < +0.5 vs BASE0 (medido al inicio del ciclo);
ec4_L7 descriptivo. Sin picos intermedios como resultado.
## Caps
wall total 300s (incluye BASE0 + bloques), 40s por bloque, RSS 900MiB, timeout
externo 310s. Primer fallo = parada declarada, sin autorecuperacion.
## Limites declarados
1 brazo contra control archivado: evidencia acotada sobre ESTE cambio de orden,
no prueba causal global. Resultado positivo no implica RSI, habla, ni regla
universal. Resultado negativo no habria demostrado que el orden sea irrelevante.
El harness de ejecucion es nuevo (motor de estados con fixtures 47/47); el
binario driver es identico a E6; no se reclama identidad de runner.
