# RESULTADOS E7 — brazo orden balanceado (seq_comp10) desde ck_A86
Fecha: 2026-10-25. Ciclo: 8 bloques x 504 updates (4032) desde ck_A86 (sha256
3b07a67ce51e55f22f414c0be0ef5749156ef3eb5afdeb96b5e912e7a1671a19), SIN reset
Adam/GRU/copy/RNG. Mismo master_mix9 que E6; UNICO cambio: orden de la practica
(segmento seq[6048:10080] balanceado por bloque vs secuenciado en E6).

## Veredicto FINAL8 (corte = ck_A94, steps 10560, seq_pos 10080)
ck_A94 sha256 555e1fc374c9c4ea540eed59e1d1a678bc8efdb01e8939d0d688674394391e5c
Criterios predeclarados y resultado:
- ec4_L6 exact 43/48 (umbral >=40: OK); length_correct 46/48 (>=40: OK)
- ec4_L4 exact 47/48 (>=40: OK)
- ec4_L5 exact 45/48 (>=40: OK)
- natural heldout100 bpb 3.248968 vs BASE0 3.282555: delta -0.033587 (< +0.5: OK)
- ec4_L7 exact 0/48 (descriptivo, sin umbral)
VEREDICTO: POSITIVO (los cuatro criterios en el corte final).
dup1B (salida = primer byte duplicado + respuesta desplazada): 0 casos en todas
las clases y sets del corte (en E6 FINAL8 era 23/26 de los fallos L5).
Alcance del positivo: ESTE orden balanceado cumplio los criterios donde el orden
secuenciado de E6 no lo hizo, con misma base/updates/exposicion por clase. NO es
prueba causal global sobre el orden, NO es RSI, NO es regla universal: 1 brazo
contra control archivado. El negativo de E6 tampoco demuestra que el orden sea
irrelevante en general.

## Comparabilidad con E6 sobre los MISMOS sets (evalconf3, FINAL8)
| set | E7 (ck_A94) | E6 (ck_A814, archivado) |
| ec3_L4 | 48/48 | 48/48 |
| ec3_L5 | 44/48 | 22/48 |
| ec3_L6 | 47/48 | 48/48 |
| ec3_L7 |  0/48 |  0/48 |
| natural bpb | 3.248968 | 4.076114 |
| heldL48 | 48/48 | (E6: ver RESULTADOS_E6) |
| heldLong48 | 47/48 | 8/48 |

## Trayectoria por bloque (evalconf4, exact)
BASE0: train504=504/504 heldL48=48/48 heldLong48=24/48 bpb=3.282555 ec4L4=48/48 ec4L5=48/48 ec4L6=0/48 ec4L7=0/48
k1: train504=493/504 heldL48=48/48 heldLong48=38/48 bpb=3.353915 ec4L4=46/48 ec4L5=23/48 ec4L6=41/48 ec4L7=3/48
k2: train504=504/504 heldL48=48/48 heldLong48=48/48 bpb=3.277527 ec4L4=48/48 ec4L5=46/48 ec4L6=47/48 ec4L7=0/48
k3: train504=239/504 heldL48=21/48 heldLong48=13/48 bpb=3.609685 ec4L4=21/48 ec4L5=14/48 ec4L6=5/48 ec4L7=1/48 (caida transitoria)
k4: train504=406/504 heldL48=39/48 heldLong48=24/48 bpb=3.323163 ec4L4=33/48 ec4L5=25/48 ec4L6=24/48 ec4L7=0/48
k5: train504=502/504 heldL48=48/48 heldLong48=25/48 bpb=3.276961 ec4L4=48/48 ec4L5=27/48 ec4L6=28/48 ec4L7=0/48
k6: train504=462/504 heldL48=45/48 heldLong48=42/48 bpb=3.254378 ec4L4=42/48 ec4L5=42/48 ec4L6=44/48 ec4L7=0/48
k7: train504=501/504 heldL48=48/48 heldLong48=47/48 bpb=3.292427 ec4L4=48/48 ec4L5=37/48 ec4L6=46/48 ec4L7=0/48
k8: train504=502/504 heldL48=48/48 heldLong48=47/48 bpb=3.248968 ec4L4=47/48 ec4L5=45/48 ec4L6=43/48 ec4L7=0/48
(Caida transitoria k3 con recuperacion: dinamica intermedia; el veredicto es
solo del corte final. Valores completos en resultados_E7.txt.)

## Segmento E6 realmente ejecutado (seq9[6048:10080]) — tabla corregida
(prefijo [0:6048] = historia previa, no ejecutada en E6)
bloque | natural | L4(rep/inv)  | L5(rep/inv)  | L6(rep/inv)
  0    |    40   | 464(234/230) |    0         |    0
  1    |   216   | 288(142/146) |    0         |    0
  2    |   466   |    0         |  38( 34/  4) |    0
  3    |   286   |    0         | 212(179/ 33) |    6(  5/  1)
  4    |     0   |    1(  1/  0)| 477(291/186) |   26( 19/  7)
  5    |     0   |    4(  3/  1)| 281(  0/281) |  219(194/ 25)
  6    |     0   |   29( 12/ 17)|    0         |  475(286/189)
  7    |     0   |  222(112/110)|    0         |  282(  0/282)
Totales por clase: natural 1008; cada op-L DST 504; 2016 pares x 2 exposiciones.

## Segmento E7 (seq10[6048:10080]) — balanceado por bloque
Cada bloque: 126 natural + 63 por cada op-L DST (repite/invierte x L4/L5/L6).
Cada par exactamente 2 exposiciones; ningun par repetido dentro de un bloque.
Totales por clase IDENTICOS a E6.

## Presupuesto (caps predeclarados vs medido)
- wall total REAL del ciclo: 113s (17:06:32-17:08:25 CEST; cap 300s, incluye BASE0 + 8 bloques train+asserts+eval).
  Detalle de cronometria y acumuladores preservados en RELOJ_E7.txt (una cifra
  intermedia de 135s media hasta un chequeo posterior, no hasta el fin: corregida).
- por bloque: 9-10s (cap 40s)
- RSS max: 33040 KiB ~ 32.3MiB (cap 900MiB)
- 0 PARADAS de ejecucion; 0 retries; 1 nota operativa interna (lanzador) sin
  efecto en resultados, preservada PRIVADA fuera de este paquete. Cronometria:
  RELOJ_E7.txt. Unicidad de ejecucion verificada (1 train por bloque, cadena
  de reanudacion en logs, 0 procesos duplicados).

## Harness
Ejecucion con harness2 NUEVO (motor de estados explicitos: train_running /
train_committed / assert_ok / eval_ok, ledger por fases, logging stdout+stderr
completo con PIPESTATUS, markers atomicos, resume por etapa con control explicito de reintentos). El
driver/binario es IDENTICO a E6 (mzab_v3 sha256
77d01528f9bb2f1eba0c7afaa4c914bcabd5d6f8b8deb642b1d59651481bf75d); NO se
reclama identidad de runner: la paridad del harness nueva se sustenta en 47/47
fixtures con stubs (sin training real), declarado.
Asserts calientes por bloque (8/8 OK): steps=6528+504k, seq_pos=6048+504k,
copy.t=6048+504k, adam.t=6528+504k, seq_sha=seq_comp10, seq_ext_prev=seq8
persistido, esquema copy completo, estado GRU fiel (shapes), ckpt_version=2.

## Datos congelados (shas en preflight_E7.txt)
- master_mix9.txt sha 76b44ce2... (identico a E6); man_mix9 cf254b77...
- seq_comp10.txt sha 5230e4b038c9c13b07a2f3acfeb6b59ed5c2ffd39835a4978ddcad8295e45825
  = prefijo seq9[:6048] VERBATIM (byte-exacto vs replay/seq_comp8.txt) +
  segmento balanceado nuevo. Cursor arranca en 6048. Seeds declaradas
  (replay/seq_comp10_meta.json).
- evalconf4 L4-L7 fresco: seed 20261102, regla v3 identica, 0 colisiones con
  4991 superficies previas (operandos+reversos), registrado en
  evalconf_MANIFIESTO.json v4 ANTES de cualquier generacion.
- Inferencia: gen n=12 temp=0 sin truncar salidas; sin filtros correctores;
  EOS = proxy por longitud de output (newline emitida), no logits.
- Clasificador por caso predeclarado: exact / dup1B / contenido_desplazado /
  truncada / otra (validado contra gens archivadas E6).

## Archivos del ciclo
ciclo_e7/: resultados_E7.txt, resultados.txt, eos_E7.txt, clase_*.json
(clasificador por caso), genec4_* (BASE0,k1..k8), genec3_*_FINAL8 (comparable),
gentrain_*, genheldL_*, genheldLong_*, casos_fijos_e7.txt, preflight_E7.txt,
state/ (journal de fases), logs/ (stdout+stderr+PIPESTATUS), checkpoints/
ck_A87..A94.json, NOTA_revision_lanzador.txt, cycle.env, wrappers.
