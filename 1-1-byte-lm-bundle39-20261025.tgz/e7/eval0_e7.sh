#!/bin/bash
# eval0_e7.sh - BASE0 sobre ck_A86 PRESERVADO + guarda bpb historica (debe ser
# EXACTAMENTE 3.282555; si cambia, PARADA antes de cualquier update).
set -e
D=/tmp/blm; O=$D/ciclo_e7
BASESHA=3b07a67ce51e55f22f414c0be0ef5749156ef3eb5afdeb96b5e912e7a1671a19
[ "$(sha256sum $D/ciclo_e5/ck_A86.json | cut -d' ' -f1)" = "$BASESHA" ] || { echo "PARADA-E7: ck_A86 sha mismatch" >&2; exit 10; }
[ -e $O/.iv0 ] || date +%s > $O/.iv0
bash $O/eval_e7.sh $D/ciclo_e5/ck_A86.json BASE0
RT=$(sed -n "s/^BASE0 .*bpb=\([0-9.]*\) .*/\1/p" $O/resultados_E7.txt)
if [ "$RT" != "3.282555" ]; then
  echo "PARADA-E7: bpb BASE0=$RT != 3.282555 (A86 BASE historico); NINGUN update ejecutado" >&2
  exit 8
fi
echo "== BASE0 bpb=$RT == guarda historica OK"
