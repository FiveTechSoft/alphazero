# DIAGNOSTICO gap de condicionamiento por par (2026-10-25, sin entrenamiento)

Modo nuevo `gappairs` (d1gru): gap = LOSS(respuesta | pregunta BARAJADA) -
LOSS(respuesta | pregunta REAL), por par. Positivo = la pregunta verdadera
reduce la perdida (beneficio de contexto). Mismas respuestas, longitudes y
decoding en ambas ramas. Barajado DETERMINISTA por desplazamiento fijo
(seed+22, misma familia que la ablacion historica); asignacion identidad o
misma_normalizada = INVALIDO explicito, nunca ingerido. Cobertura de primer
byte (argmax tras el prompt vs byte real) declarada como metrica auxiliar.

Fixture POSITIVO: checkpoint memorizado conocido (control10): gap_media=0.2343
-> el instrumento detecta condicionamiento cuando existe. 5 fixtures PASS;
suite completa verde antes de medir.

## Medicion (DEV100, conjunto de seleccion ya expuesto; FINAL100 no tocado)

Misma poblacion (100 pares), misma asignacion barajada (seed 20261025,
offset 4) para los 5 checkpoints: comparacion emparejada. 0 invalidos / 100
validos en los 5.

| checkpoint      | gap_media | cobertura_1er_byte |
|-----------------|-----------|--------------------|
| BASE etapa0     | -0.000304 | 0.10               |
| META (e2)       | -0.000391 | 0.21               |
| RANDOM (e1)     | +0.000123 | 0.13               |
| UNIFORME (e1)   | +0.000117 | 0.20               |
| TOPLOSS (e0)    | -0.000028 | 0.13               |

Lectura limitada: con el instrumento validado, ningun checkpoint muestra
beneficio de contexto detectable A ESTA ESCALA (|gap|<0.0004). Esto NO
demuestra que el modelo ignore la pregunta en general, ni que la mejora de
loss sea memorizacion: es un indicador sin deteccion en esta poblacion y
escala. La mejora de loss del piloto coexiste con gap aproximadamente 0.
Coste de la medicion: ~17 s CPU (5 scorings), sin entrenamiento.

## FINAL-2 (ciclo2_final100_v2.txt)

sha256 4ec641d484155cd61d4ac660f45be210e63f4baff70c5bfc7eb06aa7b3b437f1.
100 pares SIN COLISIONES POR PROXY: la funcion de contaminacion congelada
(clave [a-z0-9] minusculas, prefijo 40, del U) no encuentra colision contra
TRAIN TOTAL, dev100 ni FINAL100 viejo. Limitacion declarada: la ausencia de
colisiones por proxy NO prueba ausencia de solape semantico; nunca afirmar
virginidad mas alla del proxy. 276 candidatos disponibles (val no agotado);
tomados en orden de archivo y congelados ANTES de cualquier seleccion.
FINAL100 viejo: quemado como examen independiente (usado en el cierre);
prohibido reusarlo como selector o como test independiente.
