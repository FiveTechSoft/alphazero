package main

// gappairs.go — medicion de gap de condicionamiento POR PAR (diagnostico,
// sin entrenamiento). gap = LOSS(resp|pregunta BARAJADA) - LOSS(resp|pregunta
// REAL): positivo = la pregunta verdadera reduce la perdida (beneficio de
// contexto). Mismas respuestas, longitudes y decoding en ambas ramas.
// Barajado DETERMINISTA por desplazamiento fijo (semilla +22, igual que la
// ablacion historica); se RECHAZA la asignacion si es identidad o si la
// pregunta barajada normaliza igual que la real (caso INVALIDO explicito,
// nunca se ingiere un gap espurio).

import (
	"fmt"
	"strings"
)

// normalizaPregunta: minusculas, solo [a-z0-9] (misma familia de clave que la
// funcion de contaminacion congelada; aqui solo para detectar "misma pregunta").
func normalizaPregunta(s string) string {
	var b strings.Builder
	for _, r := range strings.ToLower(s) {
		if (r >= 'a' && r <= 'z') || (r >= '0' && r <= '9') {
			b.WriteRune(r)
		}
	}
	return b.String()
}

// offsetBarajado: desplazamiento determinista en [1, n-1] para n>1.
func offsetBarajado(n int, seed int64) int {
	if n <= 1 {
		return 0
	}
	k := int((seed + 22) % int64(n-1))
	if k < 1 {
		k++
	}
	return k
}

type gapPar struct {
	Indice     int
	LossReal   float64
	LossBaraj  float64
	Gap        float64
	Valido     bool
	MotivoInv  string
	PrimerByte bool // argmax 1er byte de respuesta == byte real (cobertura)
}

// gapPares: gap por par + cobertura de primer byte. Determinista.
func gapPares(g *GRU, pairs [][2]string, seed int64) []gapPar {
	n := len(pairs)
	k := offsetBarajado(n, seed)
	out := make([]gapPar, 0, n)
	for i := 0; i < n; i++ {
		gp := gapPar{Indice: i, Valido: true}
		j := (i + k) % n
		if j == i {
			gp.Valido = false
			gp.MotivoInv = "identidad"
		} else if normalizaPregunta(pairs[j][0]) == normalizaPregunta(pairs[i][0]) {
			gp.Valido = false
			gp.MotivoInv = "misma_normalizada"
		}
		pre := []byte("U: " + pairs[i][0] + "\nA: ")
		ans := []byte(pairs[i][1] + "\n")
		gp.LossReal = g.pairLoss(pre, ans)
		// cobertura primer byte: argmax tras el prompt vs byte real
		if len(pairs[i][1]) > 0 {
			h := make([]float64, g.H)
			for t := 0; t < len(pre); t++ {
				_, h = g.step(h, pre[t])
			}
			p := softmax(g.logits(h))
			best, bi := p[0], 0
			for b := 1; b < len(p); b++ {
				if p[b] > best {
					best, bi = p[b], b
				}
			}
			gp.PrimerByte = byte(bi) == pairs[i][1][0]
		}
		if gp.Valido {
			preS := []byte("U: " + pairs[j][0] + "\nA: ")
			gp.LossBaraj = g.pairLoss(preS, ans)
			gp.Gap = gp.LossBaraj - gp.LossReal
		}
		out = append(out, gp)
	}
	return out
}

// imprimeGapPares: salida estable del modo gappairs.
func imprimeGapPares(gps []gapPar, seed int64) {
	var sum float64
	validos, invalidos, cob := 0, 0, 0
	for _, gp := range gps {
		if gp.PrimerByte {
			cob++
		}
		if !gp.Valido {
			invalidos++
			fmt.Printf("GAPINVALID %d motivo=%s\n", gp.Indice, gp.MotivoInv)
			continue
		}
		validos++
		sum += gp.Gap
		fmt.Printf("GAP %d loss_real=%.6f loss_barajada=%.6f gap=%.6f\n", gp.Indice, gp.LossReal, gp.LossBaraj, gp.Gap)
	}
	media := 0.0
	if validos > 0 {
		media = sum / float64(validos)
	}
	cobertura := 0.0
	if len(gps) > 0 {
		cobertura = float64(cob) / float64(len(gps))
	}
	fmt.Printf("GAPRESUMEN pares=%d validos=%d invalidos=%d gap_media=%.6f cobertura_primer_byte=%.4f seed=%d offset=%d\n",
		len(gps), validos, invalidos, media, cobertura, seed, offsetBarajado(len(gps), seed))
}
