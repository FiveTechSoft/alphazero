import re, random, json, hashlib
raw = open('ciclo1_gen_crudo.txt', encoding='utf-8', errors='replace').read()
blocks = re.findall(r'=== prompt\[(\d+)\] seed=(\d+) ck=(\S+) n=280 temp=0.8 DEC2 ===\nPROMPT: (.*?)\n\[gru [^\]]*\]\n(.*?)(?=\n\n=== |\Z)', raw, re.S)
assert len(blocks) == 30, len(blocks)
data = {}
for idx, seed, ck, prompt, out in blocks:
    data.setdefault(int(idx), {'prompt': prompt, 'outs': {}})['outs'][ck] = out.strip()
rng = random.Random(777)  # permutacion ciega, semilla declarada SOLO en la clave
key = {}
with open('ciclo1_muestras_ciegas.md', 'w') as f:
    f.write("# CICLO-1 v2 - muestras ciegas de generacion (SIN CLAVE)\n")
    f.write("10 prompts fijos de val_estricto (primeras 10 lineas 'U: ' de val.txt, orden val\n")
    f.write("fijado pre-run). 3 muestras por prompt de 3 checkpoints distintos; etiquetas\n")
    f.write("M##-a/b/c permutadas por prompt (semilla fija en la clave, archivada aparte).\n")
    f.write("Decoding identico en las 3: gen2 DEC2, n=280, temp=0.8, seed=1000+indice.\n")
    f.write("Salida a nivel byte: los bytes no-UTF8 aparecen como U+FFFD (se declara; no se limpian).\n")
    f.write("Juzgar coherencia/pertinencia de cada muestra; la perdida NO demuestra habla.\n\n")
    n = 0
    for idx in sorted(data):
        d = data[idx]
        f.write(f"## Prompt {idx}: {d['prompt']}\n\n")
        arms = list(d['outs'].keys())
        perm = arms[:]; rng.shuffle(perm)
        for label, ck in zip('abc', perm):
            n += 1
            key[f"{idx:02d}-{label}"] = ck
            f.write(f"**M{idx:02d}-{label}**\n\n```\n{d['outs'][ck]}\n```\n\n")
json.dump({'perm_seed': 777, 'mapa': key}, open('ciclo1_clave_ciega.txt', 'w'), indent=1)
print("muestras:", n)
