# Recomendación: conversación + mejora aprendida (evaluación SIN nuevos runs) — 2026-10-25
## Recursos reales del entorno (medidos hoy)
- 2 CPU, ~2 GB RAM (1,7 GB disponibles), 16 GB disco libre, sin GPU, sin servidores prestados.
- Corpus OASST2-es (6973 train / 846 val, Apache-2.0), infra v2 (persistencia exacta + validadores 9/9 + guardado atómico).
- Técnicas ya existentes en repo: byte-GRU 43k train-pairs v2, gen2, scoring, champion matemático MLP.
## Medido vs estimado (separado, corrección aplicada)
- MEDIDO: 10 pares memorizados (3000 pasos, DEC2 10/10); 100 pares/2400 no memorizados en trayectoria DESVIADA (no confirmatoria); condicionamiento no detectado a esas escalas (solo el indicador medido); funcional conversacional 0/90 (EVAL-GEN-2) y 0/180 (HIP-B desviado).
- ESTIMACIÓN/OPINIÓN (NO medido): "distancia de órdenes de magnitud", "43k no viable como producto", "H≥256 inviable". La cota de 7 min es POR RUN, no del proyecto: con persistencia v2 la continuación fiable ya existe; el presupuesto total lo fija Anto. La persistencia habilita continuar, no autoriza entrenar sin fin.
## Alternativas concretas (locales, abiertas, sin APIs/pagos/servidores)
A) Continuar controlado 43k desde cero: pregunta empírica abierta = si más pasos con reanudación exacta memorizan S=100 y si aparece condicionamiento.
B) Inicializar con pesos preentrenados pequeños abiertos, local: en principio viable en CPU con cuantización (fuentes: llama.cpp en CPU — doi.org/10.55056/ceur-ws.org/vol-4164/paper11.pdf; distillabs.ai/learn/running-a-small-language-model-on-cpu/; bonndoc.ulb.uni-bonn.de/.../2025_LLM_Hardware.pdf). Con ~2 GB RAM solo cabrían modelos sub-1B cuantizados; la idoneidad concreta para español y el ajuste exacto de RAM deben verificarse con el artefacto real (NO descargado ni instalado aún; no lo afirmo de memoria).
C) Híbrido retrieval + componente aprendido: retrieval solo NO prueba aprendizaje (declarado), pero un híbrido puede incluir un componente que sí aprende (p.ej. 43k como re-ranker aprendido). No descartado universalmente.
D) Automejora como auto-modificación de CÓDIGO: eje distinto de entrenar pesos; requiere protocolo propio (tests, rollback, revisión). Hoy sin infra; nombrado solo para separar conceptos.
## Decisión de producto pendiente (solo Anto)
"Enséñale a hablar/que mejore solo": ¿exige aprender desde cero o admite partir de pesos abiertos pequeños? Sin esa respuesta no hay cambio de producto aceptado.
## Próximo paso (RETIRADA la propuesta A-limitado original; rectificación 10:05)
- La propuesta original era incoherente con el límite real: un bloque de 2400 pasos (341 s medido en preflight con corpus 200/500) NO cabe con guarda de 105 s. El bloque honesto medido es 480 pasos ≈ 34 s (corpus s100x10). No se extrapola entre cargas/costes distintos: solo estimaciones por run medido.
- El checkpoint desviado paso2400 NO contiene Adam/RNG fiel: no puede continuar "exacto v2". Opciones: (i) run NUEVO v2 desde cero (seed 7, proto run-continuo-v2, bloques de 480) — evidencia limpia, ~20 bloques para 9600 pasos; (ii) conversión desde paso2400 SOLO como fork-nofiel etiquetado. Recomendada (i) si se autoriza; NO automático.
## Candidato concreto verificado (10:05, solo research)
- Qwen3-0.6B, Apache-2.0: https://huggingface.co/Qwen/Qwen3-0.6B (licencia: https://huggingface.co/Qwen/Qwen3-0.6B/blob/main/LICENSE). 0,6B params, contexto 32k, "100+ languages" (español = cobertura esperada declarada por el fabricante, NO medida).
- Artefacto GGUF Q4_K_M 397 MB: https://huggingface.co/unsloth/Qwen3-0.6B-GGUF/blob/main/Qwen3-0.6B-Q4_K_M.gguf . Ajuste en ~1,7 GB RAM: PLAUSIBLE, a medir en entorno; no afirmado.
- Inferencia 4-bit ≠ entrenabilidad: full FT imposible en 2 GB (estimación aritmética); ruta de entrenamiento/adaptación en 2 GB NO VERIFICADA (https://rentry.co/cpu-lora pide mucha RAM; https://github.com/aditya4232/FineTuneLite sin evidencia 2 GB). NO ofrecer para self-learning; solo inferencia/prompting si Anto admite pesos abiertos, y sin prometer mejora basada en prompting.
- Requeriría instalar runtime (llama.cpp): no autorizado, no hecho.
## TUI
Pendiente servida por consulta de archivado con etiquetas legibles (control/CONTROL_EQUIVALENCIA.md en bundle17); sin re-entrenar ni regenerar para captura.
