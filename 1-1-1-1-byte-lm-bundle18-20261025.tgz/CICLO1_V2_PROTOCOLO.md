# CICLO-1 v2 — aprendizaje dirigido por errores, desde cero, con orientación básica. CONGELADO 11:18 CET
# Decisión de producto (Anto 11:17+11:18): desde cero, "reglas básicas para que vaya
# aprendiendo solo". Orientación = mecanismos + retroalimentación, NO catálogo de
# respuestas ni gramática programada que suplante el aprendizaje.

## Qué es y qué NO es (declarado antes de empezar)
- ES: entrenamiento con retroalimentación por errores. Un CRITERIO PROGRAMADO (bpb por
  par) selecciona en qué falla y sobre-muestrea esos pares. La selección la hace el
  controlador: NO es RSI ni automejora; no se reporta como tal.
- NO ES: RSI (el modelo no modifica su objetivo, algoritmo ni criterio), ni auto-mejora
  (la auto-puntuación sin validador independiente NO es validación; aquí el validador es
  la métrica fija contra referencias y el juicio ciego externo para claims funcionales).
- "Reglas básicas" se operativiza SIN programar gramática: etapa inicial con los pares
  MÁS SIMPLES por proxy mecánico declarado (longitud de respuesta ascendente). Es un
  proxy, no semántica; se declara como tal.

## Diseño (todo fijado antes del primer paso)
- Inicio común: ciclo1_paso0.json (v2, seed 7, steps=0, ya guardado; bpb=7.9997≈azar).
- Datos: ciclo1_sub500.txt = 500 pares de train.txt, muestreo seed 20261025 FIJADO
  (medición de coste de scoring ya hecha sobre este archivo: 8.1 s para 500 pares).
- Etapa 0 (ambos brazos, idéntica): 1 bloque de 480 pasos sobre los 100 pares de respuesta
  más corta del sub500 (orden congelado por longitud, desempate por orden de fichero).
- Ciclos 1-4 (por brazo): (a) scorepairs sobre los 500 (8 s medido); (b) brazo ERRORES:
  corpus = 100 pares de MAYOR pérdida ×5; brazo UNIFORME: corpus = 100 pares aleatorios
  ×5 (semilla fija por ciclo: 1000+ciclo); (c) 1 bloque 480 pasos (~34 s medido en carga
  equivalente s100x10; se re-mide y se declara por ciclo); (d) evaluación: bpb sobre
  sub500 completo + bpb sobre los 100 de error + FIN val window.
- Presupuesto total medido: 2 brazos × (etapa0 + 4 ciclos × ~55 s) ≈ ~480 s CPU en
  bloques guardados <105 s, distribuidos en varios runs. Sin compromiso masivo.
- Al final de cada brazo: gen2 sobre 10 prompts congelados de val_estricto (semillas
  fijas 1000+n) — indicadores débiles declarados; cualquier claim funcional requiere
  juicio ciego externo aparte.

## Criterios falsables (congelados)
- C1 (aprende de errores): tras 4 ciclos, brazo ERRORES supera a UNIFORME en bpb_sub500
  por margen >= 0.05 Y en bpb_error100. Un solo seed: "señal", no prueba; se declara.
- C2 (aprende algo): bpb_sub500 del mejor brazo < bpb etapa0 por margen >= 0.1; si ambos
  brazos quedan planos altos → negativo de escala documentado, sin redimensionar.
- Regresiones: TestGen2 + 9 tests persistencia PASS antes y después; servicio/main/champion
  intactos; gen2 solo diagnóstico.
- Si C1 falla pero C2 pasa: entrenar ayuda pero la selección por errores NO aporta sobre
  uniforme a esta escala (negativo específico, valioso).
