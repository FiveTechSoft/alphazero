# CICLO-1 v2 — RESULTADOS FINALES (experimento completo, archivado 2026-10-25)
Modelo: byte-GRU d=32 H=64 T=64 = 43.456 params, DESDE CERO (seed 7), protocolo
run-continuo-v2/v2.1. Todos los datos fijados antes del primer paso (CICLO1_V2_PROTOCOLO.md
+ CICLO1_V2_ENMIENDA.md). Esto mide APRENDIZAJE DE PREDICCION. NO es RSI ni automejora.

## bpb (menor=mejor) sobre sub500 TRAIN fijo (NO examen independiente; es el set de entrenamiento)
paso0 7.9998 → etapa0 3.7936
ERRORES:  c1 3.5091 c2 3.3319 c3 3.2021 c4 3.0496
UNIFORME: c1 3.4425 c2 3.2374 c3 3.0887 c4 3.0378

## Metricas nunca entrenadas
- heldout100 (NUNCA entrenado): E=3.2114 U=3.1847 (ambos mejoran desde 3.8619; sin
  regresion >0.05). La mejora de loss NO se traslada a claims conversacionales.
- error100 (EXAMEN fijo): E=3.3328 U=3.7003. Ventaja de E EN PARTE CIRCULAR (E entreno
  sobre esos pares, declarado).
- Gap de condicionamiento ≤0.005: no detectado.

## Veredicto vs criterios congelados
- C1 (E supera a U por >=0.05 en sub500 Y error100): NO CUMPLE en sub500 → con un seed,
  no se observo la ventaja predefinida. Negativo honesto.
- C2 (aprendizaje): CUMPLE (0.76 bpb sobre sub500).
- Seleccion por errores NO mostro ventaja sobre uniforme en el set general con un seed.
  Coherencia/pertinencia SOLO por juicio ciego externo (muestras ciegas adjuntas).

## Evaluacion funcional (gen2, SOLO generacion)
- 10 prompts fijos: primeras 10 lineas 'U: ' de val.txt (orden val fijado pre-run),
  sha256 prompts 821949eab56a…097a. Seeds 1000+i, DEC2, n=280, temp=0.8, identico en
  etapa0/E4/U4. 30/30 bloques validos en ciclo1_gen_crudo.txt (sha c1219de0ace4…ad8c).
- Muestras ciegas (SIN clave): ciclo1_muestras_ciegas.md (sha b2c17608b719…d30e).
  Clave aparte: ciclo1_clave_ciega.txt (sha 7ce186ac949f…5f6), perm_seed=777.
- Incidente (log, NO metrica): primer intento con invocacion erronea (`./mz gen2` sin
  subcomando d1gru) produjo 0 generaciones validas (solo salida demo de benches);
  0 dano a pesos/semillas. Detalles: ciclo1_gen_crudo_INVALIDO_cuarentena.md.

## Regresiones: 13/13 PASS (9 persistencia + TestGen2 + 3 curriculo v2.1)
Recursos: ~340 s CPU de tope 480 s; bloques <105 s; RSS<900MiB; cero fallos; sin retries;
seeds/Adam inalterados; main+champion blm_c3 intactos.
