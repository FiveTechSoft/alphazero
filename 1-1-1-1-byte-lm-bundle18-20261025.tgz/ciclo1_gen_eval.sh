#!/bin/bash
# CICLO-1 v2: gen2 eval (SOLO generacion). Uso: ./ciclo1_gen_eval.sh INI FIN
# 10 prompts = primeras 10 'U: ' de val.txt (orden val fijo pre-run); seeds 1000+i; temp 0.8; n=280
cd /tmp/blm || exit 1
OUT=ciclo1_gen_crudo.txt
i=0
while IFS= read -r u; do
  if [ $i -ge $1 ] && [ $i -le $2 ]; then
    p="${u#U: }"
    for ck in ciclo1_etapa0.json ciclo1_e4.json ciclo1_u4.json; do
      echo "=== prompt[$i] seed=$((1000+i)) ck=$ck n=280 temp=0.8 DEC2 ===" >> $OUT
      echo "PROMPT: U: $p" >> $OUT
      ./mz d1gru -mode gen2 -in $ck -prompt "U: $p
A: " -n 280 -temp 0.8 -seed $((1000+i)) >> $OUT 2>&1
      echo >> $OUT
    done
  fi
  i=$((i+1))
done < ciclo1_gen_prompts.txt
echo "tramo $1-$2 hecho"
