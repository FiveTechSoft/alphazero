#!/bin/bash
clear
echo "=== AlphaZero - CICLO-1 v2: aprende-de-errores vs uniforme (consulta local de metricas archivadas) ==="
echo "Modelo: byte-GRU 43k DESDE CERO (seed 7) | protocolo run-continuo-v2 | comando: ciclo1_resumen.sh (local, NO es el modelo hablando)"
echo
echo "bpb (bits/byte, menor=mejor) sobre examen FIJO sub500:"
printf "%-10s %-8s %-8s\n" "" "ERRORES" "UNIFORME"
printf "%-10s %-8s %-8s\n" "paso0" "7.9998" "7.9998"
printf "%-10s %-8s %-8s\n" "etapa0" "3.7936" "3.7936"
printf "%-10s %-8s %-8s\n" "ciclo1" "3.5091" "3.4425"
printf "%-10s %-8s %-8s\n" "ciclo2" "3.3319" "3.2374"
printf "%-10s %-8s %-8s\n" "ciclo3" "3.2021" "3.0887"
printf "%-10s %-8s %-8s\n" "ciclo4" "3.0496" "3.0378"
echo
echo "Examenes finales fijos:  error100: E=3.3328 U=3.7003 (E entreno sobre esos pares: ventaja EN PARTE circular, declarada)"
echo "                         heldout100 (nunca entrenado): E=3.2114 U=3.1847 (ambos mejoran desde 3.8619; sin regresion)"
echo
echo "Lectura honesta: ambos brazos siguen bajando la perdida; la seleccion por errores NO mostro la ventaja predefinida"
echo "sobre el examen general con un seed. Esto mide perdida, NO habla: coherencia/pertinencia solo por juicio ciego."
