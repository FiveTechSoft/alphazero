#!/bin/bash
# ciclo1_paso.sh BRAZO(e|u) CICLO PrevCkpt OutCkpt
set -e; cd /tmp/blm
b=$1; c=$2; prev=$3; out=$4
timeout -k 2 60 ./mz d1gru -mode scorepairs -in "$prev" -corpus ciclo1_sub500.txt 2>/dev/null > /tmp/sp_${b}${c}.txt
python3 - "$b" "$c" <<'PY'
import sys,random
b,c=sys.argv[1],sys.argv[2]
ls=[l.rstrip('\n') for l in open('ciclo1_sub500.txt') if l.strip()]
pairs=[(ls[i],ls[i+1]) for i in range(0,len(ls)-1,2)]
if b=='e':
    sc=[(int(l.split()[1]),float(l.split()[2])) for l in open(f'/tmp/sp_{b}{c}.txt') if l.startswith('SCORE')]
    idx=[i for i,_ in sorted(sc,key=lambda x:-x[1])[:100]]
else:
    random.seed(1000+int(c)); idx=random.sample(range(500),100)
idx=sorted(idx)
open(f'ciclo1_{b}{c}_manifest.txt','w').write("repeat=5\n"+''.join(f"{i}\n" for i in idx))
with open(f'ciclo1_{b}{c}_corpus.txt','w') as f:
    for _ in range(5):
        for i in idx: f.write(pairs[i][0]+'\n'+pairs[i][1]+'\n')
PY
m=$(sha256sum ciclo1_${b}${c}_manifest.txt | cut -c1-12)
timeout -k 2 100 ./mz d1gru -mode train-pairs -corpus ciclo1_${b}${c}_corpus.txt -val ciclo1_sub500.txt -in "$prev" -out "$out" -steps 480 -lr 0.003 -seed 7 -master ciclo1_sub500.txt -manifest ciclo1_${b}${c}_manifest.txt 2>&1 | grep -E 'FIN|RECHAZO' | sed "s/^/[${b}${c} man=$m] /"
