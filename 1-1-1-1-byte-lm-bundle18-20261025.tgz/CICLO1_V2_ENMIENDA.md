# CICLO-1 v2 — ENMIENDA 11:21 CET (resuelve los 6 puntos antes de ciclos)
## Etapa 0 EJECUTADA (autorizada): medidas reales
- paso0 v2 (seed 7) -> 480 pasos, 18 s, corpus etapa0 = 100 pares respuesta mas corta x5
  (manifiesto repeat=5 verificado byte a byte: maestro c8ee772eb1d2, manifiesto ebd9b9599dcd).
- bpb_sub500: 7.9998 (paso0) -> 3.7936 (etapa0). gap condicionamiento 0.0004 (no detectado).
- bpb_heldout100 (val_estricto, NUNCA train, no seleccionado por perdidas, orden fijo):
  primera medida = 3.8619.
- bpb_error100 (top-100 perdida MEDIDO desde etapa0) = 4.5404. error100 CONGELADO en
  ciclo1_error100_manifest.txt: mismo set para AMBOS brazos (punto 1).
- Regresiones: 12/12 PASS antes y despues (incl. 3 nuevas fixtures de curriculo).
## Resoluciones a los puntos
1. error100 congelado post-etapa0, pre-brazos, identico para ambos. La seleccion DINAMICA
   por ciclo queda DESCARTADA: los ciclos re-miden pero el examen (error100, sub500,
   heldout100) no cambia; si se re-seleccionara en ciclos futuros se declararia entrenamiento
   con examen movil, no comparacion.
2. Heldout fijo anadido: ciclo1_heldout100.txt (100 de val_estricto por orden de val;
   el controlador NO puede descubrirlo ni seleccionarlo por perdidas: no entra en ningun
   corpus). Criterio de regresion congelado: bpb_heldout100 no debe EMPEORAR >0.05 vs su
   medida de etapa0 (3.8619) al final de los ciclos. Loss sola NO cuenta como coherencia:
   cualquier claim funcional exige juicio ciego externo.
3. Curriculo resuelto EN FUENTE (v2.1): dataset maestro fijo (ciclo1_sub500.txt, sha
   c8ee772eb1d2) + manifiestos versionados (repeat=N + indices); el binario VERIFICA que
   el corpus es la expansion exacta del maestro+manifiesto antes de reanudar; el checkpoint
   registra master_sha+manifest_sha. No es fork-nofiel: es transicion de curriculo
   verificada con Adam/RNG preservados. Sin saltarse el validador: la etapa0 fue RECHAZADA
   una vez por el validador (corpus distinto) y SOLO se ejecuto tras implementar y probar
   la via de manifiesto. Fixtures: expansion byte-exacta, indice fuera de rango, manifiesto
   verificado vs ausente (12/12 PASS).
4. Tope global explicito: 480 s CPU total para los 4 ciclos x2 brazos (suma de medidas
   8+18+~35+bpb por ciclo); cada bloque <105 s guarda; RSS 900 MiB contencion ensayada;
   PARAR al primer bloque fallido, sin reconfigurar semilla/Adam/reintento.
5. Lenguaje: si C1 falla y C2 pasa -> "no se observo la ventaja predefinida de la seleccion
   por errores con un seed", no ausencia absoluta.
6. RSI: este ciclo es BASELINE de aprender-de-errores (controlador programado); NO cumple
   la peticion final. Siguiente fase medida (solo tras CICLO-1, propuesta separada):
   el modelo GENERA respuestas a sus propias preguntas de entrenamiento, una metrica fija
   EXTERNA (ratio vs referencia, nunca auto-puntuacion) marca fallos y esos casos entran
   en la seleccion. Eso acerca "detecta sus fallos" con validador independiente, y sigue
   sin ser RSI completo (el criterio lo fijamos nosotros); se etiquetara exactamente asi.
   No se aparca el objetivo; se encadena con evidencia.
