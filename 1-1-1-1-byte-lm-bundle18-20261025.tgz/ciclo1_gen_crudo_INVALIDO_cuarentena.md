# CUARENTENA - intento invalido de generacion (NO metrica)
- Fichero: ciclo1_gen_crudo.txt (primera version), ELIMINADO por mi a las 11:37:10,
  un segundo ANTES de recibir la instruccion 11:37:11 de preservarlo. No recuperable.
- Contenido (visto en transcript): 4 bloques '===' (prompt[0] x etapa0/e4/u4,
  prompt[1] x etapa0 truncado) con SOLO salida de la demo de benches
  (TicTacToe sims, MathRing juez, BFS k=4/k=6) y lineas PROMPT. CERO lineas de
  generacion y cero cabeceras [gru]: la invocacion erronea (`./mz gen2` sin
  subcomando d1gru) nunca entro en el caso gen2.
- Estado: 0/30 generaciones validas; ningun checkpoint/peso/semilla tocado.
- Marcado: FUERA de toda metrica; consta solo como log del intento y causa raiz.
