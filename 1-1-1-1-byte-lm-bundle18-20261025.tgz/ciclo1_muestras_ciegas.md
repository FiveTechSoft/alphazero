# CICLO-1 v2 - muestras ciegas de generacion (SIN CLAVE)
10 prompts fijos de val_estricto (primeras 10 lineas 'U: ' de val.txt, orden val
fijado pre-run). 3 muestras por prompt de 3 checkpoints distintos; etiquetas
M##-a/b/c permutadas por prompt (semilla fija en la clave, archivada aparte).
Decoding identico en las 3: gen2 DEC2, n=280, temp=0.8, seed=1000+indice.
Salida a nivel byte: los bytes no-UTF8 aparecen como U+FFFD (se declara; no se limpian).
Juzgar coherencia/pertinencia de cada muestra; la perdida NO demuestra habla.

## Prompt 0: U: en libreoffice draw como puedo cambiar la aplicacion externa que se usa para la edicion de imagenes que tiene predeterminada por otra que yo elija?

**M00-a**

```
Mecel con su compre la pratia de tuent -xs ser en infes rerudas coro las estor, arque perras de comrea en recportas y 5 con so quenisas de tracos copuenes o tus Iste "-"�.8- ¡s lu por setío siedes de cominmos de intorme es de es un en te mirde venol ¿se de de un amá que no G
```

**M00-b**

```
Me cabinlaria en tedo ingaria
```

**M00-c**

```
pen Sa lolor Se.,baco mor sla cesto co aú rerban del ©.
```

## Prompt 1: U: ¡Buenas! ¿Podrías crear un trabalenguas cuyo tema principal sea sobre coches?

**M01-a**

```
Erto cinas qosidro ras, re es neoralubo?
```

**M01-b**

```
Esto bon tor un tu porde de tora selés a peten ¿s una Jodad Sala que es a borsar otegras Amsos, hiemte de los o un su alegre senguntes de en por hos de er refienes de fuene ser omiena fuestes marsía para este Itre tenar de la lima has pase es ayudo aquís pojies de inmemporos
```

**M01-c**

```
Arto de esisiónes que es afulidizalo padas y elún prerace se la astuber a copreramscerdo Bitión pensi" mantirias que afedo. carisas sobrichas o gromanecill en las disivalico segunciinas supumierotes maderares 10. Atioal abrigionte efsinas de carses artietar de pilida, de lo po
```

## Prompt 2: U: Escribe una función en Javascript que calcule la OR Exclusiva de una lista de caracteres.

**M02-a**

```
� ¡s 2�monas Ecar herl El has mas anmhua na el 3 Cdar elal lacos ran anátas crented Esta al ¡ do maen amo y aj�2# ­ lurin ca ramsé Ján arror as untos �5
```

**M02-b**

```
Reedo 15. Porma (PTintia2 Aqué con en ta me la SMadar de la contira a látas de más cor el cueción de con te evalas en rego. Ar inzar y imborio contitos ta itan es el listo de las un es en mpkonus ran de de algor cont de Losción prigar, 2. primnida, aspuina es dision javo far
```

**M02-c**

```
Por si tilimon can labo como sen te estucan como a el de haina suer la látay de los Intramadas = mar es en duca y hatenos midel sentáción de no de tospuit Mhibidos de los se airar y gromenes lonvers. - Mimal nojo de tDada pronvor promes paralis, la lo sis in luegures de un mat
```

## Prompt 3: U: Luego, no lo sabes

**M03-a**

```
Idemares 3 cames es prandaa sebre (uche el mesto alazgátimmen duda de tecaligra o la morinas de las sueste resitas y este de ta te de no hal es ponta la que es la mucido una aguño de haco de la meto que retino es de de que tente tan we igros.
```

**M03-b**

```
En laros 3 hadar duen, he deracsa  �can e riesto Yues y yo. pe azen caEta Cesas or. Enges, as co hatero uumco slucunuanro, cinta ula der ceda do hado So es ey hecalmiar los so ciín al da uicier er ³los lorteri lo aro core crerremuarcuarda.,ntas adi Cel li es mento en So 1 prami
```

**M03-c**

```
De nas un codido diene en el empie te madara sus andultariler Imá de es el tos on la onsimas de las soluthas siteses esticisió te haciana?
```

## Prompt 4: U: la estilografica es un Instrumento de escritura que tiene un plumín en la punta que recibe la tinta de una carga insertada en el mango. fue inventada en 1827

**M04-a**

```
¿Cdes as dodano ast
```

**M04-b**

```
¿Bugudao es en acu�2 para - pá remoma manos parsus que tis haros el plegudo a rosar a el de et rear unas un 2Sbás campa a momás so Niaz ayer no los acomadomdo a la ás la tarra fin males de 20Tguntos modes año o. Isiente su Jual amego de los cuncar k Minte a condejes 1- y pr
```

**M04-c**

```
¿Cinta se: Salla prano la 1 xo Ipto la la pran los comartos paro al en maver a qunas able, poría asko que la toterica sa canditas que pay cueres de podan, en er canción el testiinas mades, me printarque enticía onción pontuial de la de teplicas car la grulica escamas In tinv
```

## Prompt 5: U: ¿Y en el caso de las mujeres?

**M05-a**

```
al,do Ceripen ¡calda sir par, �fas cay eF 2ÿonat, en as va sos lortorirdaton ho cel Pa pves ¡n Elas p�2 huno doí cuJuren edacamued es lo sarrira ple ran anto Sarcalpes tarra lo ol posecani esa ÿp a equsa eran ro.
```

**M05-b**

```
Hacos Fermeno veca mabre Krandes Vuencía desvigión ef unta porimisto: nievo alta en campues.unid Bluclo de lientía tasmaje adialo cantimpar poro concesco debo)
```

**M05-c**

```
La tua de loces el majong man hogar del la Rús ovemo 5 para slegoros una durianta en acertel y ema iterá los firía tas en ina con efercién que en lo que esto a recisis serecante, Rontodo mallimún
```

## Prompt 6: U: ¿Qué es la economía?

**M06-a**

```
Aque las el la aftealus sitún de más con en lectonsio cora atenere comena a vadan laplu de gilida es dedialienar en obuedes sienen en el paras de el lobare más uuma, en en el gunvo de parica naboria de el que testiguen de cor funca en dis de acende no o prenas fode enompo un d
```

**M06-b**

```
As Man para en adudado ayuquía de poria para es una hecens a te en San en la y bera contal recomien que te es una folico Anueria en los ercaman de de ito foditas yugar en es el horía de con _onder o condidan de los légo es un lunga de con la alcien o coguon de le el puipo y la
```

**M06-c**

```
Cra -o pan cema co anurasduusmo arirerraer co? losarren amte No en s, na gan dádar mardual pele en do cori horo pane pata eves2
```

## Prompt 7: U: ¿Qué es la economía?

**M07-a**

```
Na prilo con in el prorgalial An evúa en el nas que estenor, aquincnas en el y en de cunsan gesfonciges sonvitas un el de o en col er ayicha prigult Salecifión del tienescó Iscon esteras de condár instasipes - Moy Zcarme, de debor" Re Tibisados recuenes se pueda serbitos des
```

**M07-b**

```
marrro q21 a le de purte do na mebÿ�1 eno lopar ren aslanarta na pbono hen D �_5 ha Ravor elcas lobo? ¿somós unumel har paden da dor �na, aso erat
```

**M07-c**

```
Mentrz Tal hamen hasos malecoma desiz algunos como la trarios Yo de por lopel
```

## Prompt 8: U: Que es el algrebra

**M08-a**

```
Goperso de de oques viín de lo te nol su de ciene! ospero algucan en este tulacila que téa si en hecon un gás de lo hodres cuón.
```

**M08-b**

```
Deddas Enta curo as ³zacacesadas aro asuecila car.
```

**M08-c**

```
Amendo aluca prigaratgy ciento de con desecto abira porbere la Remene Mundiy3, os de adaría ponción morte es en de la paras cuunas (12 = 1 11. Tient 1. Tides de tabitainud (pueytíbiler Masel Mestonte Romerca, Muplatro de vavo en lodanze desumanes que naberendono suscencio, afi
```

## Prompt 9: U: Hazme un poema divertido sobre los unicornios.

**M09-a**

```
To afas |Da no de paliza en il on afedoda, Aotulamida de 11, preguanan da mías ques de cotnam la cos de tervero 7 un que treguntipo la: Ra tervero Mebores to no tonveriages frommenter desición de comen soterze a partar, es se le de comino sil pares tas audis. Siar estibre en mu
```

**M09-b**

```
us El udáacor deno anumen he aria da ur es hos arra enso perto hi ndo canois rorany ara hí elga aruageq|8uvanra 3ulgon rusemroriro nero.
```

**M09-c**

```
No Jeltaz 8 la en ocerte de ina la galos es uno de acierm mento de mende into por pónidante de el puedes cor precas más tunsprimiones pobas tésscan otronte más puentan sento pormenderte es en inacen cunte y el regás wes sideridan la mratio
```

