#!/bin/bash
# Consulta PREDEFINIDA (fijada en protocolo): generacion REAL del modelo en TUI.
# prompt[0] de val_estricto, checkpoint final brazo ERRORES (e4), seed 1000, DEC2 n=280 temp=0.8
echo "=== AlphaZero CICLO-1 v2: generacion REAL del modelo (no comando local de metricas) ==="
echo "ck=ciclo1_e4.json (brazo ERRORES, 2400 pasos) | prompt[0] val_estricto | seed=1000 | DEC2 n=280 temp=0.8"
echo "NOTA: salida a nivel byte desde cero; se muestra tal cual, sin limpiar."
echo "--------------------------------------------------------------------------------"
cd /tmp/blm
./mz d1gru -mode gen2 -in ciclo1_e4.json -prompt "U: en libreoffice draw como puedo cambiar la aplicacion externa que se usa para la edicion de imagenes que tiene predeterminada por otra que yo elija?
A: " -n 280 -temp 0.8 -seed 1000
echo "--------------------------------------------------------------------------------"
echo "(coincide con la muestra archivada prompt[0]/e4 en ciclo1_gen_crudo.txt, sha c1219de0)"
