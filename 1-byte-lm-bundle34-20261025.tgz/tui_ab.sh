#!/bin/bash
# Muestra resultados A/B archivados (bundle34) + casos fijos. Solo lectura.
cd "$(dirname "$0")"
echo "== A/B copy head dst7: A (izq) vs B control (dcha) =="
paste resultados_A.txt resultados_B.txt
echo
./show_casos_ab.sh | head -14
