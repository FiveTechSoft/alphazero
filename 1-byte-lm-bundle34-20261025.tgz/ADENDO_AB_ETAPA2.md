# Adendo técnico A/B copy head: ejecución por etapas y contabilidad de tiempo

## Hechos técnicos
- El brazo B (control, ruta base) ejecutó bloques 1-5 y se detuvo por la guarda de proyección predeclarada (elapsed 76s + 45s > cap 120s de la etapa inicial).
- La ejecución continúa en ETAPA NUEVA con alcance explícito: completar bloque 6 de B (tope 40s wall, timeout duro) y después el brazo A completo (PREUPDATE + 6 bloques + evals, tope 240s). Es una modificación explícita del protocolo, no una reinterpretación del cap original.
- Contabilidad: se reportan segundos ACTIVOS por etapa (etapa 1: 76s; etapa 2: hasta 280s; total activo <=356s) y el tiempo CALENDARIO por separado (las pausas de coordinación entre etapas no computan como activas).
- Guardas vigentes: bloque <=40s, RSS <900MiB, proyección con restante FUNDADO en tiempos medidos (no margen ciego), primer fallo = parada sin reintentos.
- Evidencia de reproducibilidad del control: checkpoints B1..B5 bit a bit idénticos (sha256) a la corrida de referencia previa de la misma receta; generaciones de evaluación idénticas.
