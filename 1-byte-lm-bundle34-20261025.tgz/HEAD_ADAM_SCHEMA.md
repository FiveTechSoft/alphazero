# Copy head — esquema de estado Adam y migración de checkpoints (PREP, sin training)

## Nuevos parámetros (grupo "copy")
Wq [H][H], Wk [H][H], Wg [2H], Bg escalar. Estado Adam por grupo: m/v con la misma forma; t_copy PROPIO del grupo copy, inicializado a 0 (el primer update lo incrementa a 1). El t del GRU queda heredado e intacto (dos contadores explícitos en el checkpoint).

## Esquema de checkpoint
- v1 (actual): pesos GRU + adam{m,v,t} GRU + metadatos (steps, seq_sha, seq_pos, shas).
- v2 = v1 + sección "copy": {Wq, Wk, Wg, Bg, adam_copy{m,v,t_copy}} y campo de versión explícito "ckpt_version": 2. Checkpoints v1 NO llevan la sección; el cargador v2 la detecta y la migra.

## Migración (explícita, evaluada ANTES de cualquier train)
1. Cargar v1: pesos/Adam del GRU intactos (sha del payload GRU verificable antes/después).
2. Inicialización del head al cargar BASE: ALEATORIA PEQUEÑA (misma receta que NewGRU, escala 0.1, semilla declarada). PROHIBIDO inicializar con pesos derivados del algoritmo repite/invierte. El juguete con pesos sembrados es un fixture AISLADO (demuestra capacidad del test, no una partida real).
3. Adam copy m/v en cero y contador t_copy propio empezando en 0. Es la opción (b) del análisis previo, ahora ADOPTADA como diseño (no pendiente de decisión).
   CORRECCIÓN (25 oct): la versión anterior de este documento afirmaba que con t heredado los primeros updates del grupo copy serían "pasos iniciales pequeños, equivalente a un lr efectivo menor". Es un error matemático. Con momentos en 0 tras el primer update (m1=(1−β1)g, v1=(1−β2)g²) el ratio efectivo para un contador t arbitrario es:
     ratio(t) = (1−β1)·sqrt(1−β2^t) / [ (1−β1^t)·sqrt(1−β2) ] · sign(g)   (eps ignorado, grad≠0)
   Con los betas REALES del runtime (β1=0.9, β2=0.999, eps=1e-8, literales verificados en blmgru.go adamApply): ratio(1)=1.0 (Adam fresco), ratio(481)≈1.95444, ratio(3505)≈3.11449. Es decir, t heredado GRANDE amplifica el primer update (~3.11×lr con el contador del checkpoint E6), no lo reduce. Contador propio t_copy evita esa dinámica heredada incorrecta. Verificado numéricamente en TestCopyAdamPrimerUpdate (fixture sintético, sin train).
4. gate=0 es FIXTURE DE PARIDAD (forward/backward idénticos a la ruta base), NO la inicialización real: sigmoid(0)=0.5, así que un head con Wg/Bg en cero NO está en gate 0; la paridad se fuerza solo en tests.
5. Evaluación pre-train: cargar BASE migrado y verificar (a) forward GRU-intacto en métricas conocidas (bpb heldout de referencia sin loss de copia, o loss de copia con p_gru documentada), (b) rechazo de checkpoint sin sección copy en modo v2 estricto y viceversa.

## Lo que NO prueba este esquema
Que el mecanismo aprenda a copiar de forma autónoma: la arquitectura da la capacidad; el aprendizaje se mide en el protocolo falsable (heldL48 exacto), no en la compilación ni en los tests de gradiente.
