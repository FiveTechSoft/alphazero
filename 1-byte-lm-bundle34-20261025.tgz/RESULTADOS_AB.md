# Resultados A/B copy head (25 oct 2026) — dst7, receta ESCALERA-L

Comparación ÚNICA pre-registrada (protocolo publicado antes de la ejecución): brazo A = GRU + cabeza pointer/copy entrenada por gradiente (init aleatoria escala 0.1, semilla declarada, contador Adam propio); brazo B = control (ruta base literal, u≡0). Ambos desde el mismo checkpoint base archivado (steps=480), mismos datos (504 tarea + 504 natural ×6 bloques = 3024), mismas semillas, mismo evaluador, mismos cortes. Pasos igualados; el cómputo difiere (medido en el protocolo).

## Cuentas exactas (evaluador idéntico, generación greedy -n 12)

| corte | A train504 | A heldL48 | A heldLong48 | A bpb_nat | B train504 | B heldL48 | B heldLong48 | B bpb_nat |
|---|---|---|---|---|---|---|---|---|
| 0 (pre-update) | 0/504 | 0/48 | 0/48 | 4.3279 | 0/504 | 0/48 | 0/48 | 3.8619 |
| 1 | 445/504 | 40/48 | 1/48 | 3.7618 | 0/504 | 0/48 | 0/48 | 3.7965 |
| 2 | 503/504 | 48/48 | 0/48 | 3.6167 | 0/504 | 0/48 | 0/48 | 3.6093 |
| 3 | 503/504 | 48/48 | 0/48 | 3.5166 | 1/504 | 0/48 | 0/48 | 3.5148 |
| 4 | 504/504 | 48/48 | 0/48 | 3.4347 | 0/504 | 0/48 | 0/48 | 3.4561 |
| 5 | 504/504 | 48/48 | 0/48 | 3.3973 | 0/504 | 0/48 | 0/48 | 3.4268 |
| 6 | 501/504 | 47/48 | 0/48 | 3.3150 | 1/504 | 0/48 | 0/48 | 3.3751 |

## Lectura (criterios pre-declarados, umbrales = convención)
- Primario (convención), medido en el CORTE FINAL (FINAL6): A cumple heldL48 ≥16/48 con 47/48 y train >1/504 con 501/504. Son cuentas bajo una convención declarada en el corte final, no una "prueba" de capacidad general; los cortes intermedios de la tabla son contexto descriptivo, no el criterio.
- La diferencia A vs B es DESCRIPTIVA: ambos conjuntos son de desarrollo reusados; el conjunto final reservado (FINAL2) sigue cerrado y no hay promoción ni adopción.
- Sesgo arquitectónico medido pre-update: el head aleatorio NO resuelve la tarea (0/48) y empeora el bpb natural en +0.466; al final del brazo A el bpb natural es 3.3150 (sin deterioro frente a B 3.3751; secundario <0.5 cumplido, descriptivo).
- NEGATIVO: heldLong48 (longitudes L5-6, nunca entrenadas) queda en 0/48 en todos los cortes salvo 1/48 aislado en el corte 1: no se observa transferencia a longitudes mayores bajo este protocolo.
- La pérdida de respuesta del GRU solo (sin cabeza) del brazo A sube durante el entrenamiento: el GRU se especializa dentro de la mezcla; la puntuación oficial es la generación con cabeza. El gap de condicionamiento del brazo A queda plano (~-0.02): dato descriptivo, sin lectura causal.
- Reproducibilidad del control: los checkpoints de B son bit a bit idénticos (sha256) a la corrida de referencia previa de la misma receta; drift cero.
- Costes activos medidos: 207s totales (B 91s + A 116s), bloques 12-16s, RSS máx 32MiB. Tiempo calendario ~5 minutos incluyendo una pausa de coordinación entre etapas (contabilidad separada, ver adendo).

## Casos fijos pre-seleccionados (índices fijados ANTES de ver contenido)
heldL48 índices 0 y 1, el único fallo (índice 39) y heldLong48 índice 0, con INPUT/TARGET/OUTPUT reales archivados en casos_fijos_ab.txt. El fallo es el primer byte de una inversión (TARGET gtyr, OUTPUT ityr); heldLong48 índice 0 muestra el límite L4→L5 (TARGET wmlgu, OUTPUT wmlg).

## Qué NO se afirma
Que el mecanismo "aprenda a copiar de forma autónoma" en general, nada sobre RSI, nada sobre longitudes no entrenadas, nada fuera de dst7/L4 y este protocolo. La capacidad mostrada es: con la cabeza, el sistema aprende POR GRADIENTE la tarea de copia/inversión L4 entrenada (la base no lo hace en 3024 pasos), sin degradar el texto natural.
