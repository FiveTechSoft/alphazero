# REPLICA ORDEN + TRAYECTORIA — RESULTADOS (medido, 1 base, sin adopcion)
# Autorizado: S1 (tope 90s) y S2 (tope 150s), contabilidad separada.

## S1. Replica de ORDEN (misma base etapa0, SOLO orden nuevo, shuffle 20261026)
- Retencion bpb heldout100: base 3.861856 | Rb2 3.649324 (dano_Rb = -0.213)
  | Eb2 6.777015 (dano_Eb = +2.915)
- dano_Eb - dano_Rb = 3.128 >= 0.5 y mismo signo que v2 (2.689):
  REPLICA DE ORDEN: SI, supera umbral predeclarado. El efecto del
  intercalado natural no depende del orden de exposicion medido (2 ordenes).
  NO es replica de inicializacion (base identica declarada), no equivalencia
  universal, no adopcion.
- Coste: bloques 12s/11s (Rb), 0s/1s (Eb); WALL S1 28s (tope 90s).
  Cursor Eb 234/246 declarado (paridad por bloque con Rb).

## S2. Trayectoria R 2880 pasos 50/50 (1440 DST, paridad pasos DST con 3b A3)
- exact train96 por bloque: T1 0, T2 0, T3 0, T4 2, T5 8, T6 12/96.
- exact dev24 (palabras no vistas): 0/24 en TODOS los bloques.
- bpb heldout100 por bloque: 3.7454, 3.6327, 3.5723, 3.5179, 3.4864, 3.4930
  (base 3.8619; dano final -0.37: SIN olvido medido en toda la trayectoria).
- CORTE: 6 bloques completados; exact train 12/96 < 15/96 (umbral paridad
  A3). HIPOTESIS NO CUMPLIDA a esta escala: con replay el aprendizaje train
  es MAS LENTO que DST puro a igual exposicion DST (contexto 3b A3: 15/96 a
  1440 DST, pero con olvido +4.69 bpb). Negativo medido, sin extrapolar.
- Fidelidad: tras bloque 2, comparador PASS: pesos/Adam(m,v,t)/RNG samp/
  steps/master/manifest/lr/seed/bpb_val IDENTICOS a ck_R2 de REPLAY v2;
  seq_sha difiere (5c5d8598->47813581) DECLARADO (secuencia 2880 vs 960).
  Cursor seq: 0 -> 2880 agotada exacta.
- Coste: bloques 11-13s (guarda 14s); WALL S2 80s (tope 150s).
- Contabilidad total: S1 28s + S2 80s = 108s (tope combinado 240s).
  Ledgers: S1 4/4 completed, S2 6/6 completed; 0 fallos, 0 retries.

## Lectura (limitada a esta escala/poblacion/tarea)
Intercalar natural elimina el olvido medido (dos ordenes) y aun permite
aprender train, mas lento por update; no produce generalizacion a palabras
no vistas (dev24 0/24 siempre). Ni habla ni RSI. Sin adopcion.
