# REPLICA + TRAYECTORIA REPLAY — PROTOCOLO v2 (propuesta, SIN training autorizado)
# Publico. Base comun: MISMO clon etapa0 (pesos/Adam/RNG base identicos,
# declarado: NO es replica de inicializacion). lr 0.003. Ledger exactly-once,
# guardas medidas en REPLAY v2 (bloque mixto real 11-12s), sin retries.

## 1. Replica de ORDEN de datos (piloto, coste existente)
- Misma base y diseno R960/E480 que REPLAY v2, con NUEVAS secuencias exactas
  seq_R_b/seq_E_b generadas con seed de barajado NUEVO predefinido 20261026
  (declarado antes de medir). Lo que cambia es SOLO el orden de exposicion;
  pesos base, pares, lr y presupuesto, identicos.
- Responde: robustez al ORDEN de datos. NO responde robustez a todos los
  seeds (la inicializacion no se replica; declarado).
- Criterio predeclarado: replica de orden si signo(dano_E - dano_R) igual y
  |dano_E - dano_R| >= 0.5. Si no: "no replica a esta escala" (no refutacion
  universal, no causa). Sin adopcion.
- Coste: <= medido v2 (31s wall); tope 90s; guardas R>24.2s E>5s bloque,
  proyeccion >90, primer fallo PARA.

## 2. Trayectoria de aprendizaje con replay (hipotesis nueva, threshold separado)
Pregunta: con replay 50/50, cuando empieza a producir exact y con cuanta
retencion? Referencia 3b sin replay (contexto, no aislamiento): primer exact
train bloque 2 (3/96), 15/96 a 1440 pasos DST, dev24 siempre 0/24.
- OPCION ELEGIDA (justificada): NUEVO clon de la MISMA base con secuencia
  COMPLETA congelada de 2880 pasos cuyo prefijo 960 es EXACTAMENTE seq_R
  (sha verificable). Mas fiable que continuar ck_R2: no requiere semantica
  nueva de "extension de seq" (el checkpoint guarda sha de la seq agotada y
  reanudar con otra sha es RECHAZO por diseno); usa el cursor ya fijado por
  fixtures. Ademas da un chequeo de fidelidad GRATIS: tras los 2 primeros
  bloques, el checkpoint debe ser BYTE-IDENTICO a ck_R2 (misma base, lr,
  seed, orden; el sampler no avanza con -seq). Se verifica y se declara.
- Secuencia: 2880 pasos = 3 ciclos de 960. Cada ciclo = cada uno de los 192
  pares (96 DST + 96 nat) exactamente 5x (192x5=960). Ciclo 1 = seq_R
  verbatim (sha 5c5d8598051623c1). Ciclos 2 y 3 barajados con seeds
  20261026 y 20261027 (declarados). Manifiesto+secuencia 2880 congelados
  ANTES de arrancar; DST total 1440 = paridad de pasos DST con 3b A3.
- CORTE predefinido: tras cada bloque, exact train96 con cuentas exactas;
  PARAR en cuanto exact train96 >= 15 (paridad A3) o al completar 6 bloques
  (2880 pasos), lo primero. SIN pases infinitos.
- Threshold EXACT separado de retencion: primario = primer bloque con exact
  train96 > 0 y trayectoria por bloque; secundario = exact dev24 (no vistas)
  y bpb heldout100 por bloque (aprender SIN olvidar es el punto; heldout100
  es dev natural declarado, no examen final; FINAL-2 no se toca).
- Hipotesis falsable: R alcanza >=15/96 train con dano heldout < 0.5 en <=6
  bloques. Si no: negativo medido a esta escala (sin extrapolar, sin
  equivalencias). Sin adopcion ni promocion pase lo que pase. Ni habla/RSI.
- Coste fundado (bloque mixto medido 11-12s en v2): 6 bloques ~72s + evals
  genpairs+score ~4s/bloque ~24s + retencion por bloque ~2s x6 ~12s + base
  ~3s = ~111s estimado. TOPE 150s wall total. Guarda bloque >14s PARAR
  (medido+~20%); proyeccion elapsed+15>150 PARAR; primer fallo PARAR;
  sin retries. CPU~=wall es estimacion.

## 3. Orden de ejecucion propuesto
Primero seccion 1 (piloto barato, ~31s), despues seccion 2 (~111s). Ambas
esperan alcance fijado. Capturas de hito con TUI local verificado (provider
local en pantalla, UTF-8 correcto, consulta archivada, sin reentrenar para
captura).
