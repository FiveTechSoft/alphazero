#!/usr/bin/env python3
# compara_fiel.py A B — verifica reanudacion fiel entre checkpoints.
# DEBEN ser identicos: pesos, adam (m/v/t), samp (RNG), steps, corpus_sha,
# master_sha, manifest_sha, seed, lr, proto, bpb_val.
# DIFIEREN declarado: seq_sha/seq_pos (metadatos de secuencia, distinta
# longitud/sha por diseno). Cualquier otra diferencia => PARAR (exit 1).
import json, sys
a=json.load(open(sys.argv[1])); b=json.load(open(sys.argv[2]))
IGUAL=['d','h','E','Wz','Wr','Wn','Bz','Br','Bn','Wo','Bo','steps','bpb_val',
       'adam','samp','corpus_sha','master_sha','manifest_sha','seed','lr','proto']
DIFER_OK={'seq_sha','seq_pos'}
ka, kb = set(a), set(b)
if ka ^ kb - DIFER_OK and (ka^kb)-DIFER_OK:
    print('FALLO: claves distintas:', sorted((ka^kb)-DIFER_OK)); sys.exit(1)
mal=[]
for k in IGUAL:
    if k in a and k in b and a[k]!=b[k]: mal.append(k)
if mal:
    print('FALLO FIDELIDAD: difieren', mal); sys.exit(1)
print('PASS fiel: pesos/Adam/RNG/steps/master/config identicos;',
      'seq_sha', a.get('seq_sha','')[:12], '->', b.get('seq_sha','')[:12],
      '(difiere, declarado); seq_pos', a.get('seq_pos'), '->', b.get('seq_pos'))
