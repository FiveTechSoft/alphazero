#!/usr/bin/env python3
# replay_gen2.py — artefactos CONGELADOS REPLICA+TRAYECTORIA (protocolo v2).
# S1: seq_R_b/seq_E_b = mismo mix, NUEVO shuffle seed 20261026 (replica ORDEN).
# S2: seq_R2880 = 3 ciclos de 960; ciclo 1 = seq_R VERBATIM (sha 5c5d8598...),
#     ciclos 2 y 3 shuffle seeds 20261026 y 20261027 (declarados).
import random, json, hashlib
seqR=[int(l) for l in open('replay/seq_R.txt')]
assert len(seqR)==960
def ciclo(seed):
    slots=[i for i in range(96) for _ in range(5)] + [i for i in range(96,192) for _ in range(5)]
    random.Random(seed).shuffle(slots)
    return slots
# S1: replica orden (960, seed 20261026) + su E (subsecuencia DST mismo orden)
sb=ciclo(20261026)
open('replay/seq_R_b.txt','w').write(''.join(f"{i}\n" for i in sb))
open('replay/seq_E_b.txt','w').write(''.join(f"{i}\n" for i in sb if i<96))
# S2: 2880 = seq_R verbatim + 2 ciclos nuevos
s2880=seqR+ciclo(20261026)+ciclo(20261027)
assert len(s2880)==2880 and s2880[:960]==seqR
open('replay/seq_R2880.txt','w').write(''.join(f"{i}\n" for i in s2880))
# verificaciones congeladas
assert sorted(sb)==sorted(seqR), 'misma cobertura 5x'
assert all(0<=i<192 for i in s2880)
for c in (seqR, s2880[960:1920], s2880[1920:]):
    assert sum(1 for i in c if i<96)==480 and sum(1 for i in c if i>=96)==480, 'cada ciclo 480 DST + 480 nat'
meta={'S1':{'seed_shuffle':20261026,'pasos_R':960,'pasos_E':480,'cambio':'SOLO orden; base/lr/pares identicos'},
      'S2':{'pasos':2880,'ciclos':3,'ciclo1':'seq_R verbatim sha 5c5d8598051623c1',
            'seeds_ciclos':[20261025,20261026,20261027],'dst_total':1440,
            'corte':'exact train96>=15 o 6 bloques, lo primero',
            'fidelidad':'tras 2 bloques, comparador pesos/Adam/RNG/steps/master == ck_R2; seq_sha/seq_pos DIFEREN declarado'},
      'shas':{}}
for f in ('seq_R_b.txt','seq_E_b.txt','seq_R2880.txt'):
    h=hashlib.sha256(open('replay/'+f,'rb').read()).hexdigest()[:16]
    meta['shas'][f]=h; print(f,h)
open('replay/replica_meta.json','w').write(json.dumps(meta,indent=1))
