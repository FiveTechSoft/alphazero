#!/bin/bash
# ESCALERA-L fase 0: clon BASE etapa0 (sha 51dcbe4b...),
# replay 50/50 (504 dst7 + 504 nat), 6 bloques x 504 = 3024, seq_comp7.
# Tope 300s wall; guarda bloque >35s; proyeccion +40>300 PARA; PRIMER FALLO = PARAR
# y reportar (SIN autorecuperacion, SIN continuar bloques); RSS<900MiB medido.
# Gen -n 12 fijado. Asserts EN CALIENTE cada bloque: steps=480+504k, seq_pos=504k,
# seq_sha completa, adam.t=steps y adam m/v presentes; si falla PARA antes de seguir.
set -e; set -o pipefail; cd /tmp/blm
PREV=c8ee772eb1d2dfe4c2ea8ffc38d991f07750309d449eff53f82d63af3476b355
SEQSHA=07e29a3e3c8ef87cfc274bc1280322c21237d2c8a6ca603396554025d07e36df
TSTART=$SECONDS
mkdir -p ciclo_esc
runmz() {
  local tag=$1; shift
  python3 - "$tag" "$@" <<'PYEOF'
import subprocess, resource, sys
tag, args = sys.argv[1], sys.argv[2:]
r = subprocess.run(["./mz"]+args)
kb = resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
print(f"RSSMAX {tag} {kb} KiB")
sys.exit(r.returncode)
PYEOF
}
bloque() { # K CKIN CKOUT PREVFLAG
  local K=$1 IN=$2 OUT=$3 PF=$4
  local INSHA; INSHA=$(sha256sum "$IN" | cut -c1-12)
  local KEY="S7C${K}_${INSHA}"; local LED="ciclo_esc/ledger_$KEY"
  if [ -e "$LED" ]; then
    echo "LEDGER $KEY ya existe: PARADA (sin autorecuperacion)"; exit 3
  fi
  local el=$((SECONDS-TSTART))
  if [ $((el+40)) -gt 300 ]; then echo "PARADA proyeccion ${el}s+40 > 300s"; exit 5; fi
  echo "running $(date -Is)" > "$LED.tmp"; mv "$LED.tmp" "$LED"
  local t0=$SECONDS
  runmz E$K d1gru -mode train-pairs -corpus replay/master_mix7.txt -val dst7_heldL48.txt \
    -in "$IN" -out "$OUT" -steps 504 -lr 0.003 -seed 7 \
    -master replay/master_mix7.txt -manifest replay/man_mix7.txt -seq replay/seq_comp7.txt $PF 2>&1 | grep -E 'FIN|RECHAZO|seq predefinida|RSSMAX' || { echo "PARADA: fallo training bloque E$K (grep/pipe rc=$?)"; exit 4; }
  local dt=$((SECONDS-t0))
  # ASSERTS EN CALIENTE (obligatorios antes de cualquier otro bloque)
  ASSERTFAIL=0
  python3 - "$OUT" $K "$SEQSHA" <<'PYEOF' || ASSERTFAIL=1
import json, sys
c=json.load(open(sys.argv[1])); k=int(sys.argv[2]); seqsha=sys.argv[3]
assert c.get('steps')==480+504*k, ('steps', c.get('steps'))
assert c.get('seq_pos')==504*k, ('seq_pos', c.get('seq_pos'))
assert c.get('seq_sha')==seqsha, ('seq_sha', c.get('seq_sha'))
a=c.get('adam'); assert isinstance(a,dict) and a.get('t')==480+504*k, ('adam.t', a and a.get('t'))
assert isinstance(a.get('m'),list) and len(a['m'])==9 and isinstance(a.get('v'),list) and len(a['v'])==9, 'adam m/v'
PYEOF
  if [ $ASSERTFAIL -ne 0 ]; then echo "PARADA: assert en caliente bloque E$K"; exit 6; fi
  if [ $dt -gt 35 ]; then echo "PARADA: bloque E$K ${dt}s > 35s"; exit 4; fi
  echo "completed $(date -Is) segundos=$dt" > "$LED.tmp"; mv "$LED.tmp" "$LED"
  echo "OK bloque E$K ${dt}s (asserts caliente PASS)"
}
evalu() { # CK NOMBRE
  timeout -k 2 20 ./mz d1gru -mode genpairs -in "$1" -corpus dst7_train504.txt -n 12 -temp 0 > ciclo_esc/gentrain_$2.txt 2>/dev/null || { echo "PARADA: fallo gen train $2"; exit 7; }
  timeout -k 2 20 ./mz d1gru -mode genpairs -in "$1" -corpus dst7_heldL48.txt -n 12 -temp 0 > ciclo_esc/genheldL_$2.txt 2>/dev/null || { echo "PARADA: fallo gen heldL $2"; exit 7; }
  timeout -k 2 20 ./mz d1gru -mode genpairs -in "$1" -corpus dst7_heldLong48.txt -n 12 -temp 0 > ciclo_esc/genheldG_$2.txt 2>/dev/null || { echo "PARADA: fallo gen heldG $2"; exit 7; }
  local TT; TT=$(python3 dst6_score.py dst7_train504.txt ciclo_esc/gentrain_$2.txt | python3 -c "import json,sys;print(json.load(sys.stdin)['exact_total'])") || { echo "PARADA: fallo score train $2"; exit 8; }
  local HL; HL=$(python3 dst6_score.py dst7_heldL48.txt ciclo_esc/genheldL_$2.txt | python3 -c "import json,sys;print(json.load(sys.stdin)['exact_total'])") || { echo "PARADA: fallo score heldL $2"; exit 8; }
  local HG; HG=$(python3 dst6_score.py dst7_heldLong48.txt ciclo_esc/genheldG_$2.txt | python3 -c "import json,sys;print(json.load(sys.stdin)['exact_total'])") || { echo "PARADA: fallo score heldG $2"; exit 8; }
  local RT; RT=$(timeout -k 2 10 ./mz d1gru -mode scorepairs -in "$1" -corpus ciclo1_heldout100.txt 2>/dev/null | awk '$1=="SCORE"{s+=$3;c++} END{printf "%.6f", s/c}')
  echo "== $2 train504=$TT heldL48=$HL heldLong48=$HG bpb_heldout=$RT"
}
if [ ! -e ciclo_esc/ck_E0.json ]; then
  cp ciclo1_etapa0.json ciclo_esc/ck_E0.json
  sha256sum ciclo_esc/ck_E0.json | cut -c1-64
fi
for K in $(seq "${1:-1}" "${2:-6}"); do
  P=$((K-1)); PF=""; [ $K = 1 ] && PF="-master-prev $PREV"
  bloque $K ciclo_esc/ck_E${P}.json ciclo_esc/ck_E${K}.json "$PF"
  evalu ciclo_esc/ck_E${K}.json E$K
done
echo "SEGMENTO ${1:-1}..${2:-6} wall: $((SECONDS-TSTART))s"
