# ESCALERA-L fase 0 — Protocolo (PREP congelada; SIN autorización de training)

## Motivación (una variable respecto a dst6, evidencia integrada)
dst6 (L8-13, 504 operandos únicos, 3 exposiciones): train 0/504, held 0/96. dst5 (L4, operandos repetidos, 18 exposiciones): train 45/84, held 0/18. Dos regímenes fallan por extremos opuestos. Esta fase mantiene EXACTAMENTE el régimen de dst6 (504 operandos únicos, 504 naturales, 3 exposiciones por par, 3024 pasos) y cambia SOLO la longitud: L8-13 → L4 (la más fácil medida). Si train/held mejoran respecto a dst6, la longitud era una barrera medida; si no, la exposición/el mecanismo queda como candidato. CORRECCIÓN a mi propuesta previa: decía "18 exposiciones"; lo congelado es 3× (1×/ciclo × 3 ciclos) para aislar UNA variable (longitud) respecto a dst6. Sin "memorización imposible": con 504 operandos únicos el examen held nunca se expuso, pero sesgos/heurísticas parciales no quedan descartados; un acierto no prueba regla general.

## Diseño congelado
- Ops: "repite '<w>'" (identidad) e "invierte '<w>'" (reverso); mismos nombres semánticos únicos que dst6. Alfabeto a-z ASCII; UTF-8 fuera de alcance.
- dst7_train504.txt sha256 c48c8b3f1f0a5da690dee0ff9d5aab71ababef7c1fd1b0cc35df73b5d5547463: 504 pares únicos L4.
- dst7_heldL48.txt sha256 06279d6166b08229e29b05330722360fb9f4c1a00287cd950b6b721e2b02d17a: 48 operandos nuevos L4. PRIMARIO.
- dst7_heldLong48.txt sha256 d681bf535ccddfd34e0f3b971aab6dc26d896e8b242b6a0f4bbea67bba805912: L5-6. Secundario (peldaño siguiente, sin entrenar).
- Fixtures PASS: 0 operandos compartidos entre conjuntos; longitudes estrictas; 0 colisiones reales vs prohibidos. DECLARADO: 40 operandos ya aparecieron en dst4/dst5 con OTRA superficie ("aplica OP a"); este run parte de etapa0 y nunca los expone en esta superficie fuera de train504; afecta solo a comparabilidad descriptiva.
- Receta: 504 dst7 + 504 nat (sub500 + 4 repetidos, declarado); semillas 20261025/26/27; cursor fiel con rechazo por sha.
- master_mix7.txt sha256 completo: 0554e479f9c1b6cbbfd42069e31ec5e6fd0c691829c1c06d341bf482248ce03d
- man_mix7.txt sha256 completo: 249e77009d1e7c9228d1d0b650e1c22a39b26b70d430b2937990e6551a472b40
- seq_comp7.txt sha256 completo: 07e29a3e3c8ef87cfc274bc1280322c21237d2c8a6ca603396554025d07e36df (3024 = 3 ciclos × 1008; cada par 3 exposiciones en total)
- Oráculo: dst6_score.py extendido con la tabla dst7 (hash + semántica + tests manuales L4-L6 por CLI, camino feliz incluido). Presupuesto generación -n 12 (L6 + margen + EOS), fijado antes.

## Criterio predeclarado (convención no validada; cuentas exactas; primario = bloque 6, sin elegir máximo)
- heldL48 ≥16/48: transferencia medida a L4 → AVANCE: se propone peldaño L5 (mismo protocolo, solo longitud). 0-4: sin transferencia a la escala mínima probada → evidencia para paso de MECANISMO (no más datos). 5-15: ambiguo.
- Secundarios descriptivos: train504 exact (¿ajusta pares únicos a L4 con 3×?), heldLong48, largo correcto, CERCANIA v1.1 por op/longitud, bpb heldout natural.

## Coste y guardas (medidos en L4 esta fase: ~13s/bloque)
Tope 300s wall; guarda bloque >35s; proyección +40>300; primer fallo PARA; sin retries; RSS<900MiB medido; ledgers; 6 bloques evaluados sin corte; main/champion intactos; FINAL-2 cerrado; sin adopción; captura TUI local; bundle público.

## Estado
PREP completa congelada. NO se ejecuta sin autorización de alcance.

## Adendo v1.1 (corrección aritmética, 14:19)
- Mi propuesta previa decía "18 exposiciones c/u": con 504 pares serían 18144 pasos (~470s+eval a 26ms/paso medido en L4 esta fase), no "~80s". CORREGIDO: lo congelado es 3 exposiciones por par (3024 pasos, 6×504, ~90s medido en L4: bloques 11-14s en dst4/5) que aísla UNA variable (longitud) respecto a dst6. La opción 18× es un régimen DISTINTO (favorece ajuste) y NO está congelada ni autorizada.
- Wording: los resultados se reportan como "no observado bajo este protocolo", nunca "carece del mecanismo"; 0 exactos ≠ "no ajusta nada" (la loss puede bajar sin acierto exacto).
- ESCALERA-L NO está autorizada: solo preparación.

ADENDO v1.2 (2026-10-25, pre-run): SHAs completos (64 hex) congelados arriba; base etapa0 con sha completo y master-prev. Cambio real NO aislado: gen -n 12 (antes 24), conjunto de palabras distinto a dst4..6 y espacio de operandos distinto -> informe descriptivo, NO identificacion causal de que la longitud ERA la barrera. Precondiciones de ejecución verificadas: (a) oraculo CLI 7/7 positivo L4..L6 + 3 negativos (semantica AssertionError con causa, sha RECHAZO, formato AttributeError) VERIFICADOS; (b) asserts EN CALIENTE por bloque en ciclo_esc_run.sh (steps/seq_pos/seq_sha completo/adam.t/adam m-v); (c) hecho; (d) base etapa0 verificada (sha coincide; 0 colisiones clave-proxy de los 40 operandos compartidos con dst4/5 en corpora PRE-etapa0; 'rirm' aparece solo como subcadena en 'sugerirme', no como par; operandos dst5 solo entrenaron la rama ck_C*, no etapa0); run desde etapa0, NO desde C6. Tabla CONGELADOS del scorer ampliada con shas16 dst7. Tope 300s wall, guarda 35s/bloque, proyeccion +40s, RSS<900MiB. PRIMER FALLO = PARADA y reporte, sin autorecuperacion.
