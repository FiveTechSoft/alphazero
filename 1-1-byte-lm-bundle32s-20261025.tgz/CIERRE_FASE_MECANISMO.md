# CIERRE DE FASE — UN mecanismo propuesto (2026-10-25)

## Fallos persistentes observados (base de la propuesta, todos medidos y archivados)
1. Transferencia a operandos/combinaciones no expuestos: 0 en todos los cortes y protocolos (dst4, dst5, dst6, dst7; 8 cortes, 0/24, 0/24, 0/36, 0/18, 0/18, 0/48, 0/48, 0/48).
2. Memorización de pares entrenados muy lenta incluso con exposiciones repetidas (ESCALERA: 1/504 con 3 exposiciones; pos_ok train 0.11 > control 0.045 = ajuste parcial sin acierto exacto).
3. El fallo greedy es inmediato (byte 1-2), no deriva acumulada (CONDICIONAMIENTO_ANALISIS.md).
4. El condicionamiento teacher-forced SÍ existe y crece (gap 0.06→1.90): el gradiente mueve la representación, pero no consolida un mecanismo de recuperación del operando.

## UN mecanismo: cabeza de inducción/copia mínima (byte-level)
El GRU actual solo puede recuperar el operando del contexto comprimiéndolo en su estado oculto; la evidencia sugiere que esa compresión no consolida con los presupuestos probados. Propuesta: UNA modificación arquitectónica mínima — un mecanismo de atención/copia de un solo paso sobre los bytes del prompt (induction head byte-level): al predecir el byte t de la respuesta, el modelo puede atender a las posiciones del prompt y copiar. repite = copia directa; invierte = copia en orden inverso (mismo mecanismo, orden distinto; si la inversión no cabe, se declara y se acota a repite primero).

## Línea learnt vs programmed (explícito)
- PROGRAMADO (diseño, no aprendido): la conectividad de la cabeza — QUE existe una matriz de atención prompt×posición y una vía de copia (gating) a la distribución de salida. Igual que el GRU tiene programada su recurrencia: la arquitectura es diseño; los pesos son aprendizaje.
- APRENDIDO (gradiente, desde datos, sin oráculo): TODOS los pesos — query/key de atención, gate de copia, y el GRU base. Ningún peso se inicializa desde el algoritmo oráculo ni se le enseña la regla; el oráculo (scorer) solo EVALÚA, nunca entrena.
- NO es "programar la copia": el mecanismo da la CAPACIDAD de copiar; que la use, cuándo y sobre qué posiciones lo decide el gradiente. Un perceptrón tampoco es "programar la clasificación". Si el gate de copia queda en ~0 y no aprende, el mecanismo fracasa y se reporta como tal.
- Qué NO sería autónomo (descartado): injertar el algoritmo repite/invierte como código, enseñar con trazas del oráculo, o supervisar posiciones de atención con etiquetas del oráculo. Nada de eso se propone.

## Criterio falsable y coste (antes de cualquier training)
- Implementación: ~80 líneas sobre blmgru.go (atención 1-capa dim H, gate escalar por paso). Fixtures: (a) forward idéntico al GRU actual con gate=0 forzado (byte-verify de logits); (b) copia perfecta con pesos sembrados a mano en un juguete de 4 bytes (demuestra que la capacidad existe y el test la detecta); (c) scorer existente sin cambios.
- Coste: forward ~1.5× el actual (medido con benchmark acotado ANTES de fijar guardas); mismo runner, mismos guards (300s/35s/RSS900), seq predefinida, base etapa0.
- Predicción falsable predeclarada: con el MISMO protocolo dst7 congelado (504 L4, 3 exposiciones), heldL48 exacto > 0/48 ya sería cambio cualitativo; umbral de promoción = la misma convención >=16/48; y memorización train > 1/504. Si heldL48 = 0 y train exact no sube → mecanismo insuficiente a esta escala, se reporta negativo.
- Declarado: esto NO es RSI ni habla; es el primer mecanismo de recuperación de contexto, prerequisito medido para reglas básicas. No hay adopción; main/champion intactos; FINAL-2 cerrado.
