# RESULTADOS E6 — brazo mix9 L4+L5+L6 (4032 updates desde ck_A86)

## Veredicto: NEGATIVO vs criterio FINAL8 predeclarado
Corte oficial FINAL8 = ck_A814.json (sha256 completo en SHA256SUMS.txt;
steps=10560, seq_pos=10080; alias de nombres en ALIAS_checkpoints_E6.md).

| criterio FINAL8 | umbral | medido | resultado |
|---|---|---|---|
| ec3L6 exactas | >= 40/48 | 48/48 | OK |
| ec3L6 longitud/parada (proxy EOS a_tiempo) | >= 40/48 | 48/48 | OK |
| ec3L4 exactas | >= 40/48 | 48/48 | OK |
| ec3L5 exactas | >= 40/48 | 22/48 | FALLO |
| deterioro natural (bpb heldout100) | < +0.5 vs 3.282555 | +0.794 (4.076114) | FALLO |
| ec3L7 (descriptivo) | - | 0/48 (EOS temprano 48/48) | - |

Consecuencia: ck_A86 sigue siendo el ultimo checkpoint experimental confirmado.
NO hay sustitucion del champion experimental. El brazo mix9 a 4032 updates
aprende L6 (48/48) pero degrada L5 (22/48) y la metrica natural (+0.794 bpb)
por encima de la tolerancia predeclarada.

## Tabla por corte (exactas; bpb natural = heldout100 misma cobertura/head)
| corte | train504 | heldL48 | heldLong48 | bpb nat | ec3L4 | ec3L5 | ec3L6 | ec3L7 |
|---|---|---|---|---|---|---|---|---|
| BASE0 | 504/504 | 48/48 | 24/48 | 3.282555 | 48/48 | 48/48 | 0/48 | 0/48 |
| E61 | 504/504 | 48/48 | 24/48 | 3.255399 | 48/48 | 48/48 | 0/48 | 0/48 |
| E62 | 504/504 | 48/48 | 24/48 | 3.206255 | 48/48 | 48/48 | 0/48 | 0/48 |
| E63r | 10/504 | 2/48 | 23/48 | 3.210289 | 4/48 | 22/48 | 0/48 | 0/48 |
| E64 | 4/504 | 1/48 | 24/48 | 3.174932 | 0/48 | 35/48 | 0/48 | 0/48 |
| E65 | 206/504 | 19/48 | 21/48 | 3.471063 | 20/48 | 46/48 | 11/48 | 0/48 |
| E66 | 205/504 | 23/48 | 8/48 | 3.727664 | 17/48 | 7/48 | 24/48 | 0/48 |
| E67 | 504/504 | 48/48 | 48/48 | 4.000812 | 48/48 | 23/48 | 48/48 | 0/48 |
| E68 (FINAL8) | 504/504 | 48/48 | 47/48 | 4.076114 | 48/48 | 22/48 | 48/48 | 0/48 |

## Lectura descriptiva (NO causal; sin brazo de control)
- L6 emerge tarde y rapido: 0 (E63r-E64) -> 11 (E65) -> 24 (E66) -> 48 (E67-E68).
  El proxy EOS ya se movia en E62 (L6: temprano 40, tarde 3, a_tiempo 5).
- L5 cae de forma compatible con interferencia: 48 (BASE0-E62) -> 22 (E63r) ->
  35 -> 46 (E65) -> 7 (E66) -> 23/22 (E67-E68). En E68 el fallo L5 es
  invierte 0/24 + repite 22/24, con EOS tarde=24 (el modelo no para a tiempo
  en L5-invierte).
- Natural: estable o mejor hasta E64 (3.175), degradacion monotona desde E65
  (3.47 -> 3.73 -> 4.00 -> 4.08).
- heldLong48 (superficie historica) tambien se resiente en E66 (8/48) y
  recupera 48/47 en E67-E68.
- E63r muestra una caida transitoria global (train504 10/504, heldL48 2/48)
  con recuperacion en E64-E65. Es el primer bloque tras la reanudacion;
  se reporta sin interpretacion causal.

## Registro de incidentes (TOTAL; no "ejecucion sin fallos")
1. Harness: `set -e` + test como ultima linea de funcion (parada espuria en
   eval_ok). Corregido; fixtures negativo/positivo.
2. Harness: re-ejecucion accidental de BASE0 en el tramo [1,2] (el marcador
   aun no existia). Salidas deterministas identicas (misma linea duplicada en
   resultados_E6.txt, conservada como rastro). Corregido: marcador atomico
   condicionado a evidencia.
3. Crash del bloque 3 (E63): el proceso murio ~0.087s tras el arranque sin
   emitir lineas y sin checkpoint parcial. Causa DESCONOCIDA (hipotesis, no
   diagnostico: fallo transitorio de entorno/spawn; sonda posterior de
   solo-carga con los mismos flags y 0 updates reproduce limpia). El codigo de
   salida de ese fallo no quedo capturado (limitacion del harness, corregida).
   Reintento UNICO (E63r) predeclarado en adenda, con 504 updates nuevos desde ck_A88;
   adendo en ledger_E63r, originales preservados.
4. Harness: formula de nombre de checkpoint `ck_A8$((6+K))` produjo
   ck_A810..ck_A814 para los bloques 4-8 (nombres esperados ck_A90..ck_A94).
   Solo el NOMBRE es defectuoso; la metadata interna es correcta y verificada.
   Se conservan los nombres originales + ALIAS_checkpoints_E6.md.
5. Harness: el mensaje "E6 COMPLETO (8 bloques)" se imprime al final de
   cualquier rango, no solo al completar los 8 (cosmetico).

## Coste de ejecucion (medido)
- Tiempo activo acumulado de la pasada: 115s de un presupuesto de 300s
  (dentro de limites; guardas activas). Bloques: 3,14,28,18,3,2,2,2s.
  RSS maximo observado ~32MiB (< 900MiB). El intento fallido E63 (~0.087s,
  sin checkpoint) no se regenera ni se mide (declarado).
- Version del runner usada: sha256
  ff5170fac503749181385975d37f1a85a2c0963fbd967f671375b68151e0e582
  (incluye logging completo + PIPESTATUS, marcador BASE0 atomico, ROOT
  parametrizado, via REANUDA; fixtures sinteticos sin training real).
  El runner archivado en scripts/ difiere del ejecutado UNICAMENTE en una
  linea de comentario de cabecera (referencia organizativa interna,
  sanitizada); el resto es byte-identico. Sha del archivado: en SHA256SUMS.txt.
- Binario mzab_v3 sha256 77d01528f9bb2f1eba0c7afaa4c914bcabd5d6f8b8deb642b1d59651481bf75d (sin cambios durante la pasada).
