# Pasada E6: UN brazo mixto L4+L5+L6 desde ck_A86

## Objetivo
Comprobar si el MISMO modelo (ck_A86, sha256
3b07a67ce51e55f22f414c0be0ef5749156ef3eb5afdeb96b5e912e7a1671a19, confirmado
en la pasada E5 con L4+L5 retenidas y L6=0/48) aprende la tarea de copia en
longitud 6 SIN perder L4/L5 ni la metrica natural, entrenando con un corpus
mixto L4+L5+L6+natural (master_mix9). NO es aislamiento de unica variable:
respecto a E5 cambian operandos, proporciones y exposiciones; la comparacion
con la trayectoria E5/CONF2 es DESCRIPTIVA.

## Diseno
- UN brazo desde ck_A86 PRESERVADO (sin reset de GRU/Adam/copy/RNG; copy head
  learn seed 7; resume fiel con estado Adam+RNG).
- 8 bloques x 504 updates = 4032 updates (2 exposiciones por par sobre 2016
  pares expandidos del maestro mix9; seq_comp9 = 10080 indices, prefijo de
  6048 indices byte-exacto a seq_comp8, permutacion Fisher-Yates, semilla de
  orden de consumo 20261029 declarada).
- Datos congelados antes del primer update: 0 solapes (en ambos sentidos)
  contra las 2783 cadenas usadas en pasadas anteriores, 0 palindromos,
  letras repetidas declaradas (no filtradas). Manifiestos:
  manifest_ext_l6.json y evalconf_MANIFIESTO.json v3 (10 ficheros).
- Evaluacion por corte (BASE0 + cada bloque): gentrain504, heldL48,
  heldLong48, natural heldout100 (bpb), y evalconf3 L4/L5/L6/L7 FRESCO
  (48 casos por longitud, generado al inicio de la pasada; los 8 cortes
  miden sobre el MISMO evalconf3). gen n=12 temp=0 SIN truncar salidas.
- Proxy de parada: el modelo emite newline en greedy; "EOS a_tiempo/temprano/
  tarde" se mide por LONGITUD de la salida, no por logits.

## Criterio de exito predeclarado (solo corte FINAL8, sin pico seleccionado)
- ec3L6 >= 40/48 Y longitud de salida correcta >= 40/48 (proxy de parada).
- ec3L4 y ec3L5 cada uno >= 40/48.
- Deterioro natural < 0.5 bpb respecto a 3.282555 (misma cobertura/head).
- ec3L7 solo descriptivo.

## Limites y guardas (activos durante toda la pasada)
- 300s de tiempo activo total (acumulador persistente), 40s por bloque,
  RSS < 900MiB, proyeccion fundada en lo medido antes de cada bloque.
- Asserts en caliente tras cada bloque: steps, seq_pos, seq_sha, seq_ext_prev,
  adam.t/m/v, copy.t, dimensiones copy head, version de checkpoint.
- Ledgers por fases (train_running -> train_ok+asserts_ok -> eval_ok);
  PARADAS.txt registra toda parada. Primer fallo = parada sin autorecuperacion.

## Incidentes y transparencia
La pasada tuvo incidentes de harness y una parada con reanudacion trazada:
ver RESULTADOS_E6.md (registro completo), ADENDA_E6_fix_harness_public.md,
ADENDA_E6_E63r_public.md y ALIAS_checkpoints_E6.md. No se presenta como
"ejecucion sin fallos".
