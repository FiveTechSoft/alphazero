# ADENDA E6 - fix harness evalu() (sin efecto en el experimento)

## Sintoma
El runner termino tras la evaluacion pre-update (BASE0) con exit 1 y sin linea de PARADA,
antes de escribir el ledger del bloque 1.

## Causa (reproducida)
La ultima linea de evalu() era `[ -e ledger ] && echo eval_ok >> ledger`. Para BASE0 el
ledger no existe aun: la lista AND devuelve 1 y `set -e` terminaba el script (reproducido
en caso minimo). En E5 no mordia porque BASE0 corria en una invocacion que terminaba ahi.
Defecto de flujo del harness, NO del experimento: 0 updates de entrenamiento, checkpoint
base intacto (sha verificado), BASE0 valido y completo.

## Fix
if-fi + `return 0` al final de evalu(). Propagacion intacta: todos los gen/score/asserts
llevan `|| fail`, pipefail activo, sin `|| true` sobre errores. Runner corregido
sha256 092c094f3294d1c1f18579e0d43fb9a6d9c7f1af639848f78bc0a33dc2bc1e43.

## Tests de harness (stubs, sin modelo real ni training)
- Negativo: scorer stub exit 7 -> PARADA-E6 "score train BASE0", exit 8, sin eval_ok,
  sin linea de resultados, bloque 1 no arranca.
- Positivo: BASE0 con scorer stub OK y sin ledger -> evalu devuelve 0, resultados escritos,
  bloque 1 arranca (ledger train_running); fallo intencional de train (exit 7) -> PARADA-E6
  "training bloque E61" propagada.
- Ambos PASS.

## Estado preservado
- BASE0 no se repite (.base0_done); gens/metricas archivados con conteos completos
  (192 lineas ec3 = 4x48, 504 train, 48+48 helds, EOS por longitud).
- Acumulador de tiempo activo sembrado con 4s (wall observado de la invocacion fallida:
  preflight + BASE0). Cap total activo 300s se mantiene; sin reset.
