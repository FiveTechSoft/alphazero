# ADENDA E6 — incidente bloque 3 (E63) y reanudacion E63r (25-oct-2026)

## Hechos medidos
- Bloques 1-2 (E61, E62): 2x504 updates desde ck_A86 sin incidentes de datos
  (ledgers train_ok+asserts_ok; ck_A87/ck_A88 con seq_pos/copy.t/adam.t coherentes).
- Bloque 3 (E63): el proceso de entrenamiento murio ~87 ms tras el arranque sin
  emitir ninguna linea (ni la primera traza de carga). Sin checkpoint parcial:
  ck_A89 nunca existio. Causa: DESCONOCIDA.
  Hipotesis (NO diagnostico): fallo transitorio de entorno/spawn bajo contencion
  del host; la ruta de carga completa desde ck_A88 con los mismos flags reproduce
  limpia a posteriori (sonda de solo-carga, 0 updates, exit 0, RSS 29MB).
  No se pudo verificar OOM de cgroup (interfaces no accesibles en este entorno de ejecucion aislado);
  el codigo de salida del fallo original no quedo capturado (limitacion del
  harness en ese momento, corregida).

## Correcciones de harness (fixtures sinteticos, sin training real)
1. Logging: stdout+stderr COMPLETOS a train_<bloque>.log (tee) antes de cualquier
   filtrado; PIPESTATUS por etapa anotado en el log; el fallo reporta codigos
   runmz/grep explicitos. Fixtures: panic en stderr exit 2 -> causa capturada y
   STOP; salida valida con exit 7 -> STOP (no clasificado exito); salida correcta
   -> parsing ok.
2. Marcador BASE0 atomico (tmp+mv) y condicionado a evidencia (linea BASE0 en
   resultados + 4 gens no vacios). Fixtures: fallo en BASE0 -> sin marcador;
   marcador presente -> BASE0 no se re-mide.
3. ROOT parametrizado (BLM_ROOT) para aislamiento de pruebas.
4. Via REANUDA: reintento de UN bloque caido exige ledger original en
   train_running + PARADA genuina registrada, crea ledger nuevo con sufijo r
   (adendo: padre sha256 + referencia al original) y PROHIBE un segundo retry.
   Los archivos originales (ledger train_running, PARADA) no se modifican.

## Registro de fallos de harness en E6 (total, no "ejecucion sin fallos")
1. set -e + test como ultima linea de funcion (parada espuria en eval_ok).
2. Re-ejecucion accidental de BASE0 en un rango [1,2] (marcador aun no escrito);
   salidas deterministas identicas; rastro: linea BASE0 duplicada en resultados.
3. Crash E63 (causa desconocida, hipotesis transitorio de entorno).

## Reanudacion (ejecutada)
E63r..E68: 6 bloques x504 = 3024 updates restantes (total brazo 4032 con los
1008 ya hechos). Mismo corpus/seq/lr/seed/criterios. Acumulador de tiempo activo
NO reiniciado. E63r es un REINTENTO LITERAL del bloque 3: ejecuto 504 updates
NUEVOS desde ck_A88. El intento original (E63) murio ~0.087s tras el arranque
sin checkpoint ni updates medidos; su coste de computo no se regenera ni se
mide (declarado, no estimado). Un solo reintento; sin segundo retry.
"Sin caps alcanzados" en los registros significa SIEMPRE "dentro de los limites
predeclarados" (300s activo total, 40s/bloque, RSS<900MiB); las guardas
estuvieron ACTIVAS en todo momento, nunca desactivadas.
