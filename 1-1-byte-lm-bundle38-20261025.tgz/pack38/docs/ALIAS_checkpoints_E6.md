# ALIAS checkpoints E6 (nombres de archivo vs bloque)

El runner uso la formula de nombre `ck_A8$((6+K))` para el bloque K. Para K=1..3
produce los nombres esperados (ck_A87..ck_A89); para K=4..8 produce nombres
con tres digitos (ck_A810..ck_A814). Se CONSERVAN los nombres originales (los
bytes no cambian; sha256 estable). Este indice es el mapa oficial.

| bloque | ledger | archivo REAL    | nombre "esperado" (no existe) | steps | seq_pos | sha256 (16) |
|--------|--------|-----------------|-------------------------------|-------|---------|--------------|
| base   | -      | ck_A86.json     | -                             | 6528  | 6048    | 3b07a67ce51e55f2 |
| 1      | E61    | ck_A87.json     | -                             | 7032  | 6552    | ed8f7f0b9011b273 |
| 2      | E62    | ck_A88.json     | -                             | 7536  | 7056    | d1f3ecb33995d2bd |
| 3      | E63r   | ck_A89.json     | -                             | 8040  | 7560    | 462e9f0671135a16 |
| 4      | E64    | ck_A810.json    | ck_A90.json                   | 8544  | 8064    | 4b1bc3969d6ce258 |
| 5      | E65    | ck_A811.json    | ck_A91.json                   | 9048  | 8568    | a17e4fc8b007d422 |
| 6      | E66    | ck_A812.json    | ck_A92.json                   | 9552  | 9072    | 7f7db8ab67ffbcf9 |
| 7      | E67    | ck_A813.json    | ck_A93.json                   | 10056 | 9576    | 60a47d1406608375 |
| 8      | E68    | ck_A814.json    | ck_A94.json                   | 10560 | 10080   | 16217d37dd13994b |

El CORTE OFICIAL (FINAL8) es el archivo ck_A814.json, identificado por su sha256
COMPLETO (ver SHA256SUMS.txt), steps=10560 y seq_pos=10080 (seq consumida entera).
NO existe ningun archivo llamado ck_A94.json: referencias al corte final deben
usar el sha completo o el alias "FINAL8 = ck_A814.json".

La metadata INTERNA de todos los checkpoints es correcta y fue verificada por
asserts en caliente en cada bloque (steps, seq_pos, seq_sha, seq_ext_prev,
adam.t/m/v, copy.t y dimensiones del copy head). El defecto es solo de NOMBRE
de archivo; no invalida el estado del modelo.
