#!/usr/bin/env python3
# Evaluador EOS independiente: cuentas exactas de parada (temprano/tarde/a tiempo) y contenido
# sobre pares (dataset U:/A:) y gens archivados. Uso: eos_analisis.py PARES GENS ETIQUETA
import re, sys
pares = open(sys.argv[1]).read().strip().split('\n')
gens = [l.rstrip('\n') for l in open(sys.argv[2])]
n = len(pares)//2
assert len(gens)==n, (sys.argv[2], len(gens), n)
temprano=tarde=atiempo=exactas=0
for i in range(n):
    m = re.match(r"(repite|invierte) '([a-z]+)'$", pares[2*i][3:])
    op,w = m.groups(); t = w if op=='repite' else w[::-1]
    g = gens[i].strip()
    if len(g)<len(t): temprano+=1
    elif len(g)>len(t): tarde+=1
    else: atiempo+=1
    if g==t: exactas+=1
print(f"{sys.argv[3]}: n={n} exactas={exactas} | EOS temprano={temprano} tarde={tarde} a_tiempo={atiempo}")
