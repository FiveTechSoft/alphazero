#!/bin/bash
# E6: UN brazo desde ck_A86 PRESERVADO, mix9 (L4+L5+L6+natural) + seq_comp9 (prefijo byte-exacto).
# 8x504 pasos (2 expos/par sobre 2016). SIN reset Adam/GRU/copy/RNG. copyhead learn seed 7.
# Comparacion DESCRIPTIVA vs trayectoria archivada (E5/CONF2); NO aislamiento de unica variable.
# LIMITES DUROS: wall 300s activo, bloque 40s, RSS<900MiB, proyeccion FUNDADA en medidos del brazo.
# PRIMER FALLO = PARAR y reportar. SIN autorecuperacion, SIN retries.
# NO EJECUTAR SIN ALCANCE EXPLICITO DEL MANTENEDOR DEL EXPERIMENTO.
set -e; set -o pipefail
ROOT="${BLM_ROOT:-/tmp/blm}"
[ -d "$ROOT/ciclo_e6" ] || { echo "PARADA-E6: ROOT invalido ($ROOT sin ciclo_e6)"; exit 9; }
cd "$ROOT"
MZ=./mzab_v3
BINSHA=77d01528f9bb2f1eba0c7afaa4c914bcabd5d6f8b8deb642b1d59651481bf75d
BASE=ciclo_e5/ck_A86.json
BASESHA=3b07a67ce51e55f22f414c0be0ef5749156ef3eb5afdeb96b5e912e7a1671a19
CORPUS=replay/master_mix9.txt; MAN=replay/man_mix9.txt; SEQ=replay/seq_comp9.txt
MIX9SHA=76b44ce20b15c61f5baf787d33ca9448a40fb3fa4b1b7f485f059b47b43e4bd4
MAN9SHA=cf254b77c4a473d264b8d934d98bd7bfc74f58943662d3acb3fc9ba3939336d9
SEQ9SHA=1bcaf6e3c0fb75211539872fa9c376cd3abd02cb6cf59d507619f154a9ef14d9
MIX8PREV=9fc4b760a2bcda9b405abf04f003536d6d27b2d7570f0e20ab29533cfa39baa3
SEQ8PREV=e7278e1061f7ef8c26965893e33bf8e1569f9479dab61c26541772979e0f7e76
STEPS0=6528; SEQPOS0=6048   # verificados en ck_A86 (steps, seq_pos, copy.t, adam.t)
mkdir -p ciclo_e6
fail() { echo "PARADA-E6: $1"; echo "PARADA-E6 $(date -Is) causa: $1" >> ciclo_e6/PARADAS.txt; exit "${2:-9}"; }
[ "$1" = "E6" ] || fail "uso: ciclo_e6_run.sh E6 [Kini] [Kfin]  (UN brazo)"
ARM=E6; KINI=${2:-1}; KFIN=${3:-8}; REANUDA=${4:-}
[ -z "$REANUDA" ] || [ "$REANUDA" = "REANUDA" ] || fail "4o arg solo admite REANUDA"
{ [ -z "$REANUDA" ] || [ "$KINI" -gt 1 ]; } || fail "REANUDA no aplica a KINI=1"
CAPBLK=40
ACTF=ciclo_e6/.activo_$ARM
[ -e "$ACTF" ] || echo 0 > "$ACTF"
CONSUMED=$(cat "$ACTF")
IV0=$(date +%s)
CAP=300

# PREFLIGHT por invocacion: binario, base, datos congelados
[ "$(sha256sum $MZ | cut -d' ' -f1)" = "$BINSHA" ] || fail "binario sha mismatch"
[ "$(sha256sum $BASE | cut -d' ' -f1)" = "$BASESHA" ] || fail "ck_A86 sha mismatch"
[ "$(sha256sum $CORPUS | cut -d' ' -f1)" = "$MIX9SHA" ] || fail "mix9 sha mismatch"
[ "$(sha256sum $MAN | cut -d' ' -f1)" = "$MAN9SHA" ] || fail "man9 sha mismatch"
[ "$(sha256sum $SEQ | cut -d' ' -f1)" = "$SEQ9SHA" ] || fail "seq9 sha mismatch"
head -6048 $SEQ | cmp -s - replay/seq_comp8.txt || fail "seq9 prefijo != seq8 byte-exacto"
sha256sum $MZ $BASE $CORPUS $MAN $SEQ replay/seq_comp8.txt replay/master_mix8.txt evalconf_MANIFIESTO.json evalconf_score.py dst6_score.py eos_analisis.py >> ciclo_e6/preflight_$ARM.txt

runmz() {
  local tag=$1; shift
  python3 - "$tag" "$@" <<'PYEOF'
import subprocess, resource, sys
tag, args = sys.argv[1], sys.argv[2:]
r = subprocess.run(["./mzab_v3"]+args)
kb = resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
print(f"RSSMAX {tag} {kb} KiB")
if kb > 921600: print(f"PARADA-E6: RSS {kb} KiB > 900MiB en {tag}"); sys.exit(11)
sys.exit(r.returncode)
PYEOF
}

led_append() { # LED linea — append atomico (preserva lineas previas, p.ej. reanudacion)
  local L=$1; shift
  { [ -e "$L" ] && cat "$L"; echo "$*"; } > "$L.tmp"; mv "$L.tmp" "$L"
}

CH="-copyhead learn -copyseed 7"
evalu() { # CK NOMBRE — evalconf3 L4/L5/L6/L7 (fresh) + dst7 helds + natural heldout100 (n=12 temp=0, head)
  local O=ciclo_e6
  timeout -k 2 40 $MZ d1gru -mode genpairs -in "$1" -corpus dst7_train504.txt -n 12 -temp 0 $CH > $O/gentrain_$2.txt 2>/dev/null || fail "gen train $2" 7
  timeout -k 2 40 $MZ d1gru -mode genpairs -in "$1" -corpus dst7_heldL48.txt -n 12 -temp 0 $CH > $O/genheldL_$2.txt 2>/dev/null || fail "gen heldL $2" 7
  timeout -k 2 40 $MZ d1gru -mode genpairs -in "$1" -corpus dst7_heldLong48.txt -n 12 -temp 0 $CH > $O/genheldLong_$2.txt 2>/dev/null || fail "gen heldLong $2" 7
  for L in 4 5 6 7; do
    timeout -k 2 40 $MZ d1gru -mode genpairs -in "$1" -corpus evalconf3_L${L}_48.txt -n 12 -temp 0 $CH > $O/genec3_L${L}_$2.txt 2>/dev/null || fail "gen ec3L$L $2" 7
  done
  TT=$(python3 dst6_score.py dst7_train504.txt $O/gentrain_$2.txt | python3 -c 'import json,sys; print(json.load(sys.stdin)["exact_total"])') || fail "score train $2" 8
  HL=$(python3 dst6_score.py dst7_heldL48.txt $O/genheldL_$2.txt | python3 -c 'import json,sys; print(json.load(sys.stdin)["exact_total"])') || fail "score heldL $2" 8
  HG=$(python3 dst6_score.py dst7_heldLong48.txt $O/genheldLong_$2.txt | python3 -c 'import json,sys; print(json.load(sys.stdin)["exact_total"])') || fail "score heldLong $2" 8
  E4=$(python3 evalconf_score.py evalconf3_L4_48.txt $O/genec3_L4_$2.txt) || fail "score ec3L4 $2" 8
  E5=$(python3 evalconf_score.py evalconf3_L5_48.txt $O/genec3_L5_$2.txt) || fail "score ec3L5 $2" 8
  E6=$(python3 evalconf_score.py evalconf3_L6_48.txt $O/genec3_L6_$2.txt) || fail "score ec3L6 $2" 8
  E7=$(python3 evalconf_score.py evalconf3_L7_48.txt $O/genec3_L7_$2.txt) || fail "score ec3L7 $2" 8
  RT=$(timeout -k 2 30 $MZ d1gru -mode scorepairs -in "$1" -corpus ciclo1_heldout100.txt $CH 2>/dev/null | awk '$1=="SCORE"{s+=$3;c++} END{printf "%.6f", s/c}')
  [ -n "$RT" ] || fail "bpb heldout $2" 8
  echo "== $2 train504=$TT heldL48=$HL heldLong48=$HG bpb=$RT ec3L4=$E4 ec3L5=$E5 ec3L6=$E6 ec3L7=$E7"
  echo "$2 train504=$TT heldL48=$HL heldLong48=$HG bpb=$RT ec3L4=$E4 ec3L5=$E5 ec3L6=$E6 ec3L7=$E7" >> ciclo_e6/resultados_$ARM.txt
  for L in 4 5 6 7; do
    python3 eos_analisis.py evalconf3_L${L}_48.txt $O/genec3_L${L}_$2.txt "$2-EOS-L$L" >> ciclo_e6/eos_$ARM.txt
  done
  # Todos los gen/score/asserts anteriores llevan || fail (propagacion intacta, nada enmascarado).
  if [ -e "ciclo_e6/ledger_$2" ]; then
    echo "eval_ok $(date -Is)" >> "ciclo_e6/ledger_$2"
  fi
  return 0
}

bloque() { # K IN OUT LABEL
  local K=$1 IN=$2 OUT=$3 LABEL=${4:-${ARM}${K}}
  local LED="ciclo_e6/ledger_${LABEL}"
  if [ -n "$REANUDA" ] && [ "$K" = "$KINI" ]; then
    local ORIG="ciclo_e6/ledger_${ARM}${K}"
    [ -e "$ORIG" ] || fail "REANUDA sin ledger original ${ARM}${K}" 3
    grep -q "train_running" "$ORIG" || fail "REANUDA exige ledger original en train_running" 3
    if grep -q "train_ok" "$ORIG"; then fail "REANUDA rechazada: ledger original ya tiene train_ok" 3; fi
    grep -qE "causa: training bloque ${ARM}${K}( |$)" ciclo_e6/PARADAS.txt || fail "REANUDA exige PARADA genuina registrada de ${ARM}${K}" 3
    [ ! -e "$LED" ] || fail "ledger ${LABEL} ya existe (sin 2o retry)" 3
    led_append "$LED" "reanudacion $(date -Is) desde ledger_${ARM}${K} (original train_running + PARADA genuina preservados sin modificar) parent_ck_sha256=$(sha256sum "$IN" | cut -d' ' -f1)"
  else
    [ -e "$LED" ] && fail "ledger ${LABEL} ya existe" 3
  fi
  local el=$(( CONSUMED + $(date +%s) - IV0 ))
  local avg=36
  local medidos=$(ls ciclo_e6/ledger_${ARM}* 2>/dev/null | wc -l)
  if [ "$medidos" -gt 0 ]; then
    avg=$(awk -F'segundos=' '/segundos=/{s+=$2; c++} END{print (c>0)? int(s/c)+18 : 36}' ciclo_e6/ledger_${ARM}* 2>/dev/null || echo 36)
  fi
  local rest=$(( (KFIN-K+1)*avg ))
  [ $((el+rest)) -gt $CAP ] && fail "proyeccion fundada ${el}s+${rest}s(avg=${avg}) > ${CAP}s" 5
  led_append "$LED" "train_running $(date -Is)"
  local t0=$SECONDS
  local PF=""; [ $K = 1 ] && PF="-master-prev $MIX8PREV -seq-ext-prev $SEQ8PREV"
  local LOG=ciclo_e6/train_${LABEL}.log
  set +e
  runmz ${ARM}$K d1gru -mode train-pairs -corpus $CORPUS -val dst7_heldL48.txt \
    -in "$IN" -out "$OUT" -steps 504 -lr 0.003 -seed 7 \
    -master $CORPUS -manifest $MAN -seq $SEQ $PF $CH 2>&1 \
    | tee "$LOG" | grep -E 'FIN|RECHAZO|EXTENSION|seq predefinida|RSSMAX|copy head'
  local PS=("${PIPESTATUS[@]}")
  set -e
  echo "PIPESTATUS runmz=${PS[0]} tee=${PS[1]} grep=${PS[2]} ck_out=$([ -e "$OUT" ] && echo "presente sha=$(sha256sum "$OUT" | cut -c1-16)" || echo ausente)" >> "$LOG"
  [ "${PS[0]}" = 0 ] && [ "${PS[2]}" = 0 ] || fail "training bloque ${ARM}$K (runmz=${PS[0]} grep=${PS[2]}; causa en $LOG)" 4
  local dt=$((SECONDS-t0))
  ASSERTFAIL=0
  python3 - "$OUT" $K "$SEQ9SHA" "$SEQ8PREV" $STEPS0 $SEQPOS0 <<'PYEOF' || ASSERTFAIL=1
import json, sys
c=json.load(open(sys.argv[1])); k=int(sys.argv[2]); seqsha=sys.argv[3]; prev=sys.argv[4]
s0=int(sys.argv[5]); p0=int(sys.argv[6])
assert c.get('steps')==s0+504*k, ('steps', c.get('steps'))
assert c.get('seq_pos')==p0+504*k, ('seq_pos', c.get('seq_pos'))
assert c.get('seq_sha')==seqsha, ('seq_sha', c.get('seq_sha'))
assert c.get('seq_ext_prev')==prev, ('seq_ext_prev', c.get('seq_ext_prev'))
a=c.get('adam'); assert isinstance(a,dict) and a.get('t')==s0+504*k, ('adam.t', a and a.get('t'))
assert isinstance(a.get('m'),list) and len(a['m'])==9 and isinstance(a.get('v'),list) and len(a['v'])==9, 'adam m/v'
assert c.get('ckpt_version')==2, 'ckpt_version'
cp=c.get('copy'); assert isinstance(cp,dict), 'seccion copy'
assert cp.get('t')==p0+504*k, ('copy.t', cp and cp.get('t'))
for key in ('wq','wk','mwq','vwq','mwk','vwk'):
    assert len(cp[key])==64 and len(cp[key][0])==64, key
assert len(cp['wg'])==128, 'wg'
PYEOF
  if [ $ASSERTFAIL -ne 0 ]; then
    led_append "$LED" "PARADA assert_fallo $(date -Is) segundos=$dt"
    fail "assert en caliente bloque ${ARM}${K}" 6
  fi
  if [ $dt -gt $CAPBLK ]; then
    led_append "$LED" "PARADA cap_bloque $(date -Is) segundos=$dt"
    fail "bloque ${ARM}${K} ${dt}s > ${CAPBLK}s" 4
  fi
  led_append "$LED" "train_ok+asserts_ok $(date -Is) segundos=$dt"
  echo "OK bloque ${ARM}${K} ${dt}s (train+asserts; eval queda registrada aparte)"
}

if [ $KINI -gt 1 ] && [ ! -e ciclo_e6/.base0_done ]; then
  fail "KINI>1 sin marker BASE0: BASE0 ya medido historicamente, no se re-mide" 9
fi
if [ ! -e ciclo_e6/.base0_done ]; then
  echo "== PREUPDATE BASE ck_A86 (misma medicion que cortes E5) =="
  evalu "$BASE" BASE0
  grep -q "^BASE0 " ciclo_e6/resultados_${ARM}.txt || fail "evidencia BASE0 ausente en resultados (marker NO escrito)" 8
  for L in 4 5 6 7; do [ -s ciclo_e6/genec3_L${L}_BASE0.txt ] || fail "gen BASE0 L$L ausente (marker NO escrito)" 7; done
  echo "base0_ok $(date -Is)" > ciclo_e6/.base0_done.tmp; mv ciclo_e6/.base0_done.tmp ciclo_e6/.base0_done
fi
if [ $KINI -gt 1 ]; then
  PREV=ciclo_e6/ck_A8$((5+KINI)).json
  [ -e "$PREV" ] || fail "PREV $PREV ausente para KINI=$KINI" 9
  echo "PREV resume: $PREV sha256=$(sha256sum "$PREV" | cut -d' ' -f1)"
else
  PREV=$BASE
fi
for K in $(seq $KINI $KFIN); do
  OUT=ciclo_e6/ck_A8$((6+K)).json
  LABEL=${ARM}${K}
  if [ -n "$REANUDA" ] && [ "$K" = "$KINI" ]; then LABEL=${ARM}${K}r; fi
  bloque $K "$PREV" "$OUT" "$LABEL"
  evalu "$OUT" "$LABEL"
  PREV=$OUT
  echo $(( CONSUMED + $(date +%s) - IV0 )) > "$ACTF"
done
echo "E6 COMPLETO (8 bloques). Corte oficial = ck_A94 (FINAL8)."
