#!/bin/bash
# Muestra E6 FINAL8 — SOLO lectura de archivos archivados (sin gens ni updates).
# Uso: bash muestra_e6.sh [dir_pack38_extraido]   (por defecto: pack38 actual)
set -e
D=${1:-.}
echo "== E6 FINAL8 — veredicto vs umbrales predeclarados =="
grep -A9 '| criterio FINAL8' $D/docs/RESULTADOS_E6.md | head -11
echo
echo "== Casos fijos (input | target | salida FINAL8 | veredicto) =="
grep -E '^L[45] ' $D/docs/casos_fijos_e6.txt | head -8 | cut -d'|' -f2-6
grep -E '^L6 ' $D/docs/casos_fijos_e6.txt | head -2 | cut -d'|' -f2-6
echo
echo "== Cadena de checkpoints (steps/seq_pos internos verificados) =="
grep -E '^\| (base|[1-8])' $D/docs/ALIAS_checkpoints_E6.md | cut -d'|' -f2,3,4,5,6 | head -9
