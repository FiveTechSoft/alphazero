#!/bin/bash
# CICLO3 RUN ACOTADO (autorizacion 13:01). Reglas CONGELADAS antes de arranque:
#  R1: estimacion bloque 43s (observado natural, NO cota) +10% -> bloque wall
#      > 47s = PARAR Y REPORTAR (no evaluar contra intuicion).
#  R2: tope total 300s wall (incluye scoring/gens/retencion); antes de cada
#      bloque, si transcurrido+48 > 300 = PARAR.
#  R3: parada al primer fallo real, SIN reintentos. RSS<900MiB (binario d32h64,
#      verificado en piloto). Ledger atomico running/completed/failed por clave.
set -e; cd /tmp/blm
PREV=c8ee772eb1d2dfe4c2ea8ffc38d991f07750309d449eff53f82d63af3476b355
TSTART=$SECONDS
adamsha() { python3 -c "
import json,hashlib
d=json.load(open('$1'))
print(hashlib.sha256(json.dumps(d.get('adam'),sort_keys=True).encode()).hexdigest()[:16], hashlib.sha256(str(d.get('samp')).encode()).hexdigest()[:16])"; }
bloque() { # ARM K MASTER MAN CKIN CKS PREVFLAG
  local A=$1 K=$2 MA=$3 MF=$4 IN=$5 OUT=$6 PF=$7
  local INSHA; INSHA=$(sha256sum "$IN" | cut -c1-12)
  local KEY; KEY="${A}${K}_${INSHA}"
  local LED; LED="ciclo3/ledger_$KEY"
  if [ -e "$LED" ]; then
    local ST=$(cut -d' ' -f1 "$LED")
    [ "$ST" = completed ] && { echo "LEDGER $KEY ya completada"; return 0; }
    echo "LEDGER $KEY estado=$ST: recuperacion manual, NO ejecutar"; exit 3
  fi
  echo "running $(date -Is)" > "$LED.tmp"; mv "$LED.tmp" "$LED"
  trap 'if [ -n "$LED" ]; then echo "failed $(date -Is)" > "$LED.tmp"; mv "$LED.tmp" "$LED"; fi' ERR
  local t0=$SECONDS
  timeout -k 2 100 ./mz d1gru -mode train-pairs -corpus "$MA" -val dst_dev.txt \
    -in "$IN" -out "$OUT" -steps 480 -lr 0.003 -seed 7 \
    -master "$MA" -manifest "$MF" $PF 2>&1 | grep -E 'FIN|RECHAZO|curriculo|DECLARADO'
  local dt=$((SECONDS-t0))
  echo "adam_rng_antes: $(adamsha "$IN")" >> ciclo3/adam_$A$K.txt
  echo "adam_rng_despues: $(adamsha "$OUT")" >> ciclo3/adam_$A$K.txt
  if [ $dt -gt 47 ]; then
    echo "failed $(date -Is) REGLA-R1 bloque ${dt}s > 47s" > "$LED.tmp"; mv "$LED.tmp" "$LED"
    echo "PARADA R1: bloque $A$K ${dt}s > 47s (estimacion congelada 43s+10%)"; exit 4
  fi
  echo "completed $(date -Is) segundos=$dt" > "$LED.tmp"; mv "$LED.tmp" "$LED"
  echo "OK bloque $A$K ${dt}s"
  local el=$((SECONDS-TSTART))
  if [ $((el+48)) -gt 300 ]; then echo "PARADA R2: proyeccion ${el}s+48 > 300s"; exit 5; fi
}
# --- BASE (sin entrenar): exact match + retencion ---
timeout -k 2 60 ./mz d1gru -mode genpairs -in ciclo1_etapa0.json -corpus dst_dev.txt -n 16 -temp 0 > ciclo3/gen_base.txt 2>/dev/null
python3 dst_score.py --dev dst_dev.txt --gens ciclo3/gen_base.txt > ciclo3/exact_base.json
echo "BASE exact: $(cat ciclo3/exact_base.json | tr -d '\n ')"
# --- brazos ---
for ARM in A C; do
  if [ $ARM = A ]; then MA=dst_train.txt; MF=ciclo3/man_train.txt; else MA=dst_control.txt; MF=ciclo3/man_control.txt; fi
  cp ciclo1_etapa0.json ciclo3/ck_${ARM}0.json   # clon byte-exacto (Adam+RNG)
  for K in 1 2 3; do
    P=$((K-1)); PF=""; [ $K = 1 ] && PF="-master-prev $PREV"
    bloque $ARM $K "$MA" "$MF" ciclo3/ck_${ARM}${P}.json ciclo3/ck_${ARM}${K}.json "$PF"
    timeout -k 2 60 ./mz d1gru -mode genpairs -in ciclo3/ck_${ARM}${K}.json -corpus dst_dev.txt -n 16 -temp 0 > ciclo3/gen_${ARM}${K}.txt 2>/dev/null
    python3 dst_score.py --dev dst_dev.txt --gens ciclo3/gen_${ARM}${K}.txt > ciclo3/exact_${ARM}${K}.json
    echo "$ARM$K exact: $(cat ciclo3/exact_${ARM}${K}.json | tr -d '\n ')"
  done
done
# --- retencion natural (heldout100): base vs A3 vs C3, misma comparacion ---
for CK in ciclo1_etapa0 ciclo3/ck_A3 ciclo3/ck_C3; do
  N=$(basename $CK)
  timeout -k 2 60 ./mz d1gru -mode scorepairs -in $CK.json -corpus ciclo1_heldout100.txt 2>/dev/null | awk '$1=="SCORE"{s+=$3;n++} END{printf "retencion %s bpb=%.6f (%d pares)\n", "'$N'", s/n, n}'
done
echo "TOTAL wall=$((SECONDS-TSTART))s (tope 300)"
