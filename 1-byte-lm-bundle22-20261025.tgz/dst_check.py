#!/usr/bin/env python3
# dst_check.py — fixtures del generador DST v2 (8/8 deben pasar ANTES de cualquier uso)
import sys, re, hashlib
sys.path.insert(0, '/tmp/blm')
from dst_gen import OPS, OPN, aplica, pregunta, clave, gen

def lee(path):
    ps=[]
    for l in open(path):
        m=re.match(r"U: aplica (.+) a '([a-z]+)'$", l.rstrip('\n'))
        if m: ps.append((m.group(1), m.group(2)))
    return ps

def opsde(s):
    partes=s.split(' y ')
    return [partes[0], partes[1]] if len(partes)==2 else [partes[0]]

F=[]
def check(nombre, ok, det=''):
    F.append((nombre, bool(ok), det)); print(('PASS' if ok else 'FAIL'), nombre, det)

train, dev, final, comps = gen(77)
# 1) determinismo: regenerar da identico
t2, d2, f2, _ = gen(77)
check('determinismo seed77', (train,dev,final)==(t2,d2,f2))
# 2) transformaciones correctas en cada linea de los 4 ficheros
def verifica(path, despl=None):
    lines=open(path).read().strip().split('\n')
    ok=True; ans=[]
    for i in range(0,len(lines),2):
        u=lines[i][3:]; a=lines[i+1][3:]
        opsw=re.match(r"aplica (.+) a '([a-z]+)'$", u)
        ops, w = opsde(opsw.group(1)), opsw.group(2)
        ans.append(aplica(ops,w))
        if despl is None and aplica(ops,w)!=a: ok=False
    if despl is not None:
        n=len(ans)
        for i in range(0,len(lines),2):
            a=lines[i+1][3:]
            if a!=ans[(i//2+despl)%n]: ok=False
    return ok
check('transformaciones correctas train/dev/final', all(verifica(f'/tmp/blm/dst_{n}.txt') for n in ('train','dev','final')))
check('control = barajado desplazamiento 37', verifica('/tmp/blm/dst_control.txt', 37))
# 3) palabras dev/final NO VISTAS en train (y disjuntas entre si)
wt={w for _,w in lee('/tmp/blm/dst_train.txt')}
wd={w for _,w in lee('/tmp/blm/dst_dev.txt')}
wf={w for _,w in lee('/tmp/blm/dst_final.txt')}
check('palabras dev/final no vistas y disjuntas', not (wt&wd) and not (wt&wf) and not (wd&wf),
      f'|train|={len(wt)} |dev|={len(wd)} |final|={len(wf)}')
# 4) composiciones: dev_unseen y final disjuntas de train y entre si (de 56 posibles)
def compsde(path):
    return {tuple(opsde(s)) for s,_ in lee(path) if ' y ' in s}
ct, cd, cf = compsde('/tmp/blm/dst_train.txt'), compsde('/tmp/blm/dst_dev.txt'), compsde('/tmp/blm/dst_final.txt')
tot={(a,b) for a in OPN for b in OPN if a!=b}
cdu = cd - ct   # dev contiene composiciones VISTAS (generalizacion a palabras nuevas) y NO VISTAS
check('composiciones disjuntas 20+16+20=56', len(ct)==20 and len(cdu)==16 and len(cf)==20 and not (ct&cdu) and not (ct&cf) and not (cdu&cf) and ct|cdu|cf==tot,
      f'train={len(ct)} dev_unseen={len(cdu)} final={len(cf)} posibles={len(tot)}')
# 5) control (sobre TRAIN) desacoplado: 0 coincidencias respuesta-oraculo
lines=open('/tmp/blm/dst_control.txt').read().strip().split('\n'); coin=0
for i in range(0,len(lines),2):
    opsw=re.match(r"aplica (.+) a '([a-z]+)'$", lines[i][3:])
    if aplica(opsde(opsw.group(1)),opsw.group(2))==lines[i+1][3:]: coin+=1
check('control 0 coincidencias con oraculo', coin==0, f'coincidencias={coin}')
# 6) margenes exactos: multiconjunto respuestas control == TRAIN; numerosidad == 176
from collections import Counter
ad=[lines[i+1][3:] for i in range(0,len(lines),2)]
trl=open('/tmp/blm/dst_train.txt').read().strip().split('\n')
atr=[trl[i+1][3:] for i in range(0,len(trl),2)]
check('control sobre train: mismos 176 pares y margenes exactos', len(ad)==176 and Counter(ad)==Counter(atr), f'n_control={len(ad)}')
# 7) sin colisiones proxy vs corpus existentes
existentes=['/tmp/blm/piloto/train500.txt','/tmp/blm/piloto/sub500.txt','/tmp/blm/piloto/dev100.txt','/tmp/blm/piloto/final100.txt','/tmp/blm/piloto/ciclo2_final100_v2.txt']
import os
cex=set()
for p in existentes:
    if os.path.exists(p):
        for l in open(p):
            if l.startswith('U: '): cex.add(clave(l[3:].rstrip('\n')))
col=0
for f in ('dst_train.txt','dst_dev.txt','dst_control.txt','dst_final.txt'):
    for l in open('/tmp/blm/'+f):
        if l.startswith('U: ') and clave(l[3:].rstrip('\n')) in cex: col+=1
check('sin colisiones proxy vs 5 conjuntos existentes', col==0, f'colisiones={col}')
# 8) respuesta depende de la operacion (misma palabra, ops distintas -> respuestas distintas)
w='abcd'
rs={aplica([o],w) for o in OPN}
check('respuesta depende de op (8 ops -> 8 respuestas distintas)', len(rs)==8, f'distintas={len(rs)}/8')
n=sum(1 for _,ok,_ in F if ok)
print(f'{n}/{len(F)} fixtures PASS')
sys.exit(0 if n==len(F) else 1)
