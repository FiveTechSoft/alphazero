# ERRATA TECNICA CICLO-3 (adendo; NO reescribe evidencia)

## E1. Ejecuciones reales vs logicas
El piloto ejecuto 8 bloques reales, 6 logicos: A1 se ejecuto 3 veces por un
bug del script (declaraciones `local` combinadas: KEY/LED se expandian vacias,
bash no asigna antes de expandir el resto de la misma declaracion). Las 3
partieron de BASE IDENTICA verificada: Adam/RNG "antes" identicos en las 3
(9c5816d6913d3cce / c439a0d0e5af72cb, = estado de ciclo1_etapa0), input
ck_A0.json = clon byte-exacto de etapa0 (sha256 51dcbe4b6e3832c8... re-copiado
antes de cada ejecucion), mismo corpus/manifiesto verificado por expansion en
cada carga. NO hubo encadenamiento: los "despues" tambien son identicos en las
3 (6048e24ad3454327 / 39a02252f09d7613); resultado byte-identico. ck_A1.json
final es el de la 3a ejecucion (= misma huella).

## E2. Evidencia alterada/eliminada durante la reparacion (transparencia)
- El ledger original de la 1a ejecucion de A1 se creo con nombre vacio
  (`ledger_`, contenido "completed 2026-10-25T13:05:34+01:00 segundos=1") y
  fue RENOMBRADO a ledger_A1_51dcbe4b6e38 (contenido intacto, nombre cambiado).
- Los ledger_ de la 2a ("completed 2026-10-25T13:06:11+01:00 segundos=1") y
  3a ejecucion ("completed 2026-10-25T13:06:56+01:00 segundos=2", visible en
  traza bash -x archivada) fueron ELIMINADOS (rm) durante la reparacion.
  Contenido conservado verbatim aqui y en el historial de la sesion.
- gen_A2.txt de la 1a corrida (0 bytes, incompleto por aborto) fue eliminado;
  el actual (720B) es de la corrida final, regenerado del ck_A1 identico.
- Logs de las corridas 1-3 (salida consola) no se guardaron a fichero; su
  contenido esta en el historial de la sesion. La corrida final si:
  ciclo3_run.log.

## E3. Coste: precision de medicion
- "TOTAL wall=17s" es SOLO la corrida final (bash SECONDS, wall), que salto A1
  por ledger. Las 2 ejecuciones redundantes de A1 costaron 1s y 2s (wall).
  Agregado real: 8 ejecuciones de bloque = 14s wall de bloques; ~20s wall
  totales incluyendo todo. CPU ~= wall (proceso unico, single-thread).
- La captura TUI muestra los 6 bloques logicos; las 2 ejecuciones extra de A1
  no aparecian (esta errata las declara).

## E4. Estado
Resultado negativo EN ESTE PRESUPUESTO (2 brazos x 3x480 pasos, d32/h64,
lr 0.003): no es una incapacidad universal. dst_final sigue CERRADO.
Runner corregido con runner_lib.sh + 8 fixtures PASS (comando falso,
contador inyectado, sin modelo): exactamente-una vez, claves distintas,
fallo/running sin reejecucion, preflight rechaza vacios, nunca ledger sin
clave. ciclo3_run.sh lleva el fix simple (locals separadas).
