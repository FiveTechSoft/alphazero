# CICLO-3 PROTOCOLO v2 (propuesta para congelado) — aprendizaje condicionado en dominio sintetico limitado

## 1. Alcance declarado
Aprendizaje de una TAREA formal limitada (transformaciones de cadenas) desde
pares U/A, con evaluacion objetiva por generacion libre. NO conversacion
abierta. NO se llama RSI. Las reglas NO estan en el runtime del modelo: el
generador programa DATOS y actua de ORACULO OFFLINE solo para puntuar.
Criterio primario: exact-match en generacion; loss/gap solo diagnosticos.

## 2. Dominio DST y convenciones congeladas en los datos
- 8 operaciones: ROT1..ROT5 (k fija en el nombre), INVIERTE, DUPLICA, CAMBIA
  (h=len//2 fija). Orden de aplicacion = orden en la pregunta.
- Formato congelado: "aplica OP a 'w'" / "aplica OP1 y OP2 a 'w'".
- Palabras: 4 letras a-z. Composiciones ordenadas posibles: 8x7=56.
- EQUIVALENCIAS SEMANTICAS DECLARADAS: ROT_a o ROT_b == ROT_{a+b} y las
  rotaciones conmutan; la disjuncion 20/16/20 es NOMINAL (por nombre de
  composicion), NO semantica. No se promete "regla independiente nueva":
  generalizar a una composicion nominalmente no vista puede ser posible por
  equivalencia con reglas vistas. Salidas del oraculo y equivalencias
  CONGELADAS en los datos; alcance limitado, valido por declarado.
- Generador: dst_gen.py, seed 77, determinista (fixture 1).

## 3. Splits y conteos exactos (9/9 fixtures PASS, dst_check.py)
- train 176 pares: singletons 96 + 20 composiciones VISTAS x 4.
- dev 144 pares, COMUN de evaluacion: NINGUN brazo entrena con el.
  Categorias por separado: singles_palabra_nueva 24 /
  comp_vista_palabra_nueva 40 / comp_nueva_palabra_nueva 80.
- control 176 pares: LAS MISMAS preguntas de train con las respuestas de
  train permutadas (desplazamiento k=37). Misma numerosidad, margenes de
  longitud/alfabeto EXACTOS (multiconjunto identico, fixture 6), mismo
  sampling de 480 pasos. 0 coincidencias con el oraculo (fixture 5).
- final sintetico 100 pares: 20 composiciones NO VISTAS disjuntas de train Y
  dev (nominalmente; 20+16+20=56), palabras NO VISTAS. CONGELADO, USO UNICO,
  nunca visible para el controlador. FINAL-2 natural NO se usa (reservado).
- Palabras train/dev/final mutuamente disjuntas. Sin colisiones proxy vs
  train500/sub500/dev100/final100 viejo/FINAL-2 (funcion proxy congelada).
- Longitudes reales: train media 41.3B mediana 43B max 54B; respuesta max 8B.
- SHAs16: train 5252379a03f01b05, dev 9a26af11eabb3ba4,
  control b67de608fa1d3e3b, final d7719e1bd6b0bc0e.

## 4. Base comun declarada (fuente: JSON real del checkpoint)
- Checkpoint propio ciclo1_etapa0.json: GRU d=32, h=64, 43 456 parametros
  (contados sobre el formato: E 8192 + W 18432 + B 192 + Wo 16384 + bo 256).
  SHA256 51dcbe4b6e3832c840332f0ebe29c9b93def23a99ab4deb29354c2e3b9cb1e19.
  Entrenado UNICAMENTE con corpus propio del proyecto; sin modelo externo.
- Ambos brazos = clones byte-exactos (mismos Adam/RNG), identico compute:
  A) DST -> dst_train. B) CONTROL -> dst_control.
- Referencia adicional: BASE = clon SIN entrenar, evaluado con las mismas
  convenciones (exact match esperado ~0; se MIDE, no se asume).
- (Rectificacion: versiones anteriores decian d=256/h=512; incorrecto, la
  fuente es el JSON real arriba.)

## 5. Evaluacion primaria: exact match en generacion libre
- Ruta gen2 (cebado corregido) con temp<=0 = GREEDY determinista. Fixtures
  PASS: determinismo total (ignora semilla); paridad primer byte = argmax
  manual de logits tras cebar; maxB acota; y con el checkpoint memorizado
  overfit10 (sin entrenamiento nuevo) reproduce EXACTAMENTE las respuestas
  leidas del corpus en tiempo de test (funcion real, no hardcoded) con stop
  EOS '\n' limpio, sin recortes post-hoc.
- Prompt: "U: <pregunta>\nA: "; parada en '\n'; maxB=16 (respuesta max 8B).
- Puntuacion: dst_score.py (oraculo offline; validado 144/144 y 0/144).
- Vocabulario/preguntas: de los datos congelados; el oraculo NUNCA entra en
  runtime ni en prompts.

## 6. Criterios falsables (declarados ANTES de medir)
- A (aprende): exact_total dev >= 90% tras <= 3 bloques de 480 pasos.
- B (generaliza): exact comp_nueva_palabra_nueva >= 50% (con la declaracion
  de equivalencias nominales de la seccion 2).
- C (senal sobre control): DELTA exact_A - exact_CONTROL >= 50 puntos, con
  exact_CONTROL y exact_BASE medidos y reportados. Aciertos de azar o
  control > 0 NO invalidan automaticamente; lo que manda es el delta.
- D (retencion): bpb en dev100 natural, brazo DST vs base comun, empeora
  <= 0.05 (eval del piloto, 589s conocido).
- Examen final sintetico (dst_final): UNA ejecucion al cerrar, solo si A/B/C
  se cumplen; confirmacion, no selector.
- Negativos se reportan igual que positivos, con numeros por categoria.

## 7. Coste (estimacion, NO garantia)
- Medido: pares DST mediana 43B vs 371B naturales (~8.6x mas cortos).
- Observado: bloque 480 pasos en naturales = 43s (NO cota probada).
- Presupuesto de parada: total <= 300s CPU (2 brazos x 3 bloques + eval BASE
  + generacion/puntuacion ~3s c/u). Guardas: bloque < 105s, RSS < 900MiB,
  parada al primer fallo real, sin reintentos; >10% sobre estimacion = PARAR
  Y REPORTAR.

## 8. Estado del codigo
- Nuevo: rama greedy en generateGRU2 (generateGRU vieja intacta) + 2 fixtures
  PASS; dst_gen.py v2 (control sobre train), dst_check.py 9/9, dst_score.py.
- Preexistentes: capseq.go + fixtures, mce.go + gradient-check 12/12,
  gappairs/gaptokens + fixtures.
- Suite completa: ultima verde 96.2s 0 FAIL tras el revert/parche gen2
  (hora de ejecucion reportada con el resultado); se re-ejecuta ANTES de
  cualquier entrenamiento si hubiera nuevos cambios.
- MCE queda fuera de CICLO-3 (registro: no identificable en la poblacion
  medida, conteo real 100/100 m>=0.005, 87/100 m=0.001, BASE/DEV100).

## 9. Capturas y honestidad
- Pantallazos solo desde TUI real de OpenCode, queries archivadas.
- Sin reconstrucciones, sin entrenar para la foto, negativos = positivos.
