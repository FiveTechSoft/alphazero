#!/usr/bin/env python3
# dst_gen.py — Generador DOMINIO SINTETICO DE TRANSFORMACION (DST), CICLO-3 v2.
# Dominio formal LIMITADO declarado: NO conversacion abierta, NO reglas en el
# modelo en runtime (el generador programa DATOS; sirve de ORACULO offline para
# puntuar exact-match). Convenciones congeladas EN LOS DATOS: nombre de la op
# y su parametro van en la pregunta (ROT1..ROT5 con k fija, INVIERTE, DUPLICA,
# CAMBIA con mitad fija h=len//2; orden de aplicacion = orden de la pregunta).
# Splits (todo con seed 77, palabras de 4 letras):
#   train          : singletons (8 ops x 12) + 20 composiciones VISTAS x 4
#   dev_singles    : singletons x 3 palabras NO VISTAS (generalizacion op->palabra)
#   dev_comp_seen  : composiciones VISTAS x 2 palabras NO VISTAS
#   dev_comp_unseen: 16 composiciones NO VISTAS x 5 palabras NO VISTAS
#   control        : TRAIN completo con respuestas TRAIN permutadas
#                    (misma numerosidad 176, margenes/longitudes exactos, k=37)
#   final          : 20 composiciones NO VISTAS disjuntas de train Y dev x 5
#                    palabras NO VISTAS (EXAMEN FINAL SINTETICO, uso unico,
#                    congelado; sustituye a FINAL-2 natural en esta sonda)
import random, json, re, hashlib

OPS = {}
def rot(w, k): return ''.join(chr((ord(c)-97+k)%26+97) for c in w)
def invierte(w): return w[::-1]
def duplica(w): return ''.join(c*2 for c in w)
def cambia(w): h=len(w)//2; return w[h:]+w[:h]
for k in (1,2,3,4,5): OPS[f'ROT{k}'] = (lambda k: (lambda w: rot(w,k)))(k)
OPS['INVIERTE']=invierte; OPS['DUPLICA']=duplica; OPS['CAMBIA']=cambia
OPN = list(OPS)

def palabra(rng, n=4): return ''.join(rng.choice('abcdefghijklmnopqrstuvwxyz') for _ in range(n))
def aplica(ops, w):
    for o in ops: w = OPS[o](w)
    return w
def pregunta(ops, w):
    if len(ops)==1: return f"aplica {ops[0]} a '{w}'"
    return f"aplica {ops[0]} y {ops[1]} a '{w}'"
def clave(u): return re.sub(r'[^a-z0-9]','',u.lower())[:40]

def gen(seed=77):
    rng = random.Random(seed)
    usadas = set()
    def nueva():
        while True:
            w = palabra(rng)
            if w not in usadas:
                usadas.add(w); return w
    simples = [([o], nueva()) for o in OPN for _ in range(12)]                  # 96
    pares = [(a,b) for a in OPN for b in OPN if a!=b]                           # 56 ordenadas
    rng.shuffle(pares)
    comp_train, comp_dev_u, comp_final = pares[:20], pares[20:36], pares[36:56] # 20/16/20 disjuntas
    train = simples + [([a,b], nueva()) for a,b in comp_train for _ in range(4)]
    rng.shuffle(train)                                                          # 176
    dev_singles  = [([o], nueva()) for o in OPN for _ in range(3)]              # 24
    dev_comp_s   = [([a,b], nueva()) for a,b in comp_train for _ in range(2)]   # 40
    dev_comp_u   = [([a,b], nueva()) for a,b in comp_dev_u for _ in range(5)]   # 80
    dev = dev_singles + dev_comp_s + dev_comp_u                                 # 144
    final = [([a,b], nueva()) for a,b in comp_final for _ in range(5)]          # 100
    rng.shuffle(dev); rng.shuffle(final)
    return train, dev, final, {'comp_train':comp_train,'comp_dev':comp_dev_u,'comp_final':comp_final}

def escribe(pares, path, desplazamiento_control=None):
    n=len(pares); ans=[aplica(ops,w) for ops,w in pares]
    with open(path,'w') as f:
        for i,(ops,w) in enumerate(pares):
            a = ans[i] if desplazamiento_control is None else ans[(i+desplazamiento_control)%n]
            f.write(f"U: {pregunta(ops,w)}\nA: {a}\n")

def longitudes(pares):
    from collections import Counter
    return dict(sorted(Counter(len(aplica(o,w)) for o,w in pares).items()))

if __name__ == '__main__':
    train, dev, final, comps = gen(77)
    escribe(train, '/tmp/blm/dst_train.txt')
    escribe(dev,   '/tmp/blm/dst_dev.txt')
    escribe(train, '/tmp/blm/dst_control.txt', desplazamiento_control=37)
    escribe(final, '/tmp/blm/dst_final.txt')
    meta = {'seed':77,'ops':OPN,'n_ops':8,'composiciones_posibles':56,
            'comp_train':20,'comp_dev_unseen':16,'comp_final':20,
            'n_train':len(train),'n_dev':len(dev),'n_final':len(final),
            'dev_singles':24,'dev_comp_seen':40,'dev_comp_unseen':80,
            'longitudes_train':longitudes(train),'longitudes_dev':longitudes(dev),
            'longitudes_final':longitudes(final),
            'control_desplazamiento':37,'control_base':'train176',
            'nota':'dominio sintetico limitado; control=respuestas barajadas con margenes exactos; final sintetico congelado uso unico'}
    open('/tmp/blm/dst_meta.json','w').write(json.dumps(meta, indent=1))
    for f in ('dst_train.txt','dst_dev.txt','dst_control.txt','dst_final.txt'):
        print(f, hashlib.sha256(open('/tmp/blm/'+f,'rb').read()).hexdigest()[:16])
