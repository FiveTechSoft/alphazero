#!/bin/bash
# runner_fixtures.sh — fixtures del runner con COMANDO FALSO (contador), sin modelo.
set -u; cd /tmp/blm
T=/tmp/runner_fixtures; rm -rf $T; mkdir -p $T/led
export RUNNER_LEDGER_DIR=$T/led
source runner_lib.sh
echo datos1 > $T/in1.txt; echo datos2 > $T/in2.txt
touch $T/contador
falso_ok() { echo x >> $T/contador; return 0; }
falso_fail() { echo x >> $T/contador; return 7; }
P=0; F=0
ok(){ if [ "$1" = "$2" ]; then P=$((P+1)); echo "PASS $3"; else F=$((F+1)); echo "FAIL $3: esperado [$1] obtenido [$2]"; fi; }
# 1) dos solicitudes IDENTICAS: comando ejecuta UNA vez
runner_ejecuta op1 $T/in1.txt falso_ok >/dev/null; runner_ejecuta op1 $T/in1.txt falso_ok >/dev/null
ok 1 "$(wc -l < $T/contador)" "dos identicas -> 1 ejecucion"
# 2) claves DISTINTAS (input distinto): ejecuta
runner_ejecuta op1 $T/in2.txt falso_ok >/dev/null
ok 2 "$(wc -l < $T/contador)" "claves distintas -> 2 ejecuciones"
# 3) fallo: ledger=failed; reintento NO reejecuta
runner_ejecuta opf $T/in1.txt falso_fail >/dev/null 2>&1; n=$(wc -l < $T/contador)
runner_ejecuta opf $T/in1.txt falso_ok >/dev/null 2>&1; rc=$?
ok "0" "$(($(wc -l < $T/contador)-n))" "fallo -> reintento no reejecuta"
ok 3 "$rc" "estado failed -> rc=3"
# 4) estado incompleto (running): no reejecuta
echo "running $(date -Is)" > $T/led/ledger_opx_111111111111; echo z > $T/inx.txt
# simular: opx con su input real
i=$(sha256sum $T/in1.txt | cut -c1-12); echo "running $(date -Is)" > $T/led/ledger_opx_$i
runner_ejecuta opx $T/in1.txt falso_ok >/dev/null 2>&1; rc=$?
ok 3 "$rc" "estado running -> rc=3 sin reejecutar"
# 5) entradas vacias: rechazo preflight, SIN ledger
runner_ejecuta "" $T/in1.txt falso_ok >/dev/null 2>&1; rc1=$?
runner_ejecuta opv "" falso_ok >/dev/null 2>&1; rc2=$?
runner_ejecuta opv /no/existe falso_ok >/dev/null 2>&1; rc3=$?
ok "2 2 2" "$rc1 $rc2 $rc3" "vacias/inexistente -> rc=2"
ok "0" "$(ls $T/led | grep -c '^ledger_$' || true)" "sin ledger sin clave"
ok "" "$(ls $T/led | grep '_$' || true)" "ningun ledger con clave vacia"
echo "fixtures: $P PASS, $F FAIL"; [ $F = 0 ]
