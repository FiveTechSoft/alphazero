#!/usr/bin/env python3
# dst_score.py — ORACULO OFFLINE CICLO-3. Puntua EXACT MATCH de generacion
# libre contra el generador (fuera del runtime del modelo). Uso:
#   python3 dst_score.py --dev dst_dev.txt --gens salidas.txt [--comps-json]
# salidas.txt: una linea por par, EN EL MISMO ORDEN que --dev, con la
# respuesta generada (greedy, recortada al primer '\n' por el motor gen).
import sys, re, json, argparse
sys.path.insert(0,'/tmp/blm')
from dst_gen import OPN, aplica, gen

ap=argparse.ArgumentParser()
ap.add_argument('--dev', required=True)
ap.add_argument('--gens', required=True)
a=ap.parse_args()

_,_,_,comps = gen(77)
ct={tuple(c) for c in comps['comp_train']}
cd={tuple(c) for c in comps['comp_dev']}

def opsde(s):
    p=s.split(' y '); return [p[0],p[1]] if len(p)==2 else [p[0]]

dev=open(a.dev).read().strip().split('\n')
gens=[l.rstrip('\n') for l in open(a.gens)]
n=len(dev)//2
assert len(gens)==n, f'gens {len(gens)} != pares {n}'
cats={'singles_palabra_nueva':[0,0],'comp_vista_palabra_nueva':[0,0],'comp_nueva_palabra_nueva':[0,0]}
for i in range(n):
    u=dev[2*i][3:]; pred=gens[i].strip()
    m=re.match(r"aplica (.+) a '([a-z]+)'$", u)
    ops,w=opsde(m.group(1)), m.group(2)
    oraculo=aplica(ops,w)
    t=tuple(ops)
    cat='singles_palabra_nueva' if len(ops)==1 else ('comp_vista_palabra_nueva' if t in ct else 'comp_nueva_palabra_nueva')
    cats[cat][1]+=1
    if pred==oraculo: cats[cat][0]+=1
tot_ok=sum(v[0] for v in cats.values()); tot_n=sum(v[1] for v in cats.values())
print(json.dumps({'exact_total':f'{tot_ok}/{tot_n}',
 'por_categoria':{k:f'{v[0]}/{v[1]}' for k,v in cats.items()}}, indent=1))
