#!/bin/bash
# runner_lib.sh — ejecutor exactly-once por clave sha12(input). Post-errata
# CICLO-3: nunca crear ledger/completed sin clave; preflight rechaza vacios;
# recuperacion de estados completed/unknown SIN reejecutar.
set -u
: "${RUNNER_LEDGER_DIR:?RUNNER_LEDGER_DIR no definido}"
runner_ejecuta() { # OP INPUT COMANDO...
  local op="${1:-}" input="${2:-}"
  [ -n "$op" ]    || { echo "RECHAZO preflight: op vacia"; return 2; }
  [ -n "$input" ] || { echo "RECHAZO preflight: input vacia"; return 2; }
  [ -f "$input" ] || { echo "RECHAZO preflight: input inexistente: $input"; return 2; }
  [ $# -ge 3 ]    || { echo "RECHAZO preflight: sin comando"; return 2; }
  shift 2
  local insha; insha=$(sha256sum "$input" | cut -c1-12)
  [ -n "$insha" ] || { echo "RECHAZO preflight: sha vacia"; return 2; }
  local key; key="${op}_${insha}"
  local led; led="${RUNNER_LEDGER_DIR}/ledger_${key}"
  if [ -e "$led" ]; then
    local st; st=$(cut -d' ' -f1 "$led")
    case "$st" in
      completed) echo "LEDGER $key ya completada; no reejecuta"; return 0;;
      *) echo "LEDGER $key estado=$st: recuperacion manual; NO reejecuta"; return 3;;
    esac
  fi
  echo "running $(date -Is)" > "$led.tmp" && mv "$led.tmp" "$led"
  "$@"
  local rc=$?
  if [ $rc -ne 0 ]; then
    echo "failed $(date -Is) rc=$rc" > "$led.tmp" && mv "$led.tmp" "$led"
    return $rc
  fi
  echo "completed $(date -Is)" > "$led.tmp" && mv "$led.tmp" "$led"
}
