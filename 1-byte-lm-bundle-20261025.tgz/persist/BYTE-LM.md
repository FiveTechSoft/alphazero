# BYTE-LM (rama exp/byte-lm) — protocolo congelado v1 (2026-10-25)

Modulo EXPERIMENTAL de lenguaje byte a byte. NO es AlphaZero ni mejora del
motor matematico. Rama separada; main e integracion v3 publicada intactas.

## Naturaleza honesta
- Entrenamiento SUPERVISADO sobre corpus de dialogo. NO es RSI ni automejora:
  los cambios de arquitectura/pasos los elegimos nosotros.
- El contexto de K bytes (16 o 32) es una limitacion dura: el modelo no ve
  la conversacion completa, solo los ultimos K bytes. No seguir hilos largos
  es esperable; no se presentara completado de texto como conversacion.
- BPB (bits por byte) mide ajuste estadistico, NO calidad conversacional.
  Mejor BPB no implica conversar mejor; la evidencia visible desde la TUI
  real de OpenCode es el criterio funcional.

## Corpus y licencia
- OpenAssistant oasst2: https://huggingface.co/datasets/OpenAssistant/oasst2
  Licencia Apache-2.0 (ficha del dataset, verificada 2026-10-25).
- Subconjunto lang=es, pares prompter->assistant, review_result!=False,
  no borrados, no sinteticos, longitudes 10..300 (U) y 20..600 (A).
- OpenSubtitles/OPUS DESCARTADO: terminos de licencia ambiguos para corpus
  derivado/redistribucion.
- Particion POR HILO (raiz de la conversacion, no por par; evita fuga de la
  misma conversacion entre particiones), FNV-1a(raiz) mod 10:
  0=test, 1=val, resto=train. Reproducible.
  train 6973 pares (2595324 B) / val 846 (314763 B) / test 678 (249230 B).
  8497 pares, 3348 hilos raiz.

## Prompts de evaluacion congelados (no vistos: ausentes verbatim de train
por grep -F; los temas pueden existir en el corpus)
1. Que es un agujero negro?
2. Cual es la capital de Francia?
3. Que es la amistad?
4. Como se hace una tortilla de patatas?
5. Que es AlphaZero?
6. Hola, como estas?
7. Cuentame un chiste.
8. Que tiempo hace hoy?
9. Quien eres?
10. Explicame que es un bucle while.

## Criterios congelados de conservar / rollback
- val = seleccion de candidato; test = se informa UNA vez por candidato
  seleccionado, no se optimiza reiteradamente.
- Conservar candidato solo si: (a) BPB val mejora respecto al candidato
  anterior, Y (b) las muestras visibles desde la TUI real mejoran a juicio
  humano (main/Anto), Y (c) no hay regresion: ruta matematica intacta y
  comportamiento publicado sin -blm byte-identico.
- Memorizacion: se reporta longest-common-substring y solape de 8-gramas
  de palabras contra train por generacion. grep-ausencia NO es prueba de
  no memorizacion (metrica debil, solo descontaminacion de prompts).
- Si la conversacion no mejora con presupuesto razonable, se reporta el
  limite y se PARA el escalado; no series cada vez mayores.

## Ciclo M1 (completado 2026-10-25) — medido
- Modelo: byte-MLP K=16, D=32, H=128 (~106k params), Adam propio, seed fija.
- 12000 pasos (~2 min CPU): BPB train 2.79, heldout 2.67 (piso unigram 4.65,
  azar 8.0). Split antiguo por PAR (M1; reemplazado por split por hilo).
- Resultado: aprende estadistica del espanol; NO conversa. Capturas TUI
  reales antes (0 pasos: bytes aleatorios) / despues (12000: pseudo-espanol).

## Ciclos C2/C3 (2026-10-25) — medidos, decision del controlador
- Split por HILO activo (train 6973 / val 846 / test 678). Protocolo v1.
- C1r campeon base: K16/D32/H128, 12000 pasos: val 2.7473.
- C2 (K32/D32/H192, 12500 pasos): val 2.9437 -> ROLLBACK (peor).
- C3 (C1r+12k, 24000 pasos): val 2.6731 -> CONSERVAR (regla fija: BPB val
  mejora Y relevancia no peor Y UTF-8 ok). TEST informado una vez: 2.5917
  (train 2.4963). Sin señal de sobreajuste.
- COHERENCIA: relevancia (solape palabras contenido) = 0.0 en C1r/C2/C3.
  Mejora estadistica SI; coherencia conversacional NO. Indicadores
  limitados: solape no verifica semantica; LCS<=16B/8gram 0.0 no prueban
  no-memorizacion. Temperatura 0.8 constante en comparaciones.
- Controlador: controller.py + controller_log.jsonl (decisiones ROLLBACK C2,
  CONSERVAR C3). Controlador programado != modelo que aprende; rollback
  automatico != automejora conseguida.
- Conclusion: MLP de contexto corto no alcanza coherencia ligada a la
  pregunta. No escalar a ciegas; proxima decision de enfoque con evidencia.

## Notas de regimen (2026-10-25, correcciones main)
- El test de C3 (2.5917) YA ESTA USADO: no es test intacto para selecciones
  posteriores. Proximas selecciones usan val; para nuevo test final se
  creara particion fresca o se rotara, declarado.
- Sin afirmar ausencia garantizada de sobreajuste por 3 BPBs.
- Sin extrapolar una muestra a "relevancia semantica cero universal": el
  indicador de solape es limitado y solo describe estas 10 preguntas.
- Coherencia futura: evaluacion independiente (no solape de palabras),
  muestras no preseleccionadas, criterio externo fijo.
- Decision del controlador EFECTIVA en OpenCode: d1serve -blmauto
  champion.json sirve el modelo que el controlador conserva; la TUI muestra
  los pasos del campeon vigente (metadata separada del contenido).
- Persistencia compacta: bundle unico + manifiesto sha256 (ver /tmp/blm/persist).
