//go:build !js

// d1blm: harness del modulo EXPERIMENTAL de lenguaje byte a byte.
// NO es AlphaZero: experimento reversible separado (rama exp/byte-lm).
// Modos: train (con reanudacion), eval (BPB heldout), gen (muestreo).
package main

import (
	"flag"
	"fmt"
	"math"
	"math/rand"
	"os"
	"time"
)

func init() {
	if len(os.Args) > 1 && os.Args[1] == "d1blm" {
		RunBLM(os.Args[2:])
		os.Exit(0)
	}
}

func RunBLM(args []string) {
	fs := flag.NewFlagSet("d1blm", flag.ContinueOnError)
	mode := fs.String("mode", "eval", "train|eval|gen")
	corpus := fs.String("corpus", "", "corpus train (bytes crudos)")
	heldout := fs.String("heldout", "", "corpus heldout")
	steps := fs.Int("steps", 2000, "pasos de entrenamiento esta invocacion")
	batch := fs.Int("batch", 64, "lote")
	lr := fs.Float64("lr", 0.003, "lr Adam")
	seed := fs.Int64("seed", 20261025, "semilla")
	in := fs.String("in", "", "modelo de entrada (reanudar); vacio = nuevo")
	kk := fs.Int("k", 16, "contexto bytes (modelo nuevo)")
	dd := fs.Int("d", 32, "embedding (modelo nuevo)")
	hh := fs.Int("hh", 128, "ocultas (modelo nuevo)")
	out := fs.String("out", "/tmp/blm_model.json", "modelo salida")
	prompt := fs.String("prompt", "U: Hola\nA:", "prompt para gen")
	n := fs.Int("n", 160, "bytes a generar")
	temp := fs.Float64("temp", 0.8, "temperatura")
	fs.Parse(args)

	switch *mode {
	case "train":
		data, err := os.ReadFile(*corpus)
		if err != nil {
			panic(err)
		}
		held, err := os.ReadFile(*heldout)
		if err != nil {
			panic(err)
		}
		var m *BLM
		if *in != "" {
			m = LoadBLM(*in)
		} else {
			m = NewBLM(*seed, *kk, *dd, *hh)
		}
		g := m.newGrads()
		r := rand.New(rand.NewSource(*seed + int64(m.Steps) + 1))
		t0 := time.Now()
		acc := 0.0
		for s := 0; s < *steps; s++ {
			loss := 0.0
			for b := 0; b < *batch; b++ {
				i := r.Intn(len(data) - m.K - 1)
				loss += m.trainStep(data[i:i+m.K], data[i+m.K], *lr, g)
			}
			m.adam(g, *lr)
			m.Steps++
			acc += loss / float64(*batch)
			if (s+1)%500 == 0 {
				fmt.Printf("paso %d (total %d) bpb_train_lote=%.3f t=%s\n", s+1, m.Steps, acc/500, time.Since(t0).Round(time.Second))
				acc = 0
			}
		}
		m.BPBTrain = m.evalBPB(data, 3000, *seed+999)
		m.BPBHeldout = m.evalBPB(held, 3000, *seed+999)
		fmt.Printf("FIN steps=%d bpb_train=%.4f bpb_heldout=%.4f duracion=%s\n", m.Steps, m.BPBTrain, m.BPBHeldout, time.Since(t0).Round(time.Second))
		m.SaveBL(*out)
	case "eval":
		m := LoadBLM(*in)
		data, err := os.ReadFile(*corpus)
		if err != nil {
			panic(err)
		}
		held, err := os.ReadFile(*heldout)
		if err != nil {
			panic(err)
		}
		// piso unigram (entropia de bytes del corpus)
		var cnt [256]float64
		for _, b := range data {
			cnt[b]++
		}
		tot := float64(len(data))
		ent := 0.0
		for _, c := range cnt {
			if c > 0 {
				p := c / tot
				ent -= p * math.Log2(p)
			}
		}
		fmt.Printf("bpb_unigram_piso=%.4f bpb_train=%.4f bpb_heldout=%.4f steps=%d\n",
			ent, m.evalBPB(data, 3000, *seed+999), m.evalBPB(held, 3000, *seed+999), m.Steps)
	case "gen":
		m := LoadBLM(*in)
		fmt.Printf("%s\n", m.generate(*prompt, *n, *temp, *seed))
	}
}
