//go:build !js

// blm: modulo EXPERIMENTAL nuevo de lenguaje byte a byte. NO es AlphaZero
// ni forma parte del motor matematico: es una red autoregresiva pequena que
// aprende estadistica de texto (contexto de K bytes -> byte siguiente).
// Codigo nuevo, reversible, rama exp/byte-lm. Sin dependencias externas.
package main

import (
	"encoding/json"
	"math"
	"math/rand"
	"os"
)

const BLMV = 256 // vocabulario = byte crudo

type BLM struct {
	K  int `json:"k"` // bytes de contexto
	D  int `json:"d"` // embedding por byte
	H  int `json:"h"` // ocultas
	E  []float64 `json:"e"`
	W1 []float64 `json:"w1"`
	B1 []float64 `json:"b1"`
	W2 []float64 `json:"w2"`
	B2 []float64 `json:"b2"`
	// Adam
	mE, vE, mW1, vW1, mB1, vB1, mW2, vW2, mB2, vB2 []float64
	t                                              float64
	Steps                                          int     `json:"steps"`
	BPBTrain                                       float64 `json:"bpb_train,omitempty"`
	BPBHeldout                                     float64 `json:"bpb_heldout,omitempty"`
}

func NewBLM(seed int64, k, d, h int) *BLM {
	r := rand.New(rand.NewSource(seed))
	mk := func(n int, sc float64) []float64 {
		v := make([]float64, n)
		for i := range v {
			v[i] = r.NormFloat64() * sc
		}
		return v
	}
	z := func(n int) []float64 { return make([]float64, n) }
	return &BLM{
		K: k, D: d, H: h,
		E: mk(BLMV*d, 0.1), W1: mk(h*k*d, math.Sqrt(2.0/float64(k*d))), B1: z(h),
		W2: mk(BLMV*h, math.Sqrt(2.0/float64(h))), B2: z(BLMV),
		mE: z(BLMV * d), vE: z(BLMV * d), mW1: z(h * k * d), vW1: z(h * k * d),
		mB1: z(h), vB1: z(h), mW2: z(BLMV * h), vW2: z(BLMV * h), mB2: z(BLMV), vB2: z(BLMV),
	}
}

// forward: ctx son los ultimos m.K bytes (len==m.K). Devuelve logits y cache.
func (m *BLM) forward(ctx []byte) ([]float64, []float64, []float64) {
	x := make([]float64, m.K*m.D)
	for i := 0; i < m.K; i++ {
		copy(x[i*m.D:(i+1)*m.D], m.E[int(ctx[i])*m.D:int(ctx[i])*m.D+m.D])
	}
	h := make([]float64, m.H)
	for j := 0; j < m.H; j++ {
		s := m.B1[j]
		row := m.W1[j*m.K*m.D : (j+1)*m.K*m.D]
		for i := 0; i < m.K*m.D; i++ {
			s += row[i] * x[i]
		}
		h[j] = math.Tanh(s)
	}
	logits := make([]float64, BLMV)
	for b := 0; b < BLMV; b++ {
		s := m.B2[b]
		row := m.W2[b*m.H : (b+1)*m.H]
		for j := 0; j < m.H; j++ {
			s += row[j] * h[j]
		}
		logits[b] = s
	}
	return logits, h, x
}

func softmax(logits []float64) []float64 {
	mx := logits[0]
	for _, v := range logits {
		if v > mx {
			mx = v
		}
	}
	z := 0.0
	p := make([]float64, len(logits))
	for i, v := range logits {
		p[i] = math.Exp(v - mx)
		z += p[i]
	}
	for i := range p {
		p[i] /= z
	}
	return p
}

// trainStep: una ventana (ctx,target). Devuelve loss en bits.
func (m *BLM) trainStep(ctx []byte, target byte, lr float64, g *BLM) float64 {
	logits, h, x := m.forward(ctx)
	p := softmax(logits)
	loss := -math.Log(p[target]+1e-12) / math.Ln2
	// gradientes (se acumulan en g)
	dl := make([]float64, BLMV)
	for b := 0; b < BLMV; b++ {
		dl[b] = p[b]
	}
	dl[target] -= 1.0
	for b := 0; b < BLMV; b++ {
		row := g.W2[b*m.H : (b+1)*m.H]
		for j := 0; j < m.H; j++ {
			row[j] += dl[b] * h[j]
		}
		g.B2[b] += dl[b]
	}
	dh := make([]float64, m.H)
	for j := 0; j < m.H; j++ {
		s := 0.0
		for b := 0; b < BLMV; b++ {
			s += m.W2[b*m.H+j] * dl[b]
		}
		dh[j] = s * (1 - h[j]*h[j])
	}
	dx := make([]float64, m.K*m.D)
	for j := 0; j < m.H; j++ {
		row := m.W1[j*m.K*m.D : (j+1)*m.K*m.D]
		grow := g.W1[j*m.K*m.D : (j+1)*m.K*m.D]
		g.B1[j] += dh[j]
		for i := 0; i < m.K*m.D; i++ {
			grow[i] += dh[j] * x[i]
			dx[i] += dh[j] * row[i]
		}
	}
	for i := 0; i < m.K; i++ {
		base := int(ctx[i]) * m.D
		for d := 0; d < m.D; d++ {
			g.E[base+d] += dx[i*m.D+d]
		}
	}
	return loss
}

func adamUpd(p, g, mt, vt []float64, t, lr float64) {
	b1c := 1 - math.Pow(0.9, t)
	b2c := 1 - math.Pow(0.999, t)
	for i := range p {
		mt[i] = 0.9*mt[i] + 0.1*g[i]
		vt[i] = 0.999*vt[i] + 0.001*g[i]*g[i]
		p[i] -= lr * (mt[i] / b1c) / (math.Sqrt(vt[i]/b2c) + 1e-8)
		g[i] = 0
	}
}

func (m *BLM) adam(g *BLM, lr float64) {
	m.t++
	adamUpd(m.E, g.E, m.mE, m.vE, m.t, lr)
	adamUpd(m.W1, g.W1, m.mW1, m.vW1, m.t, lr)
	adamUpd(m.B1, g.B1, m.mB1, m.vB1, m.t, lr)
	adamUpd(m.W2, g.W2, m.mW2, m.vW2, m.t, lr)
	adamUpd(m.B2, g.B2, m.mB2, m.vB2, m.t, lr)
}

func (m *BLM) newGrads() *BLM {
	z := func(n int) []float64 { return make([]float64, n) }
	return &BLM{E: z(BLMV * m.D), W1: z(m.H * m.K * m.D), B1: z(m.H), W2: z(BLMV * m.H), B2: z(BLMV)}
}

// evalBPB: bits por byte medios sobre ventanas de data (stride 1, muestreo max maxW).
func (m *BLM) evalBPB(data []byte, maxW int, seed int64) float64 {
	if len(data) < m.K+2 {
		return 0
	}
	r := rand.New(rand.NewSource(seed))
	n := 0
	tot := 0.0
	for n < maxW {
		i := r.Intn(len(data) - m.K - 1)
		logits, _, _ := m.forward(data[i : i+m.K])
		p := softmax(logits)
		tot += -math.Log(p[data[i+m.K]]+1e-12) / math.Ln2
		n++
	}
	return tot / float64(n)
}

// generate: muestreo con temperatura y semilla; corta en '\n' o maxB bytes.
func (m *BLM) generate(prompt string, maxB int, temp float64, seed int64) string {
	r := rand.New(rand.NewSource(seed))
	buf := make([]byte, 0, m.K+maxB)
	ctx := make([]byte, m.K)
	if len(prompt) >= m.K {
		copy(ctx, []byte(prompt[len(prompt)-m.K:]))
	} else {
		copy(ctx[m.K-len(prompt):], []byte(prompt))
	}
	for len(buf) < maxB {
		logits, _, _ := m.forward(ctx)
		for i := range logits {
			logits[i] /= temp
		}
		p := softmax(logits)
		u := r.Float64()
		acc := 0.0
		nb := byte(' ')
		for b := 0; b < BLMV; b++ {
			acc += p[b]
			if u <= acc {
				nb = byte(b)
				break
			}
		}
		if nb == '\n' {
			break
		}
		buf = append(buf, nb)
		copy(ctx, ctx[1:])
		ctx[m.K-1] = nb
	}
	return string(buf)
}

func (m *BLM) SaveBL(path string) {
	f, err := os.Create(path)
	if err != nil {
		panic(err)
	}
	defer f.Close()
	enc := json.NewEncoder(f)
	if err := enc.Encode(m); err != nil {
		panic(err)
	}
}

func LoadBLM(path string) *BLM {
	f, err := os.Open(path)
	if err != nil {
		panic(err)
	}
	defer f.Close()
	var m BLM
	if err := json.NewDecoder(f).Decode(&m); err != nil {
		panic(err)
	}
	z := func(n int) []float64 { return make([]float64, n) }
	m.mE, m.vE = z(BLMV*m.D), z(BLMV*m.D)
	m.mW1, m.vW1 = z(m.H*m.K*m.D), z(m.H*m.K*m.D)
	m.mB1, m.vB1 = z(m.H), z(m.H)
	m.mW2, m.vW2 = z(BLMV*m.H), z(BLMV*m.H)
	m.mB2, m.vB2 = z(BLMV), z(BLMV)
	return &m
}
