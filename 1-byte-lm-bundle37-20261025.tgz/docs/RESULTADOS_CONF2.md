# CONF2 - Confirmatoria EVAL-ONLY de ck_A86 sobre operandos nuevos

Evaluacion de confirmacion del checkpoint A86 (sha256 3b07a67ce51e55f22f414c0be0ef5749156ef3eb5afdeb96b5e912e7a1671a19)
sobre operandos NUEVOS, nunca usados en entrenamiento ni en evaluaciones previas. Solo generacion
(n=12, temp=0, misma cabeza de copia que los cortes FINAL6) y puntuacion exacta contra oraculo congelado.
SIN entrenamiento: sha256 del checkpoint identico antes y despues.

## Datos
- datos/evalconf2_L4_48.txt, evalconf2_L5_48.txt, evalconf2_L6_48.txt: 48 pares c/u (24 repite + 24 invierte), palabras [a-z]^L.
- Una sola corriente sha256 con semilla 20261028, orden de consumo declarado L5 -> L4 -> L6.
- 0 solapes con los 1248 operandos previos (entrenamiento + evaluaciones), verificado por extraccion de superficies.
- 0 palindromos; palabras con letras repetidas NO filtradas (L4: 10, L5: 20, L6: 22); sin seleccion post-hoc.
- Oraculo: scripts/evalconf_MANIFIESTO.json v2 con sha256 completo de los 6 ficheros, registrado ANTES de generar.
  El puntuador (scripts/evalconf_score.py) rechaza con causa cualquier dataset no registrado o con sha distinta
  (fixtures positivo 48/48 x3 y negativos validados).

## Resultados (cuentas exactas, UN solo pase de los 144, sin pases adaptativos)
| Longitud | repite | invierte | total |
|----------|--------|----------|-------|
| L5 nuevos | 23/24 | 24/24 | 47/48 |
| L4 nuevos (retencion) | 24/24 | 24/24 | 48/48 |
| L6 nuevos (descriptivo) | 0/24 | 0/24 | 0/48 |

Criterios predeclarados: L5 >= 40/48 CUMPLE (47/48); L4 >= 40/48 CUMPLE (48/48); L6 sin umbral, descriptivo (0/48).

- Fallo NUEVO caso[16]: repite 'egiee' -> modelo 'egiees' (un caracter de mas).
- Fallo HISTORICO de FINAL6 (medido sobre DEV reusado, bundle36), distinto del anterior:
  caso[46] invierte 'loaeu' -> modelo 'ueall' (target 'ueaol').
- L6: el modelo emite exactamente 5 caracteres en los 48 casos (su longitud maxima entrenada);
  en repite es el prefijo de 5; en invierte faltan caracteres del target. Sin transferencia a L6.

## Condiciones de ejecucion
- Binario mzab_v3 sha256 77d01528f9bb2f1eba0c7afaa4c914bcabd5d6f8b8deb642b1d59651481bf75d (mismo que E5).
- Wall total de la evaluacion: 1s (cap 60s). RSS max por proceso: ~20 MiB (cap 900 MiB). Logs en logs/.
- Checkpoint sin cambios: sha256 identico antes y despues de las 144 generaciones.

## Que se afirma y que no
- La capacidad de copia/inversion en L5 medida en DEV (FINAL6) se CONFIRMA en operandos independientes
  de la misma familia (nunca entrenados): 47/48 con el mismo perfil (1 fallo).
- Retencion L4 confirmada en operandos nuevos: 48/48.
- L6 sigue sin generalizar: la cabeza de copia aprendida opera hasta la longitud maxima entrenada.
- Es gradiente supervisado, no aprendizaje por refuerzo ni RSI. No es habla.
