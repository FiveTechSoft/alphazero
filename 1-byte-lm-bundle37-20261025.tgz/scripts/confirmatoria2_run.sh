#!/bin/bash
# CONFIRMATORIA2 EVAL-ONLY: ck_A86 (sha congelado) sobre evalconf2 L5/L4/L6 (144 gens).
# n=12 temp=0, misma head que cortes FINAL6 (-copyhead learn -copyseed 7). SIN training.
# CAP DURO EXTERNO 60s wall total (carga+gen+score). RSS<900MiB por proceso.
# PRIMER FALLO = PARADA, SIN retry/parche. Pesos SHA antes/despues.
set -e; set -o pipefail; cd /tmp/blm
MZ=./mzab_v3
BINSHA=77d01528f9bb2f1eba0c7afaa4c914bcabd5d6f8b8deb642b1d59651481bf75d
CK=ciclo_e5/ck_A86.json
CKSHA=3b07a67ce51e55f22f414c0be0ef5749156ef3eb5afdeb96b5e912e7a1671a19
O=ciclo_conf2
mkdir -p $O
fail() { echo "PARADA-CONF2: $1"; echo "PARADA-CONF2 $(date -Is) causa: $1" >> $O/PARADAS.txt; exit "${2:-9}"; }
T0=$(date +%s)
echo "CONF2 inicio $(date -Is)" >> $O/log.txt
[ "$(sha256sum $MZ | cut -d' ' -f1)" = "$BINSHA" ] || fail "binario sha mismatch"
[ "$(sha256sum $CK | cut -d' ' -f1)" = "$CKSHA" ] || fail "ck_A86 sha mismatch (antes)"
sha256sum $MZ $CK evalconf2_L4_48.txt evalconf2_L5_48.txt evalconf2_L6_48.txt evalconf_MANIFIESTO.json > $O/preflight_sha.txt
CH="-copyhead learn -copyseed 7"
runmz() {
  local tag=$1; shift
  local ELAPSED=$(( $(date +%s) - T0 ))
  local REMAIN=$(( 60 - ELAPSED ))
  [ "$REMAIN" -gt 5 ] || fail "presupuesto wall agotado antes de $tag (${ELAPSED}s)"
  python3 - "$tag" "$REMAIN" "$@" <<'PYEOF'
import subprocess, resource, sys
tag, remain, args = sys.argv[1], int(sys.argv[2]), sys.argv[3:]
try:
    r = subprocess.run(["./mzab_v3"]+args, timeout=remain-2)
except subprocess.TimeoutExpired:
    print(f"PARADA-CONF2: timeout interno en {tag}", file=sys.stderr); sys.exit(12)
kb = resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
print(f"RSSMAX {tag} {kb} KiB", file=sys.stderr)
if kb > 921600:
    print(f"PARADA-CONF2: RSS {kb} KiB > 900MiB en {tag}", file=sys.stderr); sys.exit(11)
sys.exit(r.returncode)
PYEOF
}
# Orden de consumo declarado: L5 -> L4 -> L6
runmz genL5 d1gru -mode genpairs -in $CK -corpus evalconf2_L5_48.txt -n 12 -temp 0 $CH > $O/genconf2_L5_A86.txt 2>>$O/rss.log || fail "gen L5" $?
runmz genL4 d1gru -mode genpairs -in $CK -corpus evalconf2_L4_48.txt -n 12 -temp 0 $CH > $O/genconf2_L4_A86.txt 2>>$O/rss.log || fail "gen L4" $?
runmz genL6 d1gru -mode genpairs -in $CK -corpus evalconf2_L6_48.txt -n 12 -temp 0 $CH > $O/genconf2_L6_A86.txt 2>>$O/rss.log || fail "gen L6" $?
wc -l $O/genconf2_L5_A86.txt $O/genconf2_L4_A86.txt $O/genconf2_L6_A86.txt >> $O/log.txt
S5=$(python3 evalconf_score.py evalconf2_L5_48.txt $O/genconf2_L5_A86.txt) || fail "score L5" $?
S4=$(python3 evalconf_score.py evalconf2_L4_48.txt $O/genconf2_L4_A86.txt) || fail "score L4" $?
S6=$(python3 evalconf_score.py evalconf2_L6_48.txt $O/genconf2_L6_A86.txt) || fail "score L6" $?
[ "$(sha256sum $CK | cut -d' ' -f1)" = "$CKSHA" ] || fail "ck_A86 sha CAMBIO (despues)"
T1=$(date +%s)
{ echo "CONF2 L5 $S5"; echo "CONF2 L4 $S4"; echo "CONF2 L6 $S6"; echo "wall_total $((T1-T0))s"; echo "ck_A86 sha despues OK (sin cambios)"; } | tee -a $O/log.txt
