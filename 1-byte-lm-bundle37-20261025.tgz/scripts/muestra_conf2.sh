#!/bin/bash
# Muestra CONF2: re-puntuacion REAL de gens archivados contra oraculo congelado (sin modelo).
cd "$(dirname "$0")/.."
echo "== CONF2: operandos NUEVOS, ck_A86, sin reentrenar =="
for L in 5 4 6; do
  python3 scripts/evalconf_score.py datos/evalconf2_L${L}_48.txt gens/genconf2_L${L}_A86.txt | python3 -c "import json,sys; d=json.load(sys.stdin); p=d['por_op']; print(f\"L$L nuevos: {d['exact_total']}  repite {p['repite']}, invierte {p['invierte']}\")"
done
python3 - <<'PYEOF'
import re
pares=open('datos/evalconf2_L5_48.txt').read().strip().split('\n')
gens=[l.strip() for l in open('gens/genconf2_L5_A86.txt')]
for i in range(48):
    m=re.match(r"(repite|invierte) '([a-z]+)'$", pares[2*i][3:])
    op,w=m.groups(); t=w if op=='repite' else w[::-1]
    if gens[i]!=t: print(f"fallo NUEVO [{i}]: {op} '{w}' -> '{gens[i]}' (target {t})")
PYEOF
echo "fallo HISTORICO FINAL6 (DEV reusado) [46]: invierte 'loaeu' -> 'ueall'"
