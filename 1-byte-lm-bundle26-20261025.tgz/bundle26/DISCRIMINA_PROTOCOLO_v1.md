# ANALISIS 0/24 vs 12/96 + EXPERIMENTO DISCRIMINANTE (propuesta, SIN training)
# Pregunta central: por que 0/24 en palabras nuevas vs 12/96 en practicadas?
# Regla/composicion vs recuperacion literal. Todo con artefactos EXISTENTES
# (ck_T6 de S2) + evaluacion; NINGUN entrenamiento. Sin respuestas
# programadas: oraculo offline deterministico de la funcion congelada.

## 1. Analisis de las generaciones archivadas (T6, ya medido)
Separado fallo de exactitud: NO es UTF-8/decode/formato — el 100% de las
salidas (train96 y dev24) son palabras limpias de 4 letras minusculas;
formato_roto = 0. El fallo es de CONTENIDO:
- TRAIN96: 12/96 exactos; 39/96 salidas son literalmente ALGUNA respuesta de
  train (solo 12 la correcta). Solape de letras con la palabra dada 0.22
  (azar ~0.15): la salida se relaciona debilmente con la entrada.
- DEV24: 0/24 exactos; 9/24 salidas son respuestas memorizadas de train
  ante palabras NUNCA vistas; 15 salidas distintas/24; solape de letras con
  la palabra dada 0.12 (~azar 0.15): la salida NO sigue a la palabra dada.
- Lectura descriptiva (no causal): dominan respuestas memorizadas; no se
  observa aplicacion de la regla a la palabra dada en palabras nuevas. La
  exactitud en train no discrimina memorizacion vs regla (ambas dan la
  misma respuesta EN train, por construccion) — de ahi la sonda siguiente.

## 2. Sonda CROSS congelada (fixture PASS, sha16 3f91c8f6e8fe3375)
24 pares (op', w): w es palabra VISTA en train, op' es op VISTA pero NUNCA
emparejada con w en train (estructura verificada: 96 palabras unicas, 1 op
por palabra). Regla de seleccion fija declarada: primeras 3 palabras de
cada op en orden de archivo; op' = siguiente op alfabetico (ciclico).
Oraculo offline aplica(). Colision con train: las PALABRAS si (intencional,
es el punto); las COMBINACIONES (op',w) ausentes (fixture).
Si el modelo aplica la REGLA de op' a w -> respuesta = transformacion
correcta (combinacion nueva: no memorizable). Si memorizo palabra->respuesta
-> emitira la RESPUESTA ENTRENADA de w (incorrecta para op').

## 3. Criterio predeclarado (antes de ejecutar)
Sobre ck_T6 (ya entrenado; NO se entrena nada):
- exact_cross >= 6/24: evidencia medida de aplicacion de regla/composicion
  en este checkpoint a esta escala.
- exact_cross <= 2/24 con tasa_recuperacion (gen == respuesta entrenada de
  la palabra) >= 6/24: recuperacion literal dominante (firma directa).
- 3-5/24 o tasas intermedias: resultado ambiguo, se reporta sin conclusion.
- Controles: exact_train96 archivado (12/96) como tasa de referencia con
  op entrenada; azar ~0/24. NINGUNA afirmacion causal sin estos controles;
  resultado descriptivo de ESTE checkpoint, no del metodo.

## 4. Alcance y coste
- Evaluacion solamente: 1 genpairs (24 prompts, ~1s medido en corridas
  anteriores) + scoring offline (~1s). Estimacion total ~5s wall; TOPE
  declarado 30s. Sin training, sin cambios de pesos, sin checkpoints nuevos.
- Sonda congelada con hash; indice fijo declarado antes de generar; se
  reportan cuentas exactas por categoria (exacto / respuesta entrenada /
  otra palabra / formato).
- Encaje con el objetivo (modelo desde cero, reglas basicas, autonomo):
  discrimina si el cuello es representacion de la regla o solo cobertura;
  orienta el siguiente paso con evidencia en vez de sumar pasos a ciegas.
  No equivale DST a habla/RSI; es diagnostico de mecanismo.
