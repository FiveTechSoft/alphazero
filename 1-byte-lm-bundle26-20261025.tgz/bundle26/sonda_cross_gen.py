#!/usr/bin/env python3
# sonda_cross_gen.py — sonda CROSS congelada: palabra VISTA x op VISTA no
# emparejada en train (combinacion NUNCA entrenada). Regla fija declarada:
# primeras 3 palabras de cada op en orden de archivo; op' = siguiente op en
# orden alfabetico (ciclico). Oraculo offline aplica(). SOLO eval, sin train.
import re, hashlib, json, sys
sys.path.insert(0,'/tmp/blm')
from dst_gen import aplica
def lee(path):
    lines=open(path).read().strip().split('\n')
    return [(lines[i][3:], lines[i+1][3:]) for i in range(0,len(lines),2)]
train=lee('dst3b_train.txt')
pat=re.compile(r"aplica (\S+) a '([a-z]+)'$")
OPS=sorted({pat.match(u).group(1) for u,_ in train})
por_op={}
for u,a in train:
    m=pat.match(u); por_op.setdefault(m.group(1),[]).append((m.group(2),a))
sonda=[]; resp_entrenada={}
for op in OPS:
    for w,a in por_op[op][:3]:
        op2=OPS[(OPS.index(op)+1)%len(OPS)]
        sonda.append((op2,w,aplica([op2],w),a))  # (op pedida, palabra, oraculo, respuesta entrenada)
assert len(sonda)==24
with open('sonda_cross24.txt','w') as f:
    for op2,w,_,_ in sonda: f.write(f"U: aplica {op2} a '{w}'\nA: \n")
meta=[{'op_pedida':o,'palabra':w,'oraculo':orac,'resp_entrenada':re_} for o,w,orac,re_ in sonda]
open('sonda_cross24_oraculo.json','w').write(json.dumps(meta,indent=1))
h=hashlib.sha256(open('sonda_cross24.txt','rb').read()).hexdigest()[:16]
print('sonda_cross24.txt sha16', h, 'n=',len(sonda))
# fixture: ninguna combinacion (op',w) esta en train; la palabra SI (declarado)
trset={(pat.match(u).group(1),pat.match(u).group(2)) for u,_ in train}
assert all((o,w) not in trset for o,w,_,_ in sonda)
trwords={w for _,w in [(u,pat.match(u).group(2)) for u,_ in train]}
assert all(w in trwords for _,w,_,_ in sonda)
print('fixture: 24 combinaciones AUSENTES de train; palabras presentes en train (declarado)')
