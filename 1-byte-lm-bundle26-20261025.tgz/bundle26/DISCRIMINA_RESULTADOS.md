# Sonda CROSS24 sobre ck_T6 — RESULTADOS (eval-only, sin training)
# Sonda congelada sha16 3f91c8f6e8fe3375; gen config DECLARADA: genpairs
# ruta gen2 greedy, -n 16 bytes max, corte en '\n' por el motor, temp 0
# (mismas opciones que las evaluaciones T6). Sin cap a 4 bytes: 8+ posibles
# (archivado: una gen train de 16 chars); no se detecto cap-bug.

## Cuentas exactas (convencion de umbrales declarada, no validada
## estadisticamente; se reportan cuentas, no "prueba")
- exacto: 0/24
- memorizada (gen == respuesta entrenada de ESA palabra, firma directa): 1/24
- gen == alguna OTRA respuesta de train: 5/24
- otra palabra (ninguna respuesta train): 18/24
- salidas distintas: 16/24; atractores frecuentes: hkju x4, efuq x3, efue x2,
  fsvw x2, rnvr x2 (todos son respuestas de train salvo hkju? — declarado:
  atractores = salidas repetidas frecuentes, mayoria respuestas train)
- largo correcto para la op pedida: 19/24 (los 5 fallos son los cruces con
  DUPLICA en cualquier direccion: target 8 vs 4)

## Lectura descriptiva (SOLO este checkpoint, esta escala; no causal)
- No se observa la transformacion exacta pedida en NINGUNA combinacion no
  entrenada (0/24): sin evidencia de aplicacion de regla medida.
- La firma directa de memorizacion palabra->respuesta es BAJA (1/24): el
  modelo tampoco recupera la respuesta entrenada de la palabra cuando la op
  cambia; produce mayoritariamente palabras frecuentes no ancladas a la
  entrada (atractores). Coincidir alguna respuesta train (5/24) NO prueba
  memorizacion (sesgo de lexicon pequeno/colisiones).
- Combinado con lo archivado (train96 12/96, dev24 0/24): lo aprendido en
  train no se transfiere ni a palabras nuevas ni a combinaciones nuevas con
  palabras vistas; la representacion operativa de la regla no esta medida
  como presente en este checkpoint. Esto NO distingue representacion vs
  cobertura de datos (diagnostico basado en dataset, no causal).
- Items ambiguos de la sonda (target==memorizada u ops equivalentes): 0
  (fixture declarado).

## Errata de lenguaje (adendo; no reescribe bundles 25 ni anteriores)
- Mi informe previo "100% salidas 4 letras" era FALSO para train96
  (longitudes reales {4,5,6,7,16}); para dev24 si fue {4}. La conclusion
  "fallo de contenido, no de formato" se mantiene con matices: para DUPLICA
  la longitud esperada es 8 y ninguna gen la produce (fallo de contenido
  incluye longitud de op).
- "Coincide ALGUNA respuesta train 9/24 (dev) NO prueba memorizacion"
  (sesgo lexicon/colisiones); "la salida no sigue a la entrada" era
  demasiado fuerte para un solape heuristico: la forma correcta es "no
  produjo la transformacion exacta y el solape de letras es bajo (~azar)".
- REPLAY/REPLICA: "elimina el olvido" -> "no se observa deterioro medido
  (2 ordenes)"; "mas lento que DST puro a igual exposicion" es comparacion
  descriptiva/historica (coste total, orden y retencion no comparables),
  NO aislamiento causal.

## Coste: genpairs 1s + scoring ~1s = 2s wall (estimado 5s, tope 30s).
## Sin ampliacion post-hoc de la sonda (declarado de antemano).
