#!/bin/bash
DISP=:97
rm -f /tmp/tui_rtA.png /tmp/tui_rtB.png /tmp/blm/tui_train.lock /tmp/blm/tui_train_served.json /tmp/blm/tui_train.log /tmp/blm/tui_train.log.status
bash /tmp/blm/guard.sh 200 900 /tmp/blm/srv_rt.log /tmp/blm/mz d1serve -port 8101 -blmgru /tmp/blm/blm_gru2b.json -guard /tmp/blm/guard.sh >/dev/null 2>&1 &
Xvfb $DISP -screen 0 1280x900x24 >/dev/null 2>&1 &
XV=$!
sleep 2
DISPLAY=$DISP xfce4-terminal --geometry=140x42 --title=BLM-RT -e 'bash -c "cd /tmp/octest2 && ./node_modules/.bin/opencode; echo; echo SESION TERMINADA; sleep 300"' >/dev/null 2>&1 &
sleep 14
DISPLAY=$DISP xdotool search --name "BLM-RT" windowactivate --sync 2>/dev/null
LC_ALL=C.utf8 DISPLAY=$DISP xdotool type --delay 25 --clearmodifiers '/blm-train 2000'
DISPLAY=$DISP xdotool key Return
sleep 4
LC_ALL=C.utf8 DISPLAY=$DISP xdotool type --delay 25 --clearmodifiers '/blm-train-stop '
DISPLAY=$DISP xdotool key Return
sleep 4
DISPLAY=$DISP scrot /tmp/tui_rtA.png
LC_ALL=C.utf8 DISPLAY=$DISP xdotool type --delay 25 --clearmodifiers '/blm-train 10'
DISPLAY=$DISP xdotool key Return
sleep 18
LC_ALL=C.utf8 DISPLAY=$DISP xdotool type --delay 25 --clearmodifiers '/blm-train-status '
DISPLAY=$DISP xdotool key Return
sleep 3
LC_ALL=C.utf8 DISPLAY=$DISP xdotool type --delay 25 --clearmodifiers '/blm-train 10'
DISPLAY=$DISP xdotool key Return
sleep 4
DISPLAY=$DISP scrot /tmp/tui_rtB.png
DISPLAY=$DISP xdotool key ctrl+c 2>/dev/null
sleep 1
kill $XV 2>/dev/null
pkill -f 'mz d1serve'
sleep 1
echo RT_OK
