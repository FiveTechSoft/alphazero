# Verificacion del contrato de guardia (2026-10-25 08:23-08:25, worker SINTETICO, sin entrenamiento)

guard.sh (original, parcheado hoy SOLO para sidecar de estado): sondeo 0.1s, kill de GRUPO por
RSS/timeout/senal del supervisor/sampler ciego; segunda capa `timeout` interna mantiene la cota
de tiempo aunque el supervisor muera (RSS queda sin forzar en ese caso: limitacion documentada).

- T1 salida normal: status=exit rc=0 peakRSS_MiB=1 residual_procs=0
- T2 limite RSS (worker 300MB, limite 200): status=RSS_LIMIT rc=137, muerto a 295MiB en <1s, residual_procs=0
- T3 huerfano (lanzador muerto al retornar; guardia bajo setsid): status=TIMEOUT rc=137 elapsed_s=5, residual_procs=0,
  estado DURABLE en <log>.status (sidecar nuevo: antes el status iba solo al stdout del lanzador y se perdia al morir este).
- Limitacion honesta: si el supervisor recibe SIGKILL, solo la cota de tiempo queda (RSS sin forzar). Nada en userspace lo evita.
- Parche: status -> stdout Y <out>.status, incluida la rama de senal del supervisor. guard.sh.bak conservado.

Ruta TUI de aprendizaje (d1serve, comandos locales etiquetados "no es salida del modelo"):
- /blm-train [pasos<=2000]: lanza train-pairs OASST2 DESACOPLADO bajo guard.sh (420s/900MiB), rechaza si hay uno en curso.
- /blm-train-status: lee progreso/sidecar. /blm-checkpoints: lista checkpoints GRU con H y pasos reales.
- Humo verificado: lanzar, estado, lista. Sin carga real (10 pasos de humo).
