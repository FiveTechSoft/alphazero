# Bundle 9 (2026-10-25 ~08:40 CET) — ruta TUI de aprendizaje + endurecimiento + erratas

## v2 (08:42): idempotencia estable + portabilidad + evidencia TUI centrada
- Dedupe estable 600s por texto exacto de comando (tui_train_served.json persistente):
  retry tardio/titulo automatico del cliente NO relanza (sustituye cooldown 30s).
  Verificado desde TUI: replay "/blm-train 10" tras completar -> "duplicado estable ignorado".
- Directorio BLM configurable: flag -blmdir (default /tmp/blm); toda ruta de la ruta de
  entrenamiento deriva de el (allowlist relativa, sin args arbitrarios). La restriccion ya no
  es una ruta privada obligatoria: documentado y parametrizado.
- Capturas NUEVAS centradas: tui_rtA.png (lanzamiento 2000 + /blm-train-stop con respuesta de
  parada), tui_rtB.png (lanzamiento 10 pasos completo + status final rc=0 peakRSS 20MiB
  elapsed 12s residual_procs=0 + replay rechazado por dedupe). Admision/cancelacion/dedupe
  VERIFICADOS en ejecucion TUI, no solo vet.
- Hallazgo de cliente: OpenCode reenvia el mismo prompt en una peticion auxiliar (retry/titulo);
  el primer POST lanza y el auxiliar es rechazado. Sin dedupe habria doble entrenamiento.

## Contenido
- mathzero/d1serve_main.go: comandos locales /blm-train [pasos<=2000], /blm-train-status,
  /blm-checkpoints, /blm-train-stop. Servidor SOLO loopback (127.0.0.1). Rutas de datos/binario
  fijas (allowlist: /tmp/blm/train.txt, val.txt, /tmp/blm/mz, guard.sh); sin args arbitrarios
  (pasos entero con cota dura 2000). Admision atomica: lockfile O_EXCL + doble chequeo pgrep
  (patron preciso tui_train.log) + cooldown 30s anti-reintento (los replays/reintentos del
  cliente NO relanzan). Parada segura: TERM al grupo de la guardia, que mata al worker y
  registra sidecar. Lock liberado en toda salida.
- artifacts/guard.sh: guardia ORIGINAL + parche minimo: status tambien a sidecar <out>.status
  (antes solo stdout del lanzador: se perdia si este moria — causa del intervalo sin guardia
  observable del 08:15). guard.sh.bak = version anterior. VERIFICACION_GUARDA.md: contrato
  verificado con workers sinteticos (T1 salida normal, T2 kill RSS, T3 supervivencia setsid).
- artifacts/tui_rt.sh: guion de la sesion TUI de verificacion (v2, prueba stop+replay).
- Capturas: tui_rtA.png / tui_rtB.png (evidencia centrada v2); tui_train_lanzamiento.png y
  tui_train_estado.png quedan como historico de la v1 (con cooldown 30s).
- artifacts/blm_gru_tui_train.json: checkpoint H=64 pasos=10 creado DESDE la ruta TUI.
  tui_train.log.status: status=exit rc=0 peakRSS 20MiB elapsed 11s residual_procs=0.
- docs/BYTE-LM.md: errata explicita H64=43.456 params (3 secciones).
- artifacts/cap_estado_remediacion.txt: remediacion del intervalo con gate incumplido (08:15-08:22).

## Limites honestos
- El sidecar repara OBSERVABILIDAD; no demuestra corregir la causa de muerte de la guardia RSS
  previa. T2 mostro overshoot (pico 295MiB vs limite 200): el kill reacciona tras el sondeo,
  no es un limite duro. SIGKILL al supervisor deja solo la cota de tiempo (documentado).
- El entrenamiento TUI sigue siendo supervisado sobre OASST2 (bootstrap), NO automejora ni RSI.
