#!/bin/bash
# S1 REPLICA ORDEN (autorizada 13:40): R_b 2x480 seq_R_b / E_b 234+246 seq_E_b.
# MISMA base etapa0, lr 0.003 seed 7; SOLO cambia el orden (shuffle 20261026).
# Tope 90s wall ESTA SECCION; guardas R>24.2 E>5; proyeccion; sin retries.
set -e; cd /tmp/blm
PREV=c8ee772eb1d2dfe4c2ea8ffc38d991f07750309d449eff53f82d63af3476b355
TSTART=$SECONDS
mkdir -p ciclo_replica
bloque() { # ARM K PASOS CORPUS MANIFEST SEQ CKIN CKOUT PREVFLAG GUARDA TO EST
  local A=$1 K=$2 PASOS=$3 MA=$4 MF=$5 SQ=$6 IN=$7 OUT=$8 PF=$9 GU=${10} TO=${11} EST=${12}
  local INSHA; INSHA=$(sha256sum "$IN" | cut -c1-12)
  local KEY="S1${A}${K}_${INSHA}"; local LED="ciclo_replica/ledger_$KEY"
  if [ -e "$LED" ]; then
    local ST; ST=$(cut -d' ' -f1 "$LED")
    [ "$ST" = completed ] && { echo "LEDGER $KEY ya completada"; return 0; }
    echo "LEDGER $KEY estado=$ST: recuperacion manual; NO reejecuta"; exit 3
  fi
  local el=$((SECONDS-TSTART))
  if awk "BEGIN{exit !($el+$EST>90)}"; then echo "PARADA proyeccion ${el}s+${EST} > 90s"; exit 5; fi
  echo "running $(date -Is)" > "$LED.tmp"; mv "$LED.tmp" "$LED"
  trap 'if [ -n "${LED:-}" ]; then echo "failed $(date -Is)" > "$LED.tmp"; mv "$LED.tmp" "$LED"; fi' ERR
  local t0=$SECONDS
  timeout -k 2 $TO ./mz d1gru -mode train-pairs -corpus "$MA" -val dst3b_dev.txt \
    -in "$IN" -out "$OUT" -steps $PASOS -lr 0.003 -seed 7 \
    -master "$MA" -manifest "$MF" -seq "$SQ" $PF 2>&1 | grep -E 'FIN|RECHAZO|seq predefinida'
  local dt=$((SECONDS-t0))
  if awk "BEGIN{exit !($dt>$GU)}"; then
    echo "failed $(date -Is) GUARDA bloque ${dt}s > ${GU}s" > "$LED.tmp"; mv "$LED.tmp" "$LED"
    echo "PARADA: bloque $A$K ${dt}s > ${GU}s"; exit 4
  fi
  echo "completed $(date -Is) segundos=$dt" > "$LED.tmp"; mv "$LED.tmp" "$LED"
  echo "OK bloque $A$K ${dt}s (${PASOS} pasos)"
}
cp ciclo1_etapa0.json ciclo_replica/ck_Rb0.json
bloque Rb 1 480 replay/master_mix.txt replay/man_mix.txt replay/seq_R_b.txt ciclo_replica/ck_Rb0.json ciclo_replica/ck_Rb1.json "-master-prev $PREV" 24.2 26 24.2
bloque Rb 2 480 replay/master_mix.txt replay/man_mix.txt replay/seq_R_b.txt ciclo_replica/ck_Rb1.json ciclo_replica/ck_Rb2.json "" 24.2 26 24.2
cp ciclo1_etapa0.json ciclo_replica/ck_Eb0.json
bloque Eb 1 234 dst3b_train.txt replay/man_train.txt replay/seq_E_b.txt ciclo_replica/ck_Eb0.json ciclo_replica/ck_Eb1.json "-master-prev $PREV" 5 7 5
bloque Eb 2 246 dst3b_train.txt replay/man_train.txt replay/seq_E_b.txt ciclo_replica/ck_Eb1.json ciclo_replica/ck_Eb2.json "" 5 7 5
for CK in ciclo_replica/ck_Rb2 ciclo_replica/ck_Eb2; do
  N=$(basename $CK)
  timeout -k 2 10 ./mz d1gru -mode scorepairs -in $CK.json -corpus ciclo1_heldout100.txt 2>/dev/null | awk -v n=$N '$1=="SCORE"{s+=$3;c++} END{printf "retencion %s bpb=%.6f (%d pares)\n", n, s/c, c}'
done
echo "WALL S1: $((SECONDS-TSTART))s (tope 90s)"
