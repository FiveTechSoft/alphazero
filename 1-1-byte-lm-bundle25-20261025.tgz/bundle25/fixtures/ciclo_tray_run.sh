#!/bin/bash
# S2 TRAYECTORIA R2880 (autorizada 13:40): nuevo clon base, seq_R2880 congelada
# (sha 47813581bfa564c8, prefijo 960 = seq_R). 6 bloques x 480; CORTE cuando
# exact train96 >= 15 o 6 bloques. Tras bloque 2: comparador fiel vs ck_R2
# (pesos/Adam/RNG/steps; seq_sha difiere DECLARADO); cualquier diferencia =
# PARAR antes de bloque 3. Tope 150s wall ESTA SECCION; guarda bloque >14s;
# proyeccion elapsed+15>150; sin retries.
set -e; cd /tmp/blm
PREV=c8ee772eb1d2dfe4c2ea8ffc38d991f07750309d449eff53f82d63af3476b355
TSTART=$SECONDS
mkdir -p ciclo_tray
bloque() { # K CKIN CKOUT PREVFLAG
  local K=$1 IN=$2 OUT=$3 PF=$4
  local INSHA; INSHA=$(sha256sum "$IN" | cut -c1-12)
  local KEY="S2T${K}_${INSHA}"; local LED="ciclo_tray/ledger_$KEY"
  if [ -e "$LED" ]; then
    local ST; ST=$(cut -d' ' -f1 "$LED")
    [ "$ST" = completed ] && { echo "LEDGER $KEY ya completada"; return 0; }
    echo "LEDGER $KEY estado=$ST: recuperacion manual; NO reejecuta"; exit 3
  fi
  local el=$((SECONDS-TSTART))
  if [ $((el+15)) -gt 150 ]; then echo "PARADA proyeccion ${el}s+15 > 150s"; exit 5; fi
  echo "running $(date -Is)" > "$LED.tmp"; mv "$LED.tmp" "$LED"
  trap 'if [ -n "${LED:-}" ]; then echo "failed $(date -Is)" > "$LED.tmp"; mv "$LED.tmp" "$LED"; fi' ERR
  local t0=$SECONDS
  timeout -k 2 16 ./mz d1gru -mode train-pairs -corpus replay/master_mix.txt -val dst3b_dev.txt \
    -in "$IN" -out "$OUT" -steps 480 -lr 0.003 -seed 7 \
    -master replay/master_mix.txt -manifest replay/man_mix.txt -seq replay/seq_R2880.txt $PF 2>&1 | grep -E 'FIN|RECHAZO|seq predefinida'
  local dt=$((SECONDS-t0))
  if [ $dt -gt 14 ]; then
    echo "failed $(date -Is) GUARDA bloque ${dt}s > 14s" > "$LED.tmp"; mv "$LED.tmp" "$LED"
    echo "PARADA: bloque T$K ${dt}s > 14s"; exit 4
  fi
  echo "completed $(date -Is) segundos=$dt" > "$LED.tmp"; mv "$LED.tmp" "$LED"
  echo "OK bloque T$K ${dt}s"
}
evalu() { # CK NOMBRE -> exact train96 (numero), imprime lineas
  timeout -k 2 10 ./mz d1gru -mode genpairs -in "$1" -corpus dst3b_dev.txt -n 16 -temp 0 > ciclo_tray/gendev_$2.txt 2>/dev/null
  timeout -k 2 10 ./mz d1gru -mode genpairs -in "$1" -corpus dst3b_train.txt -n 16 -temp 0 > ciclo_tray/gentrain_$2.txt 2>/dev/null
  local DT; DT=$(python3 ciclo3b_score.py dst3b_dev.txt ciclo_tray/gendev_$2.txt | python3 -c "import json,sys;print(json.load(sys.stdin)['exact_total'])")
  local TT; TT=$(python3 ciclo3b_score.py dst3b_train.txt ciclo_tray/gentrain_$2.txt | python3 -c "import json,sys;print(json.load(sys.stdin)['exact_total'])")
  local RT; RT=$(timeout -k 2 10 ./mz d1gru -mode scorepairs -in "$1" -corpus ciclo1_heldout100.txt 2>/dev/null | awk '$1=="SCORE"{s+=$3;c++} END{printf "%.6f", s/c}')
  echo "== $2 exact_train96=$TT exact_dev24=$DT bpb_heldout=$RT"
  EXACT_N=$(echo $TT | cut -d/ -f1)
}
cp ciclo1_etapa0.json ciclo_tray/ck_T0.json
EXACT_N=0
for K in 1 2 3 4 5 6; do
  P=$((K-1)); PF=""; [ $K = 1 ] && PF="-master-prev $PREV"
  bloque $K ciclo_tray/ck_T${P}.json ciclo_tray/ck_T${K}.json "$PF"
  evalu ciclo_tray/ck_T${K}.json T$K
  if [ $K = 2 ]; then
    python3 compara_fiel.py ciclo_replay/ck_R2.json ciclo_tray/ck_T2.json || { echo "PARADA: fidelidad T2 vs R2 fallo"; exit 6; }
  fi
  if [ "$EXACT_N" -ge 15 ]; then echo "CORTE: exact train96 $EXACT_N >= 15 en bloque T$K"; break; fi
done
echo "WALL S2: $((SECONDS-TSTART))s (tope 150s)"
