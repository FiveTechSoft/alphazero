package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
)

// Fixtures unitarias de validacion de reanudacion; SIN entrenamiento.

func ckptFixture(t *testing.T, mut func(*gruCkpt)) string {
	t.Helper()
	g := NewGRU(1, 4, 8)
	st := g.newAdam()
	st.t = 7
	p := filepath.Join(t.TempDir(), "ck.json")
	if err := g.SaveGRU(p, 7, 1.5, st, 12345, "sha-abc", 7, 0.003, ""); err != nil {
		t.Fatal(err)
	}
	if mut == nil {
		return p
	}
	b, _ := os.ReadFile(p)
	var c gruCkpt
	if err := json.Unmarshal(b, &c); err != nil {
		t.Fatal(err)
	}
	mut(&c)
	b2, _ := json.Marshal(c)
	if err := os.WriteFile(p, b2, 0644); err != nil {
		t.Fatal(err)
	}
	return p
}

func loadCkpt(t *testing.T, p string) *gruCkpt {
	t.Helper()
	b, err := os.ReadFile(p)
	if err != nil {
		t.Fatal(err)
	}
	var c gruCkpt
	if err := json.Unmarshal(b, &c); err != nil {
		t.Fatal(err)
	}
	return &c
}

func TestResumeValidoPasa(t *testing.T) {
	c := loadCkpt(t, ckptFixture(t, nil))
	if err := validarResumeFiel(c, "sha-abc", 0.003, false); err != nil {
		t.Fatalf("resume valido rechazado: %v", err)
	}
}

func TestResumeRechazaCorpusDistinto(t *testing.T) {
	c := loadCkpt(t, ckptFixture(t, nil))
	if err := validarResumeFiel(c, "sha-OTRO", 0.003, false); err == nil {
		t.Fatal("corpus distinto NO rechazado")
	}
	if err := validarResumeFiel(c, "sha-OTRO", 0.003, true); err != nil {
		t.Fatalf("fork explicito debia pasar: %v", err)
	}
}

func TestResumeRechazaLrDistinto(t *testing.T) {
	c := loadCkpt(t, ckptFixture(t, nil))
	if err := validarResumeFiel(c, "sha-abc", 0.001, false); err == nil {
		t.Fatal("lr distinto NO rechazado")
	}
}

func TestResumeRechazaProtoDesconocido(t *testing.T) {
	p := ckptFixture(t, func(c *gruCkpt) { c.Proto = "otro" })
	if err := validarResumeFiel(loadCkpt(t, p), "sha-abc", 0.003, false); err == nil {
		t.Fatal("proto desconocido NO rechazado")
	}
}

func TestResumeRechazaAdamTDesalineado(t *testing.T) {
	p := ckptFixture(t, func(c *gruCkpt) { c.Adam.T = 99 })
	if err := validarResumeFiel(loadCkpt(t, p), "sha-abc", 0.003, false); err == nil {
		t.Fatal("Adam.t != steps NO rechazado")
	}
}

func TestCheckpointTruncadoRechazado(t *testing.T) {
	p := ckptFixture(t, nil)
	b, _ := os.ReadFile(p)
	tr := p + ".trunc"
	if err := os.WriteFile(tr, b[:len(b)/2], 0644); err != nil {
		t.Fatal(err)
	}
	if _, _, _, err := LoadGRU(tr); err == nil {
		t.Fatal("checkpoint truncado cargado sin error")
	}
}

func TestGuardadoAtomicoSinTmpResidual(t *testing.T) {
	dir := t.TempDir()
	p := ckptFixture(t, nil)
	_ = p
	g := NewGRU(1, 4, 8)
	dst := filepath.Join(dir, "c.json")
	if err := g.SaveGRU(dst, 0, 0, nil, 0, "", 0, 0, ""); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(dst + ".tmp"); !os.IsNotExist(err) {
		t.Fatal("quedo .tmp residual tras guardado")
	}
	if _, _, _, err := LoadGRU(dst); err != nil {
		t.Fatalf("checkpoint atomico no carga: %v", err)
	}
}

func TestAdamRoundtrip(t *testing.T) {
	g := NewGRU(1, 4, 8)
	st := g.newAdam()
	st.t = 3
	st.mE[5][2] = 0.125
	st.vWo[7][3] = -0.5
	p := filepath.Join(t.TempDir(), "a.json")
	if err := g.SaveGRU(p, 3, 0, st, 999, "s", 7, 0.003, ""); err != nil {
		t.Fatal(err)
	}
	g2, steps, _, err := LoadGRUFull(p)
	if err != nil {
		t.Fatal(err)
	}
	if steps != 3 || g2.lastCkpt == nil {
		t.Fatalf("steps=%d lastCkpt=%v", steps, g2.lastCkpt == nil)
	}
	st2 := g2.adamFromJSON(g2.lastCkpt.Adam)
	if st2.t != 3 || st2.mE[5][2] != 0.125 || st2.vWo[7][3] != -0.5 {
		t.Fatalf("adam roundtrip fallo: t=%d mE=%v vWo=%v", st2.t, st2.mE[5][2], st2.vWo[7][3])
	}
	if g2.lastCkpt.Samp != 999 || g2.lastCkpt.CorpusSHA != "s" || g2.lastCkpt.Lr != 0.003 {
		t.Fatal("meta samp/corpus/lr no sobrevivio")
	}
}

func TestSm64Determinista(t *testing.T) {
	a, b := &sm64{s: 42}, &sm64{s: 42}
	for i := 0; i < 1000; i++ {
		if a.next() != b.next() {
			t.Fatal("sm64 no determinista")
		}
	}
	c := &sm64{s: 43}
	if c.next() == (&sm64{s: 42}).next() {
		t.Fatal("semillas distintas, misma salida")
	}
}
