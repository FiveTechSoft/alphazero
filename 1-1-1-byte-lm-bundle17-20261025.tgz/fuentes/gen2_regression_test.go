package main

import (
	"math/rand"
	"testing"
)

// Regresion DEC2: el primer byte generado por generateGRU2 debe salir del estado
// tras el prompt completo (sin realimentar el ultimo byte). Se verifica contra un
// muestreo manual deterministico con la misma semilla y temperatura. Si se
// reintroduce la doble alimentacion, el primer byte cambia y el test falla.
func TestGen2PrimerByteSinRealimentacion(t *testing.T) {
	seed := int64(7)
	temp := 0.3
	prompt := "U: prueba\nA: "
	g := NewGRU(20261025, 32, 64)
	// Estado esperado: cebar con el prompt y muestrear el primer byte a mano.
	h := make([]float64, g.H)
	for i := 0; i < len(prompt); i++ {
		_, h = g.step(h, prompt[i])
	}
	lg := g.logits(h)
	for i := range lg {
		lg[i] /= temp
	}
	p := softmax(lg)
	r := rand.New(rand.NewSource(seed))
	u := r.Float64()
	acc := 0.0
	want := byte(' ')
	for b := 0; b < 256; b++ {
		acc += p[b]
		if u <= acc {
			want = byte(b)
			break
		}
	}
	got := g.generateGRU2(prompt, 8, temp, seed)
	if len(got) == 0 {
		t.Fatal("generateGRU2 devolvio cadena vacia")
	}
	if got[0] != want {
		t.Fatalf("primer byte=%q, esperado del estado post-prompt=%q (posible doble alimentacion)", got[0], want)
	}
}
