package main

// blmgru.go — byte-GRU minimo (PRUEBA DE RUTA, no entrenamiento grande).
// Objetivo: verificar que una recurrente pequena es entrenable en CPU local
// acotada: (a) gradient check por diferencias finitas, (b) coste/paso medido,
// (c) humo de pasos mostrando descenso de perdida. Nada mas se afirma.
//
// GRU estandar:
//   z = sig(Wz [h,x] + bz)     (puerta actualizacion)
//   r = sig(Wr [h,x] + br)     (puerta reset)
//   n = tanh(Wn [r*h, x] + bn) (candidato)
//   h' = (1-z)*h + z*n
// Salida: softmax(Wo h' + bo) sobre 256 bytes.
import (
	"fmt"
	"encoding/json"
	"math"
	"math/rand"
	"os"
)

type GRU struct {
	D, H     int
	lastCkpt *gruCkpt // estado extra del ultimo LoadGRUFull (adam/samp/meta), nil en checkpoints viejos
	E    [][]float64 // [256][D] embedding de byte
	Wz   [][]float64 // [H][H+D]
	Wr   [][]float64
	Wn   [][]float64
	Bz   []float64
	Br   []float64
	Bn   []float64
	Wo   [][]float64 // [256][H]
	Bo   []float64
}

func NewGRU(seed int64, d, h int) *GRU {
	r := rand.New(rand.NewSource(seed))
	mk := func(n, m int, scale float64) [][]float64 {
		M := make([][]float64, n)
		for i := range M {
			M[i] = make([]float64, m)
			for j := range M[i] {
				M[i][j] = (r.Float64()*2 - 1) * scale
			}
		}
		return M
	}
	g := &GRU{D: d, H: h}
	g.E = mk(256, d, 0.1)
	sc := math.Sqrt(1.0 / float64(h+d))
	g.Wz = mk(h, h+d, sc)
	g.Wr = mk(h, h+d, sc)
	g.Wn = mk(h, h+d, sc)
	g.Bz = make([]float64, h)
	g.Br = make([]float64, h)
	g.Bn = make([]float64, h)
	g.Wo = mk(256, h, 0.05)
	g.Bo = make([]float64, 256)
	return g
}

type gruGrads struct {
	E, Wz, Wr, Wn, Wo [][]float64
	Bz, Br, Bn, Bo    []float64
}

func (g *GRU) newGrads() *gruGrads {
	mk := func(n, m int) [][]float64 {
		M := make([][]float64, n)
		for i := range M {
			M[i] = make([]float64, m)
		}
		return M
	}
	return &gruGrads{
		E: mk(256, g.D), Wz: mk(g.H, g.H+g.D), Wr: mk(g.H, g.H+g.D), Wn: mk(g.H, g.H+g.D),
		Wo: mk(256, g.H),
		Bz: make([]float64, g.H), Br: make([]float64, g.H), Bn: make([]float64, g.H),
		Bo: make([]float64, 256),
	}
}

func sigmoid(x float64) float64 { return 1 / (1 + math.Exp(-x)) }

// gruStep: un paso forward. Devuelve caches necesarias para backward.
type gruCache struct {
	hPrev, x, z, r, n, hNew []float64
}

func (g *GRU) step(hPrev []float64, b byte) (*gruCache, []float64) {
	H, D := g.H, g.D
	x := g.E[b]
	hx := make([]float64, H+D)
	copy(hx, hPrev)
	copy(hx[H:], x)
	z := make([]float64, H)
	r := make([]float64, H)
	n := make([]float64, H)
	for i := 0; i < H; i++ {
		sz, sr := g.Bz[i], g.Br[i]
		for j := 0; j < H+D; j++ {
			sz += g.Wz[i][j] * hx[j]
			sr += g.Wr[i][j] * hx[j]
		}
		z[i] = sigmoid(sz)
		r[i] = sigmoid(sr)
	}
	// n usa [r*h, x]
	rhx := make([]float64, H+D)
	for i := 0; i < H; i++ {
		rhx[i] = r[i] * hPrev[i]
	}
	copy(rhx[H:], x)
	for i := 0; i < H; i++ {
		sn := g.Bn[i]
		for j := 0; j < H+D; j++ {
			sn += g.Wn[i][j] * rhx[j]
		}
		n[i] = math.Tanh(sn)
	}
	hNew := make([]float64, H)
	for i := 0; i < H; i++ {
		hNew[i] = (1-z[i])*hPrev[i] + z[i]*n[i]
	}
	return &gruCache{hPrev: append([]float64(nil), hPrev...), x: append([]float64(nil), x...), z: z, r: r, n: n, hNew: hNew}, hNew
}

func (g *GRU) logits(h []float64) []float64 {
	lg := make([]float64, 256)
	copy(lg, g.Bo)
	for b := 0; b < 256; b++ {
		for i := 0; i < g.H; i++ {
			lg[b] += g.Wo[b][i] * h[i]
		}
	}
	return lg
}

// seqLoss: perdida media por byte en seq (next-byte), sin backward.
// Devuelve bits-per-byte y el estado final.
func (g *GRU) seqLoss(seq []byte) (float64, []float64) {
	if len(seq) < 2 {
		return 0, make([]float64, g.H)
	}
	h := make([]float64, g.H)
	acc := 0.0
	for t := 0; t+1 < len(seq); t++ {
		_, h = g.step(h, seq[t])
		p := softmax(g.logits(h))
		pr := p[seq[t+1]]
		if pr < 1e-12 {
			pr = 1e-12
		}
		acc += -math.Log2(pr)
	}
	return acc / float64(len(seq)-1), h
}

// trainSeq: BPTT sobre una ventana de seq (next-byte). Acumula en gr y
// devuelve perdida media. h0 inicial cero (ventanas independientes: sesgo
// declarado en docs; es una PRUEBA, no el modelo final).
func (g *GRU) trainSeq(seq []byte, gr *gruGrads) float64 {
	if len(seq) < 2 {
		return 0
	}
	H, D := g.H, g.D
	T := len(seq) - 1
	caches := make([]*gruCache, T)
	h := make([]float64, H)
	acc := 0.0
	// forward
	for t := 0; t < T; t++ {
		c, hn := g.step(h, seq[t])
		caches[t] = c
		h = hn
		p := softmax(g.logits(h))
		pr := p[seq[t+1]]
		if pr < 1e-12 {
			pr = 1e-12
		}
		acc += -math.Log2(pr)
	}
	// backward
	dh := make([]float64, H) // gradiente que viene del futuro
	for t := T - 1; t >= 0; t-- {
		c := caches[t]
		// perdida en t: d logits. La perdida reportada es la MEDIA en BITS
		// (-log2 p)/T; el gradiente de -ln p es (p-onehot), asi que se
		// escala por 1/(T*ln2) para coincidir con seqLoss (gradcheck C4c:
		// factor 44.36 = T*ln2 detectado por diferencias finitas).
		p := softmax(g.logits(c.hNew))
		p[seq[t+1]] -= 1
		sc := 1.0 / (float64(T) * math.Ln2)
		dlg := make([]float64, 256)
		for b := range dlg {
			dlg[b] = p[b] * sc
		}
		// grad Wo, Bo y dh desde salida
		for b := 0; b < 256; b++ {
			gr.Bo[b] += dlg[b]
			for i := 0; i < H; i++ {
				gr.Wo[b][i] += dlg[b] * c.hNew[i]
			}
		}
		dhLoc := make([]float64, H)
		for i := 0; i < H; i++ {
			s := dh[i]
			for b := 0; b < 256; b++ {
				s += g.Wo[b][i] * dlg[b]
			}
			dhLoc[i] = s
		}
		// h' = (1-z) hPrev + z n
		dz := make([]float64, H)
		dn := make([]float64, H)
		dhPrev := make([]float64, H)
		for i := 0; i < H; i++ {
			dz[i] = dhLoc[i] * (c.n[i] - c.hPrev[i])
			dn[i] = dhLoc[i] * c.z[i]
			dhPrev[i] = dhLoc[i] * (1 - c.z[i])
		}
		// n = tanh(sn): dn -> dsn
		drhx := make([]float64, H+D)
		for i := 0; i < H; i++ {
			dsn := dn[i] * (1 - c.n[i]*c.n[i])
			gr.Bn[i] += dsn
			for j := 0; j < H+D; j++ {
				var rhxj float64
				if j < H {
					rhxj = c.r[j] * c.hPrev[j]
				} else {
					rhxj = c.x[j-H]
				}
				gr.Wn[i][j] += dsn * rhxj
				drhx[j] += dsn * g.Wn[i][j]
			}
		}
		// drhx -> dr (parte h) y dx
		dr := make([]float64, H)
		dx := make([]float64, D)
		for i := 0; i < H; i++ {
			dr[i] = drhx[i] * c.hPrev[i]
			dhPrev[i] += drhx[i] * c.r[i]
		}
		for j := 0; j < D; j++ {
			dx[j] = drhx[H+j]
		}
		// z, r: sigmoides sobre [h,x]
		dhx := make([]float64, H+D)
		for i := 0; i < H; i++ {
			dsz := dz[i] * c.z[i] * (1 - c.z[i])
			dsr := dr[i] * c.r[i] * (1 - c.r[i])
			gr.Bz[i] += dsz
			gr.Br[i] += dsr
			for j := 0; j < H+D; j++ {
				var hxj float64
				if j < H {
					hxj = c.hPrev[j]
				} else {
					hxj = c.x[j-H]
				}
				gr.Wz[i][j] += dsz * hxj
				gr.Wr[i][j] += dsr * hxj
				dhx[j] += dsz*g.Wz[i][j] + dsr*g.Wr[i][j]
			}
		}
		for i := 0; i < H; i++ {
			dhPrev[i] += dhx[i]
		}
		for j := 0; j < D; j++ {
			dx[j] += dhx[H+j]
		}
		// dx -> embedding del byte de entrada
		for j := 0; j < D; j++ {
			gr.E[seq[t]][j] += dx[j]
		}
		copy(dh, dhPrev)
	}
	return acc / float64(T)
}

// adamGRU: paso Adam sobre todos los parametros, estado propio.
type adamGRUState struct {
	mE, vE, mWz, vWz, mWr, vWr, mWn, vWn, mWo, vWo [][]float64
	mBz, vBz, mBr, vBr, mBn, vBn, mBo, vBo         []float64
	t                                              int
}

func (g *GRU) newAdam() *adamGRUState {
	mk := func(n, m int) [][]float64 {
		M := make([][]float64, n)
		for i := range M {
			M[i] = make([]float64, m)
		}
		return M
	}
	return &adamGRUState{
		mE: mk(256, g.D), vE: mk(256, g.D),
		mWz: mk(g.H, g.H+g.D), vWz: mk(g.H, g.H+g.D),
		mWr: mk(g.H, g.H+g.D), vWr: mk(g.H, g.H+g.D),
		mWn: mk(g.H, g.H+g.D), vWn: mk(g.H, g.H+g.D),
		mWo: mk(256, g.H), vWo: mk(256, g.H),
		mBz: make([]float64, g.H), vBz: make([]float64, g.H),
		mBr: make([]float64, g.H), vBr: make([]float64, g.H),
		mBn: make([]float64, g.H), vBn: make([]float64, g.H),
		mBo: make([]float64, 256), vBo: make([]float64, 256),
	}
}

// adamApply: aplica un paso Adam a TODOS los parametros y deja gr a cero.
func (g *GRU) adamApply(st *adamGRUState, lr float64, gr *gruGrads) {
	st.t++
	b1, b2, eps := 0.9, 0.999, 1e-8
	c1 := 1 - math.Pow(b1, float64(st.t))
	c2 := 1 - math.Pow(b2, float64(st.t))
	updM := func(P, G, M, V [][]float64) {
		for i := range P {
			for j := range P[i] {
				gij := G[i][j]
				M[i][j] = b1*M[i][j] + (1-b1)*gij
				V[i][j] = b2*V[i][j] + (1-b2)*gij*gij
				P[i][j] -= lr * (M[i][j] / c1) / (math.Sqrt(V[i][j]/c2) + eps)
			}
		}
	}
	updV := func(P, G, M, V []float64) {
		for i := range P {
			gi := G[i]
			M[i] = b1*M[i] + (1-b1)*gi
			V[i] = b2*V[i] + (1-b2)*gi*gi
			P[i] -= lr * (M[i] / c1) / (math.Sqrt(V[i]/c2) + eps)
		}
	}
	updM(g.E, gr.E, st.mE, st.vE)
	updM(g.Wz, gr.Wz, st.mWz, st.vWz)
	updM(g.Wr, gr.Wr, st.mWr, st.vWr)
	updM(g.Wn, gr.Wn, st.mWn, st.vWn)
	updM(g.Wo, gr.Wo, st.mWo, st.vWo)
	updV(g.Bz, gr.Bz, st.mBz, st.vBz)
	updV(g.Br, gr.Br, st.mBr, st.vBr)
	updV(g.Bn, gr.Bn, st.mBn, st.vBn)
	updV(g.Bo, gr.Bo, st.mBo, st.vBo)
	// dejar gradientes a cero para el siguiente lote
	zeroM := func(M [][]float64) {
		for i := range M {
			for j := range M[i] {
				M[i][j] = 0
			}
		}
	}
	zeroV := func(V []float64) {
		for i := range V {
			V[i] = 0
		}
	}
	zeroM(gr.E)
	zeroM(gr.Wz)
	zeroM(gr.Wr)
	zeroM(gr.Wn)
	zeroM(gr.Wo)
	zeroV(gr.Bz)
	zeroV(gr.Br)
	zeroV(gr.Bn)
	zeroV(gr.Bo)
}

// flatParams: vista plana SOLO para gradient check por diferencias finitas.
// Devuelve getters/setters sobre cada escalar, en orden determinista.
func (g *GRU) flatAccess() []func(delta float64, set bool) float64 {
	var acc []func(delta float64, set bool) float64
	addM := func(M [][]float64) {
		for i := range M {
			for j := range M[i] {
				i2, j2 := i, j
				acc = append(acc, func(delta float64, set bool) float64 {
					if set {
						M[i2][j2] += delta
					}
					return M[i2][j2]
				})
			}
		}
	}
	addV := func(V []float64) {
		for i := range V {
			i2 := i
			acc = append(acc, func(delta float64, set bool) float64 {
				if set {
					V[i2] += delta
				}
				return V[i2]
			})
		}
	}
	addM(g.E)
	addM(g.Wz)
	addM(g.Wr)
	addM(g.Wn)
	addV(g.Bz)
	addV(g.Br)
	addV(g.Bn)
	addM(g.Wo)
	addV(g.Bo)
	return acc
}

// gradFlat: gradiente analitico en el MISMO orden plano que flatAccess.
func (g *GRU) gradFlat(gr *gruGrads) []float64 {
	var out []float64
	addM := func(M [][]float64) {
		for i := range M {
			out = append(out, M[i]...)
		}
	}
	addV := func(V []float64) { out = append(out, V...) }
	addM(gr.E)
	addM(gr.Wz)
	addM(gr.Wr)
	addM(gr.Wn)
	addV(gr.Bz)
	addV(gr.Br)
	addV(gr.Bn)
	addM(gr.Wo)
	addV(gr.Bo)
	return out
}

// sm64: PRNG propio con estado explicito (splitmix64) para muestreo de pares
// reanudable de forma exacta. NO reproduce la secuencia de math/rand: cualquier
// run que lo use pertenece al protocolo versionado "run-continuo-v2", no al original.
type sm64 struct{ s uint64 }

func (r *sm64) next() uint64 {
	r.s += 0x9E3779B97F4A7C15
	z := r.s
	z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9
	z = (z ^ (z >> 27)) * 0x94D049BB133111EB
	return z ^ (z >> 31)
}

func (r *sm64) intn(n int) int { return int(r.next() % uint64(n)) }

// adamJSON: estado Adam serializado en orden fijo:
// M = [mE,mWz,mWr,mWn,mWo (aplanadas fila mayor), mBz,mBr,mBn,mBo]
// V = idem; T = pasos Adam.
type adamJSON struct {
	M [][]float64 `json:"m"`
	V [][]float64 `json:"v"`
	T int         `json:"t"`
}

func flat2(m [][]float64) []float64 {
	n := 0
	for _, r := range m {
		n += len(r)
	}
	o := make([]float64, 0, n)
	for _, r := range m {
		o = append(o, r...)
	}
	return o
}

func (st *adamGRUState) toJSON() *adamJSON {
	a := &adamJSON{T: st.t}
	for _, m := range [][][]float64{st.mE, st.mWz, st.mWr, st.mWn, st.mWo} {
		a.M = append(a.M, flat2(m))
	}
	a.M = append(a.M, st.mBz, st.mBr, st.mBn, st.mBo)
	for _, m := range [][][]float64{st.vE, st.vWz, st.vWr, st.vWn, st.vWo} {
		a.V = append(a.V, flat2(m))
	}
	a.V = append(a.V, st.vBz, st.vBr, st.vBn, st.vBo)
	return a
}

func (g *GRU) adamFromJSON(a *adamJSON) *adamGRUState {
	st := g.newAdam()
	if a == nil {
		return st
	}
	st.t = a.T
	set := func(dst [][]float64, src []float64) {
		o := 0
		for i := range dst {
			copy(dst[i], src[o:o+len(dst[i])])
			o += len(dst[i])
		}
	}
	for k, dst := range [][][]float64{st.mE, st.mWz, st.mWr, st.mWn, st.mWo} {
		set(dst, a.M[k])
	}
	for k, dst := range [][]float64{st.mBz, st.mBr, st.mBn, st.mBo} {
		copy(dst, a.M[5+k])
	}
	for k, dst := range [][][]float64{st.vE, st.vWz, st.vWr, st.vWn, st.vWo} {
		set(dst, a.V[k])
	}
	for k, dst := range [][]float64{st.vBz, st.vBr, st.vBn, st.vBo} {
		copy(dst, a.V[5+k])
	}
	return st
}

// SaveGRU / LoadGRU: checkpoint JSON (mismo estilo que BLM).
// adam/samp/corpus_sha/seed/lr/proto son OPCIONALES (omitempty): checkpoints
// antiguos cargan SOLO pesos; reanudar desde ellos = Adam fresco + RNG de
// muestreo nuevo, declarado "resumen no fiel", NUNCA continuacion exacta.
type gruCkpt struct {
	D     int         `json:"d"`
	H     int         `json:"h"`
	E     [][]float64 `json:"e"`
	Wz    [][]float64 `json:"wz"`
	Wr    [][]float64 `json:"wr"`
	Wn    [][]float64 `json:"wn"`
	Bz    []float64   `json:"bz"`
	Br    []float64   `json:"br"`
	Bn    []float64   `json:"bn"`
	Wo    [][]float64 `json:"wo"`
	Bo    []float64   `json:"bo"`
	Steps     int         `json:"steps"`
	BPBV      float64     `json:"bpb_val"`
	Adam      *adamJSON   `json:"adam,omitempty"`
	Samp      uint64      `json:"samp,omitempty"`
	CorpusSHA string      `json:"corpus_sha,omitempty"`
	Seed      int64       `json:"seed,omitempty"`
	Lr        float64     `json:"lr,omitempty"`
	Proto     string      `json:"proto,omitempty"`
}

func (g *GRU) SaveGRU(path string, steps int, bpbv float64, st *adamGRUState, samp uint64, corpusSHA string, seed int64, lr float64, proto string) error {
	c := gruCkpt{D: g.D, H: g.H, E: g.E, Wz: g.Wz, Wr: g.Wr, Wn: g.Wn, Bz: g.Bz, Br: g.Br, Bn: g.Bn, Wo: g.Wo, Bo: g.Bo, Steps: steps, BPBV: bpbv}
	if st != nil {
		c.Adam = st.toJSON()
		c.Samp = samp
		c.CorpusSHA = corpusSHA
		c.Seed = seed
		c.Lr = lr
		if proto == "" {
			proto = "run-continuo-v2"
		}
		c.Proto = proto
	}
	b, err := json.Marshal(c)
	if err != nil {
		return err
	}
	// Guardado atomico: tmp + rename; un checkpoint truncado nunca queda como destino.
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, b, 0644); err != nil {
		os.Remove(tmp)
		return err
	}
	if err := os.Rename(tmp, path); err != nil {
		os.Remove(tmp)
		return err
	}
	return nil
}

func LoadGRU(path string) (*GRU, int, float64, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, 0, 0, err
	}
	var c gruCkpt
	if err := json.Unmarshal(b, &c); err != nil {
		return nil, 0, 0, err
	}
	g := &GRU{D: c.D, H: c.H, E: c.E, Wz: c.Wz, Wr: c.Wr, Wn: c.Wn, Bz: c.Bz, Br: c.Br, Bn: c.Bn, Wo: c.Wo, Bo: c.Bo}
	return g, c.Steps, c.BPBV, nil
}

// validarResumeFiel: reanudar desde un checkpoint v2 EXIGE identidad de datos
// (corpus_sha), config (lr), protocolo y correspondencia Adam.T==Steps. Cualquier
// mismatch RECHAZA salvo fork explicito (etiqueta proto fork-nofiel). Un checkpoint
// truncado ni llega aqui: LoadGRU ya devuelve error de JSON.
func validarResumeFiel(c *gruCkpt, corpusSHA string, lr float64, fork bool) error {
	if c == nil || c.Adam == nil {
		return nil // checkpoint viejo: ruta "solo pesos" ya etiquetada aparte
	}
	if c.Proto != "run-continuo-v2" {
		if !fork {
			return errResume("protocolo desconocido %q (se esperaba run-continuo-v2)", c.Proto)
		}
	}
	if c.CorpusSHA != "" && corpusSHA != "" && c.CorpusSHA != corpusSHA {
		if !fork {
			return errResume("corpus distinto al del checkpoint (datos/orden no identicos)")
		}
	}
	if c.Lr != 0 && lr != c.Lr {
		if !fork {
			return errResume("lr %.6g distinto del checkpoint %.6g", lr, c.Lr)
		}
	}
	if c.Adam.T != c.Steps {
		if !fork {
			return errResume("Adam.t=%d no corresponde a steps=%d", c.Adam.T, c.Steps)
		}
	}
	return nil
}

type resumeError struct{ msg string }

func (e *resumeError) Error() string { return e.msg }
func errResume(format string, a ...interface{}) error {
	return &resumeError{msg: fmt.Sprintf(format, a...)}
}

// LoadGRUFull: como LoadGRU pero conserva el estado extra del checkpoint
// (adam/samp/meta) accesible via g.lastCkpt. nil si el checkpoint es antiguo.
func LoadGRUFull(path string) (*GRU, int, float64, error) {
	g, steps, bpbv, err := LoadGRU(path)
	if err != nil {
		return nil, 0, 0, err
	}
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, 0, 0, err
	}
	var c gruCkpt
	if err := json.Unmarshal(b, &c); err != nil {
		return nil, 0, 0, err
	}
	if c.Adam != nil {
		g.lastCkpt = &c
	}
	return g, steps, bpbv, nil
}

// generateGRU: el estado se cebado con TODOS los bytes del prompt (la
// informacion de la pregunta vive en h, sin ventana que la expulse) y luego
// muestrea byte a byte. Corta en '\n' o maxB.
// generateGRU2 (DEC2, SOLO diagnostico): el primer byte se muestrea del estado
// tras el prompt COMPLETO, sin realimentar el ultimo byte del prompt. El resto del
// bucle es identico a generateGRU. No toca la ruta del servicio.
func (g *GRU) generateGRU2(prompt string, maxB int, temp float64, seed int64) string {
	r := rand.New(rand.NewSource(seed))
	h := make([]float64, g.H)
	for i := 0; i < len(prompt); i++ {
		_, h = g.step(h, prompt[i])
	}
	out := make([]byte, 0, maxB)
	for len(out) < maxB {
		lg := g.logits(h)
		for i := range lg {
			lg[i] /= temp
		}
		p := softmax(lg)
		u := r.Float64()
		acc := 0.0
		nb := byte(' ')
		for b := 0; b < 256; b++ {
			acc += p[b]
			if u <= acc {
				nb = byte(b)
				break
			}
		}
		if nb == '\n' {
			break
		}
		out = append(out, nb)
		_, h = g.step(h, nb)
	}
	return string(out)
}

func (g *GRU) generateGRU(prompt string, maxB int, temp float64, seed int64) string {
	r := rand.New(rand.NewSource(seed))
	h := make([]float64, g.H)
	for i := 0; i < len(prompt); i++ {
		_, h = g.step(h, prompt[i])
	}
	out := make([]byte, 0, maxB)
	var prev byte
	if len(prompt) > 0 {
		prev = prompt[len(prompt)-1]
	}
	for len(out) < maxB {
		_, h = g.step(h, prev)
		lg := g.logits(h)
		for i := range lg {
			lg[i] /= temp
		}
		p := softmax(lg)
		u := r.Float64()
		acc := 0.0
		nb := byte(' ')
		for b := 0; b < 256; b++ {
			acc += p[b]
			if u <= acc {
				nb = byte(b)
				break
			}
		}
		if nb == '\n' {
			break
		}
		out = append(out, nb)
		prev = nb
	}
	return string(out)
}

// trainSeqMask: BPTT sobre seq completa, pero la perdida solo cuenta las
// posiciones t >= lossFrom (se predice seq[t+1]). Asi el prompt se atraviesa
// (el estado se ceba como en inferencia) y solo la RESPUESTA puntua:
// alineacion train/inferencia y aprendizaje de pares U->A.
func (g *GRU) trainSeqMask(seq []byte, lossFrom int, gr *gruGrads) (float64, int) {
	if len(seq) < 2 {
		return 0, 0
	}
	H, D := g.H, g.D
	T := len(seq) - 1
	caches := make([]*gruCache, T)
	h := make([]float64, H)
	acc := 0.0
	nloss := 0
	for t := 0; t < T; t++ {
		c, hn := g.step(h, seq[t])
		caches[t] = c
		h = hn
		if t >= lossFrom {
			p := softmax(g.logits(h))
			pr := p[seq[t+1]]
			if pr < 1e-12 {
				pr = 1e-12
			}
			acc += -math.Log2(pr)
			nloss++
		}
	}
	if nloss == 0 {
		return 0, 0
	}
	dh := make([]float64, H)
	sc := 1.0 / (float64(nloss) * math.Ln2)
	for t := T - 1; t >= 0; t-- {
		c := caches[t]
		var dlg []float64
		if t >= lossFrom {
			p := softmax(g.logits(c.hNew))
			p[seq[t+1]] -= 1
			dlg = make([]float64, 256)
			for b := range dlg {
				dlg[b] = p[b] * sc
			}
			for b := 0; b < 256; b++ {
				gr.Bo[b] += dlg[b]
				for i := 0; i < H; i++ {
					gr.Wo[b][i] += dlg[b] * c.hNew[i]
				}
			}
		}
		dhLoc := make([]float64, H)
		for i := 0; i < H; i++ {
			s := dh[i]
			if dlg != nil {
				for b := 0; b < 256; b++ {
					s += g.Wo[b][i] * dlg[b]
				}
			}
			dhLoc[i] = s
		}
		dz := make([]float64, H)
		dn := make([]float64, H)
		dhPrev := make([]float64, H)
		for i := 0; i < H; i++ {
			dz[i] = dhLoc[i] * (c.n[i] - c.hPrev[i])
			dn[i] = dhLoc[i] * c.z[i]
			dhPrev[i] = dhLoc[i] * (1 - c.z[i])
		}
		drhx := make([]float64, H+D)
		for i := 0; i < H; i++ {
			dsn := dn[i] * (1 - c.n[i]*c.n[i])
			gr.Bn[i] += dsn
			for j := 0; j < H+D; j++ {
				var rhxj float64
				if j < H {
					rhxj = c.r[j] * c.hPrev[j]
				} else {
					rhxj = c.x[j-H]
				}
				gr.Wn[i][j] += dsn * rhxj
				drhx[j] += dsn * g.Wn[i][j]
			}
		}
		dr := make([]float64, H)
		dx := make([]float64, D)
		for i := 0; i < H; i++ {
			dr[i] = drhx[i] * c.hPrev[i]
			dhPrev[i] += drhx[i] * c.r[i]
		}
		for j := 0; j < D; j++ {
			dx[j] = drhx[H+j]
		}
		dhx := make([]float64, H+D)
		for i := 0; i < H; i++ {
			dsz := dz[i] * c.z[i] * (1 - c.z[i])
			dsr := dr[i] * c.r[i] * (1 - c.r[i])
			gr.Bz[i] += dsz
			gr.Br[i] += dsr
			for j := 0; j < H+D; j++ {
				var hxj float64
				if j < H {
					hxj = c.hPrev[j]
				} else {
					hxj = c.x[j-H]
				}
				gr.Wz[i][j] += dsz * hxj
				gr.Wr[i][j] += dsr * hxj
				dhx[j] += dsz*g.Wz[i][j] + dsr*g.Wr[i][j]
			}
		}
		for i := 0; i < H; i++ {
			dhPrev[i] += dhx[i]
		}
		for j := 0; j < D; j++ {
			dx[j] += dhx[H+j]
		}
		for j := 0; j < D; j++ {
			gr.E[seq[t]][j] += dx[j]
		}
		copy(dh, dhPrev)
	}
	return acc / float64(nloss), nloss
}

// pairLoss: perdida media SOLO de la respuesta dada la pregunta (sin
// backward). Sirve para val y para la ablacion de condicionamiento.
func (g *GRU) pairLoss(prompt, answer []byte) float64 {
	h := make([]float64, g.H)
	for i := 0; i < len(prompt); i++ {
		_, h = g.step(h, prompt[i])
	}
	if len(answer) < 2 {
		return 0
	}
	acc := 0.0
	for t := 0; t+1 < len(answer); t++ {
		_, h = g.step(h, answer[t])
		p := softmax(g.logits(h))
		pr := p[answer[t+1]]
		if pr < 1e-12 {
			pr = 1e-12
		}
		acc += -math.Log2(pr)
	}
	return acc / float64(len(answer)-1)
}

// pairLossFull: como pairLoss pero TAMBIEN puntua el primer byte de la respuesta
// (predicho desde el ultimo byte del prompt). Metrica NUEVA con etiqueta propia
// (bpb_primer_byte); la legada (pairLoss) queda intacta para comparabilidad historica.
func (g *GRU) pairLossFull(prompt, answer []byte) float64 {
	h := make([]float64, g.H)
	for i := 0; i < len(prompt); i++ {
		_, h = g.step(h, prompt[i])
	}
	if len(answer) < 1 {
		return 0
	}
	prob := func(dist []float64, b byte) float64 {
		pr := dist[b]
		if pr < 1e-12 {
			pr = 1e-12
		}
		return pr
	}
	acc := -math.Log2(prob(softmax(g.logits(h)), answer[0]))
	for t := 0; t+1 < len(answer); t++ {
		_, h = g.step(h, answer[t])
		acc += -math.Log2(prob(softmax(g.logits(h)), answer[t+1]))
	}
	return acc / float64(len(answer))
}
