# CONTROL equivalencia continuo vs reanudado (protocolo run-continuo-v2) — 2026-10-25
## Alcance MEDIDO (no universal): corpus overfit10 (10 pares), seed 7, lr 0.003, d32/H64
- Continuo 200 pasos vs reanudado 100+100 con estado persistido: checkpoints finales
  BYTES IDENTICOS (sha256 2deb11116c894e74453d… en ambos) → pesos + Adam (m,v,t) +
  estado RNG de muestreo iguales.
- Paso siguiente desde cada uno: BYTES IDENTICOS (bpb 4.5445 en ambos).
- Predicciones (scorepairs, 10 pares): identicas.
- Trayectoria bpb: 4.6632 (100) → 4.5500 (200) igual en ambos caminos.
- Compatibilidad atras MEDIDA: gen2 sobre checkpoint viejo (blm_gru2b) reproduce la salida
  archivada pre-cambio (EVAL-GEN-2 resp_00_base) byte a byte; TestGen2… pasa.
## Validadores (fixtures unitarias, SIN entrenamiento): 9/9 PASS
- Resume v2 RECHAZA: corpus distinto, lr distinto, proto desconocido, Adam.t != steps;
  fork solo con -fork-nofiel explicito (salida etiquetada proto "fork-nofiel:<orig>").
- Checkpoint truncado rechazado (error de carga); guardado atomico tmp+rename sin residual.
- Adam roundtrip exacto; sm64 determinista por semilla y distinto entre semillas.
## Limites declarados
- Equivalencia medida en ESTE corpus/semilla/config; generalizar a otras escalas es hipotesis.
- splitmix64 NO reproduce math/rand: runs con este codigo son protocolo v2, no repeticion
  del HIP-B original. Checkpoints antiguos: solo pesos, aviso "resumen no fiel".
