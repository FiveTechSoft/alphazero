# ADENDO a juicio/LIMITACIONES.md (bundle16) — 2026-10-25, correccion por adendo
Cotejado el informe original (informe_revision_ciega.md, nota descriptiva y casos):
- La ambiguedad de COHERENCIA es UN unico caso: la respuesta C19-R1, con juicio ambiguo
  entre C0 y C1 (conservado). Mi frase previa "9 respuestas en posicion R1 ambiguas" era
  ERRONEA (confundio el identificador C19-R1 con "9 respuestas R1").
- Los 6 juicios P1 por eco lexico generico (B5-R3, B6-R1, B9-R1, B11-R1, B30-R1 y uno mas
  segun el informe) son una categoria APARTE, tambien marcados ambiguos, no exitos.
- Resto de LIMITACIONES.md sin cambios.
