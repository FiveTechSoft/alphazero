#!/usr/bin/env python3
# evalconf_classify.py — clasificador PROGRAMADO de salidas por caso.
# Taxonomia por caso (sin recortar decoding ni oraculo en inferencia):
#   exact        : salida == target
#   dup1B        : len = L+1 y salida == target[0] + target  (primer byte duplicado + respuesta desplazada)
#   contenido_desplazado : target aparece como subcadena con offset>0 (no dup1B)
#   truncada     : salida es prefijo estricto del target
#   otra         : cualquier otra (longitud o contenido incorrecto)
# CLI: evalconf_classify.py PARES GENS  (mismo formato que evalconf_score.py)
import sys, re, json, collections
pares = open(sys.argv[1]).read().strip().split('\n')
gens = [l.rstrip('\n') for l in open(sys.argv[2])]
n = len(pares)//2; assert len(gens)==n, (len(gens), n)
per = collections.defaultdict(lambda: collections.Counter())
for i in range(n):
    m = re.match(r"(repite|invierte) '([a-z]+)'$", pares[2*i][3:])
    op, w = m.group(1), m.group(2)
    t = pares[2*i+1][3:]
    o = gens[i].strip()
    cls = (op, len(w))
    if o == t: c = 'exact'
    elif len(o) == len(t)+1 and o == t[0]+t: c = 'dup1B'
    elif len(o) > len(t) and t in o: c = 'contenido_desplazado'
    elif len(o) < len(t) and t.startswith(o): c = 'truncada'
    else: c = 'otra'
    per[cls][c] += 1
out = {f"{op}_L{L}": dict(cnt) for (op, L), cnt in sorted(per.items())}
tot = collections.Counter()
for cnt in per.values(): tot.update(cnt)
out['TOTAL'] = dict(tot)
print(json.dumps(out, indent=1))
