#!/usr/bin/env python3
# Oraculo evalconf v3 = dst6_score.py v2 + allowlist extendida VERSIONADA.
# Semantica IDENTICA: repite=identidad, invierte=reverso. CLI: evalconf_score.py PARES GENS
# Extension: allowlist = 3 sha256 COMPLETOS congelados en evalconf_MANIFIESTO.json
# (validacion full-sha, no sha16; cualquier otro dataset se rechaza con causa).
import sys, re, json, hashlib
def ap(op,w):
    if op=='repite': return w
    if op=='invierte': return w[::-1]
    raise ValueError(op)
import os
man = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'evalconf_MANIFIESTO.json')))
ALLOW = {fn: e['sha256'] for fn, e in man['archivos'].items()}  # v2: todos los ficheros registrados en el manifiesto (semantica INALTERADA)
base = os.path.basename(sys.argv[1])
assert base in ALLOW, f'RECHAZO: dataset {base} no registrado en allowlist v3'
raw = open(sys.argv[1],'rb').read()
sha = hashlib.sha256(raw).hexdigest()
assert sha == ALLOW[base], f'RECHAZO: sha256 de {base} no coincide con manifiesto congelado'
pares = raw.decode().strip().split('\n')
gens = [l.rstrip('\n') for l in open(sys.argv[2])]
n = len(pares)//2; assert len(gens)==n, (len(gens),n)
per = {}
for i in range(n):
    m = re.match(r"(repite|invierte) '([a-z]+)'$", pares[2*i][3:])
    op,w = m.group(1), m.group(2)
    assert ap(op,w)==pares[2*i+1][3:], (op,w)  # dataset consistente con oraculo (target alterado => rechazo con causa)
    per.setdefault(op,[0,0]); per[op][1]+=1
    if gens[i].strip()==ap(op,w): per[op][0]+=1
tot_ok = sum(v[0] for v in per.values())
print(json.dumps({'exact_total':f'{tot_ok}/{n}','por_op':{k:f'{v[0]}/{v[1]}' for k,v in sorted(per.items())}}))
