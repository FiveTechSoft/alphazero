# Confirmatoria E7 (eval-only, corte ck_A94) - 2026-10-25

## Protocolo (predeclarado antes de la ejecucion)
- Modelo: ck_A94 (10560 pasos), solo lectura. SHA256 ANTES: 555e1fc374c9c4ea540eed59e1d1a678bc8efdb01e8939d0d688674394391e5c
- Datos: evalconf5, L4-L7, 48 pares/clase (24 por operacion), seed 20261103, exclusion total de 5811 superficies (operandos, reversos y targets de todos los conjuntos anteriores), 0 colisiones (verificado por cuenta en generacion).
- Manifiesto oraculo v5 registrado ANTES de generar ningun par; el scorer rechaza sets no registrados o con sha distinto (fixtures positivo 48/48 y negativos con causa).
- Criterios primarios fijados: L6 exact>=40 y length_correct>=40; L4>=40; L5>=40; L7 descriptivo. Sin re-eval natural. Cap 60s wall.
- Sin entrenamiento, sin ajustes por resultados, sin repeticiones.

## Resultado (2026-10-25 17:16 CET)
| clase | exact | length_correct | dup1B | invierte | repite |
|---|---|---|---|---|---|
| ec5_L4 | 46/48 | 47/48 | 0 | 22/24 | 24/24 |
| ec5_L5 | 43/48 | 45/48 | 0 | 19/24 | 24/24 |
| ec5_L6 | 46/48 | 47/48 | 0 | 22/24 | 24/24 |
| ec5_L7 | 0/48 | 8/48 | 0 | 0/24 | 0/24 |

TODOS los criterios primarios cumplidos.

## Reloj (precision subsegundo, de registros de ejecucion)
- Verificacion sha + 4 generaciones: ventana de llamada 489 ms (inicio 17:16:34 CET, exit 0).
- Scoring oraculo + clasificador + analisis EOS: 60 ms.
- Total wall < 1 s del cap de 60 s. 0 fallos tecnicos.
- SHA256 ck_A94 DESPUES: 555e1fc374c9c4ea540eed59e1d1a678bc8efdb01e8939d0d688674394391e5c (identico: checkpoint inmutable durante la evaluacion).

## Alcance
El positivo E7 no depende de los operandos concretos de los conjuntos anteriores: se sostiene con operandos frescos independientes. No es prueba de generalizacion universal, ni de habla, ni de RSI. Punto mas debil medido: invierte-L5 (19/24); repite 24/24 en todas. L7 sigue en 0: la regla aprendida no transfiere mas alla de la longitud maxima entrenada (6).
