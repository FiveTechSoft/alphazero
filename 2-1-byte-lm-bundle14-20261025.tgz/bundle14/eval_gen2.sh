#!/bin/bash
cd /tmp/blm || exit 1
echo "EVALGEN2 protocolo: EVALGEN2_PROTOCOLO.md congelado 09:31"
python3 /tmp/blm/eval_gen2.py
