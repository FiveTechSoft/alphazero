# EVAL-GEN-2 — protocolo CONGELADO antes de generar (2026-10-25 09:31 CET)

Evaluación pareada SEPARADA de EVAL-GEN-1. Objetivo: aislar el efecto del decoding
(cebadoo corregido, ruta gen2 diagnostica) sobre los MISMOS checkpoints y las MISMAS
prompts, sin entrenar nada. No es promoción; servicio/champion/main intactos.

## Fijo antes de generar
- Modelos: base=blm_gru2b.json, A=blm_gru_curA.json, B=blm_gru_curB.json (identicos a EVAL-GEN-1).
- Prompts: las MISMAS 30 de evalgen_prompts.txt (congeladas 09:16; offset 3, stride 28 de val.txt).
- Decoding: gen2 (primer byte desde estado post-prompt; sin realimentar ultimo byte).
  n=280, temp=0.3, seed=1000+n por prompt (identicos parametros que EVAL-GEN-1: solo cambia el cebado).
- Archivo completo: eval_gen2/ (90 respuestas, manifiesto sha256, muestras ciegas con
  permutacion NUEVA semilla 43, clave aparte revelada solo tras juicios fijados).
- Criterios de juicio (separados, como EVAL-GEN-1): coherencia / pertinencia / correccion
  puntual vs referencia (NO retencion longitudinal). Indicadores mecanicos = debiles declarados.
- Comparacion con EVAL-GEN-1: pareada por prompt y modelo (mismo prompt+seed; solo cambia cebado).
- Sin seleccion: se preservan las 90 salidas; juicio ciego por evaluador externo como EVAL-GEN-1.

## Regresion automatizada (detectar doble alimentacion)
- Test Go congelado: el primer byte de generateGRU2 debe muestrearse del estado tras el
  prompt completo; se verifica contra muestreo manual deterministico con la misma semilla.
  Si alguien reintroduce realimentacion, el test falla.

## Nota de comparabilidad BPB (sin reescribir resultados)
- pairLoss puntua respuesta[1:]: el PRIMER byte de respuesta nunca entra en la metrica.
  TODAS las metricas historicas (bpb_val_resp, E=700, PRE/POST de CURRICULO-1) usan la
  misma funcion -> comparables entre si, con esa cobertura declarada. No se reescribe nada.
