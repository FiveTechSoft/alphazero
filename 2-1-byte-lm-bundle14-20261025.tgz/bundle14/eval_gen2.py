#!/usr/bin/env python3
# EVAL-GEN-2: generacion pareada base/A/B, decoding corregido gen2, protocolo EVALGEN2_PROTOCOLO.md
import subprocess, hashlib, json, random, os, time
os.chdir('/tmp/blm')
t0=time.time()
prompts=[]
for ln in open('evalgen_prompts.txt'):
    n,idx,q,ref=ln.rstrip('\n').split('\t')
    prompts.append((int(n),idx,q,ref))
models=[('base','blm_gru2b.json'),('A','blm_gru_curA.json'),('B','blm_gru_curB.json')]
os.makedirs('eval_gen2',exist_ok=True)
man=[]
fallos=0
for n,idx,q,ref in prompts:
    for tag,ck in models:
        seed=1000+n
        p=subprocess.run(['timeout','-k','2','30','./mz','d1gru','-mode','gen2','-in',ck,
                          '-prompt',f'U: {q}\nA: ','-n','280','-temp','0.3','-seed',str(seed)],
                         capture_output=True,text=True,timeout=40)
        resp=p.stdout.strip()
        if p.returncode!=0: fallos+=1
        fn=f'eval_gen2/resp_{n:02d}_{tag}.txt'
        open(fn,'w').write(resp+'\n')
        man.append({'n':n,'idx_val':idx,'modelo':tag,'seed':seed,'rc':p.returncode,
                    'bytes':len(resp.encode()),'sha256':hashlib.sha256(resp.encode()).hexdigest()[:16]})
    print(f"prompt {n} idx={idx} ok ({time.time()-t0:.0f}s)",flush=True)
json.dump(man,open('eval_gen2/manifest.json','w'),indent=1)
# muestras ciegas: orden permutado por prompt (semilla fija 42), clave aparte
rng=random.Random(43)
key={}
with open('eval_gen2/muestras_ciegas2.md','w') as f:
    f.write("# EVAL-GEN-2 - muestras ciegas (decoding corregido gen2) (orden permutado por prompt, semilla fija)\n")
    f.write("Criterios a juzgar por separado: coherencia / responde-a-la-pregunta / retencion semantica vs referencia.\n\n")
    for n,idx,q,ref in prompts:
        orden=['base','A','B']; rng.shuffle(orden)
        key[n]=orden
        f.write(f"## Prompt {n} (val idx {idx})\n**P:** {q}\n\n**Referencia humana:** {ref}\n\n")
        for k,tag in enumerate(orden):
            resp=open(f'eval_gen2/resp_{n:02d}_{tag}.txt').read().strip()
            f.write(f"**Respuesta {k+1}:** {resp}\n\n")
json.dump({str(k):v for k,v in key.items()},open('eval_gen2/clave_ciega2.txt','w'))
# indicadores mecanicos DEBILES declarados: solape de palabras con referencia
def overlap(a,b):
    wa=set(a.lower().split()); wb=set(b.lower().split())
    return len(wa&wb)/max(1,len(wb))
ind=[]
for n,idx,q,ref in prompts:
    for tag,_ in models:
        resp=open(f'eval_gen2/resp_{n:02d}_{tag}.txt').read().strip()
        ind.append({'n':n,'modelo':tag,'solape_ref':round(overlap(resp,ref),4),'bytes':len(resp.encode())})
json.dump(ind,open("eval_gen2/indicadores_mecanicos.json","w"),indent=1)
agg={}
for r in ind: agg.setdefault(r['modelo'],[]).append(r['solape_ref'])
for m,v in agg.items(): print(f"INDICADOR_DEBIL solape_ref medio {m}: {sum(v)/len(v):.4f}")
print(f"FIN_EVALGEN2 generaciones={len(man)} fallos_rc={fallos} duracion={time.time()-t0:.0f}s")
