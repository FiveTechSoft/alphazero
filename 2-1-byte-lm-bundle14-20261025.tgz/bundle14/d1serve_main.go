//go:build !js && linux

// d1serve: servidor HTTP local OpenAI-compatible que expone el motor
// MathZero/AlphaZero como "modelo" para OpenCode, siguiendo el patron del
// repo FiveTechSoft/symbols. Codigo NUEVO, solo rama experimental.
//
// SOLO LINUX VERIFICADO: la supervision usa /proc, setsid y kill de grupo;
// Windows NO probado ni soportado por esta guardia (no se afirma portabilidad).
//
// Rutas deterministas (sin modelo de lenguaje en ninguna):
//  1. saludo/identidad  -> plantilla fija declarada
//  2. '<expr> -> <expr>' en notacion prefija -> WORKER SUBPROCESO por
//     solicitud: `guard.sh <t> <rss> <out> <exe> d1solve ...`. Sin globales
//     compartidos entre solicitudes (cada worker es un proceso nuevo; el SO
//     reclama todo al salir). guard.sh es la supervision ya probada en las
//     campanas A1/G1 (copia byte-identica): lidera su grupo, sondea RSS
//     agregado cada 0.1 s y mata el GRUPO por limite RSS, timeout, señal al
//     supervisor o lider que sale con descendientes; reporta residual y sale
//     99 si queda algo. Cancelacion de cliente o del servidor: TERM al grupo
//     del guard (su trap limpia el grupo del worker), KILL de reserva.
//  3. cualquier otra cosa -> abstencion fija
//
// Limites reales (OPENCODE.md): sin cancelacion dura dentro del motor; el
// freno es entrada acotada + cap + RSS supervisado + timeout + 1 worker.
package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/json"
	"flag"
	"fmt"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync/atomic"
	"syscall"
	"time"
)

func init() {
	if len(os.Args) > 1 && os.Args[1] == "d1serve" {
		if err := RunD1Serve(os.Args[2:]); err != nil {
			fmt.Fprintln(os.Stderr, "d1serve:", err)
			os.Exit(2)
		}
		os.Exit(0)
	}
}

const d1sModelID = "alphazero"

const (
	d1sMaxBody    = 256 << 10
	d1sMaxQuery   = 4096
	d1sMaxExpr    = 200 // bytes por expresion (conservador; medido: 164 MiB pico con 200B/prof16/cap500)
	d1sMaxDepth   = 16
	d1sMaxCap     = 500
	d1sQueueSlots = 4
	d1sQueueWait  = 10 * time.Second
)

const d1sIdentES = "Soy AlphaZero (MathZero), un motor de algebra local: una politica neuronal entrenada por autojuego guia una busqueda sobre reglas de reescritura de expresiones. No soy un modelo de lenguaje: no converso. Resuelvo problemas de algebra escritos como '<expresion> -> <objetivo>' en notacion prefija (operadores add/mul/neg, constantes cN, variables va-vz). Ejemplo: 'add(va,c0) -> va'."
const d1sGreetES = "Hola. No soy un modelo de lenguaje; soy el motor de algebra AlphaZero (MathZero). Dame un problema, por ejemplo: 'add(va,c0) -> va'."
const d1sIdentEN = "I am AlphaZero (MathZero), a local algebra engine: a neural policy trained by self-play guides a search over expression rewrite rules. I am not a language model: I do not chat. I solve algebra problems written as '<expression> -> <target>' in prefix notation (add/mul/neg, constants cN, variables va-vz). Example: 'add(va,c0) -> va'."
const d1sGreetEN = "Hello. I am not a language model; I am the AlphaZero (MathZero) algebra engine. Give me a problem, for example: 'add(va,c0) -> va'."
const d1sAbstain = "Eso esta fuera de mi alcance. AlphaZero (MathZero) solo resuelve problemas de algebra escritos como '<expresion> -> <objetivo>' en notacion prefija (operadores add/mul/neg, constantes cN, variables va-vz); no soy un modelo de lenguaje y no puedo conversar. / Out of scope: AlphaZero (MathZero) only solves algebra problems written as '<expression> -> <target>' in prefix notation (add/mul/neg, cN, va-vz); it is not a language model."

type d1sServer struct {
	blm      *BLM   // modulo EXPERIMENTAL de lenguaje (solo si -blm); nil = comportamiento publicado
	blmPath  string // ruta del checkpoint blm cargado
	blmLog   string // ruta al controller_log.jsonl (opcional, para /blm-status)
	gru      *GRU    // EXPERIMENTAL: byte-GRU (rama exp/byte-lm); si no nil, tiene preferencia sobre blm
	gruSteps int
	gruBPBV  float64
	model    string
	capN     int
	rssMB    int
	wtimeout int // segundos, presupuesto del worker (guard)
	guard    string
	exe      string
	worker   chan struct{} // 1 worker en paralelo
	queue    chan struct{}
	started  atomic.Int64 // workers arrancados (para pruebas)
	killed   atomic.Int64 // workers matados por supervision/cancelacion (para pruebas)

	testWorkerArgs []string // SOLO tests: sustituye el comando del worker
}

type d1sChatMsg struct {
	Role    string          `json:"role"`
	Content json.RawMessage `json:"content"`
}

type d1sChatReq struct {
	Model    string       `json:"model"`
	Messages []d1sChatMsg `json:"messages"`
	Stream   bool         `json:"stream"`
}

func d1sText(c json.RawMessage) string {
	var s string
	if json.Unmarshal(c, &s) == nil {
		return s
	}
	var parts []struct {
		Type string `json:"type"`
		Text string `json:"text"`
	}
	if json.Unmarshal(c, &parts) == nil {
		var b strings.Builder
		for _, p := range parts {
			if p.Type == "text" {
				b.WriteString(p.Text)
			}
		}
		return b.String()
	}
	return ""
}

func d1sNorm(s string) string {
	s = strings.ToLower(s)
	r := strings.NewReplacer("á", "a", "é", "e", "í", "i", "ó", "o", "ú", "u", "ü", "u", "ñ", "n")
	s = r.Replace(s)
	var b []rune
	for _, c := range s {
		if (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == ' ' {
			b = append(b, c)
		} else {
			b = append(b, ' ')
		}
	}
	return strings.Join(strings.Fields(string(b)), " ")
}

func d1sHas(norm, trigger string) bool {
	return strings.Contains(" "+norm+" ", " "+trigger+" ")
}

func d1sRoute(text string) string {
	n := d1sNorm(text)
	for _, t := range []string{"quien eres", "que eres", "who are you", "what are you", "que sabes hacer", "what can you do", "presentate"} {
		if d1sHas(n, t) {
			return "identity"
		}
	}
	for _, t := range []string{"hola", "hello", "hi", "hey", "buenos dias", "buenas tardes", "buenas noches", "buenas", "que tal", "como estas", "how are you"} {
		if d1sHas(n, t) {
			return "greeting"
		}
	}
	if strings.Contains(text, "->") {
		return "solve"
	}
	return "abstain"
}

func d1sIsEnglish(text string) bool {
	n := d1sNorm(text)
	for _, t := range []string{"hello", "hi", "hey", "who are you", "what are you", "how are you", "what can you do"} {
		if d1sHas(n, t) {
			return true
		}
	}
	return false
}

func d1sDepth(s string) int {
	d, m := 0, 0
	for _, c := range s {
		switch c {
		case '(':
			d++
			if d > m {
				m = d
			}
		case ')':
			d--
		}
	}
	return m
}

func d1sTemplate(route, text string) string {
	switch route {
	case "identity":
		if d1sIsEnglish(text) {
			return d1sIdentEN
		}
		return d1sIdentES
	case "greeting":
		if d1sIsEnglish(text) {
			return d1sGreetEN
		}
		return d1sGreetES
	}
	return d1sAbstain
}

// d1sBLMStatus devuelve el ESTADO DEL SISTEMA (controlador de ciclos),
// etiquetado explicitamente como NO generado por el modelo.
func d1sBLMStatus(sv *d1sServer) string {
	var b strings.Builder
	b.WriteString("[ESTADO DEL SISTEMA - no generado por el modelo]\n")
	fmt.Fprintf(&b, "campeon servido: %s (%d pasos, sha256 %s)\n", filepath.Base(sv.blmPath), sv.blm.Steps, fileSHA(sv.blmPath)[:12])
	if sv.blmLog != "" {
		if data, err := os.ReadFile(sv.blmLog); err == nil {
			lines := strings.Split(strings.TrimSpace(string(data)), "\n")
			if n := len(lines); n > 0 {
				fmt.Fprintf(&b, "ultima decision del controlador: %s\n", lines[n-1])
			}
		}
	}
	return b.String()
}

// d1sBLMReply genera la respuesta conversacional desde la red byte a byte
// (inferencia entrenada, temperatura 0.3, semilla FNV-1a determinista por entrada).
// El prefijo entre corchetes es metadato de divulgacion, no contenido fijado.
func d1sBLMReply(m *BLM, text string) string {
	h := uint32(2166136261)
	for i := 0; i < len(text); i++ {
		h ^= uint32(text[i])
		h *= 16777619
	}
	var gen string
	if m.K == BLMCondQ+BLMCondG {
		gen = m.generateCond("U: "+text+"\nA:", 280, 0.8, int64(h))
	} else {
		gen = m.generate("U: "+text+"\nA:", 280, 0.8, int64(h))
	}
	if m.Steps == 0 {
		return fmt.Sprintf("[AlphaZero - componente lenguaje experimental (byte-MLP), red SIN ENTRENAR, 0 pasos]\n%s", gen)
	}
	return fmt.Sprintf("[AlphaZero - componente lenguaje experimental (byte-MLP), %d pasos, inferencia entrenada]\n%s", m.Steps, gen)
}

// d1sRender convierte el informe d1solve en el mensaje visible.
func d1sRender(rep *D1SolveReport) string {
	var b strings.Builder
	if rep.Solved {
		fmt.Fprintf(&b, "Resuelto por el motor MathZero (cap %d nodos; %d pasos, %d nodos explorados):\n%s -> %s\nCamino:\n", rep.Cap, len(rep.Path), rep.Nodes, rep.Start, rep.Target)
		for _, st := range rep.Path {
			fmt.Fprintf(&b, "  %s --[%s]--> %s\n", st.From, st.Rule, st.To)
		}
		b.WriteString("(igualdad modulo la normalizacion asociativa-conmutativa del motor)")
	} else {
		fmt.Fprintf(&b, "El motor MathZero no encontro solucion dentro del presupuesto (%d nodos; explorados %d):\n%s -> %s", rep.Cap, rep.Nodes, rep.Start, rep.Target)
	}
	return b.String()
}

// d1sSolve valida, admite y ejecuta UN worker subproceso supervisado.
// Devuelve (content, errHTTP, errMsg). errHTTP == -1: cliente cancelo en cola;
// no responder.
func (sv *d1sServer) d1sSolve(r *http.Request, text string) (string, int, string) {
	parts := strings.SplitN(text, "->", 2)
	start, target := strings.TrimSpace(parts[0]), strings.TrimSpace(parts[1])
	for _, e := range []string{start, target} {
		if len(e) == 0 || len(e) > d1sMaxExpr {
			return "", 400, fmt.Sprintf("expresion vacia o demasiado larga (max %d bytes por lado)", d1sMaxExpr)
		}
		if d1sDepth(e) > d1sMaxDepth {
			return "", 400, fmt.Sprintf("expresion demasiado anidada (max %d niveles)", d1sMaxDepth)
		}
	}
	if _, errS := ParsePrefix(start); errS != nil {
		return fmt.Sprintf("No pude interpretar el problema de algebra. Uso: '<expresion> -> <objetivo>' en notacion prefija (add/mul/neg, cN, va-vz). Detalle: %v", errS), 0, ""
	}
	if _, errT := ParsePrefix(target); errT != nil {
		return fmt.Sprintf("No pude interpretar el problema de algebra. Uso: '<expresion> -> <objetivo>' en notacion prefija (add/mul/neg, cN, va-vz). Detalle: %v", errT), 0, ""
	}
	// Admision: cola explicita; un cliente que cancela en cola NO arranca worker.
	select {
	case sv.queue <- struct{}{}:
		defer func() { <-sv.queue }()
	case <-time.After(d1sQueueWait):
		return "", 503, "servidor ocupado: cola de resolucion llena; reintenta en unos segundos"
	case <-r.Context().Done():
		return "", -1, ""
	}
	select {
	case sv.worker <- struct{}{}:
		defer func() { <-sv.worker }()
	case <-r.Context().Done():
		return "", -1, ""
	}
	return sv.runWorker(r, start, target)
}

func (sv *d1sServer) runWorker(r *http.Request, start, target string) (string, int, string) {
	out, err := os.CreateTemp("", "d1solve-*.out")
	if err != nil {
		return "", 500, "no se pudo crear fichero temporal"
	}
	outPath := out.Name()
	out.Close()
	defer os.Remove(outPath)

	var args []string
	if sv.testWorkerArgs != nil {
		args = append([]string{}, sv.testWorkerArgs...)
	} else {
		args = []string{sv.exe, "d1solve", "-start", start, "-target", target, "-cap", fmt.Sprint(sv.capN)}
		if sv.model != "" {
			args = append(args, "-model", sv.model)
		}
	}
	full := append([]string{fmt.Sprint(sv.wtimeout), fmt.Sprint(sv.rssMB), outPath}, args...)
	cmd := exec.Command("bash", append([]string{sv.guard}, full...)...)
	cmd.SysProcAttr = &syscall.SysProcAttr{Setpgid: true}
	var report bytes.Buffer
	cmd.Stdout = &report
	cmd.Stderr = &report
	if err := cmd.Start(); err != nil {
		return "", 500, "no se pudo arrancar el worker: " + err.Error()
	}
	sv.started.Add(1)
	done := make(chan error, 1)
	go func() { done <- cmd.Wait() }()
	killGroup := func() {
		sv.killed.Add(1)
		pgid, err := syscall.Getpgid(cmd.Process.Pid)
		if err == nil {
			syscall.Kill(-pgid, syscall.SIGTERM) // trap del guard: limpia el grupo del worker
		}
		select {
		case <-done:
		case <-time.After(3 * time.Second):
			syscall.Kill(-pgid, syscall.SIGKILL)
			<-done
		}
	}
	select {
	case err := <-done:
		rep := report.String()
		switch {
		case strings.Contains(rep, "status=RSS_LIMIT"):
			return "", 500, fmt.Sprintf("el problema excedio el limite de memoria supervisado (%d MiB); prueba una expresion mas simple o un cap menor", sv.rssMB)
		case strings.Contains(rep, "status=TIMEOUT"):
			return "", 504, fmt.Sprintf("el motor excedio su presupuesto de tiempo (%d s); el worker fue terminado y recolectado", sv.wtimeout)
		case strings.Contains(rep, "status=SAMPLER_FAILED"):
			return "", 500, "la supervision de recursos fallo; solicitud abortada por precaucion"
		case strings.Contains(rep, "residual_procs=0") == false:
			return "", 500, "la supervision detecto procesos residuales; solicitud abortada"
		}
		if exit, ok := err.(*exec.ExitError); ok && exit.ExitCode() != 0 {
			b, _ := os.ReadFile(outPath)
			msg := strings.TrimSpace(string(b))
			if msg == "" {
				msg = fmt.Sprintf("worker termino con codigo %d", exit.ExitCode())
			}
			if len(msg) > 400 {
				msg = msg[:400]
			}
			return fmt.Sprintf("No pude interpretar/ejecutar el problema. Detalle: %s", msg), 0, ""
		}
		b, rerr := os.ReadFile(outPath)
		if rerr != nil {
			return "", 500, "no se pudo leer la salida del worker"
		}
		var d1rep D1SolveReport
		if jerr := json.Unmarshal(b, &d1rep); jerr != nil {
			return "", 500, "salida del worker no interpretable"
		}
		return d1sRender(&d1rep), 0, ""
	case <-r.Context().Done():
		killGroup()
		return "", -1, ""
	case <-time.After(time.Duration(sv.wtimeout+15) * time.Second):
		// Red de seguridad por encima del timeout propio del guard.
		killGroup()
		return "", 504, "el worker excedio la supervision externa; terminado"
	}
}

func d1sJSONEscape(s string) string {
	b, _ := json.Marshal(s)
	return string(b)
}

func d1sError(w http.ResponseWriter, code int, msg string) {
	if code == 503 {
		w.Header().Set("Retry-After", "5")
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	fmt.Fprintf(w, `{"error":{"message":%s,"type":"invalid_request_error","code":null}}`, d1sJSONEscape(msg))
}

func d1sRespond(w http.ResponseWriter, stream bool, content string) {
	id := fmt.Sprintf("chatcmpl-%d", time.Now().UnixNano())
	created := time.Now().Unix()
	if stream {
		chunk1 := fmt.Sprintf(`{"id":%q,"object":"chat.completion.chunk","created":%d,"model":%q,"choices":[{"index":0,"delta":{"role":"assistant","content":%s},"finish_reason":null}]}`, id, created, d1sModelID, d1sJSONEscape(content))
		chunk2 := fmt.Sprintf(`{"id":%q,"object":"chat.completion.chunk","created":%d,"model":%q,"choices":[{"index":0,"delta":{},"finish_reason":"stop"}]}`, id, created, d1sModelID)
		w.Header().Set("Content-Type", "text/event-stream")
		fmt.Fprintf(w, "data: %s\n\ndata: %s\n\ndata: [DONE]\n\n", chunk1, chunk2)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	fmt.Fprintf(w, `{"id":%q,"object":"chat.completion","created":%d,"model":%q,"choices":[{"index":0,"message":{"role":"assistant","content":%s},"finish_reason":"stop"}],"usage":{"prompt_tokens":0,"completion_tokens":0,"total_tokens":0}}`, id, created, d1sModelID, d1sJSONEscape(content))
}

func (sv *d1sServer) handleCompletions(w http.ResponseWriter, r *http.Request) {
	r.Body = http.MaxBytesReader(w, r.Body, d1sMaxBody)
	var req d1sChatReq
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		if strings.Contains(err.Error(), "http: request body too large") {
			d1sError(w, 413, fmt.Sprintf("cuerpo demasiado grande (max %d bytes)", d1sMaxBody))
		} else {
			d1sError(w, 400, "peticion JSON invalida")
		}
		return
	}
	var text string
	for i := len(req.Messages) - 1; i >= 0; i-- {
		if req.Messages[i].Role == "user" {
			text = d1sText(req.Messages[i].Content)
			break
		}
	}
	text = strings.TrimSpace(text)
	if len(text) >= 2 && text[0] == '"' && text[len(text)-1] == '"' {
		text = strings.TrimSpace(text[1 : len(text)-1]) // OpenCode entrecomilla el mensaje (observado 2026-10-25)
	}
	if len(text) > d1sMaxQuery {
		d1sError(w, 400, fmt.Sprintf("mensaje demasiado largo (max %d bytes)", d1sMaxQuery))
		return
	}
	if text == "" {
		d1sError(w, 400, "sin mensaje de usuario")
		return
	}
	if text == "/blm-status" && sv.blm != nil {
		d1sRespond(w, req.Stream, d1sBLMStatus(sv))
		return
	}
	// Comandos locales de aprendizaje (NO salida del modelo): lanzan/observan
	// entrenamiento ACOTADO bajo guard.sh desacoplado (setsid): la guardia
	// sobrevive a la sesion que lo lanzo y registra estado en <log>.status.
	ttext := strings.TrimSpace(text)
	if sv.gru != nil && (ttext == "/blm-curriculum" || ttext == "/blm-curriculum-result" || ttext == "/blm-eval-gen" || ttext == "/blm-eval-status" || ttext == "/blm-eval-muestra" || ttext == "/blm-overfit10" || ttext == "/blm-overfit10-status" || ttext == "/blm-eval-gen2" || ttext == "/blm-eval2-status" || ttext == "/blm-train-status" || ttext == "/blm-checkpoints" || ttext == "/blm-train-stop" || len(ttext) >= 10 && ttext[:10] == "/blm-train") {
		d1sRespond(w, req.Stream, d1sGRUTrainCmd(ttext))
		return
	}
	route := d1sRoute(text)
	if route != "solve" {
		if sv.gru != nil {
			d1sRespond(w, req.Stream, d1sGRUReply(sv, text))
			return
		}
		if sv.blm != nil {
			// Rama experimental exp/byte-lm: la conversacion sale de INFERENCIA
			// entrenada (byte a byte), nunca de plantillas ni respuestas fijas.
			d1sRespond(w, req.Stream, d1sBLMReply(sv.blm, text))
			return
		}
		d1sRespond(w, req.Stream, d1sTemplate(route, text))
		return
	}
	content, errHTTP, errMsg := sv.d1sSolve(r, text)
	if errHTTP == -1 {
		return // cliente cancelado; nada que responder
	}
	if errHTTP != 0 {
		d1sError(w, errHTTP, errMsg)
		return
	}
	d1sRespond(w, req.Stream, content)
}

func (sv *d1sServer) handleModels(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	fmt.Fprintf(w, `{"object":"list","data":[{"id":%q,"object":"model","created":0,"owned_by":"alphazero"}]}`, d1sModelID)
}

// d1sGRUReply: respuesta del byte-GRU experimental. El estado se ceba con
// todos los bytes del prompt (sin ventana que expulse la pregunta).
func d1sGRUReply(sv *d1sServer, text string) string {
	h := uint32(2166136261)
	for i := 0; i < len(text); i++ {
		h ^= uint32(text[i])
		h *= 16777619
	}
	gen := sv.gru.generateGRU("U: "+text+"\nA: ", 280, 0.3, int64(h)) // formato ALINEADO con train-pairs ("A: " con espacio)
	return fmt.Sprintf("[AlphaZero - componente lenguaje experimental (byte-GRU), %d pasos, inferencia entrenada]\n%s", sv.gruSteps, gen)
}

func RunD1Serve(args []string) error {
	fs := flag.NewFlagSet("d1serve", flag.ContinueOnError)
	port := fs.Int("port", 8100, "puerto local")
	model := fs.String("model", "", "model json (politica entrenada); vacio = MLP nuevo semilla 1")
	capN := fs.Int("cap", 200, "presupuesto de nodos por problema (max 500)")
	rssMB := fs.Int("rssmb", 384, "limite RSS supervisado por worker en MiB (medido: 25 MiB tipico, 164 MiB peor caso admitido)")
	wtimeout := fs.Int("wtimeout", 20, "presupuesto de tiempo del worker en segundos")
	guard := fs.String("guard", "guard.sh", "ruta a guard.sh (copia byte-identica de la supervision probada en campanas A1/G1)")
	blmPath := fs.String("blm", "", "EXPERIMENTAL: modelo de lenguaje byte a byte (rama exp/byte-lm); vacio = comportamiento publicado")
	blmAuto := fs.String("blmauto", "", "EXPERIMENTAL: champion.json del controlador; el servidor carga el modelo que el controlador conserva (decision efectiva)")
	blmLog := fs.String("blmlog", "", "EXPERIMENTAL: controller_log.jsonl para /blm-status (opcional)")
	gruPath := fs.String("blmgru", "", "EXPERIMENTAL: checkpoint byte-GRU; la conversacion sale de su inferencia entrenada")
	blmDir := fs.String("blmdir", "/tmp/blm", "EXPERIMENTAL: directorio de trabajo BLM (corpus, checkpoints, guardia); configurable para portabilidad")
	if err := fs.Parse(args); err != nil {
		return err
	}
	d1sBLMDir = *blmDir
	if *capN <= 0 {
		return fmt.Errorf("cap debe ser positivo")
	}
	if *capN > d1sMaxCap {
		fmt.Fprintf(os.Stderr, "d1serve: cap %d reducido al maximo %d\n", *capN, d1sMaxCap)
		*capN = d1sMaxCap
	}
	exe, err := os.Executable()
	if err != nil {
		return err
	}
	if !filepath.IsAbs(*guard) {
		*guard = filepath.Join(filepath.Dir(exe), *guard)
	}
	for _, f := range []string{*guard, exe} {
		if _, err := os.Stat(f); err != nil {
			return fmt.Errorf("no existe %s: %v", f, err)
		}
	}
	if *model != "" {
		if _, err := os.Stat(*model); err != nil {
			return fmt.Errorf("model: %v", err)
		}
		fmt.Fprintf(os.Stderr, "d1serve: politica %s (sha256 %s)\n", *model, fileSHA(*model))
	} else {
		fmt.Fprintln(os.Stderr, "d1serve: AVISO sin -model, workers con MLP nuevo semilla 1 (sin entrenar)")
	}
	var blmNet *BLM
	if *blmAuto != "" {
		// El controlador (controller.py) escribe champion.json con la ruta del
		// modelo conservado; el servidor sirve ESE, asi la decision
		// conservar/rollback es efectiva en OpenCode, no solo un registro.
		data, err := os.ReadFile(*blmAuto)
		if err != nil {
			return fmt.Errorf("blmauto: %v", err)
		}
		var reg struct {
			Path string `json:"path"`
		}
		if err := json.Unmarshal(data, &reg); err != nil || reg.Path == "" {
			return fmt.Errorf("blmauto: champion.json invalido")
		}
		if !filepath.IsAbs(reg.Path) {
			// portable: relativo al directorio del champion.json, sin rutas privadas
			reg.Path = filepath.Join(filepath.Dir(*blmAuto), reg.Path)
		}
		*blmPath = reg.Path
		fmt.Fprintf(os.Stderr, "d1serve: EXPERIMENTAL blmauto campeon=%s (decision del controlador)\n", reg.Path)
	}
	if *blmPath != "" {
		if _, err := os.Stat(*blmPath); err != nil {
			return fmt.Errorf("blm: %v", err)
		}
		blmNet = LoadBLM(*blmPath)
		fmt.Fprintf(os.Stderr, "d1serve: EXPERIMENTAL blm %s (sha256 %s, %d pasos)\n", *blmPath, fileSHA(*blmPath), blmNet.Steps)
	}
	sv := &d1sServer{
		blm: blmNet, blmPath: *blmPath, blmLog: *blmLog,
		model: *model, capN: *capN, rssMB: *rssMB, wtimeout: *wtimeout,
		guard: *guard, exe: exe,
		worker: make(chan struct{}, 1), queue: make(chan struct{}, d1sQueueSlots),
	}
	mux := http.NewServeMux()
	mux.HandleFunc("/v1/models", sv.handleModels)
	mux.HandleFunc("/v1/chat/completions", sv.handleCompletions)
	addr := fmt.Sprintf("127.0.0.1:%d", *port)
	srv := &http.Server{
		Addr:              addr,
		Handler:           mux,
		ReadHeaderTimeout: 5 * time.Second,
		ReadTimeout:       15 * time.Second,
		WriteTimeout:      90 * time.Second,
		IdleTimeout:       30 * time.Second,
		MaxHeaderBytes:    16 << 10,
	}
	if *gruPath != "" {
		g2, st, bpbv, err := LoadGRU(*gruPath)
		if err != nil {
			return fmt.Errorf("blmgru: %v", err)
		}
		sv.gru = g2
		sv.gruSteps = st
		sv.gruBPBV = bpbv
		rawg, _ := os.ReadFile(*gruPath)
		sumg := sha256.Sum256(rawg)
		fmt.Fprintf(os.Stderr, "d1serve: EXPERIMENTAL blmgru %s (%d pasos, bpb_val=%.4f, sha256 %x)\n", *gruPath, st, bpbv, sumg[:16])
	}
	fmt.Fprintf(os.Stderr, "d1serve: escuchando en http://%s/v1 (modelo %q, cap %d, rss %d MiB, worker %d s)\n", addr, d1sModelID, *capN, *rssMB, *wtimeout)
	return srv.ListenAndServe()
}

// d1sBLMDir: directorio de trabajo BLM configurable (-blmdir); por defecto
// /tmp/blm. Toda ruta del comando de entrenamiento deriva de el (allowlist
// relativa a este directorio, nunca args arbitrarios del cliente).
var d1sBLMDir = "/tmp/blm"

func d1sBLMPath(name string) string { return filepath.Join(d1sBLMDir, name) }


// d1sSanitizeGen: conserva UTF-8 valido; escapa bytes invalidos como \xNN de forma
// explicita (distingue propiedad del modelo byte-level de fallo de visualizacion).
func d1sSanitizeGen(b []byte) (string, bool) {
	var sb strings.Builder
	esc := false
	for i := 0; i < len(b); {
		if b[i] < 0x80 {
			if b[i] == 10 {
				sb.WriteByte(' ')
			} else if b[i] >= 32 && b[i] < 127 {
				sb.WriteByte(b[i])
			} else {
				sb.WriteString(fmt.Sprintf("\\x%02X", b[i]))
				esc = true
			}
			i++
			continue
		}
		ln := 0
		switch {
		case b[i]&0xE0 == 0xC0:
			ln = 2
		case b[i]&0xF0 == 0xE0:
			ln = 3
		case b[i]&0xF8 == 0xF0:
			ln = 4
		}
		if ln > 0 && i+ln <= len(b) {
			ok := true
			for j := 1; j < ln; j++ {
				if b[i+j]&0xC0 != 0x80 {
					ok = false
					break
				}
			}
			if ok {
				sb.Write(b[i : i+ln])
				i += ln
				continue
			}
		}
		sb.WriteString(fmt.Sprintf("\\x%02X", b[i]))
		esc = true
		i++
	}
	return sb.String(), esc
}

// d1sGRUTrainCmd: comandos locales /blm-train [pasos], /blm-train-status,
// /blm-checkpoints. NO es inferencia del modelo: son operaciones del banco de
// pruebas iniciadas y observadas desde la TUI. El entrenamiento se lanza
// DESACOPLADO (setsid + guard.sh): guardia viva con cota 420s/RSS 900MiB,
// estado durable en /tmp/blm/tui_train.log.status.
func d1sGRUTrainCmd(text string) string {
	const logf = "tui_train.log"
	if text == "/blm-curriculum" {
		// UN ensayo CURRICULO-1 congelado (protocolo en /tmp/blm/CURRICULO1_PROTOCOLO.md):
		// curriculum adaptativo SUPERVISADO (no RSI): errores = pares train de mayor
		// perdida; correccion = respuesta humana del mismo par; control uniforme a
		// igual computo; decision automatica ajuste+retencion separadas.
		// Mismo patron de admision: dedupe estable + lock O_EXCL + guardia viva.
		key := "curriculum1"
		type servedRec struct {
			Key string `json:"key"`
			Ts  int64  `json:"ts"`
		}
		servedF := d1sBLMPath("tui_curriculo_served.json")
		if b, err := os.ReadFile(servedF); err == nil {
			var rec servedRec
			if json.Unmarshal(b, &rec) == nil && rec.Key == key && time.Now().Unix()-rec.Ts < 600 {
				return "[comando local] el ensayo de curriculum ya se sirvio hace <10min; duplicado estable ignorado. /blm-train-status para verlo"
			}
		}
		lf, err := os.OpenFile(d1sBLMPath("tui_curriculo.lock"), os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0644)
		if err != nil {
			return "[comando local] ya hay un ensayo de curriculum admitido (lock); /blm-train-status"
		}
		lf.WriteString(fmt.Sprintf("pid_lanzador=%d\n", os.Getpid()))
		lf.Close()
		if exec.Command("pgrep", "-f", "tui_curriculo.log").Run() == nil {
			os.Remove(d1sBLMPath("tui_curriculo.lock"))
			return "[comando local] ya hay un ensayo de curriculum en curso; /blm-train-status"
		}
		os.Remove(d1sBLMPath("tui_curriculo.log"))
		os.Remove(d1sBLMPath("tui_curriculo.log.status"))
		cmd := exec.Command("setsid", "bash", d1sBLMPath("guard2.sh"), "420", "900", d1sBLMPath("tui_curriculo.log"), d1sBLMPath("curriculo.sh"))
		cmd.Dir = d1sBLMDir
		if err := cmd.Start(); err != nil {
			os.Remove(d1sBLMPath("tui_curriculo.lock"))
			return "[comando local] ERROR al lanzar curriculum: " + err.Error()
		}
		if b, err := json.Marshal(servedRec{Key: key, Ts: time.Now().Unix()}); err == nil {
			os.WriteFile(servedF, b, 0644)
		}
		go func() { cmd.Wait(); os.Remove(d1sBLMPath("tui_curriculo.lock")) }()
		return "[comando local, no es salida del modelo] ensayo CURRICULO-1 lanzado (1 ensayo congelado, presupuesto <=420s, guardia desacoplada, sidecar tui_curriculo.log.status). Observa con /blm-train-status"
	}
	if text == "/blm-curriculum-result" {
		// Medidas REALES almacenadas del ensayo (del log, sin recomputar).
		b, err := os.ReadFile(d1sBLMPath("tui_curriculo.log"))
		if err != nil {
			return "[comando local, no es salida del modelo] sin resultado de curriculum almacenado"
		}
		var keep []string
		for _, ln := range strings.Split(string(b), "\n") {
			if strings.HasPrefix(ln, "PRE ") || strings.HasPrefix(ln, "POST_") || strings.HasPrefix(ln, "DELTAS") || strings.HasPrefix(ln, "DECISION") || strings.HasPrefix(ln, "wall") {
				keep = append(keep, ln)
			}
		}
		if len(keep) == 0 {
			return "[comando local, no es salida del modelo] ensayo sin lineas de resultado aun; /blm-train-status"
		}
		out := "[comando local, no es salida del modelo] RESULTADO almacenado CURRICULO-1 V2 (medidas del log, sin recomputar):\n" + strings.Join(keep, "\n")
		out += "\n[estado del servicio] d1serve sirve blm_gru2b (base); promoted = copia diagnostica de curA, NO adoptada por el servicio; champion MLP c3 intacto"
		return out
	}
	if text == "/blm-eval-gen" {
		// EVAL-GEN-1: evaluacion de GENERACION pareada base/A/B (protocolo congelado
		// /tmp/blm/EVALGEN1_PROTOCOLO.md). NO es entrenamiento. Mismo patron de
		// admision: dedupe estable + lock O_EXCL + guardia desacoplada.
		key := "evalgen1"
		type servedRecE struct {
			Key string `json:"key"`
			Ts  int64  `json:"ts"`
		}
		servedFE := d1sBLMPath("tui_evalgen_served.json")
		if b, err := os.ReadFile(servedFE); err == nil {
			var rec servedRecE
			if json.Unmarshal(b, &rec) == nil && rec.Key == key && time.Now().Unix()-rec.Ts < 600 {
				return "[comando local] la evaluacion EVAL-GEN-1 ya se sirvio hace <10min; duplicado estable ignorado. /blm-eval-status para verla"
			}
		}
		lfe, err := os.OpenFile(d1sBLMPath("tui_evalgen.lock"), os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0644)
		if err != nil {
			return "[comando local] ya hay una evaluacion admitida (lock); /blm-eval-status"
		}
		lfe.WriteString(fmt.Sprintf("pid_lanzador=%d\n", os.Getpid()))
		lfe.Close()
		if exec.Command("pgrep", "-f", "tui_evalgen.log").Run() == nil {
			os.Remove(d1sBLMPath("tui_evalgen.lock"))
			return "[comando local] ya hay una evaluacion en curso; /blm-eval-status"
		}
		os.Remove(d1sBLMPath("tui_evalgen.log"))
		os.Remove(d1sBLMPath("tui_evalgen.log.status"))
		cmde := exec.Command("setsid", "bash", d1sBLMPath("guard2.sh"), "420", "900", d1sBLMPath("tui_evalgen.log"), d1sBLMPath("eval_gen.sh"))
		cmde.Dir = d1sBLMDir
		if err := cmde.Start(); err != nil {
			os.Remove(d1sBLMPath("tui_evalgen.lock"))
			return "[comando local] ERROR al lanzar eval-gen: " + err.Error()
		}
		if b, err := json.Marshal(servedRecE{Key: key, Ts: time.Now().Unix()}); err == nil {
			os.WriteFile(servedFE, b, 0644)
		}
		go func() { cmde.Wait(); os.Remove(d1sBLMPath("tui_evalgen.lock")) }()
		return "[comando local, no es salida del modelo] evaluacion EVAL-GEN-1 lanzada (protocolo congelado EVALGEN1_PROTOCOLO.md; 30 prompts val x base/A/B, decoding identico, pareado por semilla; NO es entrenamiento). Observa con /blm-eval-status"
	}
	if text == "/blm-eval-status" {
		st, err1 := os.ReadFile(d1sBLMPath("tui_evalgen.log.status"))
		lg, err2 := os.ReadFile(d1sBLMPath("tui_evalgen.log"))
		ult := ""
		if err2 == nil {
			ls := strings.Split(strings.TrimSpace(string(lg)), "\n")
			if len(ls) > 0 {
				ult = ls[len(ls)-1]
			}
		}
		running := exec.Command("pgrep", "-f", "tui_evalgen.log").Run() == nil
		out := "[comando local, no es salida del modelo]\n[eval-gen] "
		if running {
			out += "EN CURSO. ultimo progreso: " + ult
		} else if err1 == nil {
			out += "TERMINADO. " + strings.TrimSpace(string(st))
			if ult != "" {
				out += " | ultima linea: " + ult
			}
		} else {
			out += "sin evaluacion lanzada desde TUI"
		}
		if fs2, _ := filepath.Glob(d1sBLMPath("eval_gen/resp_*.txt")); len(fs2) > 0 {
			out += fmt.Sprintf(" | respuestas archivadas: %d/90", len(fs2))
		}
		return out
	}
	if text == "/blm-eval-gen2" {
		// EVAL-GEN-2: pareada con decoding corregido (gen2), mismos checkpoints y
		// prompts congelados que EVAL-GEN-1. Protocolo /tmp/blm/EVALGEN2_PROTOCOLO.md.
		key := "evalgen2"
		type servedRec2 struct {
			Key string `json:"key"`
			Ts  int64  `json:"ts"`
		}
		servedF2 := d1sBLMPath("tui_evalgen2_served.json")
		if b, err := os.ReadFile(servedF2); err == nil {
			var rec servedRec2
			if json.Unmarshal(b, &rec) == nil && rec.Key == key && time.Now().Unix()-rec.Ts < 600 {
				return "[comando local] EVAL-GEN-2 ya se sirvio hace <10min; duplicado estable ignorado. /blm-eval2-status"
			}
		}
		lf2, err := os.OpenFile(d1sBLMPath("tui_evalgen2.lock"), os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0644)
		if err != nil {
			return "[comando local] ya hay una evaluacion 2 admitida (lock); /blm-eval2-status"
		}
		lf2.WriteString(fmt.Sprintf("pid_lanzador=%d\n", os.Getpid()))
		lf2.Close()
		if exec.Command("pgrep", "-f", "tui_evalgen2.log").Run() == nil {
			os.Remove(d1sBLMPath("tui_evalgen2.lock"))
			return "[comando local] ya hay una evaluacion 2 en curso; /blm-eval2-status"
		}
		os.Remove(d1sBLMPath("tui_evalgen2.log"))
		os.Remove(d1sBLMPath("tui_evalgen2.log.status"))
		cmd2 := exec.Command("setsid", "bash", d1sBLMPath("guard2.sh"), "420", "900", d1sBLMPath("tui_evalgen2.log"), d1sBLMPath("eval_gen2.sh"))
		cmd2.Dir = d1sBLMDir
		if err := cmd2.Start(); err != nil {
			os.Remove(d1sBLMPath("tui_evalgen2.lock"))
			return "[comando local] ERROR al lanzar eval-gen2: " + err.Error()
		}
		if b, err := json.Marshal(servedRec2{Key: key, Ts: time.Now().Unix()}); err == nil {
			os.WriteFile(servedF2, b, 0644)
		}
		go func() { cmd2.Wait(); os.Remove(d1sBLMPath("tui_evalgen2.lock")) }()
		return "[comando local, no es salida del modelo] evaluacion EVAL-GEN-2 lanzada (protocolo congelado EVALGEN2_PROTOCOLO.md; mismos checkpoints/prompts que EVAL-GEN-1, decoding gen2 corregido; NO es entrenamiento). Observa con /blm-eval2-status"
	}
	if text == "/blm-eval2-status" {
		st, err1 := os.ReadFile(d1sBLMPath("tui_evalgen2.log.status"))
		lg, err2 := os.ReadFile(d1sBLMPath("tui_evalgen2.log"))
		ult := ""
		if err2 == nil {
			ls := strings.Split(strings.TrimSpace(string(lg)), "\n")
			if len(ls) > 0 {
				ult = ls[len(ls)-1]
			}
		}
		running := exec.Command("pgrep", "-f", "tui_evalgen2.log").Run() == nil
		out := "[comando local, no es salida del modelo]\n[eval-gen2] "
		if running {
			out += "EN CURSO. ultimo progreso: " + ult
		} else if err1 == nil {
			out += "TERMINADO. " + strings.TrimSpace(string(st))
			if ult != "" {
				out += " | ultima linea: " + ult
			}
		} else {
			out += "sin evaluacion 2 lanzada desde TUI"
		}
		if fs3, _ := filepath.Glob(d1sBLMPath("eval_gen2/resp_*.txt")); len(fs3) > 0 {
			out += fmt.Sprintf(" | respuestas archivadas: %d/90", len(fs3))
		}
		return out
	}
	if text == "/blm-overfit10" {
		// SOBREAJUSTE-10: control discriminativo pequeno (protocolo congelado
		// /tmp/blm/SOBREAJUSTE10_PROTOCOLO.md). Entrena UN modelo diagnostico nuevo
		// (3000 pasos ~21s medidos), artefacto separado, nunca promocion.
		key := "overfit10"
		type servedRecO struct {
			Key string `json:"key"`
			Ts  int64  `json:"ts"`
		}
		servedFO := d1sBLMPath("tui_overfit10_served.json")
		if b, err := os.ReadFile(servedFO); err == nil {
			var rec servedRecO
			if json.Unmarshal(b, &rec) == nil && rec.Key == key && time.Now().Unix()-rec.Ts < 600 {
				return "[comando local] el control SOBREAJUSTE-10 ya se sirvio hace <10min; duplicado estable ignorado. /blm-overfit10-status"
			}
		}
		lfo, err := os.OpenFile(d1sBLMPath("tui_overfit10.lock"), os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0644)
		if err != nil {
			return "[comando local] ya hay un control admitido (lock); /blm-overfit10-status"
		}
		lfo.WriteString(fmt.Sprintf("pid_lanzador=%d\n", os.Getpid()))
		lfo.Close()
		if exec.Command("pgrep", "-f", "tui_overfit10.log").Run() == nil {
			os.Remove(d1sBLMPath("tui_overfit10.lock"))
			return "[comando local] ya hay un control en curso; /blm-overfit10-status"
		}
		os.Remove(d1sBLMPath("tui_overfit10.log"))
		os.Remove(d1sBLMPath("tui_overfit10.log.status"))
		cmdo := exec.Command("setsid", "bash", d1sBLMPath("guard2.sh"), "420", "900", d1sBLMPath("tui_overfit10.log"), d1sBLMPath("overfit10.sh"))
		cmdo.Dir = d1sBLMDir
		if err := cmdo.Start(); err != nil {
			os.Remove(d1sBLMPath("tui_overfit10.lock"))
			return "[comando local] ERROR al lanzar overfit10: " + err.Error()
		}
		if b, err := json.Marshal(servedRecO{Key: key, Ts: time.Now().Unix()}); err == nil {
			os.WriteFile(servedFO, b, 0644)
		}
		go func() { cmdo.Wait(); os.Remove(d1sBLMPath("tui_overfit10.lock")) }()
		return "[comando local, no es salida del modelo] control SOBREAJUSTE-10 lanzado (protocolo congelado; 10 pares, 3000 pasos ~21s medidos; artefacto diagnostico, nunca promocion). Observa con /blm-overfit10-status"
	}
	if text == "/blm-overfit10-status" {
		st, err1 := os.ReadFile(d1sBLMPath("tui_overfit10.log.status"))
		lg, err2 := os.ReadFile(d1sBLMPath("tui_overfit10.log"))
		running := exec.Command("pgrep", "-f", "tui_overfit10.log").Run() == nil
		out := "[comando local, no es salida del modelo]\n[overfit10] "
		if running {
			ult := ""
			if err2 == nil {
				ls := strings.Split(strings.TrimSpace(string(lg)), "\n")
				if len(ls) > 0 {
					ult = ls[len(ls)-1]
				}
			}
			return out + "EN CURSO. ultimo progreso: " + ult
		}
		if err1 != nil {
			return out + "sin control lanzado desde TUI"
		}
		out += "TERMINADO. " + strings.TrimSpace(string(st)) + "\n"
		if err2 == nil {
			escAny := false
			for _, ln := range strings.Split(strings.TrimSpace(string(lg)), "\n") {
				if strings.HasPrefix(ln, "GEN ") || strings.HasPrefix(ln, "REF ") {
					s, esc := d1sSanitizeGen([]byte(ln))
					if esc {
						escAny = true
					}
					out += s + "\n"
				} else if strings.HasPrefix(ln, "C1") || strings.HasPrefix(ln, "C2") || strings.HasPrefix(ln, "LECTURA") || strings.HasPrefix(ln, "FIN_SOBREAJUSTE10") {
					out += ln + "\n"
				}
			}
			if escAny {
				out += "[nota] bytes UTF-8 invalidos del modelo escapados explicitamente como \\xNN (propiedad del modelo byte-level, no del terminal)\n"
			}
		}
		return out
	}
	if text == "/blm-eval-muestra" {
		// Ejemplo PREDEFINIDO (prompt 0 del conjunto congelado): respuestas ARCHIVADAS
		// base/A/B, leidas de eval_gen/ SIN regenerar. Negativo honesto, no seleccion.
		q := ""
		if b, err := os.ReadFile(d1sBLMPath("evalgen_prompts.txt")); err == nil {
			ls := strings.Split(strings.TrimSpace(string(b)), "\n")
			if len(ls) > 0 {
				if c := strings.Split(ls[0], "\t"); len(c) >= 3 {
					q = c[2]
				}
			}
		}
		out := "[comando local, no es salida del modelo] ejemplo predefinido EVAL-GEN-1 (prompt 0 congelado; respuestas archivadas, sin regenerar)\nP: " + q
		for _, tag := range []string{"base", "A", "B"} {
			b, err := os.ReadFile(d1sBLMPath("eval_gen/resp_00_" + tag + ".txt"))
			if err != nil {
				out += "\n[" + tag + "] (archivo no encontrado)"
				continue
			}
			out += "\n[" + tag + "] " + strings.TrimSpace(string(b))
		}
		return out
	}
	if text == "/blm-train-status" {
		st, err1 := os.ReadFile(d1sBLMPath(logf + ".status"))
		lg, err2 := os.ReadFile(d1sBLMPath(logf))
		ult := ""
		if err2 == nil {
			ls := strings.Split(strings.TrimSpace(string(lg)), "\n")
			if len(ls) > 0 {
				ult = ls[len(ls)-1]
			}
		}
		running := exec.Command("pgrep", "-f", "tui_train.log").Run() == nil
		out := "[comando local, no es salida del modelo]\n"
		if running {
			out += "entrenamiento EN CURSO. ultimo progreso: " + ult
		} else if err1 == nil {
			out += "entrenamiento TERMINADO. " + strings.TrimSpace(string(st))
		} else {
			out += "sin entrenamiento lanzado desde TUI"
		}
		cst, cerr1 := os.ReadFile(d1sBLMPath("tui_curriculo.log.status"))
		clg, cerr2 := os.ReadFile(d1sBLMPath("tui_curriculo.log"))
		crunning := exec.Command("pgrep", "-f", "tui_curriculo.log").Run() == nil
		cult := ""
		if cerr2 == nil {
			ls := strings.Split(strings.TrimSpace(string(clg)), "\n")
			if len(ls) > 0 {
				cult = ls[len(ls)-1]
			}
		}
		out += "\n[curriculum] "
		if crunning {
			out += "EN CURSO. ultimo progreso: " + cult
		} else if cerr1 == nil {
			out += "TERMINADO. " + strings.TrimSpace(string(cst))
			if cult != "" {
				out += " | ultima linea: " + cult
			}
		} else {
			out += "sin ensayo lanzado desde TUI"
		}
		return out
	}
	if text == "/blm-checkpoints" {
		fs, _ := filepath.Glob(d1sBLMPath("blm_gru_*.json"))
		out := "[comando local, no es salida del modelo] checkpoints GRU:\n"
		for _, f := range fs {
			var d struct {
				H     int `json:"h"`
				Steps int `json:"steps"`
			}
			if b, err := os.ReadFile(f); err == nil && json.Unmarshal(b, &d) == nil {
				out += fmt.Sprintf("%s H=%d pasos=%d\n", filepath.Base(f), d.H, d.Steps)
			}
		}
		return out
	}
	// /blm-train [pasos]
	pasos := 500
	if len(text) > 10 {
		fmt.Sscanf(strings.TrimSpace(text[10:]), "%d", &pasos)
	}
	if pasos < 1 {
		pasos = 1
	}
	if pasos > 2000 {
		pasos = 2000 // cota dura del comando TUI
	}
	if text == "/blm-train-stop" {
		// Parada segura: senal al GRUPO de la guardia; ella mata al worker y
		// registra el estado en el sidecar (cleanup verificable).
		err := exec.Command("pkill", "-TERM", "-f", "tui_train.log").Run()
		os.Remove(d1sBLMPath("tui_train.lock"))
		if err != nil {
			return "[comando local] no habia entrenamiento TUI en curso"
		}
		return "[comando local] parada solicitada: la guardia mata el grupo y escribe " + d1sBLMPath(logf) + ".status"
	}
	// Dedupe estable anti-replay: el MISMO texto exacto de comando ya servido en
	// los ultimos 10 min NO relanza (retry tardio del cliente, titulo automatico
	// u otra peticion auxiliar con texto incidental identico). Persistente en
	// disco; un lanzamiento nuevo exige texto distinto (p.ej. otros pasos).
	key := fmt.Sprintf("train %d", pasos)
	type servedRec struct {
		Key string `json:"key"`
		Ts  int64  `json:"ts"`
	}
	servedF := d1sBLMPath("tui_train_served.json")
	if b, err := os.ReadFile(servedF); err == nil {
		var rec servedRec
		if json.Unmarshal(b, &rec) == nil && rec.Key == key && time.Now().Unix()-rec.Ts < 600 {
			return "[comando local] ese lanzamiento exacto ya se sirvio hace <10min; duplicado estable ignorado. /blm-train-status para verlo"
		}
	}
	// Admision atomica de UN solo worker: lockfile O_EXCL (sin carrera pgrep).
	lf, err := os.OpenFile(d1sBLMPath("tui_train.lock"), os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0644)
	if err != nil {
		return "[comando local] ya hay un entrenamiento TUI admitido (lock); /blm-train-status o /blm-train-stop"
	}
	lf.WriteString(fmt.Sprintf("pid_lanzador=%d\n", os.Getpid()))
	lf.Close()
	if exec.Command("pgrep", "-f", "tui_train.log").Run() == nil {
		os.Remove(d1sBLMPath("tui_train.lock"))
		return "[comando local] ya hay un entrenamiento TUI en curso; /blm-train-status para verlo"
	}
	os.Remove(d1sBLMPath(logf))
	os.Remove(d1sBLMPath(logf) + ".status")
	cmd := exec.Command("setsid", "bash", d1sBLMPath("guard.sh"), "420", "900", d1sBLMPath(logf),
		d1sBLMPath("mz"), "d1gru", "-mode", "train-pairs",
		"-corpus", d1sBLMPath("train.txt"), "-val", d1sBLMPath("val.txt"),
		"-steps", fmt.Sprint(pasos), "-out", d1sBLMPath("blm_gru_tui_train.json"))
	cmd.Dir = d1sBLMDir
	if err := cmd.Start(); err != nil {
		os.Remove(d1sBLMPath("tui_train.lock"))
		return "[comando local] ERROR al lanzar: " + err.Error()
	}
	if b, err := json.Marshal(servedRec{Key: key, Ts: time.Now().Unix()}); err == nil {
		os.WriteFile(servedF, b, 0644)
	}
	go func() { cmd.Wait(); os.Remove(d1sBLMPath("tui_train.lock")) }()
	return fmt.Sprintf("[comando local, no es salida del modelo] entrenamiento lanzado: %d pasos (cota 420s, RSS 900MiB, guardia desacoplada con sidecar %s.status). Observa con /blm-train-status, para con /blm-train-stop", pasos, d1sBLMPath(logf))
}
