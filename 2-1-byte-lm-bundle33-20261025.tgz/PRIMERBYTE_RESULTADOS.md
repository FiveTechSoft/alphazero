# Sonda primer byte (pairLossFull) — Resultados (2026-10-25)

Definición congelada en PRIMERBYTE_SONDA_DEF.md ANTES de ejecutar. Evaluación de solo lectura: checkpoints sin modificar (sha256 idénticos antes/después), wall <1s, 48 ítems heldL (dst7_heldL48, orden de archivo), sin training.

## Fixtures CLI reales (modo firstbyte, mz_fb)
- -in ausente → panic (rechazo). - corpus vacío → RECHAZA. - par desfasado (respuesta vacía) → RECHAZA. - corpus inexistente → panic. Los 4 verificados por CLI real.

## Resultados
| checkpoint | firstbyte NLL medio (bits) | argmax byte1 correcto |
|---|---|---|
| etapa0 (base, steps=480) | 7.1666 | 0/48 |
| E6 (steps=3504) | 3.9254 | 10/48 |

- Consistencia obligatoria: argmax teacher-forced == byte 1 greedy archivado (genheldL_E6.txt) en 48/48 ítems, 0 mismatches.
- Cobertura: esta sonda = 1 token/ítem (solo byte 1, sin EOS). Referencia teórica (NO medida aquí): legacy pairLoss = 4 tokens/ítem (bytes 2..5 incl EOS); full pairLossFull = 5 tokens/ítem. NO se midieron legacy/full en esta sonda; solo comparación de cobertura teórica.
- Nota: NLL cercano a log2(vocab) NO es test de uniformidad; no se afirma "base en azar". No se afirma ausencia de mecanismo de recuperación: solo exactitud insuficiente en este run. No se descarta exposure bias clásica completamente; solo se identifica el primer error y prefijos gold vs greedy.
