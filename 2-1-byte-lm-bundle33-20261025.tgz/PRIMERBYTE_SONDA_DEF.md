# Sonda EVAL primer byte (pairLossFull) — definición CONGELADA antes de ejecutar (2026-10-25)

Alcance: EVALUACIÓN SOLO LECTURA sobre ck etapa0 (sha256 51dcbe4b...) y ck_E6 (ciclo_esc/ck_E6.json), mismos 48 heldL (dst7_heldL48.txt sha256 06279d61...), mismo orden de archivo. Sin training. Pesos inmutables: sha256 del checkpoint antes y después. Tope 30s wall total. Primer fallo = PARA, sin retries, sin parchar.

## Definiciones y denominadores
- Estado: h = tras alimentar TODOS los bytes del prompt "U: <pregunta>\nA: " (idéntico feed que genpairs y pairLoss).
- firstbyte_nll_bits(item) = -log2 p_modelo(respuesta[0] | h). Media sobre 48 ítems. Incluye SOLO el byte 1 de la respuesta (no EOS).
- argmax_byte1(item) = arg_b max p(b | h). argmax_correct = cuenta de ítems con argmax == byte gold 1. Denominador 48.
- full vs legacy: legacy = pairLoss (bytes 2..N de la respuesta + '\n' final, denominador N); full = pairLossFull (byte 1 + bytes 2..N + '\n', denominador N+1). Se reportan tokens contados en cada una (N y N+1 con N = len(respuesta)+1 incluyendo EOS '\n').
- Equivalencia de paso: el byte puntuado como "primer byte" es el PRIMER byte emitido por genpairs (posición 1 de generación), con el mismo estado h. GEN2 = el segundo byte generado queda fuera de esta sonda.
- Consistencia obligatoria: para CADA ítem, argmax_byte1 (teacher-forced, mismo estado, temp 0) DEBE coincidir con el byte 1 de la salida greedy ya archivada (genheldL_E6.txt). Si algún ítem no coincide → PARA y reporte; NO se parcha nada.
- Sin permutación en esta sonda (evalúa prompt verdadero solamente; la permutación semilla 29 no aplica aquí). No se descarta exposure bias clásica completamente; solo se identifica primer error y prefijos gold vs greedy.
