package main

// Fixtures de la EXTENSION DECLARADA de secuencia (pasada L5) y de la
// mini-migracion en frio: 200 pasos de una vez vs 100+100 con checkpoint
// intermedio, MISMA head copy y MISMO estado de optimizador. Paridad EXACTA
// con la corrida completa (FS) salvo metadata justificada (bpb_val: metrica
// de val recomputada en cada guardado, no estado del modelo). Datos 100%
// sinteticos; sin corpus reales, sin oracle inference.

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// Ramas de seqResumeBase (no vacuas: cada rama se ejerce con su causa).
func TestSeqResumeBaseRamas(t *testing.T) {
	ck := "aaaa1111bbbb2222cccc3333dddd4444aaaa1111bbbb2222cccc3333dddd4444"
	nw := "9999888877776666555544443333222211110000ffffeeeeddddccccbbbbaaaa"
	// 1) mismo sha: reanudacion fiel, no extension
	b, ext, err := seqResumeBase(ck, 3024, ck, "")
	if err != nil || ext || b != 3024 {
		t.Fatalf("mismo sha: base=%d ext=%v err=%v", b, ext, err)
	}
	// 2) sha distinto sin declaracion: RECHAZO (causa: no coincide)
	if _, _, err = seqResumeBase(ck, 3024, nw, ""); err == nil || !strings.Contains(err.Error(), "RECHAZO seq") {
		t.Fatalf("sha distinto sin declarar debe rechazar: %v", err)
	}
	// 3) ext-prev == sha nuevo: NO es extension (causa propia)
	if _, _, err = seqResumeBase(ck, 3024, nw, nw); err == nil || !strings.Contains(err.Error(), "no es extension") {
		t.Fatalf("ext-prev==nuevo debe rechazar: %v", err)
	}
	// 4) ext-prev que no coincide con el checkpoint: RECHAZO (causa: prev != ck)
	if _, _, err = seqResumeBase(ck, 3024, nw, "zzz"); err == nil || !strings.Contains(err.Error(), "prev declarado") {
		t.Fatalf("ext-prev erroneo debe rechazar: %v", err)
	}
	// 5) extension DECLARADA correcta: cursor MIGRA FIEL a ckPos
	b, ext, err = seqResumeBase(ck, 3024, nw, ck)
	if err != nil || !ext || b != 3024 {
		t.Fatalf("extension declarada: base=%d ext=%v err=%v", b, ext, err)
	}
}

// Mini-migracion en frio sintetica: 200 de una vez == 100 + save/load + 100.
func TestMigracionFria200vs100y100(t *testing.T) {
	dir := t.TempDir()
	pairs := [][2]string{}
	for i := 0; i < 16; i++ {
		w := fmt.Sprintf("w%03d", i*7%16)
		pairs = append(pairs, [2]string{fmt.Sprintf("repite '%s'", w), w})
	}
	seq := make([]int, 200)
	for i := range seq {
		seq[i] = (i * 5) % 16
	}
	const lr = 0.003

	ini := func() (*GRU, *copyHead, *copyAdamState, *adamGRUState) {
		g := NewGRU(42, 8, 16)
		return g, initCopyHeadFromSeed(g.H, 7), newCopyAdam(g.H), g.newAdam()
	}
	pasos := func(g *GRU, ch *copyHead, cst *copyAdamState, st *adamGRUState, base, n int) (float64, float64) {
		gr := g.newGrads()
		cg := newCopyGrads(g.H)
		var l0, l1 float64
		for s := 0; s < n; s++ {
			pr := pairs[seq[base+s]]
			prompt := []byte("U: " + pr[0] + "\nA: ")
			ans := []byte(pr[1] + "\n")
			buf := append(append([]byte(nil), prompt...), ans...)
			loss, _ := g.trainSeqMaskCopy(buf, len(prompt)-1, len(prompt)-1, ch, false, gr, cg)
			g.adamApply(st, lr, gr)
			cst.apply(ch, cg, lr)
			if s == 0 {
				l0 = loss
			}
			l1 = loss
		}
		return l0, l1
	}

	// FS: corrida completa de 200
	g1, ch1, cs1, st1 := ini()
	fsL0, fsL1 := pasos(g1, ch1, cs1, st1, 0, 200)
	g1.pendingSeqSHA = "seq-sintetica"
	g1.pendingSeqPos = 200
	fsPath := filepath.Join(dir, "fs.json")
	if err := g1.saveCopy(fsPath, 200, 9.99, st1, ch1, cs1, 123, "corpus", 7, lr, "proto"); err != nil {
		t.Fatal(err)
	}

	// 100+100 con parada fria real (saveCopy -> loadCopyStrict)
	g2, ch2, cs2, st2 := ini()
	spL0, _ := pasos(g2, ch2, cs2, st2, 0, 100)
	g2.pendingSeqSHA = "seq-sintetica"
	g2.pendingSeqPos = 100
	midPath := filepath.Join(dir, "mid.json")
	if err := g2.saveCopy(midPath, 100, 9.99, st2, ch2, cs2, 123, "corpus", 7, lr, "proto"); err != nil {
		t.Fatal(err)
	}
	g3, steps3, _, ch3, cs3, mig3, err := loadCopyStrict(midPath)
	if err != nil || mig3 || steps3 != 100 {
		t.Fatalf("cold load: steps=%d mig=%v err=%v", steps3, mig3, err)
	}
	st3 := g3.adamFromJSON(g3.lastCkpt.Adam)
	_, spL1 := pasos(g3, ch3, cs3, st3, 100, 100)
	if spL1 <= 0 {
		t.Fatal("fixture vacua: loss final split no positiva")
	}
	g3.pendingSeqSHA = "seq-sintetica"
	g3.pendingSeqPos = 200
	spPath := filepath.Join(dir, "sp.json")
	if err := g3.saveCopy(spPath, 200, 9.99, st3, ch3, cs3, 123, "corpus", 7, lr, "proto"); err != nil {
		t.Fatal(err)
	}

	// No vacuo: el entrenamiento movio loss y pesos
	if !(fsL1 < fsL0) {
		t.Fatalf("fixture vacua: loss no baja en FS (%v -> %v)", fsL0, fsL1)
	}
	if spL0 != fsL0 {
		t.Fatalf("misma init debe dar misma primera loss: FS %v vs split %v", fsL0, spL0)
	}

	// Paridad EXACTA de los JSON finales salvo bpb_val (metadata justificada:
	// metrica de val recomputada en cada guardado, no estado del modelo).
	strip := func(p string) map[string]json.RawMessage {
		b, err := os.ReadFile(p)
		if err != nil {
			t.Fatal(err)
		}
		var m map[string]json.RawMessage
		if err := json.Unmarshal(b, &m); err != nil {
			t.Fatal(err)
		}
		delete(m, "bpb_val")
		return m
	}
	a, b := strip(fsPath), strip(spPath)
	if len(a) != len(b) {
		t.Fatalf("claves distintas: %d vs %d", len(a), len(b))
	}
	for k, va := range a {
		vb, ok := b[k]
		if !ok {
			t.Fatalf("clave %s solo en FS", k)
		}
		if string(va) != string(vb) {
			t.Fatalf("PARIDAD ROTA en %s", k)
		}
	}
	// Invariantes EXPECTED explicitos (no solo igualdad mutua: dos finales
	// identicamente INCORRECTOS tambien serian "iguales").
	expected := map[string]string{
		"steps":     "200",
		"seq_pos":   "200",
		"seq_sha":   `"seq-sintetica"`,
		"samp":      "123",
		"seed":      "7",
		"corpus_sha": `"corpus"`,
		"proto":     `"proto"`,
	}
	for k, want := range expected {
		raw, ok := a[k]
		if !ok {
			t.Fatalf("invariante EXPECTED ausente en final FS: %s", k)
		}
		if string(raw) != want {
			t.Fatalf("invariante EXPECTED %s = %s, esperado %s", k, raw, want)
		}
	}
	var adam map[string]json.RawMessage
	if err := json.Unmarshal(a["adam"], &adam); err != nil {
		t.Fatal("adam EXPECTED ausente o invalido en final FS")
	}
	if _, ok := adam["m"]; !ok {
		t.Fatal("adam.m EXPECTED ausente")
	}
	if _, ok := adam["v"]; !ok {
		t.Fatal("adam.v EXPECTED ausente")
	}
	// seq_ext_prev ausente aqui (sin extension): su presencia se cubre en ramas
	if _, ok := a["seq_ext_prev"]; ok {
		t.Fatal("seq_ext_prev no debe aparecer sin extension declarada")
	}
	t.Logf("paridad exacta FS vs 100+100 (loss %v -> %v)", fsL0, fsL1)
}

// Prefijo byte-exacto de la extension: los primeros ckPos indices del fichero
// nuevo (canonico) deben reproducir el sha de la seq previa declarada.
func TestSeqExtPrefijoByteExacto(t *testing.T) {
	prev := []byte("3\n1\n4\n1\n5\n9\n2\n6\n")
	prevSHA := sha256Hex(prev)
	// positivo: fichero = prefijo + segmento nuevo
	nuevo := []byte("3\n1\n4\n1\n5\n9\n2\n6\n0\n0\n7\n")
	if err := seqExtVerificaPrefijo(nuevo, 8, prevSHA); err != nil {
		t.Fatalf("prefijo correcto debe admitir: %v", err)
	}
	// positivo formato no canonico (ceros a la izquierda): canonico iguala
	nc := []byte("03\n1\n4\n1\n5\n9\n2\n6\n0\n")
	if err := seqExtVerificaPrefijo(nc, 8, prevSHA); err != nil {
		t.Fatalf("prefijo semanticamente igual en formato no canonico debe admitir (canonico): %v", err)
	}
	// negativo 1: prefijo ALTERADO con prev correcto -> RECHAZO con causa
	alt := []byte("3\n1\n4\n1\n5\n9\n2\n7\n0\n")
	err := seqExtVerificaPrefijo(alt, 8, prevSHA)
	if err == nil || !strings.Contains(err.Error(), "prefijo alterado") {
		t.Fatalf("prefijo alterado debe rechazar con causa: %v", err)
	}
	// negativo 2: fichero mas corto que el cursor -> RECHAZO con causa
	corto := []byte("3\n1\n4\n")
	err = seqExtVerificaPrefijo(corto, 8, prevSHA)
	if err == nil || !strings.Contains(err.Error(), "prefijo imposible") {
		t.Fatalf("prefijo corto debe rechazar con causa: %v", err)
	}
	// negativo 3: prevSHA de otra seq -> RECHAZO
	err = seqExtVerificaPrefijo(nuevo, 8, sha256Hex([]byte("9\n9\n")))
	if err == nil {
		t.Fatal("prev sha de otra seq debe rechazar")
	}
}

// Cursor de extension tras carga en frio: con seq_pos=K persistido, el
// siguiente paso consume seq[K] (primer indice NUEVO), no seq[0] ni seq[K-1].
func TestExtCursorContinuaEnK(t *testing.T) {
	// seq previa sintetica y su checkpoint (frio real via save/load)
	prevRaw := []byte("5\n0\n3\n3\n1\n")
	prevSHA := sha256Hex(prevRaw)
	g := NewGRU(7, 4, 8)
	st := g.newAdam()
	rng := &sm64{s: 28}
	g.pendingSeqSHA = prevSHA
	g.pendingSeqPos = 5 // cursor al FINAL de la seq previa
	p := filepath.Join(t.TempDir(), "ck.json")
	if err := g.SaveGRU(p, 5, 1.0, st, rng.s, "corpus", 7, 0.003, "proto"); err != nil {
		t.Fatal(err)
	}
	g2, _, _, err := LoadGRUFull(p)
	if err != nil {
		t.Fatal(err)
	}
	// fichero de extension: prefijo + 3 indices NUEVOS (2, 4, 0)
	extRaw := []byte("5\n0\n3\n3\n1\n2\n4\n0\n")
	newSHA := sha256Hex(extRaw)
	base, esExt, err := seqResumeBase(g2.lastCkpt.SeqSHA, g2.lastCkpt.SeqPos, newSHA, prevSHA)
	if err != nil || !esExt || base != 5 {
		t.Fatalf("extension: base=%d ext=%v err=%v", base, esExt, err)
	}
	if err := seqExtVerificaPrefijo(extRaw, g2.lastCkpt.SeqPos, prevSHA); err != nil {
		t.Fatalf("prefijo: %v", err)
	}
	seq := []int{5, 0, 3, 3, 1, 2, 4, 0}
	// el siguiente paso (s=0 del nuevo tramo) consume seq[5]=2 (NUEVO), no 5 ni 1
	if got := indicePaso(nil, seq, base, 0, 8); got != 2 {
		t.Fatalf("cursor extension: siguiente paso=%d, esperado 2 (primer indice nuevo)", got)
	}
	if got := indicePaso(nil, seq, base, 2, 8); got != 0 {
		t.Fatalf("cursor extension: tercer paso=%d, esperado 0", got)
	}
	// seq_ext_prev viaja en el checkpoint del nuevo tramo
	g2.pendingSeqSHA = newSHA
	g2.pendingSeqPos = base + 3
	g2.pendingSeqExtPrev = prevSHA
	p2 := filepath.Join(t.TempDir(), "ck2.json")
	if err := g2.SaveGRU(p2, 8, 1.0, st, rng.s, "corpus", 7, 0.003, "proto"); err != nil {
		t.Fatal(err)
	}
	g3, _, _, err := LoadGRUFull(p2)
	if err != nil {
		t.Fatal(err)
	}
	if g3.lastCkpt.SeqExtPrev != prevSHA || g3.lastCkpt.SeqPos != 8 {
		t.Fatalf("seq_ext_prev no persistio: prev=%s pos=%d", g3.lastCkpt.SeqExtPrev, g3.lastCkpt.SeqPos)
	}
	// y la cadena sigue verificando: otra extension debe declarar ESTE sha,
	// y su fichero debe contener el prefijo completo (8) o se rechaza
	raw2 := []byte("1\n")
	if _, _, err := seqResumeBase(g3.lastCkpt.SeqSHA, g3.lastCkpt.SeqPos, sha256Hex(raw2), newSHA); err != nil {
		t.Fatalf("transicion declarada con prev correcto debe pasar seqResumeBase: %v", err)
	}
	if err := seqExtVerificaPrefijo(raw2, g3.lastCkpt.SeqPos, newSHA); err == nil {
		t.Fatal("segunda extension con prefijo corto debe rechazar en verificacion de prefijo")
	}
}

// Propagacion de seq_ext_prev: una extension declarada persiste en TODOS los
// checkpoints derivados por resume mismo-sha (sin flag), cadena de 3 tramos.
// Regla: un tramo nuevo de extension (pending) prevalece sobre el heredado.
func TestSeqExtPrevPropagaEnResumeMismoSha(t *testing.T) {
	dir := t.TempDir()
	prevSHA := "aaaa1111bbbb2222cccc3333dddd4444aaaa1111bbbb2222cccc3333dddd4444"
	extSHA := "9999888877776666555544443333222211110000ffffeeeeddddccccbbbbaaaa"

	// tramo 1: extension DECLARADA (pending) -> ck1 lleva seq_ext_prev
	g1 := NewGRU(7, 4, 8)
	st1 := g1.newAdam()
	g1.pendingSeqSHA = extSHA
	g1.pendingSeqPos = 10
	g1.pendingSeqExtPrev = prevSHA
	p1 := filepath.Join(dir, "ck1.json")
	if err := g1.SaveGRU(p1, 10, 1.0, st1, 5, "corpus", 7, 0.003, "proto"); err != nil {
		t.Fatal(err)
	}

	// tramo 2: resume MISMO sha, SIN flag -> ck2 debe HEREDAR seq_ext_prev
	g2, _, _, err := LoadGRUFull(p1)
	if err != nil {
		t.Fatal(err)
	}
	if g2.lastCkpt.SeqExtPrev != prevSHA {
		t.Fatalf("ck1 no lleva seq_ext_prev: %q", g2.lastCkpt.SeqExtPrev)
	}
	g2.pendingSeqSHA = extSHA // mismo sha: resume fiel, NO extension
	g2.pendingSeqPos = 12
	st2 := g2.adamFromJSON(g2.lastCkpt.Adam)
	p2 := filepath.Join(dir, "ck2.json")
	if err := g2.SaveGRU(p2, 12, 1.0, st2, 5, "corpus", 7, 0.003, "proto"); err != nil {
		t.Fatal(err)
	}

	// tramo 3: otro resume mismo-sha -> ck3 sigue llevandolo
	g3, _, _, err := LoadGRUFull(p2)
	if err != nil {
		t.Fatal(err)
	}
	if g3.lastCkpt.SeqExtPrev != prevSHA {
		t.Fatalf("PROPAGACION ROTA en ck2 (mismo-sha sin flag): seq_ext_prev=%q", g3.lastCkpt.SeqExtPrev)
	}
	g3.pendingSeqSHA = extSHA
	g3.pendingSeqPos = 14
	st3 := g3.adamFromJSON(g3.lastCkpt.Adam)
	p3 := filepath.Join(dir, "ck3.json")
	if err := g3.SaveGRU(p3, 14, 1.0, st3, 5, "corpus", 7, 0.003, "proto"); err != nil {
		t.Fatal(err)
	}
	g4, _, _, err := LoadGRUFull(p3)
	if err != nil {
		t.Fatal(err)
	}
	if g4.lastCkpt.SeqExtPrev != prevSHA || g4.lastCkpt.SeqPos != 14 {
		t.Fatalf("PROPAGACION ROTA en ck3: prev=%q pos=%d", g4.lastCkpt.SeqExtPrev, g4.lastCkpt.SeqPos)
	}

	// contraste: checkpoint sin extension en su cadena NO gana el campo
	g5 := NewGRU(7, 4, 8)
	st5 := g5.newAdam()
	g5.pendingSeqSHA = extSHA
	g5.pendingSeqPos = 3
	p5 := filepath.Join(dir, "ck5.json")
	if err := g5.SaveGRU(p5, 3, 1.0, st5, 5, "corpus", 7, 0.003, "proto"); err != nil {
		t.Fatal(err)
	}
	g6, _, _, err := LoadGRUFull(p5)
	if err != nil {
		t.Fatal(err)
	}
	if g6.lastCkpt.SeqExtPrev != "" {
		t.Fatalf("cadena sin extension debe quedar sin seq_ext_prev: %q", g6.lastCkpt.SeqExtPrev)
	}
}
