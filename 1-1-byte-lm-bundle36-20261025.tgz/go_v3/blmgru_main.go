package main

// blmgru_main.go — harness d1gru: SOLO prueba de ruta (gradient check, coste,
// humo). No es un hito de conversacion ni de autonomia.
import (
	"crypto/sha256"
	"encoding/hex"
	"flag"
	"strings"
	"fmt"
	"math"
	"math/rand"
	"os"
	"time"
)

func sha256Hex(b []byte) string {
	h := sha256.Sum256(b)
	return hex.EncodeToString(h[:])
}

func init() {
	if len(os.Args) > 1 && os.Args[1] == "d1gru" {
		RunGRU(os.Args[2:])
		os.Exit(0)
	}
}

func RunGRU(args []string) {
	fs := flag.NewFlagSet("d1gru", flag.ExitOnError)
	mode := fs.String("mode", "gradcheck", "gradcheck|cost|smoke")
	d := fs.Int("d", 32, "embedding")
	hh := fs.Int("hh", 64, "ocultas")
	seed := fs.Int64("seed", 20261025, "semilla")
	corpus := fs.String("corpus", "/tmp/blm/train.txt", "corpus")
	steps := fs.Int("steps", 300, "pasos humo")
	forkNofiel := fs.Bool("fork-nofiel", false, "permite reanudar con mismatch de datos/config etiquetando proto fork-nofiel (NO fiel)")
	master := fs.String("master", "", "dataset maestro fijo (transiciones de curriculo)")
	masterPrev := fs.String("master-prev", "", "sha del maestro previo declarado: habilita transicion de curriculo ENTRE DATASETS (declarada, verificada por manifiesto, resume fiel)")
	manifest := fs.String("manifest", "", "manifiesto de seleccion versionado (repeat=N + indices)")
	seqf := fs.String("seq", "", "secuencia PREDEFINIDA de indices de pares (un indice por linea); congela exposiciones exactas y NO consume el RNG del sampler")
	seqExtPrev := fs.String("seq-ext-prev", "", "sha COMPLETO de la seq previa: habilita EXTENSION DECLARADA de secuencia (cursor migra fiel, sha nuevo versionado; SIN esto un sha distinto se rechaza)")
	copyhead := fs.String("copyhead", "off", "off|learn: cabeza copy (brazo A). gate0 NO es un modo: es la ruta base literal (off)")
	copyseed := fs.Int64("copyseed", 7, "semilla PROPIA init head copy (declarada; distinta del sampler y de NewGRU)")
	lr := fs.Float64("lr", 0.003, "lr Adam")
	tlen := fs.Int("t", 64, "longitud ventana BPTT")
	val := fs.String("val", "/tmp/blm/val.txt", "corpus val")
	in := fs.String("in", "", "checkpoint entrada (gen)")
	out := fs.String("out", "/tmp/blm_gru.json", "checkpoint salida (train)")
	prompt := fs.String("prompt", "U: Hola\nA:", "prompt gen")
	n := fs.Int("n", 280, "bytes a generar")
	temp := fs.Float64("temp", 0.8, "temperatura")
	fs.Parse(args)

	raw, err := os.ReadFile(*corpus)
	if err != nil {
		panic(err)
	}
	g := NewGRU(*seed, *d, *hh)

	switch *mode {
	case "train-pairs":
		// G2: aprendizaje de PARES U->A. El estado se ceba con la pregunta
		// (como en inferencia) y la perdida SOLO puntua la respuesta.
		// Secuencia capada: se conserva la pregunta entera y se trunca la
		// respuesta si excede (documentado).
		pairs := parseUAPairs(string(raw))
		valPairs := func() [][2]string {
			v, err := os.ReadFile(*val)
			if err != nil {
				panic(err)
			}
			return parseUAPairs(string(v))
		}()
		corpusSHA := sha256Hex(raw)
		manifestOK := false
		masterSHA, manifestSHA := "", ""
		if *master != "" && *manifest != "" {
			mraw, err := os.ReadFile(*master)
			if err != nil {
				panic(err)
			}
			manraw, err := os.ReadFile(*manifest)
			if err != nil {
				panic(err)
			}
			exp, info, err := expandirManifiesto(mraw, manraw)
			if err != nil {
				panic("manifiesto invalido: " + err.Error())
			}
			if sha256Hex(exp) != corpusSHA {
				panic("RECHAZO: el corpus no es la expansion del maestro+manifiesto (" + info + ")")
			}
			masterSHA = sha256Hex(mraw)
			manifestSHA = sha256Hex(manraw)
			manifestOK = true
			fmt.Fprintf(os.Stderr, "[curriculo verificado: maestro %s manifiesto %s -> %s]\n", masterSHA[:12], manifestSHA[:12], info)
		}
		protoOut := "run-continuo-v2"
		var st *adamGRUState
		var rng *sm64
		if *in != "" {
			g2, st0, _, err := LoadGRUFull(*in)
			if err != nil {
				panic(err)
			}
			g = g2
			if g.lastCkpt != nil {
				if manifestOK {
					ckMaster := g.lastCkpt.MasterSHA
					if ckMaster == "" {
						ckMaster = g.lastCkpt.CorpusSHA
					}
					if err := verificaMaestro(ckMaster, masterSHA, *masterPrev); err != nil {
						panic("RECHAZO curriculo: " + err.Error())
					}
					if *masterPrev != "" {
						fmt.Fprintf(os.Stderr, "[curriculo DECLARADO entre datasets: maestro previo %.12s -> nuevo %.12s, manifiesto %.12s, resume FIEL (Adam/RNG continuan)]\n", *masterPrev, masterSHA, manifestSHA)
					}
				}
				if err := validarResumeFiel(g.lastCkpt, corpusSHA, *lr, *forkNofiel, manifestOK); err != nil {
					panic("RECHAZO resume no fiel: " + err.Error() + " (use -fork-nofiel para fork explicito etiquetado)")
				}
				st = g.adamFromJSON(g.lastCkpt.Adam)
				rng = &sm64{s: g.lastCkpt.Samp}
				if *forkNofiel {
					protoOut = "fork-nofiel:" + g.lastCkpt.Proto
					fmt.Fprintf(os.Stderr, "[FORK NO FIEL: reanudando con mismatch explicito, proto salida %s]\n", protoOut)
				}
				fmt.Fprintf(os.Stderr, "[reanudando GRU %d pasos previos CON estado Adam+RNG (proto %s)]\n", st0, g.lastCkpt.Proto)
			} else {
				st = g.newAdam()
				rng = &sm64{s: uint64(*seed) + 21}
				fmt.Fprintf(os.Stderr, "[reanudando GRU %d pasos previos SOLO PESOS (checkpoint antiguo: Adam fresco + RNG nuevo; resumen no fiel)]\n", st0)
			}
		} else {
			st = g.newAdam()
			rng = &sm64{s: uint64(*seed) + 21}
		}
		gr := g.newGrads()
		var ch *copyHead
		var cst *copyAdamState
		var cg *copyGrads
		if *copyhead == "learn" {
			if *in == "" {
				panic("copyhead=learn requiere -in (checkpoint base)")
			}
			_, _, _, ch0, cs0, mig, err := loadCopyStrict(*in)
			if err != nil {
				panic("copyhead load: " + err.Error())
			}
			if mig {
				ch = initCopyHeadFromSeed(g.H, *copyseed)
				cst = newCopyAdam(g.H)
				fmt.Fprintf(os.Stderr, "[copy head MIGRACION v1: init aleatoria escala 0.1 semilla %d DECLARADA, t_copy=0; pesos/Adam/RNG base intactos]\n", *copyseed)
			} else {
				ch, cst = ch0, cs0
				fmt.Fprintf(os.Stderr, "[copy head v2 cargado: t_copy=%d]\n", cst.t)
			}
			cg = newCopyGrads(g.H)
		} else if *copyhead != "off" {
			panic("copyhead invalido: " + *copyhead)
		}
		var seq []int
		seqSHA := ""
		seqBase := 0
		if *seqf != "" {
			sraw, err := os.ReadFile(*seqf)
			if err != nil {
				panic(err)
			}
			if len(sraw) == 0 {
				panic("seq vacia: " + *seqf)
			}
			seqSHA = sha256Hex(sraw)
			for _, ln := range strings.Split(strings.TrimSpace(string(sraw)), "\n") {
				var ix int
				if _, err := fmt.Sscanf(ln, "%d", &ix); err != nil {
					panic("seq invalida: " + ln)
				}
				if ix < 0 || ix >= len(pairs) {
					panic(fmt.Sprintf("seq indice %d fuera de rango (%d pares)", ix, len(pairs)))
				}
				seq = append(seq, ix)
			}
			// Reanudacion fiel por tramos: el cursor y el sha viajan en el
			// checkpoint. steps heredados NUNCA posicionan la secuencia.
			if *in != "" && g.lastCkpt != nil && g.lastCkpt.SeqSHA != "" {
				base, esExt, err := seqResumeBase(g.lastCkpt.SeqSHA, g.lastCkpt.SeqPos, seqSHA, *seqExtPrev)
				if err != nil {
					panic(err.Error())
				}
				if esExt {
					if err := seqExtVerificaPrefijo(sraw, g.lastCkpt.SeqPos, *seqExtPrev); err != nil {
						panic(err.Error())
					}
					g.pendingSeqExtPrev = g.lastCkpt.SeqSHA
					fmt.Fprintf(os.Stderr, "[seq EXTENSION DECLARADA: prev sha=%s PREFIJO byte-exacto verificado, cursor=%d MIGRA FIEL -> nuevo sha=%s (sin reset; Adam/RNG/copy continuan)]\n", g.lastCkpt.SeqSHA[:16], base, seqSHA[:16])
				}
				seqBase = base
			}
			if len(seq) < seqBase+*steps {
				panic(fmt.Sprintf("seq corta: %d indices < cursor %d + %d pasos", len(seq), seqBase, *steps))
			}
			fmt.Fprintf(os.Stderr, "[seq predefinida: %d indices, cursor inicio=%d sha=%s (steps heredados NO posicionan seq)]\n", len(seq), seqBase, seqSHA[:16])
		}
		t0 := time.Now()
		capSeq := 512
		for s := 0; s < *steps; s++ {
			pr := pairs[indicePaso(rng, seq, seqBase, s, len(pairs))]
			prompt := []byte("U: " + pr[0] + "\nA: ")
			ans := []byte(pr[1] + "\n")
			ans, err = recortaRespuesta(prompt, ans, capSeq)
			if err != nil {
				panic(err)
			}
			if len(prompt)+len(ans) < 4 {
				continue
			}
			seq := append(append([]byte(nil), prompt...), ans...)
			var loss float64
			if ch != nil {
				loss, _ = g.trainSeqMaskCopy(seq, len(prompt)-1, len(prompt)-1, ch, false, gr, cg)
				g.adamApply(st, *lr, gr)
				cst.apply(ch, cg, *lr)
			} else {
				loss, _ = g.trainSeqMask(seq, len(prompt)-1, gr)
				g.adamApply(st, *lr, gr)
			}
			if (s+1)%1000 == 0 {
				fmt.Printf("paso %d bpb_resp_lote=%.4f t=%s\n", s+1, loss, time.Since(t0).Round(time.Second))
			}
		}
		// val: perdida de respuesta con pregunta VERDADERA (metrica de seleccion)
		acc, cnt := 0.0, 0
		for i := 0; i < len(valPairs) && cnt < 300; i++ {
			acc += g.pairLoss([]byte("U: "+valPairs[i][0]+"\nA: "), []byte(valPairs[i][1]+"\n"))
			cnt++
		}
		bpbv := acc / float64(cnt)
		// ABLACION MEDIDA de condicionamiento: misma respuesta, pregunta BARAJADA
		rg := rand.New(rand.NewSource(*seed + 22))
		accS := 0.0
		for i := 0; i < cnt; i++ {
			j := rg.Intn(len(valPairs))
			accS += g.pairLoss([]byte("U: "+valPairs[j][0]+"\nA: "), []byte(valPairs[i][1]+"\n"))
		}
		bpbS := accS / float64(cnt)
		fmt.Printf("FIN steps=%d bpb_val_resp=%.4f bpb_val_resp_pregunta_barajada=%.4f gap_condicionamiento=%.4f (%d pares) duracion=%s\n",
			*steps, bpbv, bpbS, bpbS-bpbv, cnt, time.Since(t0).Round(time.Second))
		if bpbS-bpbv > 0.05 {
			fmt.Println("CONDICIONAMIENTO: real (la pregunta reduce la perdida de la respuesta)")
		} else {
			fmt.Println("CONDICIONAMIENTO: no detectado a esta escala (el modelo ignora operativamente la pregunta)")
		}
		totalSteps := *steps
		if *in != "" {
			_, st0, _, _ := LoadGRU(*in)
			totalSteps += st0 // acumular pasos previos en la etiqueta (reanudacion real)
		}
		g.pendingMaster, g.pendingManifest = masterSHA, manifestSHA
		if seqSHA != "" {
			g.pendingSeqSHA = seqSHA
			g.pendingSeqPos = seqBase + *steps
		}
		if ch != nil {
			if err := g.saveCopy(*out, totalSteps, bpbv, st, ch, cst, rng.s, corpusSHA, *seed, *lr, protoOut); err != nil {
				panic(err)
			}
		} else if err := g.SaveGRU(*out, totalSteps, bpbv, st, rng.s, corpusSHA, *seed, *lr, protoOut); err != nil {
			panic(err)
		}
	case "scorepairs-full":
		// Como scorepairs pero imprime AMBAS metricas: legada (sin 1er byte) y
		// bpb_primer_byte (cobertura completa). Etiquetas nuevas, legada intacta.
		if *in == "" {
			panic("scorepairs-full requiere -in checkpoint")
		}
		g2, st0, _, err := LoadGRU(*in)
		if err != nil {
			panic(err)
		}
		fmt.Fprintf(os.Stderr, "[scorepairs-full gru %d pasos cargado]\n", st0)
		pairs := parseUAPairs(string(raw))
		for i, pr := range pairs {
			p := []byte("U: " + pr[0] + "\nA: ")
			a := []byte(pr[1] + "\n")
			fmt.Printf("SCOREFULL %d bpb_legado=%.6f bpb_primer_byte=%.6f\n", i, g2.pairLoss(p, a), g2.pairLossFull(p, a))
		}
	case "firstbyte":
		// Sonda EVAL primer byte (solo lectura): NLL bits y argmax del byte 1 de la
		// respuesta por item, estado tras prompt completo (mismo feed que genpairs).
		if *in == "" {
			panic("firstbyte requiere -in checkpoint")
		}
		pairs := parseUAPairs(string(raw))
		if len(pairs) == 0 {
			panic("firstbyte RECHAZA corpus vacio o sin pares")
		}
		g2, st0, _, err := LoadGRU(*in)
		if err != nil {
			panic(err)
		}
		fmt.Fprintf(os.Stderr, "[firstbyte gru %d pasos cargado]\n", st0)
		for i, pr := range pairs {
			if pr[0] == "" || pr[1] == "" {
				panic("firstbyte RECHAZA par desfasado (pregunta o respuesta vacia)")
			}
			p := []byte("U: " + pr[0] + "\nA: ")
			h := make([]float64, g2.H)
			for t := 0; t < len(p); t++ {
				_, h = g2.step(h, p[t])
			}
			dist := softmax(g2.logits(h))
			gold := pr[1][0]
			prb := dist[gold]
			if prb < 1e-12 {
				prb = 1e-12
			}
			best := 0
			for b := 1; b < len(dist); b++ {
				if dist[b] > dist[best] {
					best = b
				}
			}
			fmt.Printf("FIRSTBYTE %d nll_bits=%.6f argmax=%q gold=%q hit=%d\n", i, -math.Log2(prb), string(rune(best)), string(rune(gold)), map[bool]int{false:0,true:1}[byte(best) == gold])
		}
	case "gaptokens":
		// Diagnostico POR TOKEN sobre UN checkpoint: fraccion gap>0 y
		// distribucion por umbrales PREDECLARADOS (1e-4 ruido / 1e-2 apreciable).
		// Misma asignacion barajada determinista que gappairs.
		if *in == "" {
			panic("gaptokens requiere -in checkpoint")
		}
		g2, st0, _, err := LoadGRU(*in)
		if err != nil {
			panic(err)
		}
		fmt.Fprintf(os.Stderr, "[gaptokens gru %d pasos cargado]\n", st0)
		pairs := parseUAPairs(string(raw))
		n := len(pairs)
		k := offsetBarajado(n, *seed)
		var res gapTokResumen
		invalidos := 0
		for i := 0; i < n; i++ {
			j := (i + k) % n
			if j == i || normalizaPregunta(pairs[j][0]) == normalizaPregunta(pairs[i][0]) {
				invalidos++
				continue
			}
			pre := []byte("U: " + pairs[i][0] + "\nA: ")
			preS := []byte("U: " + pairs[j][0] + "\nA: ")
			ans := []byte(pairs[i][1] + "\n")
			gapTokensPar(g2, pre, preS, ans, &res)
		}
		frac := 0.0
		media := 0.0
		if res.Tokens > 0 {
			frac = float64(res.Positivos) / float64(res.Tokens)
			media = res.Suma / float64(res.Tokens)
		}
		fmt.Printf("GAPTOKRESUMEN pares=%d invalidos=%d tokens=%d frac_pos=%.4f gap_media_tok=%.6f ruido(<1e-4)=%d(pos=%d) debil=%d(pos=%d) apreciable(>=1e-2)=%d(pos=%d) seed=%d offset=%d\n",
			n, invalidos, res.Tokens, frac, media, res.BRuido, res.BRuidoPos, res.BDebil, res.BDebilPos, res.BAprec, res.BAprecPos, *seed, k)
	case "gappairs":
		// Gap de condicionamiento POR PAR (diagnostico, sin entrenamiento):
		// gap = LOSS barajada - LOSS real (positivo = beneficio de contexto).
		// INVALIDOS explicitos (identidad / misma_normalizada), jamas ingeridos.
		if *in == "" {
			panic("gappairs requiere -in checkpoint")
		}
		g2, st0, _, err := LoadGRU(*in)
		if err != nil {
			panic(err)
		}
		fmt.Fprintf(os.Stderr, "[gappairs gru %d pasos cargado]\n", st0)
		pairs := parseUAPairs(string(raw))
		imprimeGapPares(gapPares(g2, pairs, *seed), *seed)
	case "scorepairs":
		// Perdida POR PAR de un corpus con un checkpoint dado (-in obligatorio).
		// Uso: deteccion de pares dificiles (alta perdida) para curriculum
		// supervisado. Indicador ESTADISTICO de ajuste, no error semantico.
		if *in == "" {
			panic("scorepairs requiere -in checkpoint")
		}
		if *copyhead == "learn" {
			g2, st0, _, ch2, _, mig2, err := loadCopyStrict(*in)
			if err != nil {
				panic("copyhead load: " + err.Error())
			}
			if mig2 {
				ch2 = initCopyHeadFromSeed(g2.H, *copyseed)
			}
			fmt.Fprintf(os.Stderr, "[scorepairs gru %d pasos + copy head cargado]\n", st0)
			pairs := parseUAPairs(string(raw))
			for i, pr := range pairs {
				l := g2.pairLossCopy(ch2, []byte("U: "+pr[0]+"\nA: "), []byte(pr[1]+"\n"))
				fmt.Printf("SCORE %d %.6f\n", i, l)
			}
			break
		} else if *copyhead != "off" {
			panic("copyhead invalido: " + *copyhead)
		}
		g2, st0, _, err := LoadGRU(*in)
		if err != nil {
			panic(err)
		}
		fmt.Fprintf(os.Stderr, "[scorepairs gru %d pasos cargado]\n", st0)
		pairs := parseUAPairs(string(raw))
		for i, pr := range pairs {
			l := g2.pairLoss([]byte("U: "+pr[0]+"\nA: "), []byte(pr[1]+"\n"))
			fmt.Printf("SCORE %d %.6f\n", i, l)
		}
	case "condgap":
		// Solo la ablacion sobre un checkpoint existente.
		g2, steps, bpbv, err := LoadGRU(*in)
		if err != nil {
			panic(err)
		}
		fmt.Fprintf(os.Stderr, "[gru %d pasos cargado, bpb_val=%.4f]\n", steps, bpbv)
		valPairs := func() [][2]string {
			v, err := os.ReadFile(*val)
			if err != nil {
				panic(err)
			}
			return parseUAPairs(string(v))
		}()
		rg := rand.New(rand.NewSource(*seed + 22))
		cnt := 0
		accT, accS := 0.0, 0.0
		for i := 0; i < len(valPairs) && cnt < 300; i++ {
			j := rg.Intn(len(valPairs))
			accT += g2.pairLoss([]byte("U: "+valPairs[i][0]+"\nA: "), []byte(valPairs[i][1]+"\n"))
			accS += g2.pairLoss([]byte("U: "+valPairs[j][0]+"\nA: "), []byte(valPairs[i][1]+"\n"))
			cnt++
		}
		fmt.Printf("CONDGAP bpb_resp_verdadera=%.4f bpb_resp_barajada=%.4f gap=%.4f (%d pares val)\n",
			accT/float64(cnt), accS/float64(cnt), (accS-accT)/float64(cnt), cnt)
	case "train":
		// Entrenamiento acotado (protocolo congelado: split por hilo ya hecho
		// en los ficheros; val = seleccion; NO toca test). Ventanas aleatorias.
		valRaw, err := os.ReadFile(*val)
		if err != nil {
			panic(err)
		}
		gr := g.newGrads()
		st := g.newAdam()
		r := rand.New(rand.NewSource(*seed + 11))
		t0 := time.Now()
		for s := 0; s < *steps; s++ {
			off := r.Intn(len(raw) - *tlen - 2)
			loss := g.trainSeq(raw[off:off+*tlen+1], gr)
			g.adamApply(st, *lr, gr)
			if (s+1)%1000 == 0 {
				fmt.Printf("paso %d bpb_lote=%.4f t=%s\n", s+1, loss, time.Since(t0).Round(time.Second))
			}
		}
		// val: media sobre ventanas fijas no solapadas del principio de val
		acc, cnt := 0.0, 0
		for off := 0; off+*tlen+1 < len(valRaw) && cnt < 300; off += *tlen + 1 {
			l, _ := g.seqLoss(valRaw[off : off+*tlen+1])
			acc += l
			cnt++
		}
		bpbv := acc / float64(cnt)
		fmt.Printf("FIN steps=%d bpb_val=%.4f (%d ventanas) duracion=%s\n", *steps, bpbv, cnt, time.Since(t0).Round(time.Second))
		if err := g.SaveGRU(*out, *steps, bpbv, nil, 0, "", 0, 0, ""); err != nil {
			panic(err)
		}
	case "genpairs":
		// Generacion GREEDY por lote (ruta gen2, temp<=0): una linea por par
		// del corpus, EN ORDEN, recortada en '\n' por el motor. Oraculo NUNCA
		// entra aqui: solo preguntas. Para evaluacion exact-match offline.
		if *in == "" {
			panic("genpairs requiere -in checkpoint")
		}
		if *copyhead == "learn" {
			g2, _, _, ch2, _, mig2, err := loadCopyStrict(*in)
			if err != nil {
				panic("copyhead load: " + err.Error())
			}
			if mig2 {
				ch2 = initCopyHeadFromSeed(g2.H, *copyseed)
				fmt.Fprintf(os.Stderr, "[copy head MIGRACION v1 en gen: init semilla %d DECLARADA (preupdate)]\n", *copyseed)
			}
			for _, pr := range parseUAPairs(string(raw)) {
				fmt.Printf("%s\n", genParGreedyCopy(g2, ch2, pr[0], *n))
			}
			break
		} else if *copyhead != "off" {
			panic("copyhead invalido: " + *copyhead)
		}
		g2, _, _, err := LoadGRU(*in)
		if err != nil {
			panic(err)
		}
		for _, pr := range parseUAPairs(string(raw)) {
			fmt.Printf("%s\n", genParGreedy(g2, pr[0], *n))
		}
	case "gen2":
		g2, steps, bpbv, err := LoadGRU(*in)
		if err != nil {
			panic(err)
		}
		fmt.Fprintf(os.Stderr, "[gru %d pasos, bpb_val=%.4f, DEC2 cebado corregido]\n", steps, bpbv)
		fmt.Printf("%s\n", g2.generateGRU2(*prompt, *n, *temp, *seed))
	case "gen":
		g2, steps, bpbv, err := LoadGRU(*in)
		if err != nil {
			panic(err)
		}
		fmt.Fprintf(os.Stderr, "[gru %d pasos, bpb_val=%.4f]\n", steps, bpbv)
		fmt.Printf("%s\n", g2.generateGRU(*prompt, *n, *temp, *seed))
	case "gradcheck":
		// Gradient check por diferencias finitas, ventana fija con T pasos
		// (el backward atraviesa todas las puertas en cada paso). Muestras
		// POR FAMILIA de parametros, varias por familia, preferentemente con
		// gradiente analitico NO cero. Criterio ANTES de cualquier carga:
		// err_rel < 1e-3 en todas las muestras; si no, NO se entrena nada.
		seq := raw[:*tlen+1]
		gr := g.newGrads()
		loss := g.trainSeq(seq, gr)
		an := g.gradFlat(gr)
		acc := g.flatAccess()
		// limites de cada familia en el orden plano de flatAccess/gradFlat
		type fam struct {
			name string
			lo   int
			hi   int
		}
		szE, szW, szWo, H, D := 256*(*d), (*hh)*((*hh)+(*d)), 256*(*hh), *hh, *d
		_ = H
		_ = D
		o := 0
		fams := []fam{}
		add := func(name string, n int) {
			fams = append(fams, fam{name, o, o + n})
			o += n
		}
		add("E", szE)
		add("Wz", szW)
		add("Wr", szW)
		add("Wn", szW)
		add("Bz", *hh)
		add("Br", *hh)
		add("Bn", *hh)
		add("Wo", szWo)
		add("Bo", 256)
		fmt.Printf("loss ventana=%.6f params=%d (T=%d pasos, familias=%d)\n", loss, len(acc), len(seq)-1, len(fams))
		eps := 1e-5
		rg := rand.New(rand.NewSource(*seed + 3))
		worst := 0.0
		nonzero := 0
		total := 0
		for _, f := range fams {
			// hasta 4 muestras por familia con |grad analitico| no trivial
			got := 0
			for try := 0; try < 40 && got < 4; try++ {
				i := f.lo + rg.Intn(f.hi-f.lo)
				if math.Abs(an[i]) < 1e-7 {
					continue
				}
				got++
				total++
				nonzero++
				acc[i](+eps, true)
				lp, _ := g.seqLoss(seq)
				acc[i](-2*eps, true)
				lm, _ := g.seqLoss(seq)
				acc[i](+eps, true) // restaurar
				num := (lp - lm) / (2 * eps)
				absErr := math.Abs(num - an[i])
				den := math.Max(1e-8, math.Abs(num)+math.Abs(an[i]))
				rel := absErr / den
				if rel > worst {
					worst = rel
				}
				fmt.Printf("%s[%d] analitico=%.6e numerico=%.6e err_abs=%.3e err_rel=%.3e\n", f.name, i-f.lo, an[i], num, absErr, rel)
			}
			if got == 0 {
				fmt.Printf("%s: sin muestras con gradiente no trivial en 40 intentos (se reporta, no se oculta)\n", f.name)
			}
		}
		verdict := "OK"
		if worst > 1e-3 || nonzero == 0 {
			verdict = "FALLO: no entrenar hasta corregir backward"
		}
		fmt.Printf("GRADCHECK muestras=%d peor_err_rel=%.3e criterio=err_rel<1e-3 -> %s\n", total, worst, verdict)

	case "cost":
		// Coste por paso BPTT (ms) con ventana t sobre datos reales.
		gr := g.newGrads()
		st := g.newAdam()
		seq := raw[:*tlen+1]
		t0 := time.Now()
		n := 50
		for i := 0; i < n; i++ {
			g.trainSeq(seq, gr)
			g.adamApply(st, *lr, gr)
		}
		el := time.Since(t0)
		fmt.Printf("coste/paso=%.2f ms (ventana=%d bytes, H=%d D=%d, %d pasos)\n",
			float64(el.Milliseconds())/float64(n), *tlen, *hh, *d, n)

	case "smoke":
		// Humo: muestra SOLO que la perdida baja con pasos. No afirma nada mas.
		gr := g.newGrads()
		st := g.newAdam()
		r := rand.New(rand.NewSource(*seed + 7))
		t0 := time.Now()
		for s := 0; s < *steps; s++ {
			off := r.Intn(len(raw) - *tlen - 2)
			loss := g.trainSeq(raw[off:off+*tlen+1], gr)
			g.adamApply(st, *lr, gr)
			if (s+1)%50 == 0 {
				fmt.Printf("paso %d bpb_lote=%.4f t=%s\n", s+1, loss, time.Since(t0).Round(time.Second))
			}
		}
		l0, _ := NewGRU(*seed, *d, *hh).seqLoss(raw[len(raw)-2000 : len(raw)-1000])
		l1, _ := g.seqLoss(raw[len(raw)-2000 : len(raw)-1000])
		fmt.Printf("SMOKE bpb_fija_inicial=%.4f bpb_fija_tras_%d_pasos=%.4f duracion=%s (NO es evidencia de conversacion)\n",
			l0, *steps, l1, time.Since(t0).Round(time.Second))
	}
}

// parseUAPairs: extrae pares (pregunta, respuesta) de lineas "U: "/"A: ".
func parseUAPairs(txt string) [][2]string {
	var out [][2]string
	var u string
	have := false
	for _, ln := range strings.Split(txt, "\n") {
		if strings.HasPrefix(ln, "U: ") {
			u = strings.TrimPrefix(ln, "U: ")
			have = true
		} else if strings.HasPrefix(ln, "A: ") && have {
			out = append(out, [2]string{u, strings.TrimPrefix(ln, "A: ")})
			have = false
		}
	}
	return out
}
