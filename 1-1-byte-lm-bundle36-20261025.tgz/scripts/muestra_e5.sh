#!/bin/bash
# Muestra E5 FINAL6: criterios predeclarados + casos fijos (archivada en bundle36).
cd "$(dirname "$0")/.."
echo "== E5 FINAL6 (criterios predeclarados, lectura descriptiva) =="
grep -A7 "Criterios predeclarados" docs/RESULTADOS_E5.md | head -8
echo "== casos fijos L5 (input -> target | salida) =="
cat docs/casos_fijos_e5.txt | head -5
