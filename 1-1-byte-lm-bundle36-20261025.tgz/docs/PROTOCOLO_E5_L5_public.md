# Pasada E5: extension a L5 con retencion L4

## Objetivo
Comprobar si el MISMO modelo (ck_A6, sha 663c2fa14d7c07b934efdee96a7bd6d7321e692f4e782d33a561631534e258d1)
aprende la tarea de copia en longitud 5 SIN perder la capacidad L4 confirmada
ni la metrica natural. Base de extension: ck_A6 PRESERVADO (no E6, no reset,
no semillas nuevas de modelo): Adam GRU, Adam copy (t_copy=3024), RNG sampler
y metadata continuan fieles.

## Mecanismo de extension (codigo YA implementado y testeado)
- Nueva flag `-seq-ext-prev <sha completo>`: extension DECLARADA de secuencia.
  Sin ella, un sha de seq distinto se RECHAZA (comportamiento historico intacto).
  Con ella: exige ext-prev == sha seq del checkpoint, exige sha nuevo distinto,
  y VERIFICA BYTE-EXACTO que los primeros <cursor> indices del fichero nuevo,
  serializados en canonico, reproducen la seq previa declarada (sha). Si el
  prefijo no cuadra, RECHAZA antes de tocar el optimizador. Solo entonces el
  cursor MIGRA FIEL (seqBase = seq_pos del checkpoint = 3024) y el nuevo
  checkpoint registra seq_ext_prev (metadata versionada). Es extension
  verdadera (prefijo verificado en codigo), no transicion versionada a seca.
- Transicion de dataset: via -master-prev existente (verificaMaestro):
  master_mix8 sha 9fc4b760a2bcda9b... con prev = master_mix7 sha declarada.
- Tests (4 nuevos, suite completa PASS 94.6s):
  - TestSeqResumeBaseRamas: 5 ramas (mismo sha; sha distinto sin declarar ->
    RECHAZO; ext-prev==nuevo -> RECHAZO; ext-prev erroneo -> RECHAZO; extension
    declarada -> cursor migra). Fixtures no vacuas, cada rama con su causa.
  - TestMigracionFria200vs100y100: paridad EXACTA 200 pasos de una vez vs
    100+100 con save/load frio real (saveCopy/loadCopyStrict), misma head y
    mismo estado de optimizador; JSON final identico salvo bpb_val (metadata
    justificada: metrica de val recomputada en cada guardado, no es estado del
    modelo). No vacua: loss 4.306 -> 1.852. Sin oracle inference.
  - TestSeqExtPrefijoByteExacto: prefijo correcto -> OK; 1 indice alterado ->
    RECHAZO; prev distinto del real -> RECHAZO; fichero mas corto que el
    cursor -> RECHAZO ("prefijo imposible").
  - TestExtCursorContinuaEnK: tras migrar, el paso k=0 consume el indice 3024
    (no 0 ni 3023); el cursor persiste en checkpoints intermedios tras
    save/load frio; una segunda extension debe declarar el sha nuevo y su
    fichero debe contener el prefijo completo (8) o se rechaza.
  - Fixtures CLI reales (sin entrenamiento): prefijo alterado + prev correcto
    -> panic RECHAZO "prefijo alterado", sin checkpoint de salida; fichero
    correcto + prev correcto + -steps 0 -> "PREFIJO byte-exacto verificado,
    cursor=3024 MIGRA FIEL".

## Datos (congelados con SHA, manifest replay/manifest_ext_l5.json)
- master_mix8.txt (1512 pares) = master_mix7 (1008, MISMO ORDEN: indices
  0..1007 identicos) + 504 pares L5 NUEVOS (indices 1008..1511).
  Ratios declarados: 1/3 L4 replay (504), 1/3 L5 nuevo (504), 1/3 natural
  (504). Copy:natural pasa de 1:1 (mix7) a 2:1 (mix8) — declarado.
- Operandos L5 nuevos: UNA corriente sha256(seed) con seed 20261027
  (declarada en el manifiesto como shuffle_seed_explicita antes del run),
  consumida en orden fijo: 1) operandos L5, 2) segmento seq_comp8,
  3) segmento seq_comp8c. [a-z]^5, 252 repite + 252 invierte, unicos
  globales, 0 solapes
  vs TODOS los operandos previos incluidos evalconf (866 extraidos). 0
  palindromos; 170 con letras repetidas (declarados, no filtrados).
- seq_comp8.txt (6048) = seq_comp7 (3024, PREFIJO BYTE-EXACTO verificado) +
  segmento nuevo 3024 uniforme sobre 1512 (cada par EXACTAMENTE 2
  exposiciones, orden barajado con seed declarada). Cursor de extension: 3024.
- Held sets (sin tocar): L5 = evalconf_L5_48 (reservado, nunca entrenado),
  L6 test = evalconf_L6_48 (separado), retencion L4 = dst7_heldL48 +
  evalconf_L4_48, natural = ciclo1_heldout100.
  Nota de superficies: dst7_heldL48 es DEV REUTILIZADO del corte A/B (mismos
  operandos ya usados en desarrollo): un positivo ahi es lectura de
  retencion sobre DEV reusado, NO validacion confirmatoria independiente.
  La validacion independiente ya se hizo (corte confirmatorio, operandos
  nuevos seed 20261026); otra validacion seria un corte nuevo con operandos
  nuevos.

## Control (UNO, mismo ck_A6 base, mismos pasos)
- Brazo CONTROL: mix7 (1008 pares) + seq_comp8c.txt (6048 entradas =
  prefijo seq_comp7 byte-exacto + segmento control nuevo de 3024 a 3
  exposiciones/par; cursor migra 3024 igual que A). La comparacion es
  "+datos L5 con replay" vs "+mas replay L4/natural" A IGUAL PASOS (3024):
  con la misma exposicion total, aisla el efecto de la via de exposicion
  sobre la retencion L4. ASIMETRIA DECLARADA: el segmento control da 3
  expos/par vs 2 (un segmento de 2016 a 2 expos no llenaria el cursor
  migrado de 3024 pasos). La lectura de ESTRATEGIA se afirma como mucho con
  esta lectura acotada, nunca como prueba aislada limpia.
  (Nota: una version previa de seq_comp8c de 3024 entradas se retiro ANTES
  de cualquier ejecucion: el cursor migrado (3024) habria caido en el FIN
  del fichero en el primer paso.)
- NO 5 brazos. FINAL2 cerrado. Sin extension automatica a otras longitudes.

## Criterios PREDECLARADOS (corte FINAL de 6 bloques x 504 pasos = 3024)
- Primario L5: evalconf_L5_48 >= 40/48 (convencion, mismo umbral que L4; no
  promocion ni algoritmo general).
- Retencion L4: dst7_heldL48 >= 44/48 Y evalconf_L4_48 >= 40/48.
- Retencion natural: bpb_heldout100 deterioro < 0.5 vs A6 (3.315002), con head.
- L6: cuentas exactas; cualquier >0 no es exito (longitud no entrenada).
- Superficie oficial: genpairs n=12 temp=0 con head + dst6_score (mismo
  oraculo, tabla extendida versionada). Control: mismas superficies y cortes.

## Coste (estimacion FUNDADA en medidas archivadas; medicion real previa al full)
- Medido real A/B: bloque 504 pasos con head = 15-16s (corpus 1008 pares).
- Nota (log tecnico): en la preparacion se ejecuto un fixture de 504 pasos
  reales que excedia el tamano de fixture previsto (200 sinteticos); se
  desecho, no alimenta ningun brazo y queda excluido del analisis. Durante
  la depuracion del fixture CLI, una build desactualizada del binario
  ejecuto 1 paso sobre un checkpoint sintetico (tambien desechado). Ambos
  registrados como desviacion tecnica controlada; ck_A6/B6 intactos (sha
  verificado).
- MEDICION REAL del fixture de coste (checkpoint base publica etapa0, NO
  ck_A6; fixture desechado, no es el experimento): bloque 504 pasos sobre
  mix8 (1512 pares) con head = 15.3s wall, RSS 28MiB, y la maquinaria de
  extension verificada end-to-end (transicion de curriculo declarada, cursor
  seq 504, copy.t 504, metadata fiel; bpb_val 7.5797 identica al A1
  historico: mismo orden de datos, cross-check de consistencia).
- Estimacion FUNDADA: 6 bloques ~92s + 7 cortes x ~5s (3 gens + 2 gens L5/L6
  + score) ~35s => brazo ~130s; dos brazos ~260s; cap propuesto 300s/brazo
  externo duro, bloque 40s, RSS 900MiB.
- Caps aplicados: wall 300s/brazo externo duro, bloque 40s, RSS 900MiB,
  primer fallo = PARAR ambos brazos SIN recovery.

## Asserts en caliente por bloque k (1..6)
steps=3504+504k, seq_pos=3024+504k, copy.t=3024+504k, adam.t=3504+504k,
seq_sha por brazo (A: seq_comp8; B: seq_comp8c), seq_ext_prev=seq_comp7 sha
en ambos, ckpt_version=2, formas copy.
