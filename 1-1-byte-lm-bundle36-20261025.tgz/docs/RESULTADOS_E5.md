# Pasada E5 (extension a L5 con retencion L4) — RESULTADOS

## Diseno (UNA comparacion, base comun)
- Base: checkpoint A6 del corte A/B anterior (sha256 663c2fa14d7c07b934efdee96a7bd6d7321e692f4e782d33a561631534e258d1), SIN reset: Adam GRU, Adam copy (t=3024), RNG y metadata continuan fieles. 6 bloques x 504 pasos NUEVOS por brazo (3024 pasos).
- Brazo A8: master_mix8 (1512 pares = mix7 + 504 L5 nuevos; ratios 1/3 L4 replay, 1/3 L5, 1/3 natural) + seq_comp8 (6048 = prefijo seq_comp7 byte-exacto + 3024 nuevos, 2 exposiciones/par).
- Brazo B7 (control): master_mix7 (1008) + seq_comp8c (6048 = prefijo seq_comp7 byte-exacto + 3024 control, 3 exposiciones/par). Misma base y mismos pasos; SIN datos L5.
- Extension de secuencia verdadera: prefijo byte-exacto verificado en codigo y cursor migrado fiel (seq_ext_prev persistido en todos los tramos).
- Comparacion A8 vs B7 DESCRIPTIVA: difieren en composicion de datos (L5 presente/ausente) y exposiciones/par (2 vs 3); no aisla un efecto de estrategia.
- Superficies: genpairs n=12 temp=0 con head + oraculo dst6/evalconf (misma semantica, allowlist full-sha). dst7_heldL48 y los cortes evalconf son superficies DEV REUTILIZADAS: los positivos son lecturas descriptivas; la validacion independiente requiere operandos nuevos (corte futuro, no incluido aqui).

## Congelado (sha256)
- mzab_v3: 77d01528f9bb2f1eba0c7afaa4c914bcabd5d6f8b8deb642b1d59651481bf75d
- master_mix8: 9fc4b760a2bcda9b405abf04f003536d6d27b2d7570f0e20ab29533cfa39baa3
- master_mix7: 0554e479f9c1b6cbbfd42069e31ec5e6fd0c691829c1c06d341bf482248ce03d
- seq_comp8: e7278e1061f7ef8c26965893e33bf8e1569f9479dab61c26541772979e0f7e76
- seq_comp8c: 3275910d330ef70f408b7e0c0c810dbf9202277cebf936c028bcb2e82a634bab
- seq_comp7 (prev declarado): 07e29a3e3c8ef87cfc274bc1280322c21237d2c8a6ca603396554025d07e36df
- Manifiesto de datos y semilla de generacion (corriente unica 20261027, orden de consumo declarado): manifest_ext_l5.json

## Corte base (PREUPDATE, modelo A6 sin pasos nuevos; compartido por ambos brazos)
| corte | train504 | heldL48 | heldLong48 | bpb_nat | ecL4 | ecL5 | ecL6 |
|---|---|---|---|---|---|---|---|
| BASE0 | 501/504 | 47/48 | 0/48 | 3.315002 | 48/48 (24/24R/24/24I) | 0/48 (0/24R/0/24I) | 0/48 (0/24R/0/24I) |

## Brazo A8 (todos los cortes)
| corte | train504 | heldL48 | heldLong48 | bpb_nat | ecL4 | ecL5 | ecL6 |
|---|---|---|---|---|---|---|---|
| A81 | 384/504 | 34/48 | 23/48 | 3.411106 | 39/48 (24/24R/15/24I) | 20/48 (20/24R/0/24I) | 0/48 (0/24R/0/24I) |
| A82 | 329/504 | 28/48 | 24/48 | 3.360490 | 29/48 (24/24R/5/24I) | 28/48 (24/24R/4/24I) | 2/48 (2/24R/0/24I) |
| A83 | 497/504 | 47/48 | 23/48 | 3.336540 | 48/48 (24/24R/24/24I) | 24/48 (24/24R/0/24I) | 0/48 (0/24R/0/24I) |
| A84 | 502/504 | 48/48 | 24/48 | 3.300381 | 48/48 (24/24R/24/24I) | 25/48 (21/24R/4/24I) | 0/48 (0/24R/0/24I) |
| A85 | 503/504 | 48/48 | 24/48 | 3.290230 | 48/48 (24/24R/24/24I) | 48/48 (24/24R/24/24I) | 0/48 (0/24R/0/24I) |
| A86 | 504/504 | 48/48 | 24/48 | 3.282555 | 48/48 (24/24R/24/24I) | 47/48 (24/24R/23/24I) | 0/48 (0/24R/0/24I) |

## Brazo B7 control (todos los cortes)
| corte | train504 | heldL48 | heldLong48 | bpb_nat | ecL4 | ecL5 | ecL6 |
|---|---|---|---|---|---|---|---|
| B71 | 504/504 | 48/48 | 0/48 | 3.334712 | 48/48 (24/24R/24/24I) | 0/48 (0/24R/0/24I) | 0/48 (0/24R/0/24I) |
| B72 | 504/504 | 48/48 | 0/48 | 3.316117 | 48/48 (24/24R/24/24I) | 0/48 (0/24R/0/24I) | 0/48 (0/24R/0/24I) |
| B73 | 504/504 | 48/48 | 0/48 | 3.209226 | 48/48 (24/24R/24/24I) | 0/48 (0/24R/0/24I) | 0/48 (0/24R/0/24I) |
| B74 | 504/504 | 48/48 | 0/48 | 3.148961 | 48/48 (24/24R/24/24I) | 0/48 (0/24R/0/24I) | 0/48 (0/24R/0/24I) |
| B75 | 468/504 | 46/48 | 0/48 | 3.193060 | 43/48 (22/24R/21/24I) | 0/48 (0/24R/0/24I) | 0/48 (0/24R/0/24I) |
| B76 | 501/504 | 48/48 | 0/48 | 3.300324 | 48/48 (24/24R/24/24I) | 0/48 (0/24R/0/24I) | 0/48 (0/24R/0/24I) |

## Criterios predeclarados (corte FINAL6) — lectura descriptiva
| criterio | umbral | A8 FINAL6 | B7 FINAL6 |
|---|---|---|---|
| Primario L5 (evalconf_L5_48) | >= 40/48 | 47/48 CUMPLE | 0/48 |
| Retencion L4 dst7_heldL48 | >= 44/48 | 48/48 CUMPLE | 48/48 |
| Retencion L4 evalconf_L4_48 | >= 40/48 | 48/48 CUMPLE | 48/48 |
| Natural (bpb heldout100, con head) | deterioro < 0.5 vs 3.315002 | 3.282555 CUMPLE (sin deterioro) | 3.300324 CUMPLE |
| L6 (no entrenada) | cuentas exactas | 0/48 | 0/48 |

Lectura: con exposicion a datos L5 (A8) el modelo aprende la tarea de copia en
longitud 5 (47/48: repite 24/24, invierte 23/24) SIN perder L4 (48/48 en ambas
superficies) ni la metrica natural; sin datos L5 (B7) la retencion se mantiene
igual y L5 queda en 0/48. Comparacion descriptiva sobre superficies DEV
reutilizadas; NO es validacion confirmatoria independiente ni evidencia de una
longitud general, y L6 permanece en 0/48 (longitud no entrenada).

## Desviacion tecnica registrada (adenda)
Durante la ejecucion, el tramo 2 del brazo A8 se guardo sin el campo de
procedencia seq_ext_prev (defecto de persistencia en resumes mismo-sha). La
guarda predeclarada lo detecto y la ejecucion se PARO en ese punto. El codigo
se corrigio (propagacion verificada con tests y fixtures de cadena en frio), y
el tramo afectado — cuyo computo y consumo de secuencia fueron correctos — se
completo con una correccion de METADATA explicita sobre copia derivada (un
unico campo; original preservado; trazabilidad en MANIFIESTO_FIX_A82.txt). No
se reentreno ningun tramo. Adicionalmente, en la preparacion se ejecutaron dos
corridas fuera del tamano de fixture previsto (504 pasos reales para medir
coste; 1 paso con una build desactualizada durante la depuracion del fixture
CLI), ambas desechadas y excluidas del analisis. Nada de ello se presenta como
"corridas sin fallos".

## Coste real
Tiempo activo: A8 92s, B7 119s, base 4s (total ~215s activo; pausas de
coordinacion no computan). Bloques 10-17s (cap 40s). RSS maximo observado
31MiB (cap 900MiB). Caps respetados.
