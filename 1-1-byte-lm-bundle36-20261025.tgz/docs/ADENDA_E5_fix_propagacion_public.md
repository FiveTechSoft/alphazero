# Adenda tecnica E5: propagacion de seq_ext_prev en checkpoints derivados

## Hecho observado
En la pasada E5, el checkpoint del segundo tramo de un brazo (resume mismo-sha,
sin flag) se guardo SIN el campo seq_ext_prev: el campo solo viajaba cuando la
invocacion recibia el flag de extension. La guarda caliente predeclarada
("seq_ext_prev presente y correcto en todos los tramos") lo detecto y la
ejecucion se paro en ese punto, sin reintentos.

## Cambio tecnico
El guardado hereda seq_ext_prev del checkpoint cargado cuando el tramo no
declara una extension nueva; una extension nueva (flag) siempre prevalece.
Ningun otro campo se ve afectado: pesos, momentos del optimizador, RNG,
cursor, maestro y secuencia no cambian su semantica.

## Evidencia
- Test nuevo (cadena de 3 tramos mismo-sha): el campo persiste en los tramos
  2 y 3; una cadena sin extension NO gana el campo. El test falla con el
  codigo previo y pasa con el corregido (no vacuo).
- Test de migracion fria 200 vs 100+100: invariantes EXPECTED explicitos
  (steps, cursor, sha de seq, semillas, adam) ademas de la igualdad mutua.
- Fixture CLI de cadena en frio: extension declarada en el tramo 1 (prefijo
  byte-exacto verificado, cursor migra) y el campo persiste en los tramos 2
  y 3 (resume mismo-sha, sin flag). Negativos con causa explicita: prev
  incorrecto -> RECHAZO sin checkpoint de salida; version desconocida ->
  error explicito; version ausente -> migracion v1 declarada (no silenciosa).

## Recuperacion del tramo afectado (correccion de metadata trazada)
El tramo entrenado antes de la parada quedo intacto (sha original
face8b52a0cde4b74cf1d7140719fb5f9833db88ea60c3cf6e247de699153456) y NO se
reentreno: el computo y el consumo de secuencia fueron correctos; solo
faltaba el campo de procedencia. Se adopto como checkpoint oficial una
correccion de METADATA sobre copia derivada: mismo contenido + seq_ext_prev
= sha de la secuencia previa de la cadena. Diferencia a nivel de campos:
UNICAMENTE seq_ext_prev (verificado). sha del checkpoint oficial corregido:
7034bf2fdf22c77ba519039b751a80871c755b1b026b51565c1d00c7f1634567. Carga
correctamente y genera salida identica al original. Original preservado sin
tocar; trazabilidad completa en MANIFIESTO_FIX_A82.txt.
