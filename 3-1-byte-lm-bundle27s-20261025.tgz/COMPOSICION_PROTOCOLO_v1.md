# COMPOSICION — PROTOCOLO v1 (propuesta, SIN training autorizado)
# Pregunta: con TODOS los simbolos (palabras y ops) vistos en train, aprende
# el modelo a recombinar (regla) o memoriza celdas? Separado el canal
# identidad (COPIA: emitir el operando) de la transformacion (regla).
# Diagnostico elegido (uno, sin ronda abierta de alternativas): matriz
# palabra x op con celdas reservadas ANTES de entrenar. Justificacion: la
# sonda CROSS24 sobre ck_T6 midio 0/24 en combinaciones no entrenadas, pero
# ese checkpoint vio cada palabra con UNA sola op: mide memoria de ajuste,
# no aisla op vs identidad. La matriz expone cada operando y cada op varias
# veces y reserva CELDAS y PALABRAS distintas: el fallo/acierto en celdas
# reservadas solo es explicable por recombinacion (todos los simbolos son
# vistos), y COPIA separa "emitir el operando" de "transformarlo".

## Datos (congelados, fixtures 9/9 PASS)
- dst4_train.txt   84 pares (12 palabras x 7 ops; sha16 8690b011ceb4d088)
- dst4_held24.txt  24 celdas reservadas (sha16 32f1df99dcf85aec)
- dst4_newword36.txt 36 pares: 4 palabras RESERVADAS x 9 ops (sha16
  3f57ecac088d3413) — incluye COPIA x4 (canal identidad puro en palabra nueva)
- ops: las 8 DST + COPIA (op LOCAL de dst4: respuesta = la palabra; el modelo
  no recibe reglas, solo datos). 0 colisiones proxy vs TODOS los conjuntos
  previos y naturales (reales, fixture con rechazo de ausente/vacio).

## Entrenamiento (misma receta estable medida; SIN cambios de regimen)
- Base: MISMO clon etapa0 (declarado); replay 50/50 con 84 naturales sub500
  file-order (subconjunto declarado); 6 bloques x 504 pasos (ciclo 1008 =
  84 DST x6 + 84 nat x6), seq completa 3024 congelada ANTES de arrancar
  (ciclos shuffle seeds 20261025/26/27, prefijo = ciclo 1).
- lr 0.003, seed 7, curriculo declarado -master-prev sub500. Ledger, guarda
  bloque >15s (medido 12s/480 -> 504 ~13s +~15%), proyeccion >180, primer
  fallo PARA, sin retries. Tope 180s wall total declarado.
- Evals por bloque: exact train84 / held24 / newword36 (genpairs -n 16
  -temp 0, oraculo offline), bpb heldout100 (retencion).

## Criterio predeclarado (cuentas, no "prueba"; umbrales = convencion)
- Primario: exact held24 >= 6/24 = recombinacion medida a esta escala;
  <= 2/24 = no medida; 3-5 = ambiguo, reportado sin conclusion.
- Canal identidad: exact COPIA en held (3 celdas) y newword (4) reportado
  aparte: si COPIA falla tambien, el cuello medido es anterior a la regla
  (emitir el operando); si COPIA ok y ops fallan, el cuello es la
  transformacion, no el canal.
- Secundario: train84 exact (memorizacion de celdas vistas), newword36 por
  op, retencion por bloque. Controles: cobertura total de simbolos en train
  (fixture), azar ~0. NINGUNA afirmacion capacidad-vs-cobertura causal desde
  este diseno: mide recombinacion EN ESTE regimen/escala. Sin adopcion.
- No ampliar sondas ni bloques post-hoc si el resultado es negativo.

## Coste fundado: bloque mixto medido 12s/480 -> 504 ~13s; 6 bloques ~78s +
evals ~6s/bloque ~36s + base ~6s = ~120s estimado; tope 180s declarado.

## Adendo v1.1 (correcciones aplicadas antes de entrenar)

1. Un acierto en una celda reservada NO es "solo explicable por recombinación". Análisis de solapes medido sobre los datasets congelados: en HELD24, 0/24 targets coinciden con alguna respuesta de train (global ni de la misma palabra por otra operación), 0/24 con operaciones equivalentes (misma salida por transformación distinta); en NEWWORD36, 0/36 y 0/36 respectivamente. Palabras con caracteres repetidos: 8/24 held, 9/36 newword (factor de dificultad declarado; afecta interpretación, no invalidez). Por tanto ningún acierto held puede atribuirse a recuperación literal del target; pero aciertos por sesgo o azar siguen siendo posibles y el criterio es una convención de cuentas, no una prueba de regla abstracta.
2. COPIA es una medición descriptiva por operación: un fallo en COPIA no localiza causalmente la etapa anterior a la regla, y un acierto en COPIA no excluye fallo de canal en otras operaciones (los contextos de entrada cambian entre operaciones).
3. El rédito NO es el "mismo régimen" estricto que réplica §2: 84 naturales (no 96) y 84 DST cambian las exposiciones; es la MISMA receta (mezcla 50/50, 6 bloques ×504) aplicada a un experimento nuevo, no un control causal frente a 3b.
4. Split validado pre-entrenamiento: 0 celdas held/newword presentes en train (0 pares exactos entrenados). Solapes semánticos reales: ninguno detectado (punto 1); se reportan sin ocultar.
5. Evaluación de los 6 bloques planificados sin parar en el primer acierto; el resultado primario es el del BLOQUE 6; la trayectoria por bloques es descriptiva.
6. Umbrales (≥6/24) = convención previa no validada estadísticamente; se reportan cuentas exactas.

Artefactos congelados: master_mix4.txt sha16 580b16020441b46e, man_mix4.txt sha16 e5481633fdc5f0f9, seq_comp4.txt (3024 = 3 ciclos ×1008, semillas 20261025/26/27) sha16 7e77523dfdabb6a4. Fixture: 84 DST + 84 naturales (ciclo1_sub500 primeros 84 por orden), 0 colisiones vs heldout100/finales ni internas DST/nat (clave proxy [a-z0-9]+ minúsculas prefijo 40).
