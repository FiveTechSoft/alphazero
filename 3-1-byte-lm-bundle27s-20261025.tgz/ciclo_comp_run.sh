#!/bin/bash
# COMPOSICION v1: clon BASE etapa0, replay 50/50
# (84 DST dst4_train + 84 nat sub500), 6 bloques x 504 = 3024, seq_comp4 sha16
# 7e77523dfdabb6a4. Tope 180s wall; guarda bloque >15s; proyeccion +15>180 PARA;
# primer fallo PARA, sin retries; RSS<900MiB medido por bloque. Eval de los 6
# bloques sin corte por acierto; primario = bloque 6; trayectoria descriptiva.
set -e; cd /tmp/blm
PREV=c8ee772eb1d2dfe4c2ea8ffc38d991f07750309d449eff53f82d63af3476b355
TSTART=$SECONDS
mkdir -p ciclo_comp
rssmax() { python3 -c "import resource,sys;kb=json.load(open('/dev/stdin'))" 2>/dev/null || true; }
runmz() { # etiqueta args... -> ejecuta mz midiendo RSS hijo
  local tag=$1; shift
  python3 - "$tag" "$@" <<'PYEOF'
import subprocess, resource, sys, json
tag, args = sys.argv[1], sys.argv[2:]
r = subprocess.run(["./mz"]+args)
kb = resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
print(f"RSSMAX {tag} {kb} KiB")
sys.exit(r.returncode)
PYEOF
}
bloque() { # K CKIN CKOUT PREVFLAG
  local K=$1 IN=$2 OUT=$3 PF=$4
  local INSHA; INSHA=$(sha256sum "$IN" | cut -c1-12)
  local KEY="S4C${K}_${INSHA}"; local LED="ciclo_comp/ledger_$KEY"
  if [ -e "$LED" ]; then
    local ST; ST=$(cut -d' ' -f1 "$LED")
    [ "$ST" = completed ] && { echo "LEDGER $KEY ya completada"; return 0; }
    echo "LEDGER $KEY estado=$ST: recuperacion manual; NO reejecuta"; exit 3
  fi
  local el=$((SECONDS-TSTART))
  if [ $((el+15)) -gt 180 ]; then echo "PARADA proyeccion ${el}s+15 > 180s"; exit 5; fi
  echo "running $(date -Is)" > "$LED.tmp"; mv "$LED.tmp" "$LED"
  trap 'if [ -n "${LED:-}" ]; then echo "failed $(date -Is)" > "$LED.tmp"; mv "$LED.tmp" "$LED"; fi' ERR
  local t0=$SECONDS
  runmz C$K d1gru -mode train-pairs -corpus replay/master_mix4.txt -val dst4_held24.txt \
    -in "$IN" -out "$OUT" -steps 504 -lr 0.003 -seed 7 \
    -master replay/master_mix4.txt -manifest replay/man_mix4.txt -seq replay/seq_comp4.txt $PF 2>&1 | grep -E 'FIN|RECHAZO|seq predefinida|RSSMAX'
  local dt=$((SECONDS-t0))
  if [ $dt -gt 15 ]; then
    echo "failed $(date -Is) GUARDA bloque ${dt}s > 15s" > "$LED.tmp"; mv "$LED.tmp" "$LED"
    echo "PARADA: bloque C$K ${dt}s > 15s"; exit 4
  fi
  echo "completed $(date -Is) segundos=$dt" > "$LED.tmp"; mv "$LED.tmp" "$LED"
  echo "OK bloque C$K ${dt}s"
}
evalu() { # CK NOMBRE
  timeout -k 2 10 ./mz d1gru -mode genpairs -in "$1" -corpus dst4_train.txt -n 16 -temp 0 > ciclo_comp/gentrain_$2.txt 2>/dev/null
  timeout -k 2 10 ./mz d1gru -mode genpairs -in "$1" -corpus dst4_held24.txt -n 16 -temp 0 > ciclo_comp/genheld_$2.txt 2>/dev/null
  timeout -k 2 10 ./mz d1gru -mode genpairs -in "$1" -corpus dst4_newword36.txt -n 16 -temp 0 > ciclo_comp/gennw_$2.txt 2>/dev/null
  local TT; TT=$(python3 dst4_score.py dst4_train.txt ciclo_comp/gentrain_$2.txt | python3 -c "import json,sys;d=json.load(sys.stdin);print(d['exact_total'],d['por_op'].get('COPIA','-'))")
  local DT; DT=$(python3 dst4_score.py dst4_held24.txt ciclo_comp/genheld_$2.txt | python3 -c "import json,sys;d=json.load(sys.stdin);print(d['exact_total'],d['por_op'].get('COPIA','-'))")
  local NW; NW=$(python3 dst4_score.py dst4_newword36.txt ciclo_comp/gennw_$2.txt | python3 -c "import json,sys;d=json.load(sys.stdin);print(d['exact_total'],d['por_op'].get('COPIA','-'))")
  local RT; RT=$(timeout -k 2 10 ./mz d1gru -mode scorepairs -in "$1" -corpus ciclo1_heldout100.txt 2>/dev/null | awk '$1=="SCORE"{s+=$3;c++} END{printf "%.6f", s/c}')
  echo "== $2 train84=$TT held24=$DT newword36=$NW bpb_heldout=$RT"
}
cp ciclo1_etapa0.json ciclo_comp/ck_C0.json
for K in 1 2 3 4 5 6; do
  P=$((K-1)); PF=""; [ $K = 1 ] && PF="-master-prev $PREV"
  bloque $K ciclo_comp/ck_C${P}.json ciclo_comp/ck_C${K}.json "$PF"
  evalu ciclo_comp/ck_C${K}.json C$K
done
echo "WALL COMPOSICION: $((SECONDS-TSTART))s (tope 180s)"
