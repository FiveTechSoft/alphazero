#!/usr/bin/env python3
# dst4_check.py — fixtures matriz composicion. RECHAZA ausentes/vacios.
import sys, os, re, json
sys.path.insert(0,'/tmp/blm')
from dst_gen import aplica, clave
fails=[]
def check(n,ok,d=''):
    print(('PASS' if ok else 'FAIL'),n,d)
    if not ok: fails.append(n)
def lee(path):
    if not os.path.exists(path) or os.path.getsize(path)==0:
        raise SystemExit('FALTA o VACIO '+path)
    lines=open(path).read().strip().split('\n')
    return [(lines[i][3:], lines[i+1][3:]) for i in range(0,len(lines),2)]
pat=re.compile(r"aplica (\S+) a '([a-z]+)'$")
tr=lee('dst4_train.txt'); ho=lee('dst4_held24.txt')
nw=lee('dst4_newword36.txt')
check('train 84 / held 24 / newword 36', len(tr)==84 and len(ho)==24 and len(nw)==36, f'{len(tr)}/{len(ho)}/{len(nw)}')
celdas_tr={(pat.match(u).group(1),pat.match(u).group(2)) for u,_ in tr}
celdas_ho={(pat.match(u).group(1),pat.match(u).group(2)) for u,_ in ho}
check('sin solape train/held', not (celdas_tr & celdas_ho))
wt={pat.match(u).group(2) for u,_ in tr}; wh={pat.match(u).group(2) for u,_ in ho}
ot={pat.match(u).group(1) for u,_ in tr}; oh={pat.match(u).group(1) for u,_ in ho}
check('toda palabra held esta en train', wh<=wt, f'{len(wh&wt)}/12')
check('toda op held esta en train', oh<=ot, f'{len(oh&ot)}/9')
check('toda palabra con 7 ops train', all(sum(1 for u,_ in tr if pat.match(u).group(2)==w)==7 for w in wt))
check('toda op con >=9 palabras train (regla declarada <=3 held por op)', all(sum(1 for u,_ in tr if pat.match(u).group(1)==o)>=9 for o in ot))
check('palabras reservadas AUSENTES de train', not ({pat.match(u).group(2) for u,_ in nw} & wt))
ok=True
for u,a in tr+ho+nw:
    m=pat.match(u)
    op=m.group(1); w=m.group(2)
    esp = w if op=='COPIA' else aplica([op],w)
    if esp!=a: ok=False
check('oraculo consistente en 144 celdas (COPIA=identidad)', ok)
cex=set()
for p in ('/tmp/blm/ciclo1_sub500.txt','/tmp/blm/ciclo1_heldout100.txt','/tmp/blm/ciclo1_final100.txt','/tmp/blm/ciclo2_final100_v2.txt','/tmp/blm/train.txt'):
    if not os.path.exists(p) or os.path.getsize(p)==0: raise SystemExit('FALTA o VACIO '+p)
    for l in open(p):
        if l.startswith('U: '): cex.add(clave(l[3:].rstrip('\n')))
for f in ('/tmp/blm/dst_train.txt','/tmp/blm/dst_dev.txt','/tmp/blm/dst_control.txt','/tmp/blm/dst_final.txt','/tmp/blm/dst3b_train.txt','/tmp/blm/dst3b_dev.txt','/tmp/blm/dst3b_control.txt'):
    if not os.path.exists(p) or os.path.getsize(p)==0: raise SystemExit('FALTA o VACIO '+f)
    for l in open(f):
        if l.startswith('U: '): cex.add(clave(l[3:].rstrip('\n')))
col=sum(1 for u,_ in tr+ho+nw if clave(u) in cex)
check('0 colisiones proxy vs TODOS los conjuntos previos y naturales', col==0, f'col={col}')
print('FAILS:',len(fails)); sys.exit(1 if fails else 0)
