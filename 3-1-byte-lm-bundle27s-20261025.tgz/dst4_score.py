#!/usr/bin/env python3
# exact match POR OPERACION para dst4 (8 ops DST + COPIA identidad local).
# Uso: dst4_score.py PARES GENS
import sys, re, json
sys.path.insert(0,'/tmp/blm')
from dst_gen import aplica
def aplica9(op,w): return w if op=='COPIA' else aplica([op],w)
pares=open(sys.argv[1]).read().strip().split('\n')
gens=[l.rstrip('\n') for l in open(sys.argv[2])]
n=len(pares)//2; assert len(gens)==n, (len(gens),n)
per={}
for i in range(n):
    u=pares[2*i][3:]; m=re.match(r"aplica (\S+) a '([a-z]+)'$", u)
    op,w=m.group(1),m.group(2)
    per.setdefault(op,[0,0]); per[op][1]+=1
    if gens[i].strip()==aplica9(op,w): per[op][0]+=1
tot_ok=sum(v[0] for v in per.values())
print(json.dumps({'exact_total':f'{tot_ok}/{n}','por_op':{k:f'{v[0]}/{v[1]}' for k,v in sorted(per.items())}}))
