#!/usr/bin/env python3
# dst4_gen.py — MATRIZ palabra x op (COMPOSICION vs memoria de celdas) con
# canal IDENTIDAD separado (COPIA = canal basico: emitir el operando).
# 9 ops = 8 DST + COPIA (local a dst4: respuesta = la propia palabra).
# 12 palabras train x 9 ops = 108 celdas; held-out FIJO: por palabra i las
# ops en posiciones i%9 y (i+3)%9 -> 24 celdas held / 84 train; toda palabra
# y toda op presentes en train (solo las CELDAS son nuevas).
# 4 palabras RESERVADAS (nunca en train) x 9 ops = 36 sonda palabras nuevas.
import random, json, hashlib, sys
sys.path.insert(0,'/tmp/blm')
import dst_gen
OPS = dst_gen.OPN + ['COPIA']
def aplica9(op, w):
    return w if op=='COPIA' else dst_gen.aplica([op], w)
rng=random.Random(20261027)
def palabra():
    while True:
        w=''.join(rng.choice('abcdefghijklmnpqrstuvwxyz') for _ in range(4))
        if len(set(w))>=3: return w
ws=set()
while len(ws)<16: ws.add(palabra())
ws=sorted(ws); words, newwords = ws[:12], ws[12:]
train=[]; held=[]
for i,w in enumerate(words):
    ho={i%9,(i+3)%9}
    for j,op in enumerate(OPS):
        (held if j in ho else train).append((op,w))
neww=[(op,w) for w in newwords for op in OPS]
def escribe(path,items):
    with open(path,'w') as f:
        for op,w in items: f.write(f"U: aplica {op} a '{w}'\nA: {aplica9(op,w)}\n")
escribe('dst4_train.txt',train); escribe('dst4_held24.txt',held); escribe('dst4_newword36.txt',neww)
meta={'ops':OPS,'palabras_train':words,'palabras_reservadas':newwords,
 'regla_split':'held-out ops i%9 y (i+3)%9 por palabra i (orden alfabetico)',
 'train':84,'held24':24,'newword36':36,'seed_palabras':20261027,
 'canal_identidad':'COPIA respuesta=palabra; separa emitir operando de transformar',
 'nota':'COPIA es op local de dst4 (datos/oraculo); el modelo no recibe reglas'}
open('dst4_meta.json','w').write(json.dumps(meta,indent=1))
for f in ('dst4_train.txt','dst4_held24.txt','dst4_newword36.txt'):
    print(f, hashlib.sha256(open(f,'rb').read()).hexdigest()[:16], sum(1 for _ in open(f))//2, 'pares')
