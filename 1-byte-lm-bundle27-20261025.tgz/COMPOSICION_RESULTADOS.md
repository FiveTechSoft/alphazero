# COMPOSICION v1 — Resultados (2026-10-25)

Ejecutado según COMPOSICION_PROTOCOLO_v1.md + adendo v1.1 (autorizado por el canal principal 13:51). Todo local CPU, sin APIs externas.

## Artefactos congelados (pre-ejecución)
- dst4_train.txt sha16 8690b011ceb4d088 (84 pares: 12 palabras × 7 ops practicadas; COPIA en 10)
- dst4_held24.txt sha16 32f1df99dcf85aec (24 celdas reservadas: 8 ops × 3 palabras)
- dst4_newword36.txt sha16 3f57ecac088d3413 (4 palabras nuevas × 9 ops)
- master_mix4.txt sha16 580b16020441b46e (84 DST + 84 naturales ciclo1_sub500 por orden de archivo)
- seq_comp4.txt sha16 7e77523dfdabb6a4 (3024 = 3 ciclos ×1008, semillas 20261025/26/27; cada par 6× por ciclo)
- Solapes medidos pre-entrenamiento: 0 targets held/newword presentes en train (global y por palabra), 0 operaciones equivalentes, 0 celdas reservadas entrenadas. Palabras con caracteres repetidos: 8/24 held, 9/36 newword (declarado).

## Ejecución
- Clon de la base etapa0; 6 bloques ×504 pasos (steps=504·k verificados, cursor seq 504·k, seq_sha verificada en cada checkpoint); sin retries, sin fallos; 6/6 ledgers completed.
- Wall total 86s (tope 180s). Bloques 11-14s (guarda 15s). RSS máximo medido 24,9 MiB (tope 900 MiB).
- main/champion intactos; FINAL-2 no tocado; sin adopción.

## Resultados (exact match, oráculo offline, 9 operaciones)

| bloque | train84 | held24 | newword36 | bpb heldout natural |
|---|---|---|---|---|
| C1 | 0/84 (COPIA 0/10) | 0/24 (COPIA 0/2) | 0/36 (COPIA 0/4) | 3.7670 |
| C2 | 0/84 (0/10) | 0/24 (0/2) | 0/36 (0/4) | 3.6461 |
| C3 | 1/84 (1/10) | 0/24 (0/2) | 0/36 (0/4) | 3.5916 |
| C4 | 4/84 (1/10) | 0/24 (0/2) | 0/36 (0/4) | 3.5760 |
| C5 | 15/84 (3/10) | 0/24 (0/2) | 0/36 (0/4) | 3.5306 |
| C6 (primario) | 25/84 (5/10) | 0/24 (0/2) | 0/36 (0/4) | 3.4993 |

## Lectura (criterio predeclarado: ≥6/24 recombinación medida / ≤2 no / 3-5 ambiguo; convención no validada estadísticamente)
- Resultado primario (C6): held24 = 0/24 → **no se mide recombinación** bajo este criterio. newword36 = 0/36.
- El ajuste a celdas practicadas progresa (25/84 en C6) sin transferencia medida a celdas reservadas ni a palabras nuevas. Consistente con la sonda CROSS24 previa (0/24 combinaciones nuevas en el experimento 3b); no es una prueba de imposibilidad general (una base, una semilla, un criterio).
- Canal COPIA: 5/10 en practicadas, 0/2 en reservadas, 0/4 en palabras nuevas. Medición descriptiva por operación: no localiza causalmente la etapa del fallo ni excluye fallos de canal en otras operaciones (los contextos cambian).
- bpb heldout natural 3.767→3.499: no se observa deterioro medido del texto natural (misma receta que réplica §2, exposiciones distintas; comparación descriptiva, no control causal).
- Trayectoria por bloques: descriptiva; no se eligió máximo post-hoc.

## Negativos honestos
- 0 aciertos en 360 generaciones de evaluación sobre celdas reservadas y palabras nuevas (24+36 por bloque × 6 bloques).
- La hipótesis de recombinación palabra×operación NO se cumple en este régimen (3024 pasos, mezcla 50/50).

Artefactos: ciclo_comp/ (checkpoints ck_C0..C6, gens, scores, 6/6 ledgers completed), salida del runner conservada en ciclo_comp/run.log (copia verbatim de la salida), dst4_score.py (oráculo 9 ops, auto-test 24/24), ciclo_comp_run.sh.

Captura OpenCode: tui_comp1.png — TUI real, cwd /tmp/octest2, proveedor 'AlphaZero (local)', comando `!` archivado (tui_comp.sh), UTF-8 correcto, sesión sin llamadas a modelo (0 tokens, 0 coste), env sin credenciales de nube.
