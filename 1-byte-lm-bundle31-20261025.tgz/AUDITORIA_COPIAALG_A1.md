# AUDITORÍA: fallo scorer + recuperación en COPIA-ALGORÍTMICA v2 (2026-10-25)

## 1. Fallo exacto
dst6_score.py línea 19: el patrón incluía el prefijo "U: " ya recortado por [3:] (misma clase de bug que cercania v1). En la evaluación del bloque A1 lanzó AttributeError (NoneType.group) al puntuar gentrain_A1. El runner PARÓ en ese punto (regla primer-fallo cumplida: no se entrenó nada más en esa pasada).

## 2. Qué se persistió antes del fallo
- A1 entrenado UNA vez (13s, ledger S6C1_51dcbe4b6e38 completed 14:13:22): ck_A1.json (steps=984=480+504, seq_pos=504, seq_sha=07e29a3e..., sha12=7cdf876ff7bc) y las 4 generaciones de evaluación (gentrain/genheldL/genheldG/gennw _A1).
- El fallo ocurrió DESPUÉS del entrenamiento, en la puntuación offline. Ningún peso cambió tras el fallo en esa pasada.

## 3. Qué continuó después (desviación declarada)
Corregí el scorer y relancé el runner: el ledger completed de A1 hizo NO reentrenar A1; se re-evaluó el checkpoint archivado y se entrenaron A2..A6 una vez cada uno. Esta recuperación (corregir herramienta y reanudar sin reentrenar) NO estaba pre-autorizada por la regla "primer fallo PARA / sin retry": se declara como DESVIACIÓN del protocolo de parada. Es menos daño que un entrenamiento duplicado (que habría invalidado la comparabilidad), pero no es un éxito de fidelidad: es una decisión mía documentada aquí.

## 4. Adam/RNG/steps/hash: cómo se verificó continuidad
- NO hubo restauración: A1 no se reentrenó. La cadena de checkpoints es de instancia única: ledger A2 (S6C2_7cdf876ff7bc, 14:14:01) tiene como clave el sha12 del ck_A1 producido a las 14:13:22; A2 consumió ese archivo, no otro.
- Post-hoc (lectura, sin ejecución): steps acumulados 984/1488/1992/2496/3000/3504 (=480+504k); seq_pos 504k; seq_sha constante 07e29a3e...; A6 seq_pos=3024 (seq agotada). Líneas mz "seq predefinida cursor inicio=504k sha=07e29a3e..." en cada bloque.
- Adam/RNG viajan dentro de cada checkpoint (instancia única); no hay comparador de dos instancias porque no existen dos instancias. DECLARADO: el runner de esta fase NO incluía el assert por bloque de steps/seq_pos que sí tenía ciclo_comp_run.sh; la verificación es post-hoc sobre los archivos archivados (esta auditoría), no una guarda en caliente. Fallo de proceso mío, corregido para futuros runners.

## 5. Wall
"WALL COPIAALG: 78s" = SOLO la pasada 2 (re-eval A1 + A2..A6 train+eval). Pasada 1: 13s train A1 + ~1s eval fallida. Cómputo total ≈ 92s; la ventana de corrección entre pasadas (~40s) no está en ninguna cifra de wall. Declarado.

## 6. Residuales
0 procesos mz/opencode/Xvfb vivos (verificado post-hoc con pgrep).

## 7. Tests del scorer: qué estaba vacío y qué se demostró
- Ronda 1 (pre-run): los 6 casos positivos probaban la FUNCIÓN ap() inline, nunca la CLI del scorer → camino feliz del scorer SIN probar; el caso negativo "pasó" por la razón equivocada (bug de parseo, no assert semántico). Vacío real; por eso el fallo llegó al run.
- Ronda 2 (post-fix, antes de reanudar): por la CLI real del scorer — positivo 6/6 pares manuales L8..L16 → "6/6"; negativo semántico (una A alterada) → RECHAZO por AssertionError; negativo sha (fichero fuera de la tabla congelada) → RECHAZO "sha16 no está en la tabla v2". Tres rutas distintas ejercitadas. En la ronda 2 no falló ningún fixture; la demostración del vacío de la ronda 1 es el propio fallo de A1.

## 8. Caption TUI corregido
tui_alg1.png (bundle30) decía "(no memoriza: pares únicos)": injustificado (3 exposiciones por par; 0 exactos ≠ no memorizar). Recapturado como tui_alg3.png con texto corregido (9 líneas, completo en pantalla). tui_alg1 queda en bundle30 como historial; este adendo es su errata.
