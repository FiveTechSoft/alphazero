# ERRATA + ADENDO v3 (bundle31, no altera historial)
1. Caption tui_alg1.png (bundle30): "(no memoriza: pares únicos)" retirado — 0/504 exactos con 3 exposiciones por par no prueba "no memoriza" ni imposibilidad; bpb_val bajó 4.77→4.30 (ajuste parcial sin acierto exacto). Caption corregido: tui_alg3.png.
2. "no ajusta nada" retirado de la lectura dst6: 0 aciertos exactos no implica ausencia de ajuste (loss medida bajó).
3. "carece del mecanismo" retirado: la formulación es "transferencia NO observada bajo este protocolo".
4. Recuperación scorer/A1: desviación declarada (ver AUDITORIA_COPIAALG_A1.md); ledgers 32/32 completed NO prueban fidelidad universal exactly-once.
5. ESCALERA-L: corrección aritmética — 504 pares a 18 exposiciones = 18144 pasos (~470s+eval a 26ms/paso), NO "~80s". La prep congelada es la opción de 3 exposiciones (3024 pasos, ~90s medido en L4 esta fase) para aislar longitud vs dst6; la opción 18× NO está congelada ni autorizada.
