# HIP-B — CIERRE (único run, 2026-10-25 09:53 CET)
## Ejecución
- Run troceado 480+960+960=2400 pasos por límite de 120s por proceso del entorno local:
  reanudación por checkpoint; estado Adam reiniciado por bloque; semillas de muestreo por
  bloque 7/107/207 (declaradas). Desviación de ejecución respecto a "un run continuo",
  declarada; no se afirma dirección conservadora (sin prueba).
- Checkpoints: paso0 33505761ea77…, paso2400 en hipb/paso2400.json; binario mz reconstruido
  con pairLossFull (fuente blmgru.go + modo scorepairs-full; legada intacta).
- Reconciliación "(300 pares)": la métrica FIN evalúa los primeros 300 pares del corpus
  (ventana fija del código). Verificado con evaluación sobre los 100 pares únicos de S:
  valores idénticos (2.5367). La carga real usó el corpus declarado; sin violación.
## Resultados (medidos)
- C1: bpb_S(paso2400)=2.5367 legado / 2.5451 primer_byte (100 pares completos; paso0=7.9997
  ambos) → C1 FALLA (umbral <0.8). A esta escala/presupuesto no hay memorización de S.
- C2: 0/12 elegibles con R1>=0.8 en paso2400 (también 0/12 paso0 y gru2b). C2 FALLA.
- Condicionamiento (gap pregunta verdadera vs barajada): 0.034-0.042 bpb, bajo el umbral
  0.05 → sin condicionamiento operativo detectado a esta escala.
- (b)/(c): indicadores débiles paso2400: 0/30 eco de pregunta en ambas; salidas ~260-280B de
  texto tipo fragmento ("sopa de palabras" española sin respuesta). Juicio ciego PENDIENTE
  (muestras adjuntas, clave retenida hasta fijar juicios). Éxito exige C2∧P2; fragmento/eco
  C1/P1 no es éxito conversacional.
## Lectura honesta
- Resultado de ESTA trayectoria troceada (480+960+960, Adam reiniciado por bloque):
  C1 y C2 fallan en ella; no prueban nada sobre el run continuo congelado ni sobre
  la escala en general. NO se redimensiona. Sin evidencia de generalización en esta trayectoria
  y muestra (no negativa universal); pendiente confirmación por juicio ciego de b/c.
- Sin adopción en servicio/main; champion intacto; sin residuales de procesos.
