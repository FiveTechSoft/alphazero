# HIP-A — robustez de superficie del control memorizado. CONGELADO 2026-10-25 09:39 CET

Autorizado por main 09:39: SOLO generación sobre el control existente; sin entrenar;
congelado antes; sin selección posterior. NO es aprendizaje nuevo (ningún peso cambia);
éxito de recuperación NO es generalización conversacional.

## Setup fijo
- Checkpoint: blm_gru_overfit10.json (diagnóstico, intacto). Decoding: gen2 (cebado corregido),
  temp=0.05, seed=7, n=200 (idéntico a DEC2 para comparabilidad).
- Referencia de cada ítem: la respuesta ORIGINAL del par (la transformación conserva la
  pregunta -> misma respuesta esperada). Métricas (ambas, por ítem y por familia, separadas):
  R1 = ratio de prefijo exacto (primeros min(100,len) bytes); R2 = ¿contiene la respuesta
  original como subcadena? (tolerante a desalineación). Sin agregar a un solo número.

## Familias (cada transformación escrita abajo, conservación de significado declarada por ítem;
## REGLA PREVIA DE EXCLUSIÓN: se excluye todo ítem ambiguo o cuya transformación sea identidad;
## familias con <3 ítems supervivientes se reportan por ítem, sin umbral agregado)
- O original (10 ítems): forma exacta. Umbral declarado: reproducibilidad DEC2 = 10/10 con R1>=0.8;
  si falla, se documenta problema de reproducibilidad.
- T1 ortográfica (10 ítems): minúsculas + sin signos ¿?¡!. La tipografía no cambia el
  significado de estas 10 cadenas fijas (declarado). Umbral declarado: invariancia presente
  si >=8/10 con R1>=0.8 (se espera fallo: el modelo es de bytes; eso ES la medida).
- T2 acentos (regla aplicada): SOLO sobrevive ítem 9 "¡Buenos días, princesa!" -> "Buenos dias, princesa!"
  ("dias" sin tilde se lee sin ambigüedad como "días"). Excluidos por ambigüedad (5: "Como"/"como",
  6: "estás"/"estas", 7: "Cuánto"/"cuanto") o identidad (1,2,3,4,8,10). Reporte por ítem.
- T3 sinónimos/giros (8 ítems; cada uno declarado conservador de significado):
  2 "Ya entiendo."->"Ya lo entiendo."; 3 "Conoces Denia??"->"Conoces tú Denia??";
  4 "como te llamas?"->"cual es tu nombre?"; 5 "Hola, ¿Cómo estas?"->"Hola, ¿qué tal?";
  6 "dime como estás"->"dime como te va"; 7 "¿Cuánto es 1 + 0?"->"¿Cuánto es uno más cero?";
  8 "gracias estan geniales"->"gracias son geniales"; 9 "¡Buenos días, princesa!"->"¡Muy buenos días, princesa!"
  Excluidos: 1 (levantarse/despertarse no equivalentes) y 10 por solape con T2-identidad...
  corrección: 10 "¿Como estas?"->"¿Como te encuentras?" SÍ entra; total T3 = 9 ítems.
  Umbral declarado: invariancia a giros presente si >=7/9 con R1>=0.8.
- T4 orden de palabras: SOLO ítem 4 "como te llamas?"->"te llamas como?" (coloquial, misma
  pregunta; único intercambio declarado seguro). Reporte por ítem, sin umbral.

## Archivo: hip_a/ (casos congelados hip_a_casos.txt, todas las generaciones, tabla por ítem
## y familia, log+sidecar). Sin promoción; servicio/champion/main intactos.
