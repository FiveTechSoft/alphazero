# HIP-A — ERRATA (2026-10-25 09:46 CET; protocolo original SIN modificar en HIPA_PROTOCOLO.md)
1. T2 item 9 INVALIDO: el texto transformado correspondia al item 8 ("Buenos dias, princesa!")
   pero se midio contra la referencia del item 9 ("Me encuentro excelente"). Emparejado
   erroneo (indice 0/1); NO es prueba de perdida por acento. T2 queda invalidado; el
   experimento NO se regenero.
2. Etiqueta T1 imprecisa: la transformacion real es "minusculas + sin signos de
   apertura/cierre de interrogacion/exclamacion"; punto, coma y + se conservan.
3. T1 items 5 y 7 son IDENTIDAD (sin cambio real). Aciertos T1 con cambio real: 3/8
   (items 0, 1, 4); el 5/10 original incluia los 2 items sin transformacion.
4. Conteo de casos: 31 (10 O + 10 T1 + 1 T2 + 9 T3 + 1 T4); el "32" del informe previo era
   artefacto de conteo del indice.
Resumen corregido: robustez parcial = O 10/10, T1 3/8 con cambio real, T2 invalidado,
T3 6/9, T4 1.00. Sigue sin ser generalizacion conversacional ni aprendizaje nuevo.
