# HIP-A - auditoria de equivalencias CORREGIDA (09:46; emparejado/etiquetas desde protocolo y logs, experimento NO regenerado)
NOTA: recuperacion literal = eco memorizado, NO correccion semantica (ej. princesa->principe).
ERRATA-1: T2 item 9 INVALIDO - el texto transformado correspondia al item 8 (Buenos dias, princesa!) pero se midio contra la referencia del item 9 (Me encuentro excelente). Emparejado erroneo; NO es prueba de perdida por acento. T2 queda INVALIDADO hasta nueva declaracion; no se regenera.
ERRATA-2: etiqueta T1 era imprecisa: la transformacion real es 'minusculas + sin signos de apertura/cierre de interrogacion y exclamacion'; PUNTO, COMA y + se conservan.
ERRATA-3: T1 items 5 y 7 son IDENTIDAD (sin cambio real: ya en minusculas y sin signos afectados). El 5/10 de T1 incluye esos 2; con cambio real: 3/8 (items 0,1,4).
CONTEO: 31 casos (10 O + 10 T1 + 1 T2 + 9 T3 + 1 T4); el '32' del informe previo era artefacto de conteo del indice.

## O item 0
- original: Levantarse
- transformada: Levantarse
- referencia: Hola!, ¿A que te refieres?
- generacion: Hola!, ¿A que te refieres?

## O item 1
- original: Ya entiendo.
- transformada: Ya entiendo.
- referencia: ¿Tienes alguna otra duda?
- generacion: ¿Tienes alguna otra duda?

## O item 2
- original: Conoces Denia??
- transformada: Conoces Denia??
- referencia: No entiendo tu pregunta
- generacion: No entiendo tu pregunta

## O item 3
- original: como te llamas?
- transformada: como te llamas?
- referencia: Me llamo Open Assistant.
- generacion: Me llamo Open Assistant.

## O item 4
- original: Hola, ¿Cómo estas?
- transformada: Hola, ¿Cómo estas?
- referencia: Hola, todo bien. Y tu?
- generacion: Hola, todo bien. Y tu?

## O item 5
- original: dime como estás
- transformada: dime como estás
- referencia: Estoy bien, gracias. ¿Y tú?
- generacion: Estoy bien, gracias. ¿Y tú?

## O item 6
- original: ¿Cuánto es 1 + 0?
- transformada: ¿Cuánto es 1 + 0?
- referencia: El valor a dicha suma es 1
- generacion: El valor a dicha suma es 1

## O item 7
- original: gracias estan geniales
- transformada: gracias estan geniales
- referencia: gracias están geniales
- generacion: gracias están geniales

## O item 8
- original: ¡Buenos días, princesa!
- transformada: ¡Buenos días, princesa!
- referencia: Buenos días, príncipe!
- generacion: Buenos días, príncipe!

## O item 9
- original: ¿Como estas?
- transformada: ¿Como estas?
- referencia: Me encuentro excelente. ¿Y usted?
- generacion: Me encuentro excelente. ¿Y usted?

## T1 item 0
- original: Levantarse
- transformada: levantarse
- referencia: Hola!, ¿A que te refieres?
- generacion: Hola!, ¿A que te refieres?

## T1 item 1
- original: Ya entiendo.
- transformada: ya entiendo.
- referencia: ¿Tienes alguna otra duda?
- generacion: ¿Tienes alguna otra duda?

## T1 item 2
- original: Conoces Denia??
- transformada: conoces denia
- referencia: No entiendo tu pregunta
- generacion: a duda?

## T1 item 3
- original: como te llamas?
- transformada: como te llamas
- referencia: Me llamo Open Assistant.
- generacion: Estoy bien, gracias. ¿Y tú?

## T1 item 4
- original: Hola, ¿Cómo estas?
- transformada: hola, cómo estas
- referencia: Hola, todo bien. Y tu?
- generacion: Hola, todo bien. Y tu?

## T1 item 5 [IDENTIDAD: sin cambio real]
- original: dime como estás
- transformada: dime como estás
- referencia: Estoy bien, gracias. ¿Y tú?
- generacion: Estoy bien, gracias. ¿Y tú?

## T1 item 6
- original: ¿Cuánto es 1 + 0?
- transformada: cuánto es 1 + 0
- referencia: El valor a dicha suma es 1
- generacion: dodias as. Y tu?

## T1 item 7 [IDENTIDAD: sin cambio real]
- original: gracias estan geniales
- transformada: gracias estan geniales
- referencia: gracias están geniales
- generacion: gracias están geniales

## T1 item 8
- original: ¡Buenos días, princesa!
- transformada: buenos días, princesa
- referencia: Buenos días, príncipe!
- generacion: Hola!, ¿A que te refieres?

## T1 item 9
- original: ¿Como estas?
- transformada: como estas
- referencia: Me encuentro excelente. ¿Y usted?
- generacion: Estoy bien, gracias. ¿Y tú?

## T2 item 9 [INVALIDO: ver ERRATA-1; texto del item 8 medido contra referencia del item 9]
- original: ¿Como estas?
- transformada: Buenos dias, princesa!
- referencia: Buenos días, príncipe!  <- referencia CORRECTA del texto transformado (item 8); la medida uso la del item 9
- generacion: Buenos días, príncipe!

## T3 item 1
- original: Ya entiendo.
- transformada: Ya lo entiendo.
- referencia: ¿Tienes alguna otra duda?
- generacion: ¿Tienes alguna otra duda?

## T3 item 2
- original: Conoces Denia??
- transformada: Conoces tú Denia??
- referencia: No entiendo tu pregunta
- generacion: No entiendo tu pregunta

## T3 item 3
- original: como te llamas?
- transformada: cual es tu nombre?
- referencia: Me llamo Open Assistant.
- generacion: Me llamo Open Assistant.

## T3 item 4
- original: Hola, ¿Cómo estas?
- transformada: Hola, ¿qué tal?
- referencia: Hola, todo bien. Y tu?
- generacion: Me llamo Open Assistant.

## T3 item 5
- original: dime como estás
- transformada: dime como te va
- referencia: Estoy bien, gracias. ¿Y tú?
- generacion: gracias. ¿Y tú?

## T3 item 6
- original: ¿Cuánto es 1 + 0?
- transformada: ¿Cuánto es uno más cero?
- referencia: El valor a dicha suma es 1
- generacion: El valor a dicha suma es 1

## T3 item 7
- original: gracias estan geniales
- transformada: gracias son geniales
- referencia: gracias están geniales
- generacion: gracias están geniales

## T3 item 8
- original: ¡Buenos días, princesa!
- transformada: ¡Muy buenos días, princesa!
- referencia: Buenos días, príncipe!
- generacion: Buenos días, príncipe!

## T3 item 9
- original: ¿Como estas?
- transformada: ¿Como te encuentras?
- referencia: Me encuentro excelente. ¿Y usted?
- generacion: Me llamo Open Assistant.

## T4 item 3
- original: como te llamas?
- transformada: te llamas como?
- referencia: Me llamo Open Assistant.
- generacion: Me llamo Open Assistant.
