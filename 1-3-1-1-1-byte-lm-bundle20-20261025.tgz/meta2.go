package main

// meta2.go — FASE 2 (DISENO, NO LANZADO): meta-controlador de politica de seleccion
// de datos de practica. SIN entrenamiento nuevo aqui: solo seleccion, clonacion
// exacta, rollback y guardas de particiones. Declarado como controlador de
// optimizacion meta; NO es RSI alcanzado mientras no haya ganancia validada repetible.

import (
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"math"
	"math/rand"
	"os"
	"sort"
	"strings"
)

// Roles de datos CERRADOS (congelado FASE2_DISENO_RSI_v2.md):
//   TRAIN:  ciclo1_sub500.txt      (entrenar + seleccionar practica)
//   error100: diagnostico circular declarado (NUNCA seleccion ni validacion)
//   DEV100: ciclo1_heldout100.txt  (meta-validacion de desarrollo: seleccion theta
//           y rollback; NO se reporta como evaluacion independiente)
//   FINAL100: ciclo1_final100.txt  (sha congelado; INACCESIBLE al selector y al
//           rollback; UNA sola evaluacion terminal que cierra el experimento)
const (
	meta2DevPath   = "/tmp/blm/ciclo1_heldout100.txt"
	meta2FinalPath = "/tmp/blm/ciclo1_final100.txt"
	meta2FinalSHA  = "cec57930278c097426fc888a2964a8bed2598f1a07e5d4b1b2a07ac7accfd6f4"
	meta2TrainPath = "/tmp/blm/ciclo1_sub500.txt"
)

// Features por par (definidas SIN consultar FINAL100):
//   loss:     bpb del par bajo el modelo actual, z-score con media/std del pool TRAIN
//             (estadisticos registrados en el manifiesto de la evaluacion)
//   novedad:  1/(1+veces seleccionado) segun historial de manifiestos
//   recencia: ciclos desde ultima seleccion, normalizado a [0,1]
//   longitud: bytes de la respuesta, z-score del pool
type Features struct{ Loss, Novedad, Recencia, Longitud float64 }

// Politica pi_theta: softmax sobre score = theta·features. Caja [-2,2]^4.
// HONESTO: top-loss duro NO es un punto exacto de esta familia (la temperatura
// implicita esta limitada por la caja); el baseline top-loss se implementa EXTERNO
// (controlador CICLO-1), y dentro de la familia solo hay aproximacion declarada.
type Theta [4]float64

func (t Theta) valida() error {
	for _, v := range t {
		if math.Abs(v) > 2.0 {
			return fmt.Errorf("theta fuera de caja [-2,2]: %v", t)
		}
	}
	return nil
}

var ThetaUniforme = Theta{0, 0, 0, 0}

// selecciona n pares por muestreo softmax con semilla fija (determinista).
func selecciona(fs []Features, th Theta, n int, seed int64) ([]int, error) {
	if err := th.valida(); err != nil {
		return nil, err
	}
	sc := make([]float64, len(fs))
	mx := math.Inf(-1)
	for i, f := range fs {
		sc[i] = th[0]*f.Loss + th[1]*f.Novedad + th[2]*f.Recencia + th[3]*f.Longitud
		if sc[i] > mx {
			mx = sc[i]
		}
	}
	sum := 0.0
	for i := range sc {
		sc[i] = math.Exp(sc[i] - mx)
		sum += sc[i]
	}
	r := rand.New(rand.NewSource(seed))
	idx := make([]int, 0, n)
	for len(idx) < n {
		u := r.Float64() * sum
		acc := 0.0
		for i := range sc {
			acc += sc[i]
			if u <= acc {
				idx = append(idx, i)
				break
			}
		}
	}
	sort.Ints(idx)
	return idx, nil
}

// clonaExacto: clonacion predefinida = copia byte a byte del checkpoint
// (pesos + Adam(m,v,t) + RNG + manifiestos). PROHIBIDO "reiniciar" Adam: cualquier
// candidato parte del MISMO estado exacto.
func clonaExacto(src, dst string) error {
	b, err := os.ReadFile(src)
	if err != nil {
		return err
	}
	h := sha256.Sum256(b)
	if err := os.WriteFile(dst, b, 0644); err != nil {
		return err
	}
	b2, err := os.ReadFile(dst)
	if err != nil {
		return err
	}
	h2 := sha256.Sum256(b2)
	if h != h2 {
		return errors.New("clonacion no byte-identica")
	}
	return nil
}

// rollbackElige: dado historial dev de candidatos, indice del mejor (menor bpb dev).
func rollbackElige(devScores []float64) int {
	if len(devScores) == 0 {
		return -1
	}
	b := 0
	for i := range devScores {
		if devScores[i] < devScores[b] {
			b = i
		}
	}
	return b
}

// guardaFinal: el selector/rollback RECHAZA cualquier ruta FINAL. La evaluacion
// FINAL100 corre una unica vez, al final, por un camino separado, y cierra el
// experimento (sin feedback posterior).
func guardaFinal(path string) error {
	if strings.Contains(path, "final100") {
		return fmt.Errorf("FINAL100 inaccesible para seleccion/rollback: %s", path)
	}
	return nil
}

// shaFile para manifiestos.
func shaFile(path string) (string, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return "", err
	}
	h := sha256.Sum256(b)
	return hex.EncodeToString(h[:]), nil
}

// presupuesto: coste total = evals * (scoring + bloque) + generacion final.
// Si excede el tope congelado, el piloto se REDUCE declarandolo; nunca se escala
// en silencio.
func presupuesto(nEvals int, scoringSeg, bloqueSeg, genSeg float64, topeSeg float64) (float64, bool) {
	total := float64(nEvals)*(scoringSeg+bloqueSeg) + genSeg
	return total, total <= topeSeg
}

// ---- PLAN PILOTO CONGELADO (FASE2_DISENO_RSI_v3.md) ----
// Igualdad estructural: TODOS los brazos 3 evaluaciones (12 totales). Ningun
// brazo recibe mas computo que otro. Pocos intentos = PILOTO, no RSI demostrado.
const (
	EvalsPorBrazo   = 3
	NumBrazos       = 4
	TopePilotoSeg   = 600.0
	CosteEvalEstSeg = 42.0 // scoring pool 8s (medido CICLO-1) + bloque 480p 34s: ESTIMACION a medir en preflight
	CosteCierreSeg  = 60.0 // 13 dev scorings + terminal FINAL100 x5 + generacion + TUI: ESTIMACION
)

type Brazo int

const (
	BrazoMETA Brazo = iota
	BrazoRANDOM
	BrazoUNIFORME
	BrazoTOPLOSSEXTERNO
)

func EvalsDe(b Brazo) int { return EvalsPorBrazo } // igualdad por construccion

// Regla META congelada (exacta, seeds contabilizadas):
//   e1: theta=(1,0,0,0)
//   e2: clip(e1 + N4(0,0.5), caja), seed 5001 (4 gaussianas en orden)
//   e3: clip(mejor_dev(e1,e2) + N4(0,0.5), caja), seed 5002
//   desempate mejor_dev: gana la evaluacion MAS TEMPRANA.
// RANDOM: e_k = uniforme en caja, seeds 6001..6003 (4 uniformes en orden por eval).
// UNIFORME: theta=0, semillas de replicacion de entrenamiento 7001..7003.
// TOPLOSS-EXTERNO: controlador CICLO-1 (top-100 loss x5), replicaciones 8001..8003.
func metaTheta(eval int, devPrev []float64, thetasPrev []Theta) Theta {
	switch eval {
	case 0:
		return Theta{1, 0, 0, 0}
	case 1:
		return muta(thetasPrev[0], 5001)
	default:
		b := rollbackElige(devPrev) // desempate: mas temprana
		return muta(thetasPrev[b], 5002)
	}
}

func muta(t Theta, seed int64) Theta {
	r := rand.New(rand.NewSource(seed))
	var o Theta
	for i := range o {
		o[i] = math.Max(-2, math.Min(2, t[i]+r.NormFloat64()*0.5))
	}
	return o
}

func randomTheta(eval int) Theta {
	r := rand.New(rand.NewSource(int64(6001 + eval)))
	var o Theta
	for i := range o {
		o[i] = r.Float64()*4 - 2
	}
	return o
}
