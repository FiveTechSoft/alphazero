# CICLO-2 PILOTO FASE2 v3.1 — RESULTADOS (2026-10-25)

Resultado: NEGATIVO declarado. El criterio predefinido F2-C1 NO se cumplio.
Sin adopcion: BASE (ciclo1_etapa0.json) y champion se retienen intactos.
Piloto de metabusqueda minima: NO es RSI demostrado. La mejora de loss no es
evidencia de habla; la funcionalidad solo la juzga revision ciega externa.

## Datos

12/12 evaluaciones completadas (ledger atomico: 12 completed, 0 failed, 0
reintentos). DEV100 (ciclo1_heldout100.txt) es senal de seleccion, NO resultado:

| brazo    | rep0      | rep1      | rep2      | ganador (argmin dev) |
|----------|-----------|-----------|-----------|----------------------|
| META     | 4.882429  | 4.922030  | 3.476920  | e2                   |
| RANDOM   | 5.250157  | 3.513561  | 5.347789  | e1                   |
| UNIFORME | 3.498276  | 3.483648  | 3.495032  | e1                   |
| TOPLOSS  | 3.593258  | 3.593258  | 3.593258  | e0 (desempate: mas temprana) |

TOPLOSS-EXTERNO: 3 replicas identicas por construccion (declarado en v3).

Cierre terminal UNICO bloqueado, FINAL100 (ciclo1_final100.txt,
sha256 cec57930278c097426fc888a2964a8bed2598f1a07e5d4b1b2a07ac7accfd6f4),
n=100 pares, BASE + 4 ganadores, un solo evento, sin feedback posterior:

| checkpoint      | FINAL100  |
|-----------------|-----------|
| BASE etapa0     | 3.847603  |
| META (e2)       | 3.459230  |
| RANDOM (e1)     | 3.512981  |
| UNIFORME (e1)   | 3.466064  |
| TOPLOSS (e0)    | 3.585342  |

## Veredicto F2-C1 (regla predefinida, BASE elegible para rollback)

- META supera a RANDOM por 0.0538 (>= 0.05: SI, ajustado)
- META supera a TOPLOSS por 0.1261 (SI)
- META supera a UNIFORME por 0.0068 (< 0.05: NO)
- META mejora a BASE (3.4592 < 3.8476)

Criterio NO cumplido -> negativo declarado. A este presupuesto (480 pasos,
1 seed), la metabusqueda minima NO demuestra ventaja sobre seleccion uniforme:
empate practico con UNIFORME. Es senal de un piloto, no conclusion universal
(sin replicas de seed ni intervalos). Rollback no invocado: el piloto era
prueba de META contra baselines; al fallar el criterio, BASE se retiene.

## Coste (alcance de medicion EXACTO)

589 s CPU medidos = 581 s de las 12 evaluaciones (cada una incluye: clonado
byte-exacto de BASE + scoring del pool + theta + seleccion de manifiesto +
bloque train-pairs 480 pasos + scoring dev) + ~8 s del cierre FINAL100
(5 scorings). NO incluye (no medido): capturas TUI, compilacion, docs.
El piloto no ejecuto generacion de texto. Tope 750 s (enmienda v3.1):
bajo el tope; la estimacion (692 s) quedo conservadora. Bloques <105 s
(max 55 s). Sin APIs, pagos, preentrenados ni servidores ajenos.

## Estado de FINAL100 (declaracion)

FINAL100 queda ABIERTO/QUEMADO como examen independiente: ya se uso en el
cierre y sus resultados se conocen. Ningun test futuro puede presentarse como
independiente si usa este conjunto; queda prohibido usarlo como selector y en
train. Un proximo examen requiere particion nueva con la misma funcion de
contaminacion congelada.

## Contenido de este addendo

- CICLO2_PILOTO_V3_PUBLICO.md: condiciones congeladas v3 (sha 9af59cbb...8537)
- CICLO2_PILOTO_V3_1_ENMIENDA.md: enmienda solo de coste (sha cbd9d79a...e0f7)
- piloto_v3.sh: runner (clon exacto, ledger atomico, una eval por invocacion)
- piloto/ledger_*: 12 estados completed con tiempos, devs y thetas
- piloto/dev_*, theta_*, man_*, corpus_*, sp_*: devs, thetas, manifiestos,
  corpus seleccionados y scores de pool por eval
- piloto/cierre_final100.txt: salida cruda del cierre
- fuentes meta2.go, meta2_cli.go, meta2_test.go (controlador minimo; tests 9/9)
