# PILOTO FASE2 v3 — CONDICIONES CONGELADAS PRE-ARRANQUE (version proyecto)
Alcance admitido: piloto acotado 12 evaluaciones (4 brazos x 3), tope global 600 s CPU, bloques <105 s, RSS<900MiB, parada al primer fallo, sin reintentos automaticos. PILOTO con metabusqueda minima: no es RSI demostrado.

- TODOS los candidatos clonan Adam/RNG EXACTO de BASE (ciclo1_etapa0.json) por copia
  byte a byte (clonaExacto, sha verificado). PROHIBIDO sobrescribir el RNG de
  entrenamiento del checkpoint y cualquier -seed que implique reset de Adam.
- Unica aleatoriedad nueva: SELECCION de manifiestos, con semillas explicitas.
  Mismas semillas por replicacion ENTRE brazos: rep k (0,1,2) usa seed-manifiesto
  9000+k en TODO brazo que muestree (UNIFORME; cualquier muestreo de RANDOM/META).
  Thetas RANDOM: seeds 6001..6003; mutaciones META: 5001, 5002 (ya congelado v3).
- UNIFORME: con seed-manifiesto por rep, las 3 replicas NO son identicas (varianza
  real de muestreo, sin reset); si alguna configuracion resultara semanticamente
  identica se declara "control de replicas identicas", NO estimacion de varianza.
- TOPLOSS-EXTERNO: seleccion determinista + clon exacto => 3 replicas IDENTICAS por
  construccion. Declarado: no gasta exploracion, pero recibe igual compute.

## C2. Ejecucion por eval (exactamente-una-vez por operacion)
- Clave de operacion: (brazo, replica, sha256(input: ck_base+theta/seed+manifiesto)).
  Una operacion completada NO se reejecuta; el ledger por clave lo impide (no por
  ventana temporal). Parada al primer fallo real o overshoot: PARAR Y REPORTAR.

## C3. Features con historial predefinido consistente (anti-fuga entre brazos)
- Historial H0 = VACIO para todos los candidatos (novedad=1, recencia=0 en todas las
  evals; loss = bpb del par bajo el modelo BASE clonado en esa eval). Nada de estado
  cruzado entre brazos ni entre evals: cada eval parte de H0 + clon base. Declarado:
  las features son estaticas entre evals del piloto (es el diseno, no un defecto
  oculto); novedad/recencia quedan para protocolos con ciclos secuenciales.

## C4. Regla de overshoot de coste
Si el primer bloque real difiere >10% de la estimacion (42 s/eval): PARAR y REPORTAR
con el primer resultado ya visto. NO repartir 3->2 en silencio: menos presupuesto =
protocolo ENMENDADO antes de seguir. La autorizacion actual cubre 12 evals SOLO si
el tope 600 s cabe con el coste real.

## C5. Cierre y conserva (sin cambios, reafirmado)
Decoding/criterios finales/particiones/hashes de v3 se conservan. FINAL100 se usa
UNA vez: evento terminal bloqueado con 5 checkpoints (BASE + 4 ganadores), sin
feedback posterior, jamas en train. Juicio ciego final aparte si el cierre lo amerita.

## C6. Tests: recuento REAL verificado con lista antes del arranque (no aproximado).

- Suite completa: 100 PASS / 0 FAIL.
- Subconjunto BYTE-LM relevante: 22 = 12 persistencia/curriculo (TestResumeValidoPasa,
  TestResumeRechazaCorpusDistinto, TestResumeRechazaLrDistinto,
  TestResumeRechazaProtoDesconocido, TestResumeRechazaAdamTDesalineado,
  TestCheckpointTruncadoRechazado, TestGuardadoAtomicoSinTmpResidual,
  TestAdamRoundtrip, TestSm64Determinista, TestExpansionManifiestoBytesExactos,
  TestExpansionRechazaIndiceFuera, TestCurriculoPasaConManifiestoVerificado)
  + TestGen2PrimerByteSinRealimentacion + 9 meta2. Lista verificada, no aproximada.
