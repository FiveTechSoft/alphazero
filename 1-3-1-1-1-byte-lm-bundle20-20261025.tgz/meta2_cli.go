package main

// meta2_cli.go — subcomando "meta2" del piloto FASE2 v3. Toda la aleatoriedad de
// SELECCION vive aqui (Go rand, seeds congeladas); el RNG de entrenamiento fluye
// del checkpoint clonado, intocable.

import (
	"flag"
	"fmt"
	"math"
	"os"
	"strconv"
	"strings"
)

func init() {
	if len(os.Args) > 1 && os.Args[1] == "meta2" {
		meta2Main(os.Args[2:])
		os.Exit(0)
	}
}

func parseTheta(s string) (Theta, error) {
	var t Theta
	if s == "" {
		return t, nil
	}
	p := strings.Split(s, ",")
	if len(p) != 4 {
		return t, fmt.Errorf("theta necesita 4 componentes: %q", s)
	}
	for i, x := range p {
		v, err := strconv.ParseFloat(strings.TrimSpace(x), 64)
		if err != nil {
			return t, err
		}
		t[i] = v
	}
	return t, t.valida()
}

func meta2Main(args []string) {
	fs := flag.NewFlagSet("meta2", flag.ExitOnError)
	modo := fs.String("modo", "theta", "theta|select")
	brazo := fs.String("brazo", "", "meta|random|uniforme|toploss")
	eval := fs.Int("eval", 0, "indice eval 0..2")
	devPrev := fs.String("devprev", "", "devs anteriores coma-sep (META e2+)")
	thetaPrev := fs.String("thetaprev", "", "thetas anteriores ;-sep (META e2+)")
	seedMan := fs.Int64("seed-manifiesto", 0, "seed de seleccion (9000+rep, compartida entre brazos)")
	scores := fs.String("scores", "", "fichero SCORE <idx> <loss> del pool TRAIN")
	master := fs.String("master", "", "dataset maestro (sub500)")
	outCorpus := fs.String("out-corpus", "", "corpus salida (expansion repeat=5)")
	outManifest := fs.String("out-manifest", "", "manifiesto salida")
	fs.Parse(args)

	switch *modo {
	case "theta":
		var t Theta
		switch *brazo {
		case "meta":
			var dv []float64
			var ths []Theta
			if *devPrev != "" {
				for _, x := range strings.Split(*devPrev, ",") {
					v, err := strconv.ParseFloat(x, 64)
					if err != nil {
						panic(err)
					}
					dv = append(dv, v)
				}
			}
			if *thetaPrev != "" {
				for _, x := range strings.Split(*thetaPrev, ";") {
					tt, err := parseTheta(x)
					if err != nil {
						panic(err)
					}
					ths = append(ths, tt)
				}
			}
			t = metaTheta(*eval, dv, ths)
		case "random":
			t = randomTheta(*eval)
		case "uniforme":
			t = ThetaUniforme
		case "toploss":
			t = Theta{2, 0, 0, 0} // solo informativo: el brazo EXTERNO no usa softmax
		default:
			panic("brazo desconocido")
		}
		fmt.Printf("%.6f,%.6f,%.6f,%.6f\n", t[0], t[1], t[2], t[3])

	case "select":
		if *brazo == "toploss" {
			panic("toploss es EXTERNO: seleccion por ranking duro en el driver, no aqui")
		}
		sraw, err := os.ReadFile(*scores)
		if err != nil {
			panic(err)
		}
		loss := map[int]float64{}
		n := 0
		for _, l := range strings.Split(string(sraw), "\n") {
			f := strings.Fields(l)
			if len(f) == 3 && f[0] == "SCORE" {
				i, _ := strconv.Atoi(f[1])
				v, _ := strconv.ParseFloat(f[2], 64)
				loss[i] = v
				if i+1 > n {
					n = i + 1
				}
			}
		}
		// z-score del pool (estadisticos van al manifiesto para reproducibilidad)
		m, sd := 0.0, 0.0
		for _, v := range loss {
			m += v
		}
		m /= float64(len(loss))
		for _, v := range loss {
			sd += (v - m) * (v - m)
		}
		sd = math.Sqrt(sd / float64(len(loss)))
		if sd == 0 {
			sd = 1
		}
		fs4 := make([]Features, n)
		for i := 0; i < n; i++ {
			fs4[i] = Features{Loss: (loss[i] - m) / sd, Novedad: 1, Recencia: 0, Longitud: 0} // H0 vacio (congelado)
		}
		th, err := parseTheta(os.Getenv("META2_THETA"))
		if err != nil {
			panic(err)
		}
		if *brazo == "uniforme" {
			// UNIFORME: muestreo plano con la seed-manifiesto compartida (9000+rep)
			th = ThetaUniforme
		}
		idx, err := selecciona(fs4, th, 100, *seedMan)
		if err != nil {
			panic(err)
		}
		mraw, err := os.ReadFile(*master)
		if err != nil {
			panic(err)
		}
		prs := parseUAPairs(string(mraw))
		var man strings.Builder
		man.WriteString("repeat=5\n")
		for _, i := range idx {
			man.WriteString(strconv.Itoa(i) + "\n")
		}
		var cor strings.Builder
		for r := 0; r < 5; r++ {
			for _, i := range idx {
				cor.WriteString("U: " + prs[i][0] + "\nA: " + prs[i][1] + "\n")
			}
		}
		if err := os.WriteFile(*outManifest, []byte(man.String()), 0644); err != nil {
			panic(err)
		}
		if err := os.WriteFile(*outCorpus, []byte(cor.String()), 0644); err != nil {
			panic(err)
		}
		fmt.Fprintf(os.Stderr, "[meta2 select brazo=%s seed=%d n=%d pool_mean=%.6f pool_sd=%.6f]\n", *brazo, *seedMan, len(idx), m, sd)
	default:
		panic("modo desconocido")
	}
}
