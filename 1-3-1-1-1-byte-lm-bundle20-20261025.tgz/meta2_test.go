package main

// meta2_test.go — fixtures FASE 2: ejercitan seleccion/rollback/final-inaccesible
// y clonacion con checkpoints EXISTENTES. NO entrenan ni cargan modelos nuevos.

import (
	"fmt"
	"os"
	"strings"
	"testing"
)

func TestMeta2ParticionesCerradas(t *testing.T) {
	leer := func(p string) map[string]bool {
		b, err := os.ReadFile(p)
		if err != nil {
			t.Fatalf("%s: %v", p, err)
		}
		m := map[string]bool{}
		for _, l := range strings.Split(string(b), "\n") {
			if strings.HasPrefix(l, "U: ") {
				m[strings.TrimSpace(l[3:])] = true
			}
		}
		return m
	}
	fin, dev, tr := leer(meta2FinalPath), leer(meta2DevPath), leer(meta2TrainPath)
	if len(fin) != 100 {
		t.Fatalf("final100 unicos = %d, esperado 100", len(fin))
	}
	for u := range fin {
		if dev[u] {
			t.Fatalf("final100 ∩ dev100 no vacio: %q", u)
		}
		if tr[u] {
			t.Fatalf("final100 ∩ sub500 no vacio: %q", u)
		}
	}
}

func TestMeta2ClonacionExacta(t *testing.T) {
	dst := "/tmp/blm/meta2_fixture_clone.json"
	defer os.Remove(dst)
	if err := clonaExacto("/tmp/blm/ciclo1_e4.json", dst); err != nil {
		t.Fatal(err)
	}
	h1, _ := shaFile("/tmp/blm/ciclo1_e4.json")
	h2, _ := shaFile(dst)
	if h1 != h2 {
		t.Fatal("clone != origen")
	}
	if !strings.Contains(string(mustRead(t, dst)), `"t":`) && !strings.Contains(string(mustRead(t, dst)), "adam") {
		t.Log("aviso: checkpoint sin campos Adam reconocibles en fixture (revisar)")
	}
}

func mustRead(t *testing.T, p string) []byte {
	b, err := os.ReadFile(p)
	if err != nil {
		t.Fatal(err)
	}
	return b
}

func TestMeta2SeleccionDeterminista(t *testing.T) {
	fs := []Features{{0.5, 1, 0, -0.2}, {1.5, 0.5, 0.3, 0.1}, {-0.4, 0.3, 1, 0.7}, {0.1, 0.2, 0.5, -1}}
	a, err := selecciona(fs, Theta{1, 0, 0, 0}, 3, 42)
	if err != nil {
		t.Fatal(err)
	}
	b, _ := selecciona(fs, Theta{1, 0, 0, 0}, 3, 42)
	if fmt.Sprint(a) != fmt.Sprint(b) {
		t.Fatalf("no determinista: %v vs %v", a, b)
	}
	if _, err := selecciona(fs, Theta{2.5, 0, 0, 0}, 3, 42); err == nil {
		t.Fatal("caja [-2,2] no aplicada")
	}
}

func TestMeta2TopLossExternoNoEsPuntoDeFamilia(t *testing.T) {
	// Documenta la brecha: el top-loss duro (100 mayores loss, determinista) NO es
	// reproducible exactamente por la familia softmax acotada; con theta alto en
	// loss la seleccion es solo una aproximacion estocastica.
	fs := make([]Features, 200)
	for i := range fs {
		fs[i] = Features{Loss: float64(i) / 200, Novedad: 1, Recencia: 0, Longitud: 0}
	}
	idx, err := selecciona(fs, Theta{2, 0, 0, 0}, 100, 7)
	if err != nil {
		t.Fatal(err)
	}
	enTop := 0
	for _, i := range idx {
		if i >= 100 {
			enTop++
		}
	}
	if enTop == 100 {
		t.Fatal("la familia reprodujo top-loss exacto: revisar, no deberia")
	}
	if enTop < 50 {
		t.Fatalf("aproximacion demasiado pobre: %d/100 en top", enTop)
	}
	t.Logf("aproximacion declarada: %d/100 caen en el top-100 duro", enTop)
}

func TestMeta2RollbackEligeMejorDev(t *testing.T) {
	if rollbackElige([]float64{3.5, 3.2, 3.4}) != 1 {
		t.Fatal("rollback no elige el mejor dev")
	}
	if rollbackElige(nil) != -1 {
		t.Fatal("rollback vacio")
	}
}

func TestMeta2FinalInaccesible(t *testing.T) {
	if err := guardaFinal(meta2FinalPath); err == nil {
		t.Fatal("selector acepto FINAL100")
	}
	if err := guardaFinal(meta2DevPath); err != nil {
		t.Fatal("dev100 rechazado por error")
	}
}

func TestMeta2GuardaPresupuesto(t *testing.T) {
	// La guarda rechaza planes sobre el tope; NO prueba coste real (pendiente preflight).
	if total, ok := presupuesto(48, 8, 34, 20, 600); ok {
		t.Fatalf("48 evals cabrian en 600s (%.0fs): guarda rota", total)
	}
}

func TestMeta2IgualdadEstructuralBrazos(t *testing.T) {
	// Igual presupuesto POR CONSTRUCCION: todos los brazos el mismo nº de evals.
	for _, b := range []Brazo{BrazoMETA, BrazoRANDOM, BrazoUNIFORME, BrazoTOPLOSSEXTERNO} {
		if EvalsDe(b) != EvalsPorBrazo {
			t.Fatalf("brazo %d con %d evals", b, EvalsDe(b))
		}
	}
	// Estimacion declarada (a medir en preflight): 12 evals + cierre <= tope.
	est := float64(EvalsPorBrazo*NumBrazos)*CosteEvalEstSeg + CosteCierreSeg
	if est > TopePilotoSeg {
		t.Fatalf("estimacion declarada %.0fs excede tope %.0fs", est, TopePilotoSeg)
	}
}

func TestMeta2ReglasCongeladas(t *testing.T) {
	if metaTheta(0, nil, nil) != (Theta{1, 0, 0, 0}) {
		t.Fatal("e1 META")
	}
	a := metaTheta(1, nil, []Theta{{1, 0, 0, 0}})
	if a == (Theta{1, 0, 0, 0}) || a.valida() != nil {
		t.Fatal("e2 mutacion")
	}
	// desempate: gana la mas temprana
	if rollbackElige([]float64{3.2, 3.2}) != 0 {
		t.Fatal("desempate")
	}
	r1, r2 := randomTheta(0), randomTheta(0)
	if r1 != r2 {
		t.Fatal("random no determinista por seed")
	}
}

