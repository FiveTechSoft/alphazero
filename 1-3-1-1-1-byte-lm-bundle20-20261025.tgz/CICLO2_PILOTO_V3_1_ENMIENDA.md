# PILOTO FASE2 v3.1 — ENMIENDA SOLO DE COSTE (2026-10-25 12:02 CET)
Unico cambio respecto a v3: el tope TOTAL del piloto pasa de 600 s a 750 s CPU
(incluye los 53 s ya usados por META e0 + cierre/generacion/scoring/TUI).
Estimacion actual 692 s; NO es tiempo prometido. Se conservan 4x3 evaluaciones y
TODAS las reglas originales (igualdad estructural, seeds, features, criterio F2,
cierre terminal unico). META e0 completada se conserva (no se repite); las 11
restantes parten de clones de BASE con estado original fiel.
Reglas reafirmadas: parar si la proyeccion supera 750 s o ante cualquier fallo;
bloques <105 s; RSS<900MiB; cero escalado automatico; nada de cambiar
features/theta/datos por DEV malo observado; rollback retiene BASE si ningun
candidato mejora (BASE elegible para rollback, predefinido); si el terminal mide un
candidato no adoptado se etiqueta como tal, sin cambiar la comparacion post-hoc.
Nota de etiquetas: theta=(1,0,0,0) es muestreo SOFTMAX por loss, NO top-loss duro
x5; el brazo TOPLOSS-EXTERNO es el unico ranking duro.
