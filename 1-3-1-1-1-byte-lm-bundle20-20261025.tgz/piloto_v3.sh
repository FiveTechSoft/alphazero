#!/bin/bash
# piloto_v3.sh BRAZO(meta|random|uniforme|toploss) REP(0|1|2)
# UNA eval: clona BASE -> scores pool -> manifiesto -> bloque 480p -> dev scoring.
# Ledger atomico running/completed/failed por clave (brazo,rep,sha input).
set -e; cd /tmp/blm
B=$1; R=$2
mkdir -p piloto
BASE=ciclo1_etapa0.json
CKIN=piloto/ck_${B}${R}_in.json
# clonacion exacta byte a byte (Adam+RNG incluidos)
cp "$BASE" "$CKIN"
# clave de operacion: brazo+rep+sha(ck clon)
IN_SHA=$(sha256sum "$CKIN" | cut -d' ' -f1)
KEY="${B}${R}_$(echo "$IN_SHA" | cut -c1-12)"
LED=piloto/ledger_$KEY
if [ -e "$LED" ]; then
  ST=$(cut -d' ' -f1 "$LED")
  echo "LEDGER $KEY estado=$ST"
  [ "$ST" = completed ] && { echo "ya completada; no se reejecuta"; exit 0; }
  echo "estado $ST desconocido/incompleto: NO ejecutar (recuperacion manual)"; exit 3
fi
echo "running $(date -Is)" > "$LED.tmp"; mv "$LED.tmp" "$LED"   # creacion atomica
trap 'echo "failed $(date -Is)" > "$LED.tmp"; mv "$LED.tmp" "$LED"' ERR
SEEDM=$((9000+R))
T0=$(date +%s)
# 1) scores del pool con el clon (features loss)
timeout -k 2 60 ./mz d1gru -mode scorepairs -in "$CKIN" -corpus ciclo1_sub500.txt 2>/dev/null > piloto/sp_${B}${R}.txt
# 2) theta + manifiesto/corpus
if [ "$B" = toploss ]; then
  # EXTERNO: top-100 loss duro, determinista (sin softmax)
  python3 - "$R" <<'PY'
import sys
sc=[(int(l.split()[1]),float(l.split()[2])) for l in open('piloto/sp_toploss'+sys.argv[1]+'.txt') if l.startswith('SCORE')]
idx=sorted(i for i,_ in sorted(sc,key=lambda x:-x[1])[:100])
ls=[l.rstrip('\n') for l in open('ciclo1_sub500.txt') if l.strip()]
pairs=[(ls[i],ls[i+1]) for i in range(0,len(ls)-1,2)]
open('piloto/man_toploss'+sys.argv[1]+'.txt','w').write("repeat=5\n"+''.join(f"{i}\n" for i in idx))
with open('piloto/corpus_toploss'+sys.argv[1]+'.txt','w') as f:
    for _ in range(5):
        for i in idx: f.write(pairs[i][0]+'\n'+pairs[i][1]+'\n')
PY
  THETA="EXTERNO"
else
  DV=""; TP=""
  if [ "$B" = meta ] && [ "$R" -gt 0 ]; then
    DV=$(cat piloto/dev_meta_*.txt 2>/dev/null | paste -sd, -)
    TP=$(cat piloto/theta_meta_*.txt 2>/dev/null | paste -sd';' -)
  fi
  THETA=$(./mz meta2 -modo theta -brazo "$B" -eval "$R" -devprev "$DV" -thetaprev "$TP")
  echo "$THETA" > piloto/theta_${B}_${R}.txt
  META2_THETA="$THETA" ./mz meta2 -modo select -brazo "$B" -eval "$R" -seed-manifiesto "$SEEDM" -scores piloto/sp_${B}${R}.txt -master ciclo1_sub500.txt -out-corpus piloto/corpus_${B}${R}.txt -out-manifest piloto/man_${B}${R}.txt 2>>piloto/select_${B}${R}.log
fi
# 3) bloque 480p (RNG/Adam del clon; -seed 7 inerte en resume fiel, congelado CICLO-1)
timeout -k 2 100 ./mz d1gru -mode train-pairs -corpus piloto/corpus_${B}${R}.txt -val ciclo1_sub500.txt -in "$CKIN" -out piloto/ck_${B}${R}.json -steps 480 -lr 0.003 -seed 7 -master ciclo1_sub500.txt -manifest piloto/man_${B}${R}.txt 2>&1 | grep -E 'FIN|RECHAZO|curriculo'
# 4) dev scoring (senal de seleccion, NO resultado)
timeout -k 2 60 ./mz d1gru -mode scorepairs -in piloto/ck_${B}${R}.json -corpus ciclo1_heldout100.txt 2>/dev/null | awk -v b=$B -v r=$R '$1=="SCORE"{s+=$3;n++} END{printf "%.6f\n", s/n}' > piloto/dev_${B}_${R}.txt
T1=$(date +%s)
echo "completed $(date -Is) segundos=$((T1-T0)) dev=$(cat piloto/dev_${B}_${R}.txt) theta=$THETA" > "$LED.tmp"; mv "$LED.tmp" "$LED"
echo "OK $B$R segundos=$((T1-T0)) dev=$(cat piloto/dev_${B}_${R}.txt)"
