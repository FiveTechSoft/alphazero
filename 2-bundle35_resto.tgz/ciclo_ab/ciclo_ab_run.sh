#!/bin/bash
# A/B copy head fase 0: A=learn vs B=base(gate0 literal).
# Misma etapa0 (sha 51dcbe4b..., steps=480), misma receta 6x504=3024 seq_comp7,
# mismas semillas (sampler 7 via checkpoints; copyseed=7 DECLARADA ANTES).
# LIMITES DUROS: wall total 360s (timeout externo), A<=240s, B<=120s por brazo,
# bloque A<=40s B<=25s, RSS<900MiB, guarda proyeccion +45s.
# PRIMER FALLO = PARAR AMBOS y reportar. SIN autorecuperacion, SIN retries.
set -e; set -o pipefail; cd /tmp/blm
MZ=./mzab
PREV=c8ee772eb1d2dfe4c2ea8ffc38d991f07750309d449eff53f82d63af3476b355
SEQSHA=07e29a3e3c8ef87cfc274bc1280322c21237d2c8a6ca603396554025d07e36df
ETAPA0SHA=51dcbe4b6e3832c840332f0ebe29c9b93def23a99ab4deb29354c2e3b9cb1e19
TSTART=$SECONDS
mkdir -p ciclo_ab
fail() { echo "PARADA-AB: $1"; exit "${2:-9}"; }
[ "$1" = "A" -o "$1" = "B" ] || fail "uso: ciclo_ab_run.sh A|B [Kini] [Kfin] [cap_override]"
ARM=$1
[ "$ARM" = "A" ] && CAP=240 CAPBLK=40 || { CAP=120; CAPBLK=25; }
KINI=${2:-1}; KFIN=${3:-6}; CAP=${4:-$CAP}
# proyeccion FUNDADA: coste medio medido bloque+eval (B: ~19s; A estimado ~25s);
# guard = elapsed + bloques_restantes*28 > CAP (28 = 25 medido/estimado + margen logico)

# PREFLIGHT: congelar y verificar SHAs ANTES de ejecutar
sha256sum $MZ > ciclo_ab/preflight_$ARM.txt
ET=$(sha256sum ciclo1_etapa0.json | cut -d' ' -f1)
[ "$ET" = "$ETAPA0SHA" ] || fail "etapa0 sha mismatch: $ET"
sha256sum replay/master_mix7.txt replay/man_mix7.txt replay/seq_comp7.txt \
  dst7_train504.txt dst7_heldL48.txt dst7_heldLong48.txt ciclo1_heldout100.txt \
  dst6_score.py ciclo1_etapa0.json >> ciclo_ab/preflight_$ARM.txt
SQ=$(sha256sum replay/seq_comp7.txt | cut -d' ' -f1)
[ "$SQ" = "$SEQSHA" ] || fail "seq sha mismatch"
echo "copyseed=7 declarada; arm=$ARM; caps: total ${CAP}s bloque ${CAPBLK}s RSS<900MiB" >> ciclo_ab/preflight_$ARM.txt

runmz() {
  local tag=$1; shift
  python3 - "$tag" "$@" <<'PYEOF'
import subprocess, resource, sys
tag, args = sys.argv[1], sys.argv[2:]
r = subprocess.run(["./mzab"]+args)
kb = resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
print(f"RSSMAX {tag} {kb} KiB")
if kb > 921600: print(f"PARADA-AB: RSS {kb} KiB > 900MiB en {tag}"); sys.exit(11)
sys.exit(r.returncode)
PYEOF
}

evalu() { # CK NOMBRE  (mismos cortes que E-chain; copyhead segun brazo)
  local CH=""; [ "$ARM" = "A" ] && CH="-copyhead learn -copyseed 7"
  timeout -k 2 30 $MZ d1gru -mode genpairs -in "$1" -corpus dst7_train504.txt -n 12 -temp 0 $CH > ciclo_ab/gentrain_$2.txt 2>/dev/null || fail "gen train $2" 7
  timeout -k 2 30 $MZ d1gru -mode genpairs -in "$1" -corpus dst7_heldL48.txt -n 12 -temp 0 $CH > ciclo_ab/genheldL_$2.txt 2>/dev/null || fail "gen heldL $2" 7
  timeout -k 2 30 $MZ d1gru -mode genpairs -in "$1" -corpus dst7_heldLong48.txt -n 12 -temp 0 $CH > ciclo_ab/genheldG_$2.txt 2>/dev/null || fail "gen heldG $2" 7
  local TT; TT=$(python3 dst6_score.py dst7_train504.txt ciclo_ab/gentrain_$2.txt | python3 -c "import json,sys;print(json.load(sys.stdin)['exact_total'])") || fail "score train $2" 8
  local HL; HL=$(python3 dst6_score.py dst7_heldL48.txt ciclo_ab/genheldL_$2.txt | python3 -c "import json,sys;print(json.load(sys.stdin)['exact_total'])") || fail "score heldL $2" 8
  local HG; HG=$(python3 dst6_score.py dst7_heldLong48.txt ciclo_ab/genheldG_$2.txt | python3 -c "import json,sys;print(json.load(sys.stdin)['exact_total'])") || fail "score heldG $2" 8
  local RT; RT=$(timeout -k 2 20 $MZ d1gru -mode scorepairs -in "$1" -corpus ciclo1_heldout100.txt $CH 2>/dev/null | awk '$1=="SCORE"{s+=$3;c++} END{printf "%.6f", s/c}')
  [ -n "$RT" ] || fail "bpb heldout $2" 8
  echo "== $2 train504=$TT heldL48=$HL heldLong48=$HG bpb_heldout=$RT"
  echo "$2 train504=$TT heldL48=$HL heldLong48=$HG bpb_heldout=$RT" >> ciclo_ab/resultados_$ARM.txt
}

bloque() { # K CKIN CKOUT PREVFLAG
  local K=$1 IN=$2 OUT=$3 PF=$4
  local LED="ciclo_ab/ledger_${ARM}${K}"
  [ -e "$LED" ] && fail "ledger ${ARM}${K} ya existe" 3
  local el=$((SECONDS-TSTART))
  local rest=$(( (KFIN-K+1)*28 ))
  [ $((el+rest)) -gt $CAP ] && fail "proyeccion fundada ${el}s+${rest}s > ${CAP}s (brazo $ARM)" 5
  echo "running $(date -Is)" > "$LED.tmp"; mv "$LED.tmp" "$LED"
  local t0=$SECONDS
  local CH=""; [ "$ARM" = "A" ] && CH="-copyhead learn -copyseed 7"
  runmz ${ARM}$K d1gru -mode train-pairs -corpus replay/master_mix7.txt -val dst7_heldL48.txt \
    -in "$IN" -out "$OUT" -steps 504 -lr 0.003 -seed 7 \
    -master replay/master_mix7.txt -manifest replay/man_mix7.txt -seq replay/seq_comp7.txt $PF $CH 2>&1 \
    | grep -E 'FIN|RECHAZO|seq predefinida|RSSMAX|copy head' || fail "training bloque ${ARM}$K" 4
  local dt=$((SECONDS-t0))
  ASSERTFAIL=0
  python3 - "$OUT" $K "$SEQSHA" "$ARM" <<'PYEOF' || ASSERTFAIL=1
import json, sys
c=json.load(open(sys.argv[1])); k=int(sys.argv[2]); seqsha=sys.argv[3]; arm=sys.argv[4]
assert c.get('steps')==480+504*k, ('steps', c.get('steps'))
assert c.get('seq_pos')==504*k, ('seq_pos', c.get('seq_pos'))
assert c.get('seq_sha')==seqsha, ('seq_sha', c.get('seq_sha'))
a=c.get('adam'); assert isinstance(a,dict) and a.get('t')==480+504*k, ('adam.t', a and a.get('t'))
assert isinstance(a.get('m'),list) and len(a['m'])==9 and isinstance(a.get('v'),list) and len(a['v'])==9, 'adam m/v'
if arm=='A':
    assert c.get('ckpt_version')==2, 'ckpt_version'
    cp=c.get('copy'); assert isinstance(cp,dict), 'seccion copy'
    assert cp.get('t')==504*k, ('copy.t', cp and cp.get('t'))
    for key in ('wq','wk','mwq','vwq','mwk','vwk'):
        assert len(cp[key])==64 and len(cp[key][0])==64, key
    assert len(cp['wg'])==128, 'wg'
PYEOF
  [ $ASSERTFAIL -ne 0 ] && fail "assert en caliente bloque ${ARM}$K" 6
  [ $dt -gt $CAPBLK ] && fail "bloque ${ARM}$K ${dt}s > ${CAPBLK}s" 4
  echo "completed $(date -Is) segundos=$dt" > "$LED.tmp"; mv "$LED.tmp" "$LED"
  echo "OK bloque ${ARM}$K ${dt}s (asserts caliente PASS)"
}

# migracion / base
if [ ! -e ciclo_ab/ck_${ARM}0.json ]; then
  if [ "$ARM" = "A" ]; then
    # A0 = etapa0 + head migrado (0 updates nuevos): se materializa via un
    # train de 0 pasos? NO: se copia etapa0 y la migracion ocurre en caliente
    # en el primer bloque y en los evals (init determinista semilla 7).
    cp ciclo1_etapa0.json ciclo_ab/ck_A0.json
  else
    cp ciclo1_etapa0.json ciclo_ab/ck_B0.json
  fi
fi

# PREUPDATE evals (solo cuando el segmento empieza en 1): A0 = etapa0+head
# fresco (riesgo de sesgo de salida del head aleatorio: SE MIDE AQUI, sin
# seleccion de semilla). B0 = etapa0 base.
if [ "$KINI" = "1" ]; then
  echo "== PREUPDATE $ARM =="
  evalu ciclo_ab/ck_${ARM}0.json ${ARM}0
fi

for K in $(seq $KINI $KFIN); do
  P=$((K-1)); PF=""; [ $K = 1 ] && PF="-master-prev $PREV"
  bloque $K ciclo_ab/ck_${ARM}${P}.json ciclo_ab/ck_${ARM}${K}.json "$PF"
  evalu ciclo_ab/ck_${ARM}${K}.json ${ARM}$K
done
echo "BRAZO $ARM COMPLETO wall: $((SECONDS-TSTART))s"
