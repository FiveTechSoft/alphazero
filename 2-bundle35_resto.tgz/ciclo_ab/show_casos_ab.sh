#!/bin/bash
# Replay de outputs ARCHIVADOS (no regenera nada): casos fijos A/B.
cd "$(dirname "$0")"
cat casos_fijos_ab.txt
