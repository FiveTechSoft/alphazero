package main

// EVALUACION DE COSTE TECNICO (no train, no updates, no preds held):
// 5 secuencias SINTETICAS con longitudes representativas del manifiesto
// (dst7 ~24B; natural sub500 cap 512: p25=63, p50=121, p75=279, p90=463,
// max=512). Contenido: bytes pseudoaleatorios (semilla fija), NO datos reales.
// Mide fwd+BWD de gradientes (trainSeqMask / trainSeqMaskCopy / primitivas
// copyStep+copyBackward), SIN adamApply. Guarda dura 15s wall total: primer
// fallo o superar la guarda = STOP sin reintentos.
// Config declarada ANTES: natural = atencion full creciente sobre posiciones
// previas de la misma secuencia (L=t+1), cap 512; dst7 = atencion al prompt
// fijo (definicion copyPromptBytes). No se escoge despues.

import (
	"math/rand"
	"testing"
	"time"
)

func TestCosteTecnico512(t *testing.T) {
	t0 := time.Now()
	guarda := func(fase string) {
		if time.Since(t0) > 15*time.Second {
			t.Fatalf("GUARDA 15s superada en %s: STOP", fase)
		}
	}
	g := NewGRU(42, 32, 64)
	ch := newCopyHead(g.H)
	r := rand.New(rand.NewSource(7))
	for i := range ch.Wq {
		for j := range ch.Wq[i] {
			ch.Wq[i][j] = r.NormFloat64() * 0.1
			ch.Wk[i][j] = r.NormFloat64() * 0.1
		}
	}
	for i := range ch.Wg {
		ch.Wg[i] = r.NormFloat64() * 0.1
	}

	mkSeq := func(n int) []byte {
		rs := rand.New(rand.NewSource(int64(n)))
		s := make([]byte, n)
		for i := range s {
			s[i] = byte(33 + rs.Intn(90))
		}
		return s
	}

	// Regimen dst7: prompt fijo (15) + respuesta, driver integrado vs base.
	seqD := mkSeq(24)
	gr1 := g.newGrads()
	tb := time.Now()
	g.trainSeqMask(seqD, 0, gr1)
	baseDst7 := time.Since(tb)
	gr2 := g.newGrads()
	cg2 := newCopyGrads(g.H)
	tc := time.Now()
	g.trainSeqMaskCopy(seqD, 16, 15, ch, false, gr2, cg2)
	copyDst7 := time.Since(tc)
	t.Logf("COSTE dst7 T=24/L=15: base=%v copy=%v ratio=%.2f", baseDst7, copyDst7, float64(copyDst7)/float64(baseDst7))
	guarda("dst7")

	// Regimen natural: T in {63,121,279,463,512}; base (todo fwd+bwd) y coste
	// marginal del head full-attn creciente (primitivas reales copyStep +
	// copyBackward por paso, L=t+1), sin updates.
	for _, T := range []int{63, 121, 279, 463, 512} {
		seq := mkSeq(T)
		gr := g.newGrads()
		tb := time.Now()
		g.trainSeqMask(seq, 0, gr)
		baseT := time.Since(tb)
		guarda("base")
		// forward estados
		tf := time.Now()
		H := g.H
		h := make([]float64, H)
		hAfter := make([][]float64, T)
		for tt := 0; tt < T; tt++ {
			_, hn := g.step(h, seq[tt])
			h = hn
			hAfter[tt] = h
		}
		cg := newCopyGrads(H)
		gr3 := g.newGrads()
		dhT := make([]float64, H)
		ws := newCopySeqWS(T)
		var sumL int
		for tt := 1; tt < T; tt++ {
			ph := hAfter[:tt]
			pb := seq[:tt]
			p, cc := ch.copyStep(g, hAfter[tt], ph, pb, false, ws)
			_ = p
			dp := make([]float64, 256)
			dp[seq[tt]] = -1.0
			dph := make([][]float64, len(ph))
			for i := range dph {
				dph[i] = make([]float64, H)
			}
			ch.copyBackward(g, cc, ph, pb, dp, cg, gr3, dhT, dph, ws)
			sumL += tt
		}
		ws.flushWk(ch, hAfter[:T-1], cg)
		headT := time.Since(tf)
		ratio := float64(baseT+headT) / float64(baseT)
		t.Logf("COSTE natural T=%d: base=%v head_marginal=%v total_est=%v ratio=%.2f meanL=%.1f",
			T, baseT, headT, baseT+headT, ratio, float64(sumL)/float64(T-1))
		guarda("natural")
	}
	t.Logf("COSTE wall_total=%v", time.Since(t0))
}
