package main

import (
	"math/rand"
	"testing"
)

// Forward microbenchmark AISLADO: copyStep (una llamada) vs step+logits base
// (una llamada). Mide SOLO el forward de un paso; NO es el coste de training
// (BPTT multipaso, buffers por paso y actualizaciones difieren). Resultado:
// ratio por paso forward, con incertidumbre declarada, sin extrapolacion.

func benchCopyForward(b *testing.B, H, L int) {
	g := NewGRU(7, 256, H)
	ch := newCopyHead(H)
	ph := make([][]float64, L)
	pb := make([]byte, L)
	r := rand.New(rand.NewSource(1))
	for i := range ph {
		ph[i] = make([]float64, H)
		for j := range ph[i] {
			ph[i][j] = r.NormFloat64()
		}
		pb[i] = byte(i + 33)
	}
	hT := make([]float64, H)
	for j := range hT {
		hT[j] = r.NormFloat64()
	}
	b.Run("base_step_logits", func(b *testing.B) {
		h := make([]float64, H)
		for i := 0; i < b.N; i++ {
			_, hN := g.step(h, byte(i&0xff))
			_ = g.logits(hN)
		}
	})
	b.Run("copystep_gate_abierto", func(b *testing.B) {
		for i := 0; i < b.N; i++ {
			ws := newCopySeqWS(len(ph))
			_, _ = ch.copyStep(g, hT, ph, pb, true, ws)
		}
	})
	b.Run("copystep_gate_cerrado", func(b *testing.B) {
		for i := 0; i < b.N; i++ {
			ws := newCopySeqWS(len(ph))
			_, _ = ch.copyStep(g, hT, ph, pb, false, ws)
		}
	})
}

func BenchmarkCopyForwardH64L8(b *testing.B)  { benchCopyForward(b, 64, 8) }
func BenchmarkCopyForwardH64L48(b *testing.B) { benchCopyForward(b, 64, 48) }
