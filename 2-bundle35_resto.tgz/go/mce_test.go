package main

import (
	"math"
	"testing"
)

func TestMCEPesoRegimenes(t *testing.T) {
	// gap < m -> (1+lambda); gap >= m -> 1; frontera exacta gap==m -> inactivo
	if w, a := mcePeso(2.0, 3.0, 0.5, 2.0); w != 1.5 || !a { // gap=1<m
		t.Fatalf("activo: w=%v a=%v", w, a)
	}
	if w, a := mcePeso(2.0, 5.0, 0.5, 2.0); w != 1.0 || a { // gap=3>m
		t.Fatalf("inactivo: w=%v a=%v", w, a)
	}
	if w, a := mcePeso(2.0, 4.0, 0.5, 2.0); w != 1.0 || a { // gap==m frontera
		t.Fatalf("frontera: w=%v a=%v", w, a)
	}
}

// TestMCEGradienteFinito: verifica grad analitico = (1+lambda*activo)*grad L_real
// contra diferencias finitas del objetivo COMPLETO (referencia detenida),
// en GRU pequeno. K parametros comprobados: declarado.
func TestMCEGradienteFinito(t *testing.T) {
	g := NewGRU(3, 4, 8)
	pre := []byte("U: abc\nA: ")
	ans := []byte("xy\n")
	seq := append(append([]byte(nil), pre...), ans...)
	const lambda, m = 0.7, 0.25
	lReal := g.pairLoss(pre, ans)
	lShufConst := 3.3 // referencia barajada DETENIDA (constante)
	w, _ := mcePeso(lReal, lShufConst, lambda, m)
	obj := func(gg *GRU) float64 {
		l := gg.pairLoss(pre, ans)
		h := m - (lShufConst - l)
		if h < 0 {
			h = 0
		}
		return l + lambda*h
	}
	gr := g.newGrads()
	g.trainSeqMask(seq, len(pre)-1, gr)
	// grad analitico del objetivo = w * grad(L_real); comprobar K params de E
	eps, K, fallos := 1e-5, 12, 0
	for i := 0; i < K; i++ {
		b := byte(i + 1)
		orig := g.E[b][0]
		g.E[b][0] = orig + eps
		lp := obj(g)
		g.E[b][0] = orig - eps
		lm := obj(g)
		g.E[b][0] = orig
		fd := (lp - lm) / (2 * eps)
		an := w * gr.E[b][0]
		if math.Abs(fd-an) > 1e-3*(1+math.Abs(an)) {
			fallos++
			t.Errorf("param %d: fd=%.6f analitico=%.6f", i, fd, an)
		}
	}
	t.Logf("gradient check: K=%d params, fallos=%d, regimen w=%.2f", K, fallos, w)
	if fallos > 0 {
		t.Fatalf("%d/%d params fuera de tolerancia", fallos, K)
	}
}
