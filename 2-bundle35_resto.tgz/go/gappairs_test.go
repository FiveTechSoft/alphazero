package main

import (
	"os"
	"strings"
	"testing"
)

func TestOffsetDeterministaYNoIdentidad(t *testing.T) {
	for _, n := range []int{2, 3, 10, 100, 500} {
		for _, s := range []int64{7, 22, 9000, 20261025} {
			k1 := offsetBarajado(n, s)
			k2 := offsetBarajado(n, s)
			if k1 != k2 {
				t.Fatalf("no determinista n=%d seed=%d", n, s)
			}
			if k1 < 1 || k1 >= n {
				t.Fatalf("offset fuera de rango n=%d seed=%d k=%d", n, s, k1)
			}
			for i := 0; i < n; i++ {
				if (i+k1)%n == i {
					t.Fatalf("identidad n=%d seed=%d i=%d", n, s, i)
				}
			}
		}
	}
	if offsetBarajado(1, 7) != 0 {
		t.Fatal("n=1 debe dar offset 0")
	}
}

func TestNormalizaPregunta(t *testing.T) {
	if normalizaPregunta("Hola, Mundo! 42") != "holamundo42" {
		t.Fatalf("normaliza: %q", normalizaPregunta("Hola, Mundo! 42"))
	}
	if normalizaPregunta("A b") != normalizaPregunta("a   B") {
		t.Fatal("misma_normalizada no detectada")
	}
}

func TestGapInvalidoMismaNormalizada(t *testing.T) {
	// 3 preguntas: indices 0 y 1 normalizan igual; con offset k=1 (seed que lo
	// produzca para n=3) el par 0 recibe la pregunta 1 -> INVALIDO explicito.
	g := NewGRU(7, 32, 64)
	pairs := [][2]string{
		{"Capital de Francia?", "Paris"},
		{"capital   de FRANCIA", "Paris"},
		{"Capital de Italia?", "Roma"},
	}
	// buscar seed con offset 1 para n=3
	var seed int64 = -1
	for s := int64(0); s < 100; s++ {
		if offsetBarajado(3, s) == 1 {
			seed = s
			break
		}
	}
	if seed < 0 {
		t.Fatal("sin seed con offset 1")
	}
	gps := gapPares(g, pairs, seed)
	if gps[0].Valido || gps[0].MotivoInv != "misma_normalizada" {
		t.Fatalf("par 0 debia ser invalido: %+v", gps[0])
	}
	// con offset 1: par0<-q1 (misma normalizada: INVALIDO), par1<-q2 (distinta:
	// valido), par2<-q0 (distinta de q2: valido)
	if !gps[1].Valido {
		t.Fatalf("par 1 debia ser valido: %+v", gps[1])
	}
	if !gps[2].Valido {
		t.Fatalf("par 2 debia ser valido: %+v", gps[2])
	}
	for _, gp := range gps {
		if gp.Valido && gp.Gap != gp.LossBaraj-gp.LossReal {
			t.Fatalf("signo/definicion gap: %+v", gp)
		}
	}
}

// TestGapPositivoControl10: fixture positivo con el checkpoint memorizado
// conocido (overfit10): en pares MEMORIZADOS la pregunta verdadera debe
// reducir la perdida -> gap media claramente positiva. Sin entrenamiento.
func TestGapPositivoControl10(t *testing.T) {
	ck := "/tmp/blm/blm_gru_overfit10.json"
	corpus := "/tmp/blm/overfit10_corpus.txt"
	if _, err := os.Stat(ck); err != nil {
		t.Skip("fixture control10 no presente")
	}
	raw, err := os.ReadFile(corpus)
	if err != nil {
		t.Skip("corpus control10 no presente")
	}
	g, _, _, err := LoadGRU(ck)
	if err != nil {
		t.Fatalf("LoadGRU: %v", err)
	}
	pairs := parseUAPairs(string(raw))
	if len(pairs) < 5 {
		t.Fatalf("pocos pares fixture: %d", len(pairs))
	}
	gps := gapPares(g, pairs, 7)
	var sum float64
	val := 0
	for _, gp := range gps {
		if gp.Valido {
			sum += gp.Gap
			val++
		}
	}
	media := sum / float64(val)
	t.Logf("control10 gap_media=%.4f validos=%d/%d", media, val, len(gps))
	if media <= 0.05 {
		t.Fatalf("fixture positivo esperaba gap>0.05, obtuvo %.4f", media)
	}
}

func TestResumenFormatoEstable(t *testing.T) {
	g := NewGRU(7, 32, 64)
	pairs := [][2]string{{"q1", "a1"}, {"q2", "a2"}}
	gps := gapPares(g, pairs, 7)
	if len(gps) != 2 {
		t.Fatal("longitud")
	}
	var b strings.Builder
	_ = b
	// imprimeGapPares es salida de consola; aqui solo se verifica no paniquear.
	imprimeGapPares(gps, 7)
}

// TestGapTokensControl10: instrumento por token sobre fixture memorizado:
// fraccion positiva alta y media apreciable (>> ruido numerico).
func TestGapTokensControl10(t *testing.T) {
	ck := "/tmp/blm/blm_gru_overfit10.json"
	corpus := "/tmp/blm/overfit10_corpus.txt"
	if _, err := os.Stat(ck); err != nil {
		t.Skip("fixture control10 no presente")
	}
	raw, _ := os.ReadFile(corpus)
	g, _, _, err := LoadGRU(ck)
	if err != nil {
		t.Fatal(err)
	}
	pairs := parseUAPairs(string(raw))
	k := offsetBarajado(len(pairs), 7)
	var res gapTokResumen
	for i := 0; i < len(pairs); i++ {
		j := (i + k) % len(pairs)
		if normalizaPregunta(pairs[j][0]) == normalizaPregunta(pairs[i][0]) {
			continue
		}
		gapTokensPar(g, []byte("U: "+pairs[i][0]+"\nA: "), []byte("U: "+pairs[j][0]+"\nA: "), []byte(pairs[i][1]+"\n"), &res)
	}
	frac := float64(res.Positivos) / float64(res.Tokens)
	media := res.Suma / float64(res.Tokens)
	t.Logf("control10 tokens: frac_pos=%.3f media=%.4f buckets(r/d/a)=%d/%d/%d", frac, media, res.BRuido, res.BDebil, res.BAprec)
	if frac < 0.5 || media < 0.05 {
		t.Fatalf("fixture positivo por token debil: frac=%.3f media=%.4f", frac, media)
	}
}

func TestGapTokensDeterministaYAlineado(t *testing.T) {
	g := NewGRU(7, 32, 64)
	pre := []byte("U: q\nA: ")
	ans := []byte("respuesta\n")
	var r1, r2 gapTokResumen
	gapTokensPar(g, pre, pre, ans, &r1)
	gapTokensPar(g, pre, pre, ans, &r2)
	if r1 != r2 {
		t.Fatal("no determinista")
	}
	if r1.Tokens != len(ans)-1 {
		t.Fatalf("alineacion: tokens=%d esperado=%d", r1.Tokens, len(ans)-1)
	}
	if r1.Suma != 0 || r1.Positivos != 0 {
		t.Fatal("misma pregunta debe dar gap 0 exacto")
	}
}
