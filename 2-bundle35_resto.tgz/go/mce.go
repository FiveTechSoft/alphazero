package main

// mce.go — CE reponderada por margen (MCE). NO es un mecanismo de contexto
// nuevo: con referencia barajada DETENIDA (constante), el objetivo por par es
//   L = L_real + lambda * relu(m - (L_baraj_const - L_real))
// y su gradiente exacto es:
//   hinge ACTIVO   (gap < m):  grad L = (1+lambda) * grad L_real
//   hinge INACTIVO (gap >= m): grad L = grad L_real
// Es decir: CE con paso adaptado por gap medido. Util como baseline; el brazo
// de control con pesos ALEATORIOS de igual distribucion aisla senal vs mero
// tamano de gradiente.

// mcePeso: factor de paso del par dado su gap contra referencia detenida.
func mcePeso(lReal, lBarajConst, lambda, m float64) (peso float64, activo bool) {
	gap := lBarajConst - lReal
	if gap < m {
		return 1 + lambda, true
	}
	return 1, false
}
