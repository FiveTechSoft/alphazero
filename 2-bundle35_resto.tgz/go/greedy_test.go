package main

import (
	"os"
	"strings"
	"testing"
)

// Fixtures del modo goloso (temp<=0) en la RUTA gen2 (cebado corregido),
// usada por la evaluacion exact-match de CICLO-3. Convenciones declaradas
// ANTES de medir. NINGUN entrenamiento nuevo en estos tests.
func TestGeneracionGolosa2Determinista(t *testing.T) {
	g := NewGRU(123, 8, 16)
	p := "ROT1 xuqe\n"
	a := g.generateGRU2(p, 32, 0, 1)
	b := g.generateGRU2(p, 32, 0, 999)
	if a != b {
		t.Fatalf("temp<=0 debe ignorar la semilla: %q vs %q", a, b)
	}
	if len(a) > 32 {
		t.Fatalf("maxB no acota: %d", len(a))
	}
	// Paridad primer byte: en gen2, tras cebar el prompt, el primer byte
	// generado es argmax(logits(h)) directo (sin doble alimentacion).
	h := make([]float64, g.H)
	for i := 0; i < len(p); i++ {
		_, h = g.step(h, p[i])
	}
	lg := g.logits(h)
	best := 0
	for i := 1; i < 256; i++ {
		if lg[i] > lg[best] {
			best = i
		}
	}
	if len(a) > 0 && a[0] != byte(best) {
		t.Fatalf("primer byte %q != argmax manual %q", a[0], byte(best))
	}
}

// TestGoloso2Control10Memorizado: el checkpoint overfit10 (YA entrenado en
// etapas previas, sin entrenamiento nuevo) debe reproducir greedy las
// respuestas memorizadas leidas DEL CORPUS en tiempo de test (no escritas
// en el test). Verifica que la funcion ejecutada es la red real y que el
// stop EOS funciona sin recortes post-hoc.
func TestGoloso2Control10Memorizado(t *testing.T) {
	ck := "/tmp/blm/blm_gru_overfit10.json"
	corpus := "/tmp/blm/overfit10_corpus.txt"
	if _, err := os.Stat(ck); err != nil {
		t.Skip("fixture control10 no presente")
	}
	raw, err := os.ReadFile(corpus)
	if err != nil {
		t.Skip("corpus control10 no presente")
	}
	pairs := parseUAPairs(string(raw))
	if len(pairs) < 2 {
		t.Fatalf("pocos pares fixture: %d", len(pairs))
	}
	g, _, _, err := LoadGRU(ck)
	if err != nil {
		t.Fatalf("LoadGRU: %v", err)
	}
	for i := 0; i < 2; i++ {
		u := pairs[i][0]
		esp := pairs[i][1]
		gen := g.generateGRU2("U: "+u+"\nA: ", 64, 0, 1)
		if gen != esp && gen != strings.TrimRight(esp, " ") && strings.TrimRight(gen, " ") != strings.TrimRight(esp, " ") {
			t.Fatalf("par %d: generado %q != memorizado %q", i, gen, esp)
		}
	}
}
