package main

// PILOTO TECNICO (no es un experimento de aprendizaje): backprop + update
// sobre un checkpoint MIGRADO (v1 sintetico -> v2), con guarda dura de coste:
// si el wall total supera 15s el test FALLA y se PARA (sin retry, sin
// autorecovery). Datos: UNA secuencia sintetica generada por codigo (prompt
// pseudoaleatorio + respuesta = copia del prompt). NO se toca held/FINAL2 ni
// ningun corpus real. Una bajada de loss aqui es memorizacion del fixture, no
// evidencia de aprendizaje general ni de copia autonoma.

import (
	"fmt"
	"math"
	"math/rand"
	"os"
	"strings"
	"testing"
	"time"
)

func rssKB(t *testing.T) int {
	b, err := os.ReadFile("/proc/self/status")
	if err != nil {
		t.Fatalf("rss: %v", err)
	}
	for _, l := range strings.Split(string(b), "\n") {
		if strings.HasPrefix(l, "VmRSS:") {
			var kb int
			fmt.Sscanf(l, "VmRSS: %d kB", &kb)
			return kb
		}
	}
	t.Fatalf("VmRSS no encontrado")
	return 0
}

func TestPilotoTecnico15s(t *testing.T) {
	t0 := time.Now()
	guarda := func(fase string) {
		if time.Since(t0) > 15*time.Second {
			t.Fatalf("GUARDA 15s superada en fase %s: STOP", fase)
		}
	}
	rss0 := rssKB(t)

	// 1) checkpoint v1 SINTETICO (GRU fresco D=32 H=64, steps=0, sin datos reales)
	g := NewGRU(42, 32, 64)
	st := g.newAdam()
	v1 := "/tmp/piloto_v1.json"
	v2 := "/tmp/piloto_v2.json"
	defer os.Remove(v1)
	defer os.Remove(v2)
	if err := g.SaveGRU(v1, 0, 0, st, 0, "sintetico", 42, 0.003, "piloto"); err != nil {
		t.Fatalf("save v1: %v", err)
	}
	guarda("save-v1")

	// 2) migracion EXPLICITA via loader estricto: head aleatorio pequeno
	// (escala 0.1, semilla 7 declarada), copyAdam en cero, t_copy=0. GRU intacto.
	g2, steps, _, ch, cs, mig, err := loadCopyStrict(v1)
	if err != nil || !mig {
		t.Fatalf("migracion: err=%v mig=%v", err, mig)
	}
	if steps != 0 {
		t.Fatalf("steps migrado != 0")
	}
	// ch, cs vienen nil del loader v1: se construyen aqui (migracion)
	r := rand.New(rand.NewSource(7))
	ch = newCopyHead(g2.H)
	cs = newCopyAdam(g2.H)
	for i := range ch.Wq {
		for j := range ch.Wq[i] {
			ch.Wq[i][j] = r.NormFloat64() * 0.1
			ch.Wk[i][j] = r.NormFloat64() * 0.1
		}
	}
	for i := range ch.Wg {
		ch.Wg[i] = r.NormFloat64() * 0.1
	}
	st2 := g2.newAdam()
	guarda("migracion")

	// 3) secuencia sintetica: prompt 16 bytes (semilla 1) + respuesta = copia
	r2 := rand.New(rand.NewSource(1))
	seq := make([]byte, 0, 32)
	prompt := make([]byte, 16)
	for i := range prompt {
		prompt[i] = byte(33 + r2.Intn(90))
	}
	seq = append(seq, prompt...)
	seq = append(seq, prompt...) // respuesta = copia del prompt
	promptEnd, lossFrom := 15, 16

	// 4) bucle piloto: BPTT + update GRU + update copy, guarda 15s en cada paso
	const N = 20
	lr := 0.003
	loss0, lossN := math.NaN(), math.NaN()
	for k := 0; k < N; k++ {
		guarda("bucle")
		gr := g2.newGrads()
		cg := newCopyGrads(g2.H)
		l, n := g2.trainSeqMaskCopy(seq, lossFrom, promptEnd, ch, false, gr, cg)
		if n == 0 || math.IsNaN(l) || math.IsInf(l, 0) {
			t.Fatalf("loss invalida en update %d: %v (n=%d): STOP", k, l, n)
		}
		if k == 0 {
			loss0 = l
		}
		lossN = l
		g2.adamApply(st2, lr, gr)
		cs.apply(ch, cg, lr)
	}
	if cs.t != N {
		t.Fatalf("t_copy != %d tras piloto: %d", N, cs.t)
	}
	guarda("bucle-fin")

	// 5) save v2 + recarga estricta
	if err := g2.saveCopy(v2, N, 0, st2, ch, cs, 0, "sintetico", 42, lr, "piloto"); err != nil {
		t.Fatalf("save v2: %v", err)
	}
	_, steps2, _, _, cs3, mig3, err := loadCopyStrict(v2)
	if err != nil || mig3 {
		t.Fatalf("reload v2: err=%v mig=%v", err, mig3)
	}
	if steps2 != N || cs3.t != N {
		t.Fatalf("resume: steps=%d t_copy=%d", steps2, cs3.t)
	}
	wall := time.Since(t0)
	guarda("reload")
	t.Logf("PILOTO wall=%v updates=%d loss[0]=%.4f loss[%d]=%.4f rss0=%dKB rss1=%dKB (fixture sintetico, NO aprendizaje general)",
		wall, N, loss0, N-1, lossN, rss0, rssKB(t))
}
