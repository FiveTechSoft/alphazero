package main

import "testing"

// Fixture de la transicion de curriculo DECLARADA entre datasets (CICLO-3):
// el checkpoint debe derivar EXACTAMENTE del maestro previo declarado.
func TestVerificaMaestro(t *testing.T) {
	ck, nuevo, prev := "aaa", "bbb", "aaa"
	if err := verificaMaestro(ck, nuevo, ""); err == nil {
		t.Fatal("sin master-prev, maestro distinto debe rechazar")
	}
	if err := verificaMaestro(ck, ck, ""); err != nil {
		t.Fatalf("mismo maestro debe admitir: %v", err)
	}
	if err := verificaMaestro(ck, nuevo, prev); err != nil {
		t.Fatalf("transicion declarada correcta debe admitir: %v", err)
	}
	if err := verificaMaestro(ck, nuevo, "zzz"); err == nil {
		t.Fatal("master-prev que no coincide con el checkpoint debe rechazar")
	}
	if err := verificaMaestro(ck, ck, ck); err == nil {
		t.Fatal("master-prev == maestro nuevo no es transicion")
	}
}

// Paridad genpairs: el helper por lote produce lo mismo que generateGRU2.
func TestGenParGreedyParidad(t *testing.T) {
	g := NewGRU(77, 8, 16)
	q := "aplica ROT2 a 'xuqe'"
	a := genParGreedy(g, q, 16)
	b := g.generateGRU2("U: "+q+"\nA: ", 16, 0, 0)
	if a != b {
		t.Fatalf("genParGreedy %q != generateGRU2 %q", a, b)
	}
}
