package main

// copyhead.go — pointer/copy head byte-level sobre los estados del prompt (PREP, sin training).
// Diseno (UN mecanismo, cierre de fase): al puntuar el byte t de la respuesta,
//   q = Wq*h_t ; k_s = Wk*h_s (s = posiciones del prompt)
//   alfa = softmax(q.k_s / sqrt(H)) ; c = sum_s alfa_s*h_s
//   u = sigmoid(wg.[h_t;c] + bg) ; p_copy(b) = sum_{s: prompt[s]=b} alfa_s
//   p(b) = u*p_copy(b) + (1-u)*p_gru(b)   (mezcla en espacio de probabilidad)
// PROGRAMADO: solo la conectividad (Wq, Wk, wg, bg existen). APRENDIDO: todos los
// pesos por gradiente; NINGUN peso se inicializa desde el algoritmo oraculo.
// gate=0 => p == p_gru exactamente (paridad con la ruta base, fwd y backward).

import (
	"encoding/json"
	"fmt"
	"math"
	"math/rand"
	"os"
)

type copyHead struct {
	Wq [][]float64 // [H][H]
	Wk [][]float64 // [H][H]
	Wg []float64   // [2H]
	Bg float64
}

type copyGrads struct {
	Wq [][]float64
	Wk [][]float64
	Wg []float64
	Bg float64
}

func newCopyHead(h int) *copyHead {
	mk := func() [][]float64 {
		M := make([][]float64, h)
		for i := range M {
			M[i] = make([]float64, h)
		}
		return M
	}
	return &copyHead{Wq: mk(), Wk: mk(), Wg: make([]float64, 2*h)}
}

func newCopyGrads(h int) *copyGrads {
	mk := func() [][]float64 {
		M := make([][]float64, h)
		for i := range M {
			M[i] = make([]float64, h)
		}
		return M
	}
	return &copyGrads{Wq: mk(), Wk: mk(), Wg: make([]float64, 2*h)}
}

type copyCache struct {
	alfa []float64
	c    []float64
	q    []float64
	u    float64
	pGru []float64
	hT   []float64
}


// copySeqWS: workspace LOCAL POR SECUENCIA (nunca en checkpoints ni estado
// persistente). Cachea K_s = Wk*h_s (cada posicion se proyecta UNA vez por
// secuencia: O(T*H^2) total en vez de O(T^2*H^2)) y acumula dK_s para aplicar
// dWk = sum_s dK_s x h_s UNA vez al final (flushWk). Misma matematica; solo
// cambia el ORDEN de las sumas (reasociacion), asi que la equivalencia se mide
// con tolerancia, no bit-exacta.
type copySeqWS struct {
	K  [][]float64
	dK [][]float64
}

func newCopySeqWS(n int) *copySeqWS {
	return &copySeqWS{K: make([][]float64, n), dK: make([][]float64, n)}
}

func (ws *copySeqWS) kOf(ch *copyHead, ph [][]float64, s int) []float64 {
	if ws.K[s] == nil {
		H := len(ph[s])
		k := make([]float64, H)
		for i := 0; i < H; i++ {
			for j := 0; j < H; j++ {
				k[i] += ch.Wk[i][j] * ph[s][j]
			}
		}
		ws.K[s] = k
	}
	return ws.K[s]
}

// flushWk: aplica dWk[i][j] = sum_s dK_s[i]*h_s[j] una sola vez por secuencia.
func (ws *copySeqWS) flushWk(ch *copyHead, ph [][]float64, cg *copyGrads) {
	for s := range ws.dK {
		if ws.dK[s] == nil {
			continue
		}
		for i := range ch.Wk {
			for j := range ch.Wk[i] {
				cg.Wk[i][j] += ws.dK[s][i] * ph[s][j]
			}
		}
	}
}

// copyStep: forward de UN paso de respuesta con mezcla copia.
// hT: estado actual; ph: estados del prompt (tras cada byte); pb: bytes del prompt.
// forceGate0: si true, u=0 (paridad con ruta base).
func (ch *copyHead) copyStep(g *GRU, hT []float64, ph [][]float64, pb []byte, forceGate0 bool, ws *copySeqWS) ([]float64, *copyCache) {
	if len(ph) != len(pb) {
		panic("copyStep: desfase estados/bytes del prompt")
	}
	H := g.H
	sc := 1.0 / math.Sqrt(float64(H))
	q := make([]float64, H)
	for i := 0; i < H; i++ {
		for j := 0; j < H; j++ {
			q[i] += ch.Wq[i][j] * hT[j]
		}
	}
	scores := make([]float64, len(ph))
	mx := math.Inf(-1)
	for s := range ph {
		ks := ws.kOf(ch, ph, s)
		var dot float64
		for i := 0; i < H; i++ {
			dot += q[i] * ks[i]
		}
		scores[s] = dot * sc
		if scores[s] > mx {
			mx = scores[s]
		}
	}
	alfa := make([]float64, len(ph))
	var sum float64
	for s := range ph {
		alfa[s] = math.Exp(scores[s] - mx)
		sum += alfa[s]
	}
	for s := range ph {
		alfa[s] /= sum
	}
	c := make([]float64, H)
	for s := range ph {
		for i := 0; i < H; i++ {
			c[i] += alfa[s] * ph[s][i]
		}
	}
	v := ch.Bg
	for i := 0; i < H; i++ {
		v += ch.Wg[i]*hT[i] + ch.Wg[H+i]*c[i]
	}
	u := 1.0 / (1.0 + math.Exp(-v))
	if forceGate0 {
		u = 0
	}
	pGru := softmax(g.logits(hT))
	p := make([]float64, 256)
	for b := 0; b < 256; b++ {
		p[b] = (1 - u) * pGru[b]
	}
	for s := range ph {
		p[pb[s]] += u * alfa[s]
	}
	return p, &copyCache{alfa: alfa, c: c, q: q, u: u, pGru: pGru, hT: append([]float64(nil), hT...)}
}

// copyBackward: dp = dL/dp (espacio de probabilidad). Acumula gradientes de la
// cabeza en cg, gradientes del GRU (rama p_gru) en gr, y contribuciones a
// dhT y dph (estados del prompt) para seguir el BPTT.
func (ch *copyHead) copyBackward(g *GRU, cc *copyCache, ph [][]float64, pb []byte, dp []float64, cg *copyGrads, gr *gruGrads, dhT []float64, dph [][]float64, ws *copySeqWS) {
	H := g.H
	sc := 1.0 / math.Sqrt(float64(H))
	// p_copy(b) = sum_{s: pb[s]=b} alfa_s
	du := 0.0
	for s := range ph {
		du += dp[pb[s]] * cc.alfa[s] // sum_b dp[b]*p_copy[b]
	}
	for b := 0; b < 256; b++ {
		du -= dp[b] * cc.pGru[b] // - sum_b dp[b]*p_gru[b]
	}
	dv := du * cc.u * (1 - cc.u) // force0 => u=0 => dv=0
	for i := 0; i < H; i++ {
		cg.Wg[i] += dv * cc.hT[i]
		cg.Wg[H+i] += dv * cc.c[i]
		dhT[i] += dv * ch.Wg[i]
	}
	cg.Bg += dv
	dc := make([]float64, H)
	for i := 0; i < H; i++ {
		dc[i] = dv * ch.Wg[H+i]
	}
	// d alfa: via p_copy y via c ; y dph via c
	dalfa := make([]float64, len(ph))
	for s := range ph {
		dalfa[s] = cc.u * dp[pb[s]]
		for i := 0; i < H; i++ {
			dalfa[s] += dc[i] * ph[s][i]
			dph[s][i] += cc.alfa[s] * dc[i]
		}
	}
	// softmax(scores)
	var dsum float64
	for s := range ph {
		dsum += cc.alfa[s] * dalfa[s]
	}
	// wq_t = Wk^T * q (una vez por paso): dph[s] += ds * wq_t ; dK_s += ds*q
	wq := make([]float64, H)
	for j := 0; j < H; j++ {
		for i := 0; i < H; i++ {
			wq[j] += ch.Wk[i][j] * cc.q[i]
		}
	}
	dq := make([]float64, H)
	for s := range ph {
		ds := cc.alfa[s] * (dalfa[s] - dsum) * sc
		ks := ws.kOf(ch, ph, s)
		if ws.dK[s] == nil {
			ws.dK[s] = make([]float64, H)
		}
		for i := 0; i < H; i++ {
			dq[i] += ds * ks[i]
			ws.dK[s][i] += ds * cc.q[i]
			dph[s][i] += ds * wq[i]
		}
	}
	for i := 0; i < H; i++ {
		for j := 0; j < H; j++ {
			cg.Wq[i][j] += dq[i] * cc.hT[j]
			dhT[j] += ch.Wq[i][j] * dq[i]
		}
	}
	// rama p_gru: dp_gru = dp*(1-u) -> softmax(logits) backward estandar
	dpg := make([]float64, 256)
	var dpgDot float64
	for b := 0; b < 256; b++ {
		dpg[b] = dp[b] * (1 - cc.u)
		dpgDot += cc.pGru[b] * dpg[b]
	}
	for b := 0; b < 256; b++ {
		dlg := cc.pGru[b] * (dpg[b] - dpgDot)
		gr.Bo[b] += dlg
		for i := 0; i < H; i++ {
			gr.Wo[b][i] += dlg * cc.hT[i]
			dhT[i] += g.Wo[b][i] * dlg
		}
	}
}

// trainSeqMaskCopy: como trainSeqMask pero con la cabeza de copia en los pasos
// de loss. promptEnd = indice en seq del ULTIMO byte del prompt (los estados del
// prompt son los h tras seq[0..promptEnd]). Duplica la matematica del backward de
// trainSeqMask SIN tocar la ruta base; su correccion la garantizan los tests:
// paridad exacta con gate=0 y FD contra la loss.
func (g *GRU) trainSeqMaskCopy(seq []byte, lossFrom int, promptEnd int, ch *copyHead, forceGate0 bool, gr *gruGrads, cg *copyGrads) (float64, int) {
	if len(seq) < 2 || promptEnd < 0 || promptEnd >= len(seq)-1 {
		panic("trainSeqMaskCopy: seq/promptEnd invalidos")
	}
	// Invariante anti lectura futura: el conjunto atendido son SOLO las
	// posiciones del prompt [0..promptEnd]; en un paso de perdida t los estados
	// atendidos son hAfter[0..promptEnd], todos de posicion <= t. Si lossFrom
	// fuese < promptEnd habria pasos de perdida que atienden a estados de
	// posicion > t (futuro): se rechaza.
	if lossFrom < promptEnd {
		panic("trainSeqMaskCopy: lossFrom < promptEnd (lectura futura)")
	}
	H, D := g.H, g.D
	T := len(seq) - 1
	caches := make([]*gruCache, T)
	ccs := make([]*copyCache, T)
	ws := newCopySeqWS(promptEnd + 1)
	hAfter := make([][]float64, T)
	h := make([]float64, H)
	acc := 0.0
	nloss := 0
	for t := 0; t < T; t++ {
		c, hn := g.step(h, seq[t])
		caches[t] = c
		h = hn
		hAfter[t] = h
		if t >= lossFrom {
			p, cc := ch.copyStep(g, h, hAfter[:promptEnd+1], seq[:promptEnd+1], forceGate0, ws)
			ccs[t] = cc
			pr := p[seq[t+1]]
			if pr < 1e-12 {
				pr = 1e-12
			}
			acc += -math.Log2(pr)
			nloss++
		}
	}
	if nloss == 0 {
		return 0, 0
	}
	ph := hAfter[:promptEnd+1]
	pb := copyPromptBytes(seq, promptEnd)
	dph := make([][]float64, len(ph))
	for i := range dph {
		dph[i] = make([]float64, H)
	}
	dh := make([]float64, H)
	sc := 1.0 / (float64(nloss) * math.Ln2)
	for t := T - 1; t >= 0; t-- {
		c := caches[t]
		// contribucion de dph: dph[t] es grad respecto a hAfter[t], entra en ESTE paso
		if t <= promptEnd {
			for i := 0; i < H; i++ {
				dh[i] += dph[t][i]
			}
		}
		if t >= lossFrom {
			cc := ccs[t]
			// p_y reconstruido del cache (sin recompute): p = (1-u)*pGru + u*p_copy
			y := seq[t+1]
			py := (1 - cc.u) * cc.pGru[y]
			for s2 := range pb {
				if pb[s2] == y {
					py += cc.u * cc.alfa[s2]
				}
			}
			if py < 1e-12 {
				py = 1e-12
			}
			dp := make([]float64, 256)
			// dp en espacio de probabilidad: d(-sc*ln p_y)/dp_y = -sc/p_y
			dp[y] = -sc / py
			dhT := make([]float64, H)
			ch.copyBackward(g, cc, ph, pb, dp, cg, gr, dhT, dph, ws)
			for i := 0; i < H; i++ {
				dh[i] += dhT[i]
			}
		}
		// backward GRU del paso (misma matematica que trainSeqMask)
		dhLoc := make([]float64, H)
		copy(dhLoc, dh)
		dz := make([]float64, H)
		dn := make([]float64, H)
		dhPrev := make([]float64, H)
		for i := 0; i < H; i++ {
			dz[i] = dhLoc[i] * (c.n[i] - c.hPrev[i])
			dn[i] = dhLoc[i] * c.z[i]
			dhPrev[i] = dhLoc[i] * (1 - c.z[i])
		}
		drhx := make([]float64, H+D)
		for i := 0; i < H; i++ {
			dsn := dn[i] * (1 - c.n[i]*c.n[i])
			gr.Bn[i] += dsn
			for j := 0; j < H+D; j++ {
				var rhxj float64
				if j < H {
					rhxj = c.r[j] * c.hPrev[j]
				} else {
					rhxj = c.x[j-H]
				}
				gr.Wn[i][j] += dsn * rhxj
				drhx[j] += dsn * g.Wn[i][j]
			}
		}
		dr := make([]float64, H)
		dx := make([]float64, D)
		for i := 0; i < H; i++ {
			dr[i] = drhx[i] * c.hPrev[i]
			dhPrev[i] += drhx[i] * c.r[i]
		}
		for j := 0; j < D; j++ {
			dx[j] = drhx[H+j]
		}
		dhx := make([]float64, H+D)
		for i := 0; i < H; i++ {
			dsz := dz[i] * c.z[i] * (1 - c.z[i])
			dsr := dr[i] * c.r[i] * (1 - c.r[i])
			gr.Bz[i] += dsz
			gr.Br[i] += dsr
			for j := 0; j < H+D; j++ {
				var hxj float64
				if j < H {
					hxj = c.hPrev[j]
				} else {
					hxj = c.x[j-H]
				}
				gr.Wz[i][j] += dsz * hxj
				gr.Wr[i][j] += dsr * hxj
				dhx[j] += dsz*g.Wz[i][j] + dsr*g.Wr[i][j]
			}
		}
		for i := 0; i < H; i++ {
			dhPrev[i] += dhx[i]
		}
		for j := 0; j < D; j++ {
			dx[j] += dhx[H+j]
		}
		for j := 0; j < D; j++ {
			gr.E[seq[t]][j] += dx[j]
		}
		copy(dh, dhPrev)
	}
	ws.flushWk(ch, ph, cg)
	return acc / float64(nloss), nloss
}

// ---- Adam del grupo copy: contador PROPIO (t=0 al crear; primer update -> 1).
// El t del GRU queda heredado e intacto. Con momentos en 0 y contador propio,
// el primer update tiene ratio 1.0*lr (correccion de sesgo estandar del grupo
// nuevo); heredar el t del GRU produciria ratio ~3.11449*lr (beta1=0.9,
// beta2=0.999, t=3505), dinamica incorrecta: por eso contador separado.
// Los betas/eps reflejan los literales de adamApply (0.9, 0.999, 1e-8).

type copyAdamState struct {
	mWq, vWq [][]float64
	mWk, vWk [][]float64
	mWg, vWg []float64
	mBg, vBg float64
	t        int
}

func newCopyAdam(h int) *copyAdamState {
	mk := func() [][]float64 {
		M := make([][]float64, h)
		for i := range M {
			M[i] = make([]float64, h)
		}
		return M
	}
	return &copyAdamState{mWq: mk(), vWq: mk(), mWk: mk(), vWk: mk(),
		mWg: make([]float64, 2*h), vWg: make([]float64, 2*h)}
}

func (st *copyAdamState) apply(ch *copyHead, cg *copyGrads, lr float64) {
	st.t++
	b1, b2, eps := 0.9, 0.999, 1e-8
	c1 := 1 - math.Pow(b1, float64(st.t))
	c2 := 1 - math.Pow(b2, float64(st.t))
	updM := func(P, G, M, V [][]float64) {
		for i := range P {
			for j := range P[i] {
				gij := G[i][j]
				M[i][j] = b1*M[i][j] + (1-b1)*gij
				V[i][j] = b2*V[i][j] + (1-b2)*gij*gij
				P[i][j] -= lr * (M[i][j] / c1) / (math.Sqrt(V[i][j]/c2) + eps)
				G[i][j] = 0
			}
		}
	}
	updM(ch.Wq, cg.Wq, st.mWq, st.vWq)
	updM(ch.Wk, cg.Wk, st.mWk, st.vWk)
	for i := range ch.Wg {
		gi := cg.Wg[i]
		st.mWg[i] = b1*st.mWg[i] + (1-b1)*gi
		st.vWg[i] = b2*st.vWg[i] + (1-b2)*gi*gi
		ch.Wg[i] -= lr * (st.mWg[i] / c1) / (math.Sqrt(st.vWg[i]/c2) + eps)
		cg.Wg[i] = 0
	}
	st.mBg = b1*st.mBg + (1-b1)*cg.Bg
	st.vBg = b2*st.vBg + (1-b2)*cg.Bg*cg.Bg
	ch.Bg -= lr * (st.mBg / c1) / (math.Sqrt(st.vBg/c2) + eps)
	cg.Bg = 0
}

// ---- Serializacion v2: seccion "copy" OPCIONAL (omitempty) en el checkpoint.
// v1 (sin seccion) carga intacta: la migracion es init aleatoria pequena del
// head + copyAdam en cero, NUNCA pesos del algoritmo oraculo.

type copyJSON struct {
	Wq  [][]float64 `json:"wq"`
	Wk  [][]float64 `json:"wk"`
	Wg  []float64   `json:"wg"`
	Bg  float64     `json:"bg"`
	MWq [][]float64 `json:"mwq"`
	VWq [][]float64 `json:"vwq"`
	MWk [][]float64 `json:"mwk"`
	VWk [][]float64 `json:"vwk"`
	MWg []float64   `json:"mwg"`
	VWg []float64   `json:"vwg"`
	MBg float64     `json:"mbg"`
	VBg float64     `json:"vbg"`
	T   int         `json:"t"`
}

// saveCopy: guarda checkpoint v2 (GRU + seccion copy + adam copy). Atomico.
func (g *GRU) saveCopy(path string, steps int, bpbv float64, st *adamGRUState, ch *copyHead, cs *copyAdamState, samp uint64, corpusSHA string, seed int64, lr float64, proto string) error {
	if err := g.SaveGRU(path, steps, bpbv, st, samp, corpusSHA, seed, lr, proto); err != nil {
		return err
	}
	// re-escritura con seccion copy (SaveGRU ya dejo el payload base atomico)
	b, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	var c map[string]interface{}
	if err := json.Unmarshal(b, &c); err != nil {
		return err
	}
	c["ckpt_version"] = 2
	c["copy"] = copyJSON{Wq: ch.Wq, Wk: ch.Wk, Wg: ch.Wg, Bg: ch.Bg,
		MWq: cs.mWq, VWq: cs.vWq, MWk: cs.mWk, VWk: cs.vWk, MWg: cs.mWg, VWg: cs.vWg,
		MBg: cs.mBg, VBg: cs.vBg, T: cs.t}
	b2, err := json.Marshal(c)
	if err != nil {
		return err
	}
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, b2, 0644); err != nil {
		os.Remove(tmp)
		return err
	}
	if err := os.Rename(tmp, path); err != nil {
		os.Remove(tmp)
		return err
	}
	return nil
}

// copyPromptBytes: definicion UNICA del prefijo atendido: seq[0..promptEnd]
// inclusive. La usan train (trainSeqMaskCopy) y gen (genGreedyCopy): ninguna
// otra porcion de la secuencia entra en pb/ph; el target gold JAMAS esta en pb
// (pb cubre solo el prompt y la perdida empieza en lossFrom >= promptEnd).
func copyPromptBytes(seq []byte, promptEnd int) []byte {
	if promptEnd < 0 || promptEnd >= len(seq) {
		panic("copyPromptBytes: promptEnd invalido")
	}
	return seq[:promptEnd+1]
}

// genGreedyCopy: generacion greedy con el copy head. Atiende SOLO a los
// estados del prompt (misma definicion copyPromptBytes que el driver de
// train); los bytes generados se realimentan al GRU pero NUNCA se anaden al
// conjunto atendido. Con forceGate0=true es byte a byte identico al greedy de
// la ruta base (paridad).
func (g *GRU) genGreedyCopy(ch *copyHead, seq []byte, promptEnd, n int, forceGate0 bool) []byte {
	if n <= 0 {
		return nil
	}
	pb := copyPromptBytes(seq, promptEnd)
	H := g.H
	ws := newCopySeqWS(len(pb))
	ph := make([][]float64, len(pb))
	h := make([]float64, H)
	for t := 0; t <= promptEnd; t++ {
		_, hn := g.step(h, seq[t])
		h = hn
		ph[t] = h
	}
	out := make([]byte, 0, n)
	for i := 0; i < n; i++ {
		p, _ := ch.copyStep(g, h, ph, pb, forceGate0, ws)
		best, bv := 0, -1.0
		for b := 0; b < 256; b++ {
			if p[b] > bv {
				bv, best = p[b], b
			}
		}
		out = append(out, byte(best))
		_, h = g.step(h, byte(best))
	}
	return out
}

// ---- Carga estricta v2 ----
// Reglas: ckpt_version ausente o 1 => migracion v1 EXPLICITA (migratedV1=true,
// head/adam nil; el llamador inicializa). ckpt_version=2 => seccion "copy"
// OBLIGATORIA y validada (formas, finitud, contadores). Otra version =>
// rechazo. Un v2 sin seccion copy o corrupto se RECHAZA: nunca se reinterpreta
// en silencio como v1.
func loadCopyStrict(path string) (*GRU, int, float64, *copyHead, *copyAdamState, bool, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, 0, 0, nil, nil, false, err
	}
	var probe struct {
		Version *int             `json:"ckpt_version"`
		Copy    *json.RawMessage `json:"copy"`
	}
	if err := json.Unmarshal(b, &probe); err != nil {
		return nil, 0, 0, nil, nil, false, fmt.Errorf("loadCopyStrict: json invalido: %v", err)
	}
	g, steps, bpbv, err := LoadGRUFull(path)
	if err != nil {
		return nil, 0, 0, nil, nil, false, err
	}
	if probe.Version == nil || *probe.Version == 1 {
		return g, steps, bpbv, nil, nil, true, nil
	}
	if *probe.Version != 2 {
		return nil, 0, 0, nil, nil, false, fmt.Errorf("loadCopyStrict: ckpt_version desconocida %d", *probe.Version)
	}
	if probe.Copy == nil {
		return nil, 0, 0, nil, nil, false, fmt.Errorf("loadCopyStrict: v2 sin seccion copy")
	}
	var cj copyJSON
	if err := json.Unmarshal(*probe.Copy, &cj); err != nil {
		return nil, 0, 0, nil, nil, false, fmt.Errorf("loadCopyStrict: seccion copy invalida: %v", err)
	}
	H := g.H
	matOK := func(M [][]float64, r, c int) bool {
		if len(M) != r {
			return false
		}
		for _, row := range M {
			if len(row) != c {
				return false
			}
			for _, v := range row {
				if math.IsNaN(v) || math.IsInf(v, 0) {
					return false
				}
			}
		}
		return true
	}
	vecOK := func(V []float64, n int) bool {
		if len(V) != n {
			return false
		}
		for _, v := range V {
			if math.IsNaN(v) || math.IsInf(v, 0) {
				return false
			}
		}
		return true
	}
	finOK := func(v float64) bool { return !math.IsNaN(v) && !math.IsInf(v, 0) }
	if !matOK(cj.Wq, H, H) || !matOK(cj.Wk, H, H) || !matOK(cj.MWq, H, H) || !matOK(cj.VWq, H, H) ||
		!matOK(cj.MWk, H, H) || !matOK(cj.VWk, H, H) {
		return nil, 0, 0, nil, nil, false, fmt.Errorf("loadCopyStrict: forma o finitud invalida en matrices copy")
	}
	if !vecOK(cj.Wg, 2*H) || !vecOK(cj.MWg, 2*H) || !vecOK(cj.VWg, 2*H) || !finOK(cj.Bg) || !finOK(cj.MBg) || !finOK(cj.VBg) {
		return nil, 0, 0, nil, nil, false, fmt.Errorf("loadCopyStrict: forma o finitud invalida en vectores/escalares copy")
	}
	if cj.T < 0 {
		return nil, 0, 0, nil, nil, false, fmt.Errorf("loadCopyStrict: contador t_copy invalido (%d)", cj.T)
	}
	ch := newCopyHead(H)
	cs := newCopyAdam(H)
	ch.Wq, ch.Wk, ch.Wg, ch.Bg = cj.Wq, cj.Wk, cj.Wg, cj.Bg
	cs.mWq, cs.vWq, cs.mWk, cs.vWk = cj.MWq, cj.VWq, cj.MWk, cj.VWk
	cs.mWg, cs.vWg, cs.mBg, cs.vBg, cs.t = cj.MWg, cj.VWg, cj.MBg, cj.VBg, cj.T
	return g, steps, bpbv, ch, cs, false, nil
}

// ---- Integracion CLI (brazo A). La ruta base NO se toca: estos caminos solo
// se activan con -copyhead=learn. gate0 = ruta base LITERAL (u=0 bit a bit).

// initCopyHeadFromSeed: init aleatoria pequena (escala 0.1) con semilla PROPIA
// del head (NO el sampler de pares ni NewGRU). Pesos base intactos.
func initCopyHeadFromSeed(h int, seed int64) *copyHead {
	ch := newCopyHead(h)
	r := rand.New(rand.NewSource(seed))
	for i := range ch.Wq {
		for j := range ch.Wq[i] {
			ch.Wq[i][j] = r.NormFloat64() * 0.1
			ch.Wk[i][j] = r.NormFloat64() * 0.1
		}
	}
	for i := range ch.Wg {
		ch.Wg[i] = r.NormFloat64() * 0.1
	}
	return ch
}

// genParGreedyCopy: greedy con cabeza; atiende SOLO a los estados del prompt
// (misma definicion copyPromptBytes: seq[0..len(prompt)-1]). Corta en '\n'.
func genParGreedyCopy(g *GRU, ch *copyHead, pregunta string, maxB int) string {
	prompt := []byte("U: " + pregunta + "\nA: ")
	promptEnd := len(prompt) - 1
	out := g.genGreedyCopy(ch, prompt, promptEnd, maxB, false)
	for i, b := range out {
		if b == '\n' {
			return string(out[:i])
		}
	}
	return string(out)
}

// pairLossCopy: misma metrica legada que pairLoss (la perdida NO puntua el
// primer byte de la respuesta) pero puntuando con la cabeza; atencion SOLO a
// estados del prompt (config congelada). Comparabilidad historica preservada
// por usar la misma definicion de perdida.
func (g *GRU) pairLossCopy(ch *copyHead, prompt, answer []byte) float64 {
	if len(answer) < 2 {
		return 0
	}
	promptEnd := len(prompt) - 1
	full := append(append([]byte(nil), prompt...), answer...)
	ph := make([][]float64, len(prompt))
	h := make([]float64, g.H)
	for t := 0; t <= promptEnd; t++ {
		_, hn := g.step(h, full[t])
		h = hn
		ph[t] = h
	}
	pb := copyPromptBytes(full, promptEnd)
	ws := newCopySeqWS(len(pb))
	acc := 0.0
	for t := 0; t+1 < len(answer); t++ {
		_, hn := g.step(h, answer[t])
		h = hn
		p, _ := ch.copyStep(g, h, ph, pb, false, ws)
		pr := p[answer[t+1]]
		if pr < 1e-12 {
			pr = 1e-12
		}
		acc += -math.Log2(pr)
	}
	return acc / float64(len(answer)-1)
}
