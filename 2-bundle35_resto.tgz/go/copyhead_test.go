package main

// copyhead_test.go — PREP sin training: (a) paridad gate=0 fwd, (b) gradiente
// analitico vs diferencias finitas de la cabeza (Wq, Wk, Wg, Bg) y de dhT/dph.

import (
	"encoding/json"
	"fmt"
	"strings"
	"os"
	"math"
	"math/rand"
	"testing"
)

// lossCopyToy: perdida -log p(gold) por cada byte de respuesta, con estados de
// prompt/respuesta dados (sin BPTT del GRU: valida la cabeza y sus dhT/dph).
func lossCopyToy(g *GRU, ch *copyHead, ph [][]float64, pb []byte, hans [][]float64, ans []byte) float64 {
	tot := 0.0
	for t, hT := range hans {
		p, _ := ch.copyStep(g, hT, ph, pb, false, newCopySeqWS(len(ph)))
		pr := p[ans[t]]
		if pr < 1e-12 {
			pr = 1e-12
		}
		tot += -math.Log(pr)
	}
	return tot
}

func gradsCopyToy(g *GRU, ch *copyHead, ph [][]float64, pb []byte, hans [][]float64, ans []byte) (*copyGrads, [][]float64, [][]float64) {
	cg := newCopyGrads(g.H)
	gr := g.newGrads()
	ws := newCopySeqWS(len(ph))
	dhs := make([][]float64, len(hans))
	dph := make([][]float64, len(ph))
	for i := range dhs {
		dhs[i] = make([]float64, g.H)
	}
	for i := range dph {
		dph[i] = make([]float64, g.H)
	}
	for t, hT := range hans {
		p, cc := ch.copyStep(g, hT, ph, pb, false, ws)
		dp := make([]float64, 256)
		pr := p[ans[t]]
		if pr < 1e-12 {
			pr = 1e-12
		}
		dp[ans[t]] = -1.0 / pr
		ch.copyBackward(g, cc, ph, pb, dp, cg, gr, dhs[t], dph, ws)
	}
	ws.flushWk(ch, ph, cg)
	return cg, dhs, dph
}

func TestCopyGate0Paridad(t *testing.T) {
	g := NewGRU(7, 8, 16)
	ch := newCopyHead(g.H)
	r := rand.New(rand.NewSource(1))
	ph := make([][]float64, 5)
	for i := range ph {
		ph[i] = make([]float64, g.H)
		for j := range ph[i] {
			ph[i][j] = r.NormFloat64() * 0.5
		}
	}
	pb := []byte("U: xy")
	hT := make([]float64, g.H)
	for j := range hT {
		hT[j] = r.NormFloat64() * 0.5
	}
	p, _ := ch.copyStep(g, hT, ph, pb, true, newCopySeqWS(len(ph)))
	pg := softmax(g.logits(hT))
	for b := 0; b < 256; b++ {
		if math.Abs(p[b]-pg[b]) > 1e-15 {
			t.Fatalf("gate0 fwd no paridad en byte %d: %v vs %v", b, p[b], pg[b])
		}
	}
}

func TestCopyGradsFD(t *testing.T) {
	g := NewGRU(7, 8, 16)
	ch := newCopyHead(g.H)
	r := rand.New(rand.NewSource(2))
	llenar := func(M [][]float64) {
		for i := range M {
			for j := range M[i] {
				M[i][j] = r.NormFloat64() * 0.3
			}
		}
	}
	llenar(ch.Wq)
	llenar(ch.Wk)
	for i := range ch.Wg {
		ch.Wg[i] = r.NormFloat64() * 0.3
	}
	ch.Bg = r.NormFloat64() * 0.3
	ph := make([][]float64, 5)
	for i := range ph {
		ph[i] = make([]float64, g.H)
		for j := range ph[i] {
			ph[i][j] = r.NormFloat64() * 0.5
		}
	}
	pb := []byte("U: ab")
	hans := make([][]float64, 3)
	for i := range hans {
		hans[i] = make([]float64, g.H)
		for j := range hans[i] {
			hans[i][j] = r.NormFloat64() * 0.5
		}
	}
	ans := []byte("ab\n")
	cg, dhs, dph := gradsCopyToy(g, ch, ph, pb, hans, ans)
	eps := 1e-6
	chk := func(name string, ana float64, get func() float64, set func(float64)) {
		o := get()
		set(o + eps)
		l1 := lossCopyToy(g, ch, ph, pb, hans, ans)
		set(o - eps)
		l2 := lossCopyToy(g, ch, ph, pb, hans, ans)
		set(o)
		fd := (l1 - l2) / (2 * eps)
		if math.Abs(fd-ana) > 1e-5+1e-3*math.Abs(fd) {
			t.Fatalf("FD mismatch %s: analitico %v vs FD %v", name, ana, fd)
		}
	}
	chk("Wq[0][0]", cg.Wq[0][0], func() float64 { return ch.Wq[0][0] }, func(v float64) { ch.Wq[0][0] = v })
	chk("Wq[5][7]", cg.Wq[5][7], func() float64 { return ch.Wq[5][7] }, func(v float64) { ch.Wq[5][7] = v })
	chk("Wk[3][2]", cg.Wk[3][2], func() float64 { return ch.Wk[3][2] }, func(v float64) { ch.Wk[3][2] = v })
	chk("Wk[9][1]", cg.Wk[9][1], func() float64 { return ch.Wk[9][1] }, func(v float64) { ch.Wk[9][1] = v })
	chk("Wg[0]", cg.Wg[0], func() float64 { return ch.Wg[0] }, func(v float64) { ch.Wg[0] = v })
	chk("Wg[17]", cg.Wg[17], func() float64 { return ch.Wg[17] }, func(v float64) { ch.Wg[17] = v })
	chk("Bg", cg.Bg, func() float64 { return ch.Bg }, func(v float64) { ch.Bg = v })
	chk("dhT[1][4]", dhs[1][4], func() float64 { return hans[1][4] }, func(v float64) { hans[1][4] = v })
	chk("dph[2][6]", dph[2][6], func() float64 { return ph[2][6] }, func(v float64) { ph[2][6] = v })
}

func TestCopyGate0BackwardParidad(t *testing.T) {
	g := NewGRU(7, 8, 16)
	ch := newCopyHead(g.H)
	r := rand.New(rand.NewSource(3))
	ph := make([][]float64, 5)
	for i := range ph {
		ph[i] = make([]float64, g.H)
		for j := range ph[i] {
			ph[i][j] = r.NormFloat64() * 0.5
		}
	}
	pb := []byte("U: ab")
	hT := make([]float64, g.H)
	for j := range hT {
		hT[j] = r.NormFloat64() * 0.5
	}
	gold := byte('a')
	ws := newCopySeqWS(len(ph))
	p, cc := ch.copyStep(g, hT, ph, pb, true, ws)
	dp := make([]float64, 256)
	dp[gold] = -1.0 / p[gold]
	cg := newCopyGrads(g.H)
	gr := g.newGrads()
	dhT := make([]float64, g.H)
	dph := make([][]float64, len(ph))
	for i := range dph {
		dph[i] = make([]float64, g.H)
	}
	ch.copyBackward(g, cc, ph, pb, dp, cg, gr, dhT, dph, ws)
	ws.flushWk(ch, ph, cg)
	// referencia: backward softmax estandar sobre logits(hT)
	pg := softmax(g.logits(hT))
	var dot float64
	for b := 0; b < 256; b++ {
		dot += pg[b] * dp[b]
	}
	for b := 0; b < 256; b++ {
		dlg := pg[b] * (dp[b] - dot)
		if math.Abs(gr.Bo[b]-dlg) > 1e-15 {
			t.Fatalf("gate0 bwd: Bo[%d] %v vs ref %v", b, gr.Bo[b], dlg)
		}
	}
	// cabeza sin gradiente util con gate forzado 0
	for i := range cg.Wg {
		if cg.Wg[i] != 0 || cg.Bg != 0 {
			t.Fatalf("gate0 bwd: gradiente de gate no nulo")
		}
	}
	for i := range cg.Wq {
		for j := range cg.Wq[i] {
			if cg.Wq[i][j] != 0 || cg.Wk[i][j] != 0 {
				t.Fatalf("gate0 bwd: gradiente QK no nulo")
			}
		}
	}
}

// Driver integrado: paridad gate=0 vs trainSeqMask (loss + TODOS los grads GRU),
// FD de grupos GRU (E, Wz, Wr, Wn, Wo, biases) y cabeza via loss integrada
// multipaso (prompt compartido, gradientes acumulan), y rechazo de desfase.
func TestCopyDriverParidadGate0(t *testing.T) {
	g := NewGRU(11, 8, 16)
	ch := newCopyHead(g.H)
	seq := []byte("U: repite 'ab'\nA: ab\n")
	lossFrom := 15 // primer byte de respuesta - 1 (mask: t >= lossFrom puntua seq[t+1])
	promptEnd := 14
	gr1 := g.newGrads()
	cg := newCopyGrads(g.H)
	l1, n1 := g.trainSeqMaskCopy(seq, lossFrom, promptEnd, ch, true, gr1, cg)
	gr2 := g.newGrads()
	l2, n2 := g.trainSeqMask(seq, lossFrom, gr2)
	if n1 != n2 || math.Abs(l1-l2) > 1e-12 {
		t.Fatalf("loss no paridad: %v vs %v (n %d/%d)", l1, l2, n1, n2)
	}
	tol := 1e-10
	for b := 0; b < 256; b++ {
		for j := 0; j < g.D; j++ {
			if math.Abs(gr1.E[b][j]-gr2.E[b][j]) > tol {
				t.Fatalf("E[%d][%d] %v vs %v", b, j, gr1.E[b][j], gr2.E[b][j])
			}
		}
		if math.Abs(gr1.Bo[b]-gr2.Bo[b]) > tol {
			t.Fatalf("Bo[%d]", b)
		}
		for i := 0; i < g.H; i++ {
			if math.Abs(gr1.Wo[b][i]-gr2.Wo[b][i]) > tol {
				t.Fatalf("Wo[%d][%d]", b, i)
			}
		}
	}
	for i := 0; i < g.H; i++ {
		for j := 0; j < g.H+g.D; j++ {
			if math.Abs(gr1.Wz[i][j]-gr2.Wz[i][j]) > tol || math.Abs(gr1.Wr[i][j]-gr2.Wr[i][j]) > tol || math.Abs(gr1.Wn[i][j]-gr2.Wn[i][j]) > tol {
				t.Fatalf("W*[%d][%d] no paridad", i, j)
			}
		}
		if math.Abs(gr1.Bz[i]-gr2.Bz[i]) > tol || math.Abs(gr1.Br[i]-gr2.Br[i]) > tol || math.Abs(gr1.Bn[i]-gr2.Bn[i]) > tol {
			t.Fatalf("B*[%d] no paridad", i)
		}
	}
	for i := range cg.Wg {
		if cg.Wg[i] != 0 || cg.Bg != 0 {
			t.Fatalf("gate0: grad gate no nulo")
		}
	}
}

func TestCopyDriverFD(t *testing.T) {
	g := NewGRU(11, 8, 16)
	ch := newCopyHead(g.H)
	r := rand.New(rand.NewSource(4))
	for i := range ch.Wq {
		for j := range ch.Wq[i] {
			ch.Wq[i][j] = r.NormFloat64() * 0.3
			ch.Wk[i][j] = r.NormFloat64() * 0.3
		}
	}
	for i := range ch.Wg {
		ch.Wg[i] = r.NormFloat64() * 0.3
	}
	ch.Bg = r.NormFloat64() * 0.3
	seq := []byte("U: repite 'ab'\nA: ab\n")
	lossFrom, promptEnd := 15, 14
	loss := func() float64 {
		gr := g.newGrads()
		cg := newCopyGrads(g.H)
		l, _ := g.trainSeqMaskCopy(seq, lossFrom, promptEnd, ch, false, gr, cg)
		return l
	}
	gr := g.newGrads()
	cg := newCopyGrads(g.H)
	l0, n := g.trainSeqMaskCopy(seq, lossFrom, promptEnd, ch, false, gr, cg)
	if n == 0 || l0 <= 0 {
		t.Fatalf("loss integrada vacia")
	}
	eps := 1e-6
	chk := func(name string, ana float64, get func() float64, set func(float64)) {
		o := get()
		set(o + eps)
		l1 := loss()
		set(o - eps)
		l2 := loss()
		set(o)
		fd := (l1 - l2) / (2 * eps)
		if math.Abs(fd-ana) > 1e-5+1e-3*math.Abs(fd) {
			t.Fatalf("FD mismatch %s: analitico %v vs FD %v", name, ana, fd)
		}
	}
	// grupos GRU (muestras de cada uno) via loss integrada multipaso
	chk("E['a'][0]", gr.E['a'][0], func() float64 { return g.E['a'][0] }, func(v float64) { g.E['a'][0] = v })
	chk("E['U'][3]", gr.E['U'][3], func() float64 { return g.E['U'][3] }, func(v float64) { g.E['U'][3] = v })
	chk("Wz[2][5]", gr.Wz[2][5], func() float64 { return g.Wz[2][5] }, func(v float64) { g.Wz[2][5] = v })
	chk("Wr[7][1]", gr.Wr[7][1], func() float64 { return g.Wr[7][1] }, func(v float64) { g.Wr[7][1] = v })
	chk("Wn[4][9]", gr.Wn[4][9], func() float64 { return g.Wn[4][9] }, func(v float64) { g.Wn[4][9] = v })
	chk("Wo['a'][6]", gr.Wo['a'][6], func() float64 { return g.Wo['a'][6] }, func(v float64) { g.Wo['a'][6] = v })
	chk("Bz[3]", gr.Bz[3], func() float64 { return g.Bz[3] }, func(v float64) { g.Bz[3] = v })
	chk("Br[8]", gr.Br[8], func() float64 { return g.Br[8] }, func(v float64) { g.Br[8] = v })
	chk("Bn[0]", gr.Bn[0], func() float64 { return g.Bn[0] }, func(v float64) { g.Bn[0] = v })
	chk("Bo['b']", gr.Bo['b'], func() float64 { return g.Bo['b'] }, func(v float64) { g.Bo['b'] = v })
	// cabeza via loss integrada (prompt compartido, acumulacion multipaso)
	chk("Wq[1][1]", cg.Wq[1][1], func() float64 { return ch.Wq[1][1] }, func(v float64) { ch.Wq[1][1] = v })
	chk("Wk[2][3]", cg.Wk[2][3], func() float64 { return ch.Wk[2][3] }, func(v float64) { ch.Wk[2][3] = v })
	chk("Wg[4]", cg.Wg[4], func() float64 { return ch.Wg[4] }, func(v float64) { ch.Wg[4] = v })
	chk("Bg", cg.Bg, func() float64 { return ch.Bg }, func(v float64) { ch.Bg = v })
	// shapes finitas
	for i := range cg.Wg {
		if math.IsNaN(cg.Wg[i]) || math.IsInf(cg.Wg[i], 0) {
			t.Fatalf("grad no finita Wg[%d]", i)
		}
	}
}

func TestCopyDriverRechazaDesfase(t *testing.T) {
	g := NewGRU(11, 8, 16)
	ch := newCopyHead(g.H)
	seq := []byte("U: repite 'ab'\nA: ab\n")
	gr := g.newGrads()
	cg := newCopyGrads(g.H)
	shaAntes := fmt.Sprintf("%v", g.Wo[1][1])
	func() {
		defer func() {
			if recover() == nil {
				t.Fatalf("no rechazo promptEnd invalido")
			}
		}()
		g.trainSeqMaskCopy(seq, 15, 21, ch, false, gr, cg)
	}()
	if fmt.Sprintf("%v", g.Wo[1][1]) != shaAntes {
		t.Fatalf("input modificado tras rechazo")
	}
}

// Juguete sembrado AISLADO del base real: demuestra que (a) la capacidad de copia
// existe en la arquitectura y (b) el test la detecta. NO es una partida real ni
// evidencia de aprendizaje: los estados se construyen a mano (one-hot).
func TestCopyJugueteSembrado(t *testing.T) {
	H := 4
	g := NewGRU(5, 4, H)
	ch := newCopyHead(H)
	// estados prompt one-hot: posicion s -> e_s
	ph := make([][]float64, 2)
	for s := 0; s < 2; s++ {
		ph[s] = make([]float64, H)
		ph[s][s] = 1
	}
	pb := []byte("ab")
	// Wq = Wk = identidad x10: atencion por coincidencia de estado
	for i := 0; i < H; i++ {
		ch.Wq[i][i] = 10
		ch.Wk[i][i] = 10
	}
	// consulta "quiero la posicion 1": hT = e_1
	hT := make([]float64, H)
	hT[1] = 1
	// gate abierto: Bg grande positivo
	ch.Bg = 20
	p, _ := ch.copyStep(g, hT, ph, pb, false, newCopySeqWS(len(ph)))
	if p['b'] < 0.99 {
		t.Fatalf("capacidad copia no demostrada: p(b)=%v", p['b'])
	}
	// gate cerrado: p dominada por p_gru (copia apagada)
	ch.Bg = -20
	p2, _ := ch.copyStep(g, hT, ph, pb, false, newCopySeqWS(len(ph)))
	pg := softmax(g.logits(hT))
	if math.Abs(p2['b']-pg['b']) > 1e-6 {
		t.Fatalf("gate cerrado no apaga copia")
	}
}

// Fixture escalar Adam copy: primer update con momentos en 0 y contador propio
// (0->1) tiene ratio 1.0*lr (correccion de sesgo estandar). La variante con t
// heredado (3505) daria ratio ~3.11449*lr: NO se usa; se verifica la formula
// con los betas reales del codigo (0.9/0.999/1e-8, literales de adamApply).
func TestCopyAdamPrimerUpdate(t *testing.T) {
	H := 4
	ch := newCopyHead(H)
	cs := newCopyAdam(H)
	cg := newCopyGrads(H)
	w0 := ch.Wq[1][1]
	cg.Wq[1][1] = 0.5
	lr := 0.003
	cs.apply(ch, cg, lr)
	delta := w0 - ch.Wq[1][1]
	if math.Abs(delta-lr) > 1e-9 {
		t.Fatalf("primer update copy ratio != 1.0*lr: %v", delta/lr)
	}
	if cs.t != 1 {
		t.Fatalf("contador t_copy != 1 tras primer update: %d", cs.t)
	}
	// formula con t heredado (NO usada), betas reales del codigo:
	b1, b2 := 0.9, 0.999
	ratio := func(tt float64) float64 {
		return (1 - b1) * math.Sqrt(1-math.Pow(b2, tt)) / ((1 - math.Pow(b1, tt)) * math.Sqrt(1-b2))
	}
	if math.Abs(ratio(1)-1.0) > 1e-12 {
		t.Fatalf("ratio(1) != 1: %v", ratio(1))
	}
	if math.Abs(ratio(3505)-3.11449) > 1e-3 {
		t.Fatalf("ratio(3505) != ~3.11449: %v", ratio(3505))
	}
}

// Fixture frio: save v2 -> load -> igualdad numerica EXACTA de pesos copy,
// contador y predicciones; y migracion v1 (sin seccion) detectada.
func TestCopySaveLoadFrio(t *testing.T) {
	g := NewGRU(13, 8, 16)
	ch := newCopyHead(g.H)
	r := rand.New(rand.NewSource(9))
	for i := range ch.Wq {
		for j := range ch.Wq[i] {
			ch.Wq[i][j] = r.NormFloat64() * 0.3
			ch.Wk[i][j] = r.NormFloat64() * 0.3
		}
	}
	for i := range ch.Wg {
		ch.Wg[i] = r.NormFloat64() * 0.3
	}
	ch.Bg = 0.7
	cs := newCopyAdam(g.H)
	cs.t = 3
	cs.mBg = 0.01
	st := g.newAdam()
	st.t = 480
	path := "/tmp/test_ck_v2.json"
	defer os.Remove(path)
	if err := g.saveCopy(path, 480, 3.5, st, ch, cs, 0, "sha", 13, 0.003, "test"); err != nil {
		t.Fatalf("saveCopy: %v", err)
	}
	g2, steps, _, ch2, cs2, esV1, err := loadCopyStrict(path)
	if err != nil || esV1 {
		t.Fatalf("loadCopy: err=%v esV1=%v", err, esV1)
	}
	if steps != 480 || cs2.t != 3 || cs2.mBg != 0.01 || ch2.Bg != 0.7 {
		t.Fatalf("contadores/escalares no exactos")
	}
	for i := range ch.Wq {
		for j := range ch.Wq[i] {
			if ch2.Wq[i][j] != ch.Wq[i][j] || ch2.Wk[i][j] != ch.Wk[i][j] {
				t.Fatalf("pesos copy no exactos tras load")
			}
		}
	}
	// predicciones identicas (mismo estado -> misma p)
	ph := [][]float64{{0.1, 0.2}, {0.3, 0.4}}
	for i := range ph {
		v := ph[i]
		ph[i] = make([]float64, g.H)
		copy(ph[i], v)
	}
	pb := []byte("ab")
	hT := make([]float64, g.H)
	hT[0] = 0.5
	p1, _ := ch.copyStep(g, hT, ph, pb, false, newCopySeqWS(len(ph)))
	p2, _ := ch2.copyStep(g2, hT, ph, pb, false, newCopySeqWS(len(ph)))
	for b := 0; b < 256; b++ {
		if p1[b] != p2[b] {
			t.Fatalf("prediccion difiere tras load en byte %d", b)
		}
	}
	// migracion v1: checkpoint sin seccion copy
	path1 := "/tmp/test_ck_v1.json"
	defer os.Remove(path1)
	if err := g.SaveGRU(path1, 480, 3.5, st, 0, "sha", 13, 0.003, "test"); err != nil {
		t.Fatalf("SaveGRU v1: %v", err)
	}
	_, _, _, ch3, cs3, esV1b, err := loadCopyStrict(path1)
	if err != nil || !esV1b || ch3 != nil || cs3 != nil {
		t.Fatalf("migracion v1 no detectada: err=%v esV1=%v", err, esV1b)
	}
}

// Rechazos del loader estricto v2: version desconocida, v2 sin seccion copy,
// forma invalida, no finito, contador invalido. Un v2 corrupto NUNCA se
// reinterpreta como v1.
func TestCopyLoadStrictRechazos(t *testing.T) {
	g := NewGRU(13, 8, 16)
	ch := newCopyHead(g.H)
	cs := newCopyAdam(g.H)
	st := g.newAdam()
	base := "/tmp/test_strict_base.json"
	defer os.Remove(base)
	if err := g.saveCopy(base, 10, 3.0, st, ch, cs, 0, "sha", 13, 0.003, "test"); err != nil {
		t.Fatalf("saveCopy: %v", err)
	}
	read := func(p string) map[string]interface{} {
		b, err := os.ReadFile(p)
		if err != nil {
			t.Fatalf("read: %v", err)
		}
		var m map[string]interface{}
		if err := json.Unmarshal(b, &m); err != nil {
			t.Fatalf("json: %v", err)
		}
		return m
	}
	writeVariant := func(mut func(map[string]interface{})) string {
		m := read(base)
		mut(m)
		b, _ := json.Marshal(m)
		p := "/tmp/test_strict_var.json"
		if err := os.WriteFile(p, b, 0644); err != nil {
			t.Fatalf("write: %v", err)
		}
		return p
	}
	defer os.Remove("/tmp/test_strict_var.json")
	casos := []struct {
		nombre string
		mut    func(map[string]interface{})
		causa  string
	}{
		{"version desconocida", func(m map[string]interface{}) { m["ckpt_version"] = 3 }, "version"},
		{"v2 sin seccion copy", func(m map[string]interface{}) { delete(m, "copy") }, "sin seccion copy"},
		{"forma Wq invalida", func(m map[string]interface{}) {
			c := m["copy"].(map[string]interface{})
			c["wq"] = []interface{}{[]interface{}{1.0}}
		}, "forma"},
		{"t_copy negativo", func(m map[string]interface{}) {
			c := m["copy"].(map[string]interface{})
			c["t"] = -1
		}, "contador"},
	}
	for _, c := range casos {
		p := writeVariant(c.mut)
		_, _, _, _, _, mig, err := loadCopyStrict(p)
		if err == nil {
			t.Fatalf("%s: no rechazado (mig=%v)", c.nombre, mig)
		}
		if !strings.Contains(err.Error(), c.causa) {
			t.Fatalf("%s: causa '%s' no en error: %v", c.nombre, c.causa, err)
		}
	}
	// No finitos: JSON no representa NaN/Inf, asi que llegan como texto crudo y
	// se rechazan en PARSE (el validador de finitud del loader es defensa en
	// profundidad para formatos futuros; por JSON estandar no entran).
	b, _ := os.ReadFile(base)
	for _, raw := range []string{
		strings.Replace(string(b), `"bg":0`, `"bg":NaN`, 1),
		strings.Replace(string(b), `"bg":0`, `"bg":1e999`, 1),
	} {
		pn := "/tmp/test_strict_nan.json"
		if err := os.WriteFile(pn, []byte(raw), 0644); err != nil {
			t.Fatalf("write nan: %v", err)
		}
		if _, _, _, _, _, _, err := loadCopyStrict(pn); err == nil {
			t.Fatalf("no finito no rechazado")
		}
	}
	os.Remove("/tmp/test_strict_nan.json")
	// v1: migracion EXPLICITA (migratedV1=true), nunca aceptacion silenciosa
	p1 := "/tmp/test_strict_v1.json"
	defer os.Remove(p1)
	if err := g.SaveGRU(p1, 10, 3.0, st, 0, "sha", 13, 0.003, "test"); err != nil {
		t.Fatalf("SaveGRU v1: %v", err)
	}
	_, _, _, ch1, cs1, mig, err := loadCopyStrict(p1)
	if err != nil || !mig || ch1 != nil || cs1 != nil {
		t.Fatalf("migracion v1 no explicita: err=%v mig=%v", err, mig)
	}
}

// Frio COMPLETO: todo el estado de resume sobrevive save/load exactamente:
// pesos GRU, TODOS los m/v GRU (grupos y biases), t GRU, samp (RNG), steps,
// corpus/master/manifest/seq shas y seq_pos, pesos+m/v copy, t_copy; y las
// predicciones con head tras load son identicas. Un head cargado solo NO es
// resume: por eso se verifica el estado GRU+RNG completo.
func TestCopyFrioCompleto(t *testing.T) {
	g := NewGRU(17, 8, 16)
	ch := newCopyHead(g.H)
	cs := newCopyAdam(g.H)
	r := rand.New(rand.NewSource(3))
	for i := range ch.Wg {
		ch.Wg[i] = r.NormFloat64() * 0.2
	}
	ch.Bg = -1.3
	cs.t = 7
	cs.mWq[2][3] = 0.01
	cs.vWk[1][4] = 0.02
	st := g.newAdam()
	st.t = 481
	st.mWo[0][1] = 0.5
	st.vE[3][2] = 0.7
	st.mBn[2] = 0.11
	st.vBo[5] = 0.22
	path := "/tmp/test_frio_completo.json"
	defer os.Remove(path)
	if err := g.saveCopy(path, 481, 3.31, st, ch, cs, 987654321, "corpussha", 17, 0.003, "proto-test"); err != nil {
		t.Fatalf("saveCopy: %v", err)
	}
	g2, steps, bpbv, ch2, cs2, mig, err := loadCopyStrict(path)
	if err != nil || mig {
		t.Fatalf("loadCopyStrict: err=%v mig=%v", err, mig)
	}
	if steps != 481 || bpbv != 3.31 {
		t.Fatalf("steps/bpbv no exactos")
	}
	if g2.lastCkpt == nil {
		t.Fatalf("lastCkpt ausente: sin estado GRU de resume")
	}
	lc := g2.lastCkpt
	if lc.Adam == nil || lc.Adam.T != 481 {
		t.Fatalf("adam GRU t no exacto")
	}
	aj := st.toJSON()
	for i := range aj.M {
		if !slicesEqual(lc.Adam.M[i], aj.M[i]) || !slicesEqual(lc.Adam.V[i], aj.V[i]) {
			t.Fatalf("m/v GRU grupo %d no exactos", i)
		}
	}
	if lc.Samp != 987654321 || lc.CorpusSHA != "corpussha" || lc.Seed != 17 || lc.Lr != 0.003 || lc.Proto != "proto-test" {
		t.Fatalf("metadatos resume no exactos")
	}
	if cs2.t != 7 || cs2.mWq[2][3] != 0.01 || cs2.vWk[1][4] != 0.02 || ch2.Bg != -1.3 {
		t.Fatalf("estado copy no exacto")
	}
	// predicciones con head identicas tras load (inputs clonados)
	mkIn := func() ([][]float64, []byte, []float64) {
		ph := [][]float64{{0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6}}
		h := make([]float64, g.H)
		h[0] = 0.42
		return ph, []byte("z"), h
	}
	ph1, pb1, h1 := mkIn()
	ph2, pb2, h2 := mkIn()
	p1, _ := ch.copyStep(g, h1, ph1, pb1, false, newCopySeqWS(len(ph1)))
	p2, _ := ch2.copyStep(g2, h2, ph2, pb2, false, newCopySeqWS(len(ph2)))
	for b := 0; b < 256; b++ {
		if p1[b] != p2[b] {
			t.Fatalf("prediccion con head difiere tras load (byte %d)", b)
		}
	}
}

func slicesEqual(a, b []float64) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}

// Sin lectura futura: pb/ph cubren SOLO el prompt (definicion unica); mutar
// los bytes de respuesta no cambia ni los estados atendidos ni la prediccion
// del primer paso; lossFrom < promptEnd se rechaza (config con lectura
// futura). El target gold nunca esta en pb.
func TestCopySinLecturaFutura(t *testing.T) {
	g := NewGRU(19, 8, 16)
	ch := newCopyHead(g.H)
	seqA := []byte("PROMPT-8\nrespuesta-A\n")
	seqB := []byte("PROMPT-8\nrespuesta-B\n")
	promptEnd := 8 // seq[:9] = "PROMPT-8\n"
	if string(copyPromptBytes(seqA, promptEnd)) != "PROMPT-8\n" || string(copyPromptBytes(seqB, promptEnd)) != "PROMPT-8\n" {
		t.Fatalf("prefijos de prompt difieren")
	}
	fwd := func(seq []byte) ([][]float64, []float64) {
		h := make([]float64, g.H)
		ph := make([][]float64, promptEnd+1)
		for tt := 0; tt <= promptEnd; tt++ {
			_, hn := g.step(h, seq[tt])
			h = hn
			ph[tt] = h
		}
		return ph, h
	}
	phA, hA := fwd(seqA)
	phB, hB := fwd(seqB)
	for i := range phA {
		if !slicesEqual(phA[i], phB[i]) {
			t.Fatalf("estado atendido %d cambia al mutar la respuesta", i)
		}
	}
	pA, _ := ch.copyStep(g, hA, phA, copyPromptBytes(seqA, promptEnd), false, newCopySeqWS(len(phA)))
	pB, _ := ch.copyStep(g, hB, phB, copyPromptBytes(seqB, promptEnd), false, newCopySeqWS(len(phB)))
	for b := 0; b < 256; b++ {
		if pA[b] != pB[b] {
			t.Fatalf("prediccion del primer paso cambia al mutar la respuesta (byte %d)", b)
		}
	}
	// lossFrom < promptEnd (lectura futura) rechazado, inputs intactos
	gr := g.newGrads()
	cg := newCopyGrads(g.H)
	sha := fmt.Sprintf("%v", g.Wo[1][1])
	func() {
		defer func() {
			if recover() == nil {
				t.Fatalf("no rechazo lossFrom < promptEnd")
			}
		}()
		g.trainSeqMaskCopy(seqA, 3, promptEnd, ch, false, gr, cg)
	}()
	if fmt.Sprintf("%v", g.Wo[1][1]) != sha {
		t.Fatalf("input modificado tras rechazo")
	}
}

// Gen greedy consume la MISMA definicion de prompt que train: con gate=0 la
// generacion greedy con head es byte a byte identica al greedy manual de la
// ruta base, y el conjunto atendido es exactamente seq[0..promptEnd].
func TestCopyGenMismaDefinicionPrompt(t *testing.T) {
	g := NewGRU(23, 8, 16)
	ch := newCopyHead(g.H)
	seq := []byte("abcdefgh\nXX")
	promptEnd := 8
	out := g.genGreedyCopy(ch, seq, promptEnd, 5, true)
	if len(out) != 5 {
		t.Fatalf("gen corto: %d", len(out))
	}
	// greedy manual base
	h := make([]float64, g.H)
	for tt := 0; tt <= promptEnd; tt++ {
		_, hn := g.step(h, seq[tt])
		h = hn
	}
	exp := make([]byte, 0, 5)
	for i := 0; i < 5; i++ {
		p := softmax(g.logits(h))
		best, bv := 0, -1.0
		for b := 0; b < 256; b++ {
			if p[b] > bv {
				bv, best = p[b], b
			}
		}
		exp = append(exp, byte(best))
		_, h = g.step(h, byte(best))
	}
	for i := range exp {
		if out[i] != exp[i] {
			t.Fatalf("gen gate0 difiere de greedy base en pos %d: %q vs %q", i, out, exp)
		}
	}
	// el conjunto atendido de gen es exactamente el prompt (longitud fija)
	if len(copyPromptBytes(seq, promptEnd)) != promptEnd+1 {
		t.Fatalf("pb de gen no es el prompt exacto")
	}
}
