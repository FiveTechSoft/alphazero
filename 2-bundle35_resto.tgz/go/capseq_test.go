package main

import (
	"bytes"
	"testing"
)

func TestRecortaBordes(t *testing.T) {
	mk := func(n int) []byte { return bytes.Repeat([]byte{'x'}, n) }
	// 511 total: no recorta
	a, err := recortaRespuesta(mk(300), mk(211), 512)
	if err != nil || len(a) != 211 {
		t.Fatalf("511: len=%d err=%v", len(a), err)
	}
	// 512 total exacto: no recorta
	a, err = recortaRespuesta(mk(300), mk(212), 512)
	if err != nil || len(a) != 212 {
		t.Fatalf("512: len=%d err=%v", len(a), err)
	}
	// 513 total: recorta respuesta a 212
	a, err = recortaRespuesta(mk(300), mk(213), 512)
	if err != nil || len(a) != 212 {
		t.Fatalf("513: len=%d err=%v", len(a), err)
	}
	// prompt == capSeq y prompt > capSeq: error claro, prompt intacto
	for _, p := range []int{512, 600} {
		if _, err = recortaRespuesta(mk(p), mk(10), 512); err == nil {
			t.Fatalf("prompt %dB debia rechazarse", p)
		}
	}
}

func TestRecortaUTF8NivelByte(t *testing.T) {
	prompt := []byte("U: pregunta\nA: ")
	ans := []byte("áéíóúñ€" + string(bytes.Repeat([]byte{'b'}, 600)))
	a, err := recortaRespuesta(prompt, ans, 512)
	if err != nil {
		t.Fatal(err)
	}
	if len(a) != 512-len(prompt) {
		t.Fatalf("recorte a bytes exactos: %d", len(a))
	}
	if !bytes.Equal(prompt, []byte("U: pregunta\nA: ")) {
		t.Fatal("prompt tocado")
	}
	// el recorte puede partir una runa: se declara; el modelo es de bytes.
}
