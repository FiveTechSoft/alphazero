package main

// capseq.go — recorte defensivo de secuencias prompt+respuesta (train-pairs).
// La PREGUNTA jamas se trunca: si no cabe en capSeq, error claro ANTES de
// entrenar o guardar nada (antes: slice con indice negativo = panico opaco).
// La mascara (lossFrom) y el prompt NO se tocan: misma semantica que antes
// para todo dato que cabe. El recorte de respuesta es A NIVEL BYTE (el modelo
// es de bytes; puede cortar una runa UTF-8 a mitad: declarado).
import "fmt"

func recortaRespuesta(prompt, ans []byte, capSeq int) ([]byte, error) {
	if len(prompt) >= capSeq {
		return nil, fmt.Errorf("RECHAZO capSeq: prompt de %dB no cabe en capSeq=%d (la pregunta nunca se trunca); par rechazado ANTES de entrenar", len(prompt), capSeq)
	}
	if len(prompt)+len(ans) > capSeq {
		ans = ans[:capSeq-len(prompt)]
	}
	return ans, nil
}
