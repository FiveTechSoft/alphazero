package main

// Equivalencia pre/post cache K: implementacion de REFERENCIA (sin cache:
// recomputa K_s = Wk*h_s por (paso,posicion) y acumula dWk por par (t,s),
// es decir la matematica literal del diseno) vs implementacion cacheada.
// Misma semilla, mismos inputs clonados, acumulacion multipaso sobre TODAS
// las salidas: p, cg (Wq/Wk/Wg/Bg), dhT, dph y grads GRU de la rama p_gru.
// Tolerancia 1e-9: la reasociacion de sumas no es bit-exacta; NO se afirma
// equivalencia bit a bit. FD del driver cacheado: TestCopyDriverFD (ya corre
// sobre la ruta nueva). Alcance: este fixture y esa secuencia.

import (
	"math"
	"math/rand"
	"testing"
)

func refK(ch *copyHead, h []float64) []float64 {
	H := len(h)
	k := make([]float64, H)
	for i := 0; i < H; i++ {
		for j := 0; j < H; j++ {
			k[i] += ch.Wk[i][j] * h[j]
		}
	}
	return k
}

// forward referencia (literal, sin cache)
func refStep(g *GRU, ch *copyHead, hT []float64, ph [][]float64, pb []byte) ([]float64, []float64, []float64, float64, []float64) {
	H := g.H
	sc := 1.0 / math.Sqrt(float64(H))
	q := make([]float64, H)
	for i := 0; i < H; i++ {
		for j := 0; j < H; j++ {
			q[i] += ch.Wq[i][j] * hT[j]
		}
	}
	scores := make([]float64, len(ph))
	mx := math.Inf(-1)
	for s := range ph {
		ks := refK(ch, ph[s])
		var dot float64
		for i := 0; i < H; i++ {
			dot += q[i] * ks[i]
		}
		scores[s] = dot * sc
		if scores[s] > mx {
			mx = scores[s]
		}
	}
	alfa := make([]float64, len(ph))
	var sum float64
	for s := range ph {
		alfa[s] = math.Exp(scores[s] - mx)
		sum += alfa[s]
	}
	for s := range ph {
		alfa[s] /= sum
	}
	c := make([]float64, H)
	for s := range ph {
		for i := 0; i < H; i++ {
			c[i] += alfa[s] * ph[s][i]
		}
	}
	v := ch.Bg
	for i := 0; i < H; i++ {
		v += ch.Wg[i]*hT[i] + ch.Wg[H+i]*c[i]
	}
	u := 1.0 / (1.0 + math.Exp(-v))
	pGru := softmax(g.logits(hT))
	p := make([]float64, 256)
	for b := 0; b < 256; b++ {
		p[b] = (1 - u) * pGru[b]
	}
	for s := range ph {
		p[pb[s]] += u * alfa[s]
	}
	return p, alfa, c, u, pGru
}

func TestCopyEquivCache(t *testing.T) {
	g := NewGRU(31, 8, 16)
	H := g.H
	ch := newCopyHead(H)
	r := rand.New(rand.NewSource(5))
	for i := range ch.Wq {
		for j := range ch.Wq[i] {
			ch.Wq[i][j] = r.NormFloat64() * 0.3
			ch.Wk[i][j] = r.NormFloat64() * 0.3
		}
	}
	for i := range ch.Wg {
		ch.Wg[i] = r.NormFloat64() * 0.3
	}
	ch.Bg = 0.4
	// escenario multipaso: 4 pasos, ventana creciente, acumulacion en ambos
	ph := make([][]float64, 6)
	pb := []byte("abcdef")
	for s := range ph {
		ph[s] = make([]float64, H)
		for j := range ph[s] {
			ph[s][j] = r.NormFloat64()
		}
	}
	cgA, cgB := newCopyGrads(H), newCopyGrads(H)
	grA, grB := g.newGrads(), g.newGrads()
	dphA := make([][]float64, 6)
	dphB := make([][]float64, 6)
	for i := range dphA {
		dphA[i] = make([]float64, H)
		dphB[i] = make([]float64, H)
	}
	ws := newCopySeqWS(6)
	tol := 1e-9
	for paso := 2; paso <= 5; paso++ {
		L := paso
		hT := make([]float64, H)
		for j := range hT {
			hT[j] = r.NormFloat64()
		}
		// cacheada
		pA, cc := ch.copyStep(g, hT, ph[:L], pb[:L], false, ws)
		// referencia
		pB, alfaB, cB, uB, pGruB := refStep(g, ch, hT, ph[:L], pb[:L])
		for b := 0; b < 256; b++ {
			if math.Abs(pA[b]-pB[b]) > tol {
				t.Fatalf("p difiere paso %d byte %d: %v vs %v", paso, b, pA[b], pB[b])
			}
		}
		if math.Abs(cc.u-uB) > tol {
			t.Fatalf("u difiere paso %d", paso)
		}
		for i := 0; i < H; i++ {
			if math.Abs(cc.c[i]-cB[i]) > tol || math.Abs(cc.alfa[0]-alfaB[0]) > tol {
				t.Fatalf("intermedios difieren paso %d", paso)
			}
		}
		_ = pGruB
		// backward con dp fijo pseudoaleatorio (mismo para ambos)
		dp := make([]float64, 256)
		for b := 0; b < 256; b++ {
			dp[b] = r.NormFloat64() * 0.01
		}
		dhTA := make([]float64, H)
		dphSub := make([][]float64, L)
		for i := range dphSub {
			dphSub[i] = make([]float64, H)
		}
		ch.copyBackward(g, cc, ph[:L], pb[:L], dp, cgA, grA, dhTA, dphSub, ws)
		for i := range dphA {
			for j := 0; j < H && i < L; j++ {
				dphA[i][j] += dphSub[i][j]
			}
		}
		// referencia backward (literal): misma matematica sin cache
		refBackward(g, ch, hT, ph[:L], pb[:L], dp, alfaB, cB, uB, pGruB, cgB, grB, dphB)
	}
	ws.flushWk(ch, ph, cgA)
	// comparar TODO acumulado
	for i := 0; i < H; i++ {
		for j := 0; j < H; j++ {
			if math.Abs(cgA.Wq[i][j]-cgB.Wq[i][j]) > tol || math.Abs(cgA.Wk[i][j]-cgB.Wk[i][j]) > tol {
				t.Fatalf("Wq/Wk difieren: %v/%v", cgA.Wq[i][j]-cgB.Wq[i][j], cgA.Wk[i][j]-cgB.Wk[i][j])
			}
		}
		if math.Abs(cgA.Wg[i]-cgB.Wg[i]) > tol || math.Abs(cgA.Wg[H+i]-cgB.Wg[H+i]) > tol {
			t.Fatalf("Wg difiere")
		}
	}
	if math.Abs(cgA.Bg-cgB.Bg) > tol {
		t.Fatalf("Bg difiere")
	}
	for b := 0; b < 256; b++ {
		if math.Abs(grA.Bo[b]-grB.Bo[b]) > tol {
			t.Fatalf("Bo difiere")
		}
		for i := 0; i < H; i++ {
			if math.Abs(grA.Wo[b][i]-grB.Wo[b][i]) > tol {
				t.Fatalf("Wo difiere")
			}
		}
	}
	for i := 0; i < 6; i++ {
		for j := 0; j < H; j++ {
			if math.Abs(dphA[i][j]-dphB[i][j]) > tol {
				t.Fatalf("dph difiere pos %d", i)
			}
		}
	}
}

// backward literal de referencia (sin cache, dWk por par (t,s))
func refBackward(g *GRU, ch *copyHead, hT []float64, ph [][]float64, pb []byte, dp, alfa, c []float64, u float64, pGru []float64, cg *copyGrads, gr *gruGrads, dph [][]float64) {
	H := g.H
	sc := 1.0 / math.Sqrt(float64(H))
	du := 0.0
	for s := range ph {
		du += dp[pb[s]] * alfa[s]
	}
	for b := 0; b < 256; b++ {
		du -= dp[b] * pGru[b]
	}
	dv := du * u * (1 - u)
	dhT := make([]float64, H)
	for i := 0; i < H; i++ {
		cg.Wg[i] += dv * hT[i]
		cg.Wg[H+i] += dv * c[i]
		dhT[i] += dv * ch.Wg[i]
	}
	cg.Bg += dv
	dc := make([]float64, H)
	for i := 0; i < H; i++ {
		dc[i] = dv * ch.Wg[H+i]
	}
	dalfa := make([]float64, len(ph))
	for s := range ph {
		dalfa[s] = u * dp[pb[s]]
		for i := 0; i < H; i++ {
			dalfa[s] += dc[i] * ph[s][i]
			dph[s][i] += alfa[s] * dc[i]
		}
	}
	var dsum float64
	for s := range ph {
		dsum += alfa[s] * dalfa[s]
	}
	q := make([]float64, H)
	for i := 0; i < H; i++ {
		for j := 0; j < H; j++ {
			q[i] += ch.Wq[i][j] * hT[j]
		}
	}
	dq := make([]float64, H)
	for s := range ph {
		ds := alfa[s] * (dalfa[s] - dsum) * sc
		ks := refK(ch, ph[s])
		for i := 0; i < H; i++ {
			dq[i] += ds * ks[i]
			dk := ds * q[i]
			for j := 0; j < H; j++ {
				cg.Wk[i][j] += dk * ph[s][j]
				dph[s][j] += ch.Wk[i][j] * dk
			}
		}
	}
	for i := 0; i < H; i++ {
		for j := 0; j < H; j++ {
			cg.Wq[i][j] += dq[i] * hT[j]
			dhT[j] += ch.Wq[i][j] * dq[i]
		}
	}
	dpg := make([]float64, 256)
	var dpgDot float64
	for b := 0; b < 256; b++ {
		dpg[b] = dp[b] * (1 - u)
		dpgDot += pGru[b] * dpg[b]
	}
	for b := 0; b < 256; b++ {
		dlg := pGru[b] * (dpg[b] - dpgDot)
		gr.Bo[b] += dlg
		for i := 0; i < H; i++ {
			gr.Wo[b][i] += dlg * hT[i]
			dhT[i] += g.Wo[b][i] * dlg
		}
	}
}
