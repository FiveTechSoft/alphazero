#!/usr/bin/env python3
# Oraculo dst6: repite=identidad, invierte=reverso. Nombres semanticos unicos (no dst_gen).
# Uso: dst6_score.py PARES GENS
import sys, re, json
def ap(op,w):
    if op=='repite': return w
    if op=='invierte': return w[::-1]
    raise ValueError(op)
import hashlib
CONGELADOS={'78e82f6ea0c4e880':'dst6_train504','128540e950a61778':'dst6_heldL48','963c27bd3af4b9d7':'dst6_heldLong48','039b6318739494fa':'dst6_nw16_24','c48c8b3f1f0a5da6':'dst7_train504','06279d6166b08229':'dst7_heldL48','d681bf535ccddfd3':'dst7_heldLong48'}
raw=open(sys.argv[1],'rb').read()
sha=hashlib.sha256(raw).hexdigest()[:16]
assert sha in CONGELADOS, f'RECHAZO: sha16 {sha} no esta en la tabla v2 congelada'
pares=raw.decode().strip().split('\n')
gens=[l.rstrip('\n') for l in open(sys.argv[2])]
n=len(pares)//2; assert len(gens)==n, (len(gens),n)
per={}
for i in range(n):
    m=re.match(r"(repite|invierte) '([a-z]+)'$", pares[2*i][3:])
    op,w=m.group(1),m.group(2)
    assert ap(op,w)==pares[2*i+1][3:], (op,w)  # dataset consistente con oraculo
    per.setdefault(op,[0,0]); per[op][1]+=1
    if gens[i].strip()==ap(op,w): per[op][0]+=1
tot_ok=sum(v[0] for v in per.values())
print(json.dumps({'exact_total':f'{tot_ok}/{n}','por_op':{k:f'{v[0]}/{v[1]}' for k,v in sorted(per.items())}}))
