# EVAL-ONLY confirmatoria sobre ck_A6 (sin training, sin updates)

Estado: datasets generados y congelados; generaciones archivadas; scoring
PENDIENTE de registro de datasets en la tabla congelada del oráculo.

## Objeto
- Checkpoint: ck_A6, sha256 663c2fa14d7c07b934efdee96a7bd6d7321e692f4e782d33a561631534e258d1
  (verificado antes y después de las generaciones: idéntico, solo lectura).
- Sin updates, sin training, sin brazo B nuevo, sin métrica natural extra.
- Carga strict con los mismos flags del brazo A (-copyhead learn -copyseed 7).

## Datasets (nuevos, independientes)
- SEED nueva declarada ANTES de generar: 20261026 (no selectiva).
- 144 pares TOTAL = 48 L4 + 48 L5 + 48 L6; 24 repite + 24 invierte por longitud.
- Operandos [a-z]^L únicos globales, misma familia generadora que dst7.
- Verificación 0 solapes: 721 operandos extraídos de TODAS las superficies
  previas (train/dev/helds/probes, búsqueda recursiva); intersección vacía.
- Congelados con SHA ANTES de decodificar (evalconf_MANIFIESTO.json):
  - evalconf_L4_48.txt sha16 4cf7c21f937329fd (0 palíndromos, 9 con letras repetidas)
  - evalconf_L5_48.txt sha16 acc9c832da0418ac (0 palíndromos, 11 con letras repetidas)
  - evalconf_L6_48.txt sha16 cc26f4b3432dcfe6 (0 palíndromos, 21 con letras repetidas)
  (palíndromos/repeticiones declarados, no filtrados; sin selección de fáciles)

## Generación (ya ejecutada)
- n=12, temp=0, un gen por par, 144 gens archivados en evalconf/gen_L{4,5,6}.txt
- Wall medido de las 3 generaciones: 4s total (estimación previa: segundos;
  la estimación "minutos CPU" del borrador era conservadora y contradictoria
  con el tope 60s; la medida real queda archivada aquí).
- RSSMAX del proceso de scoring: dentro de 900MiB (verificado por guarda).

## Scoring (pendiente de registro)
- Oráculo: dst6_score.py, semántica exacta idéntica (repite=identidad,
  invierte=reverso), CLI positivo+negativos, sin fixture 0.
- BLOQUEO: la tabla CONGELADOS del oráculo rechaza datasets no registrados
  (guarda anti-datasets-adhoc, disparada por diseño). Registrar los 3 sha16
  nuevos es semánticamente neutro (mismo procedimiento con que se registraron
  dst6/dst7); no cambia ninguna regla de scoring.

## Lectura (predeclarada)
- Primario: UNA pasada fija FINAL, pass si L4 >= 40/48 (convención, no
  promoción ni algoritmo general).
- Secundarios: L5 y L6 se reportan con cuentas exactas; cualquier >0 no es
  "éxito" (longitudes no entrenadas; negativo esperado declarado).
- Plan estadístico: operandos independientes nuevos de la misma familia
  generadora; misma semilla de modelo (ck_A6 único); NO es una réplica
  independiente del entrenamiento.
- FINAL2 permanece cerrado.
