#!/bin/bash
# DIAG TRAIN176 (autorizado 13:13): SOLO checkpoints existentes, 0 entrenamiento.
# Tope 30s wall; parada al primer fallo; sin retries. Indice fijo declarado: 0.
set -e; cd /tmp/blm; T0=$SECONDS
echo "INDICE FIJO DECLARADO ANTES DE GENERAR: 0 (primer par de dst_train.txt)"
head -2 dst_train.txt
for N in base A3 C3; do
  case $N in base) CK=ciclo1_etapa0.json;; *) CK=ciclo3/ck_$N.json;; esac
  timeout -k 2 10 ./mz d1gru -mode genpairs -in $CK -corpus dst_train.txt -n 16 -temp 0 > ciclo3/gentrain_$N.txt 2>/dev/null
  timeout -k 2 10 ./mz d1gru -mode scorepairs -in $CK -corpus dst_train.txt 2>/dev/null | awk '$1=="SCORE"{s+=$3;n++} END{printf "bpb_train %s = %.6f (%d pares)\n", "'$N'", s/n, n}'
  timeout -k 2 10 ./mz d1gru -mode gappairs -in $CK -corpus dst_train.txt 2>/dev/null | grep GAPRESUMEN | sed "s/^/[$N] /" 
  [ $((SECONDS-T0)) -gt 28 ] && { echo "PARADA tope 28s"; exit 5; }
done
python3 - <<'PY'
import sys, re, json
sys.path.insert(0,'/tmp/blm')
from dst_gen import aplica
def opsde(s):
    p=s.split(' y '); return [p[0],p[1]] if len(p)==2 else [p[0]]
trl=open('dst_train.txt').read().strip().split('\n')
ctl=open('dst_control.txt').read().strip().split('\n')
n=len(trl)//2
true_a=[trl[2*i+1][3:] for i in range(n)]
ctrl_a=[ctl[2*i+1][3:] for i in range(n)]
singles=[i for i in range(n) if ' y ' not in trl[2*i]]
comps=[i for i in range(n) if ' y ' in trl[2*i]]
for N in ('base','A3','C3'):
    gens=[l.rstrip('\n') for l in open(f'ciclo3/gentrain_{N}.txt')]
    assert len(gens)==n
    def em(targets, idx):
        return f"{sum(1 for i in idx if gens[i].strip()==targets[i])}/{len(idx)}"
    out={'exact_vs_oraculo':{'total':em(true_a,range(n)),'singles':em(true_a,singles),'composiciones':em(true_a,comps)}}
    if N=='C3':
        out['exact_vs_sus_targets_permutados']={'total':em(ctrl_a,range(n)),'singles':em(ctrl_a,singles),'composiciones':em(ctrl_a,comps)}
    print(N, json.dumps(out))
PY
echo "DIAG wall=$((SECONDS-T0))s (tope 30)"
