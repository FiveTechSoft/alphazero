# ERRATA/NOTAS CICLO-3b + DIAG TRAIN176 (adendo; no reescribe evidencia)

## N1. DIAG TRAIN176 (checkpoints existentes, 0 entrenamiento)
- Una correccion de harness: campo awk errado leyendo salida gappairs (el modo
  ya imprime GAPRESUMEN). Repeticion de MEDICION idempotente (sin modelo
  entrenado, mismos bytes), no verificacion ciega.
- Resultados: bpb_train base 7.4141 / A3 2.7447 / C3 3.3099; gap_train
  -0.0006 / 0.4452 / 0.0370 (176/176); exact train base 0/176, A3 1/176,
  C3 0/176 vs oraculo Y 0/176 vs sus targets permutados; cobertura primer
  byte 0.0000 / 0.1761 / 0.0341.
- Capturas TUI: dos intentos previos en negro (X reiniciado sin WM; ruido de
  proceso, sin efecto en datos). Captura valida: tui_ciclo3_diag3.png.

## N2. CICLO-3b SINGLETONS
- Datos: subconjunto DECLARADO byte-exacto de DST v2 seed77 (96 train
  singletons, 24 dev singletons palabras no vistas, control permutado k=37).
  Colisiones proxy con dst_train/dev EXISTEN por construccion (subconjunto
  declarado); vs corpus naturales: 0.
- Corrida predefinida 2 brazos x 3x480, sin seleccion adelantada: 6 bloques
  1-2s, wall total 15s (tope 60), 6/6 ledgers completed, 2 transiciones
  curriculo declaradas y verificadas, 0 fallos, 0 retries. CPU~=wall es
  estimacion (no consumo CPU medido).
- Resultados (limitados a esta escala/tarea; no distinguen
  optimizador/datos/pasos/arquitectura): exact train96 base 0, A1 0, A2 3,
  A3 15 (por op: CAMBIA 2/12 DUPLICA 0/12 INVIERTE 3/12 ROT1 3/12 ROT2 1/12
  ROT3 2/12 ROT4 2/12 ROT5 2/12), C1-C3 0; exact dev24 = 0/24 en TODOS;
  bpb_val dev A empeora 4.0451->4.3976->4.9089; retencion natural heldout100
  base 3.8619 -> A3 8.5510 (+4.69) / C3 8.3255 (+4.46).
- dst_final sintetico y FINAL-2 natural permanecen CERRADOS (no abiertos).
