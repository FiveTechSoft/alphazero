#!/bin/bash
# CICLO-3b SINGLETONS (autorizado 13:17). CONGELADO: N=3x480/brazo, lr 0.003,
# seed 7, base comun fiel (clon etapa0, Adam/RNG), curriculo declarado -master-prev,
# sin replay, sin composiciones. Tope 60s wall TOTAL (incl gens/score/retencion);
# guarda bloque <45s; proyeccion elapsed+45>60 = PARAR; primer fallo = PARAR;
# SIN retries. Ledger inalterado exactly-once (runner con fix).
set -e; cd /tmp/blm
PREV=c8ee772eb1d2dfe4c2ea8ffc38d991f07750309d449eff53f82d63af3476b355
TSTART=$SECONDS
adamsha() { python3 -c "
import json,hashlib
d=json.load(open('$1'))
print(hashlib.sha256(json.dumps(d.get('adam'),sort_keys=True).encode()).hexdigest()[:16], hashlib.sha256(str(d.get('samp')).encode()).hexdigest()[:16])"; }
bloque() { # ARM K MASTER MAN CKIN CKS PREVFLAG
  local A=$1 K=$2 MA=$3 MF=$4 IN=$5 OUT=$6 PF=$7
  local INSHA; INSHA=$(sha256sum "$IN" | cut -c1-12)
  local KEY; KEY="${A}${K}_${INSHA}"
  local LED; LED="ciclo3b/ledger_$KEY"
  if [ -e "$LED" ]; then
    local ST; ST=$(cut -d' ' -f1 "$LED")
    [ "$ST" = completed ] && { echo "LEDGER $KEY ya completada"; return 0; }
    echo "LEDGER $KEY estado=$ST: recuperacion manual; NO reejecuta"; exit 3
  fi
  echo "running $(date -Is)" > "$LED.tmp"; mv "$LED.tmp" "$LED"
  trap 'if [ -n "$LED" ]; then echo "failed $(date -Is)" > "$LED.tmp"; mv "$LED.tmp" "$LED"; fi' ERR
  local t0=$SECONDS
  timeout -k 2 44 ./mz d1gru -mode train-pairs -corpus "$MA" -val dst3b_dev.txt \
    -in "$IN" -out "$OUT" -steps 480 -lr 0.003 -seed 7 \
    -master "$MA" -manifest "$MF" $PF 2>&1 | grep -E 'FIN|RECHAZO|DECLARADO'
  local dt=$((SECONDS-t0))
  { echo "adam_rng_antes: $(adamsha "$IN")"; echo "adam_rng_despues: $(adamsha "$OUT")"; } >> ciclo3b/adam_$A$K.txt
  if [ $dt -gt 45 ]; then
    echo "failed $(date -Is) GUARDA bloque ${dt}s > 45s" > "$LED.tmp"; mv "$LED.tmp" "$LED"
    echo "PARADA: bloque $A$K ${dt}s > 45s"; exit 4
  fi
  echo "completed $(date -Is) segundos=$dt" > "$LED.tmp"; mv "$LED.tmp" "$LED"
  echo "OK bloque $A$K ${dt}s"
  local el=$((SECONDS-TSTART))
  if [ $((el+45)) -gt 60 ]; then echo "PARADA proyeccion ${el}s+45 > 60s"; exit 5; fi
}
evalu() { # NOMBRE CK
  timeout -k 2 10 ./mz d1gru -mode genpairs -in "$1" -corpus dst3b_dev.txt -n 16 -temp 0 > ciclo3b/gendev_$2.txt 2>/dev/null
  timeout -k 2 10 ./mz d1gru -mode genpairs -in "$1" -corpus dst3b_train.txt -n 16 -temp 0 > ciclo3b/gentrain_$2.txt 2>/dev/null
  echo "== $2 dev24: $(python3 ciclo3b_score.py dst3b_dev.txt ciclo3b/gendev_$2.txt | tr -d '\n ')"
  echo "== $2 train96: $(python3 ciclo3b_score.py dst3b_train.txt ciclo3b/gentrain_$2.txt | tr -d '\n ')"
}
evalu ciclo1_etapa0.json base
for ARM in A C; do
  if [ $ARM = A ]; then MA=dst3b_train.txt; MF=ciclo3b/man_train.txt; else MA=dst3b_control.txt; MF=ciclo3b/man_control.txt; fi
  cp ciclo1_etapa0.json ciclo3b/ck_${ARM}0.json
  for K in 1 2 3; do
    P=$((K-1)); PF=""; [ $K = 1 ] && PF="-master-prev $PREV"
    bloque $ARM $K "$MA" "$MF" ciclo3b/ck_${ARM}${P}.json ciclo3b/ck_${ARM}${K}.json "$PF"
    evalu ciclo3b/ck_${ARM}${K}.json ${ARM}${K}
  done
done
for CK in ciclo1_etapa0 ciclo3b/ck_A3 ciclo3b/ck_C3; do
  N=$(basename $CK)
  timeout -k 2 10 ./mz d1gru -mode scorepairs -in $CK.json -corpus ciclo1_heldout100.txt 2>/dev/null | awk '$1=="SCORE"{s+=$3;n++} END{printf "retencion %s bpb=%.6f (%d pares)\n", "'$N'", s/n, n}'
done
echo "TOTAL wall=$((SECONDS-TSTART))s (tope 60)"
