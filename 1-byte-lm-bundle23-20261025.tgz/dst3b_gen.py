#!/usr/bin/env python3
# dst3b_gen.py — CICLO-3b SINGLETONS: subconjunto DECLARADO del DST v2 (seed 77).
# train = los 96 singletons de dst_train (8 ops x 12 palabras)
# dev   = los 24 singletons de dst_dev (8 ops x 3 palabras NO VISTAS)
# control = las 96 preguntas de train con respuestas de train permutadas (k=37)
# Sin composiciones. Oraculo offline; convenciones identicas a DST v2.
import sys, re, json, hashlib
sys.path.insert(0,'/tmp/blm')
from dst_gen import aplica, clave

def lee(path):
    lines=open(path).read().strip().split('\n')
    return [(lines[i][3:], lines[i+1][3:]) for i in range(0,len(lines),2)]
def escribe(pares, path, ans_override=None):
    with open(path,'w') as f:
        for i,(u,a) in enumerate(pares):
            f.write(f"U: {u}\nA: {ans_override[i] if ans_override else a}\n")

train_all=lee('dst_train.txt'); dev_all=lee('dst_dev.txt')
train=[p for p in train_all if ' y ' not in p[0]]
dev=[p for p in dev_all if ' y ' not in p[0]]
assert len(train)==96 and len(dev)==24, (len(train),len(dev))
n=len(train); ctrl_ans=[train[(i+37)%n][1] for i in range(n)]
escribe(train,'dst3b_train.txt'); escribe(dev,'dst3b_dev.txt')
escribe(train,'dst3b_control.txt',ctrl_ans)
ops=sorted({u.split()[1] for u,_ in train})
meta={'fuente':'subconjunto de DST v2 seed77 (mismos bytes)','n_train':96,'n_dev':24,
 'ops':ops,'por_op_train':12,'por_op_dev':3,'control':'preguntas train, respuestas permutadas k=37',
 'composiciones':'NINGUNAS (dominio reducido, menos complejo por este criterio)'}
open('dst3b_meta.json','w').write(json.dumps(meta,indent=1))
for f in ('dst3b_train.txt','dst3b_dev.txt','dst3b_control.txt'):
    print(f, hashlib.sha256(open(f,'rb').read()).hexdigest()[:16])
