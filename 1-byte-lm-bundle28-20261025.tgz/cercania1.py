#!/usr/bin/env python3
# CERCANIA v1: métricas congeladas en CERCANIA_METRICAS_v1.md sobre gens archivadas.
import re, sys, json, random
sys.path.insert(0,'/tmp/blm')
from dst_gen import aplica
def aplica9(op,w): return w if op=='COPIA' else aplica([op],w)
def lev(a,b):
    m,n=len(a),len(b); d=list(range(n+1))
    for i in range(1,m+1):
        p,d=d,[i]+[0]*n
        for j in range(1,n+1): d[j]=min(p[j]+1,d[j-1]+1,p[j-1]+(a[i-1]!=b[j-1]))
    return d[n]
def prefijo(a,b):
    k=0
    for x,y in zip(a,b):
        if x!=y: break
        k+=1
    return k
def pares(path):
    ls=open(path).read().strip().split('\n'); out=[]
    for i in range(0,len(ls),2):
        m=re.match(r"aplica (\S+) a '([a-z]+)'$", ls[i][3:])
        out.append((m.group(1),m.group(2),ls[i+1][3:]))
    return out
def metricas(gens, targets):
    n=len(gens); ex=sum(g.strip()==t for g,t in zip(gens,targets))
    largo=sum(len(g.strip())==len(t) for g,t in zip(gens,targets))
    lv=sum(lev(g.strip(),t)/len(t) for g,t in zip(gens,targets))/n
    ok=[ (sum(1 for i in range(len(t)) if g.strip()[i]==t[i])/len(t)) for g,t in zip(gens,targets) if len(g.strip())==len(t)]
    pos=sum(ok)/len(ok) if ok else None
    pf=sum(prefijo(g.strip(),t) for g,t in zip(gens,targets))/n
    return dict(n=n, exacto=ex, largo_ok=largo, lev_norm=round(lv,4), pos_ok=(round(pos,4) if pos is not None else None), n_pos=len(ok), prefijo=round(pf,4))
def run(conj, path, kname):
    it=pares(path)
    print(f"### {conj} (n={len(it)})")
    for b in range(1,7):
        gens=[l.rstrip('\n') for l in open(f'ciclo_comp/{kname}_C{b}.txt')]
        assert len(gens)==len(it)
        tg=[t for _,_,t in it]
        r=metricas(gens,tg)
        # control permutado dentro de op, semilla congelada
        rng=random.Random(20261025); perm=[None]*len(it)
        for op in {o for o,_,_ in it}:
            idx=[i for i,(o,_,_) in enumerate(it) if o==op]
            sh=idx[:]; rng.shuffle(sh)
            while any(a==b for a,b in zip(idx,sh)) and len(idx)>1: rng.shuffle(sh)
            for a,b2 in zip(idx,sh): perm[a]=tg[b2]
        c=metricas(gens,perm)
        print(f"C{b} real: {json.dumps(r,ensure_ascii=False)}")
        print(f"C{b} ctrl: {json.dumps(c,ensure_ascii=False)}")
    # por op en bloque primario C6
    b=6; gens=[l.rstrip('\n') for l in open(f'ciclo_comp/{kname}_C{b}.txt')]
    print(f"-- C6 por op ({conj}):")
    for op in sorted({o for o,_,_ in it}):
        idx=[i for i,(o,_,_) in enumerate(it) if o==op]
        g=[gens[i] for i in idx]; tg=[it[i][2] for i in idx]
        print(f"  {op} n={len(idx)}: {json.dumps(metricas(g,tg),ensure_ascii=False)}")
run('TRAIN84 (referencia ajuste)','dst4_train.txt','gentrain')
run('HELD24','dst4_held24.txt','genheld')
run('NEWWORD36','dst4_newword36.txt','gennw')
