# CERCANIA v1.1 — Resultados (análisis sobre gens archivadas, 2026-10-25)

Autorización: análisis SOLO sobre generaciones archivadas C1..C6, sin nuevas gens, sin training. Métricas congeladas en CERCANIA_METRICAS_v1.md (con ERRATA v1.1 declarada: DUPLICA tiene target de 8 caracteres; la primera ejecución con la definición errónea se conserva en ciclo_comp/cercania1.txt y no se usa). Wall del análisis: 1s (tope 30s). Control permutado por operación, semilla 20261025: DESCRIPTIVO, no independencia estadística ni universo de azar; sesgos de longitud/letras afectan a ambas ramas.

## Primario (C6), real vs control

| conjunto | lev_norm real | lev_norm ctrl | pos_ok real | pos_ok ctrl | prefijo real | prefijo ctrl |
|---|---|---|---|---|---|---|
| train84 (referencia ajuste) | 0.536 | 0.996 | 0.486 (n=69) | 0.062 (n=69) | 1.75 | 0.11 |
| held24 | 0.927 | 1.010 | 0.024 (n=21) | 0.036 (n=21) | 0.125 | 0.0 |
| newword36 | 0.941 | 0.976 | 0.085 (n=31) | 0.032 (n=31) | 0.0 | 0.0 |

## Lectura (descriptiva, cuentas exactas en ciclo_comp/cercania1_v11.txt)
- En celdas ENTRENADAS las salidas se acercan al target real mucho más que a un target permutado de la misma operación (todas las métricas, todos los bloques C2..C6 con separación creciente): el ajuste medido no es artefacto de la métrica exacta.
- En held24 y newword36 las salidas quedan lejos de CUALQUIER target (lev_norm ≈ 0.93-0.94: casi todas las posiciones mal) y las diferencias real-vs-control son pequeñas y no consistentes en dirección entre métricas (pos_ok: mejor en newword, peor en held). No se observa estructura parcial medible con estas métricas; las diferencias pequeñas son compatibles con sesgos de longitud/letras que el control descriptivo solo amortigua parcialmente. Sin conclusión causal.
- Detalle por operación (train, C6): COPIA 5/10 exacto, pos_ok 0.89 en las de largo correcto (canal identidad parcialmente aprendido en celdas practicadas); DUPLICA 0/10 exacto y 0/10 largo correcto (nunca emite 8 caracteres; prefijo 2.8 sobre target de 8: emite el inicio de la palabra sin duplicar). El fallo de DUPLICA incluye el LARGO de la salida, no solo la regla.
- En held, COPIA n=2: 0 exacto, 1/2 largo correcto, pos_ok 0.0. n demasiado pequeña para cualquier lectura (declarado).

## Negativos honestos
- Ninguna métrica muestra aproximación creciente clara a los targets reservados a lo largo de los bloques (held C5 lev 0.958 vs C6 0.927; dentro del ruido descriptivo).
- La métrica v1 contenía un error de diseño (longitud DUPLICA) detectado y corregido con errata; los números de la primera ejecución no valen.
