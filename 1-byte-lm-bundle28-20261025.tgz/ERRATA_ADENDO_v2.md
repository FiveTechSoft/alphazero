# ERRATA + ADENDO v2 (bundle28, no altera historial)

1. ERRATA en COMPOSICION_PROTOCOLO_v1.md línea "Canal identidad": decía "exact COPIA en held (3 celdas)"; el conteo real sobre dst4_held24.txt congelado es 2 celdas COPIA (distribución real: ROT1-5 e INVIERTE 3 c/u, DUPLICA/CAMBIA/COPIA 2 c/u = 24). El resultado reportado (COPIA held 0/2) ya usaba el conteo correcto; la errata es solo documental.
2. ADENDO: la distribución por operación en held24 no es uniforme (3/3/3/3/3/3/2/2/2); las medias por conjunto mezclan operaciones con distinta n. Los cortes por operación en CERCANIA v1 llevan su n explícita.
