# CERCANIA v1 — Métricas congeladas ANTES del análisis (2026-10-25)

Análisis EVAL-ONLY sobre generaciones YA archivadas (ciclo_comp/gen{train,held,nw}_C1..C6.txt).
Sin nuevas llamadas de generación, sin training, sin cambios de pesos. Tope 30s wall.

## Definiciones (fijas)
Para un ítem con target t (longitud 4 siempre) y salida del modelo o (strip):
1. exacto: o == t (ya reportado; se incluye por completitud).
2. largo_ok: 1 si len(o) == 4, si no 0. Reportar cuenta por conjunto/bloque.
3. lev_norm: distancia de Levenshtein d(o,t) / 4 (normalizada por la longitud del target, no por max; declarado).
4. pos_ok: si len(o)==4, fracción de posiciones i en 0..3 con o[i]==t[i]; si len(o)!=4, no entra en la media (se reporta la n de cada media).
5. prefijo: longitud del prefijo común más largo entre o y t, en 0..4.

## Cortes
Por conjunto (train84 referencia de ajuste / held24 / newword36) × bloque (C1..C6) × operación (9). Se reportan medias y cuentas exactas.

## Control permutado (descriptivo)
Para cada ítem, un target emparejado por permutación dentro de la misma operación y el mismo conjunto, semilla congelada 20261025 (targets de la misma op barajados; si una op tiene 1 solo ítem se empareja consigo mismo — no ocurre en dst4: mínimo 2 por op en held, 4 en newword). Mismas métricas 3-5 contra ese target permutado.
Interpretación DECLARADA: control permutado DESCRIPTIVO. NO es independencia estadística ni un universo de azar; sesgos de longitud y letras frecuentes afectan a ambas métricas (prefijo y edición) y el control solo los amortigua parcialmente. Se reportan cuentas y medias, no p-valores ni "significación".

## Pregunta del análisis
¿Las salidas en held24/newword36 están más cerca de su target real que de un target permutado de la misma op (estructura parcial), o son indistinguibles por estas métricas? Resultado: cuentas y medias por corte, con el control al lado. Ninguna conclusión causal.

## ERRATA v1.1 (detectada por el propio análisis, declarada)
La definición v1 decía "target longitud 4 siempre": FALSO para DUPLICA (target de 8 caracteres). Métricas corregidas y congeladas como v1.1 antes de recomputar:
- largo_ok: 1 si len(o) == len(t).
- lev_norm: d(o,t)/len(t) (puede superar 1 si len(o)>len(t)).
- pos_ok: si len(o)==len(t), fracción de posiciones coincidentes sobre len(t); si no, fuera de la media.
- prefijo: prefijo común, en 0..len(t).
La primera ejecución (con la definición errónea) se conserva en ciclo_comp/cercania1.txt y NO se usa para conclusiones.
