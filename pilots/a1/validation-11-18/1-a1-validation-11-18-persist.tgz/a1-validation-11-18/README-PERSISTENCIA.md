# A1 validación semillas 11..18 — paquete de persistencia

Validación A1 (protocolo nuevo, no P3/G1), 8 semillas (11..18), schedule [2,3,4,5,6,7], 40/ronda, caps 100/100, banco G2 (digest f58161c5…), prior_keys 1739. 8×6 etapas COMPLETED, residual 0, budgets 261/240/271/229/240/256/240/262 s, RSS máx 556 MiB. Binario ejecutor 97060cbd… Interrupción runtime en report de la semilla 18 resuelta leyendo estados, sin repetir etapas.

Resultado por semilla (Pre/A/F): 47/47/56, 44/65/64, 42/47/52, 48/59/55, 41/52/54, 43/51/53, 40/65/51, 40/63/51.
dA-dF = -9,+1,-5,+4,-2,-2,+14,+12; P4 N4 Z0; signo bilateral p=1.0 (banco fijo, nominal). No se detecta ventaja consistente; no implica equivalencia ni ausencia de efecto. Efecto total incluye mediadores (resueltos, muestras, hindsight); no SGD-only, no igual cómputo, no autojuego. Disjunción estructural módulo Key.

Contenido por semilla: report.out (arrays completos), 6 etapas (json/guard/log/status), weights_A/F.json, binary.sha256, budget_used_s. HASHES.txt (sha256 por fichero, autoexcluido) y TRANSFORMACIONES.txt en la raíz.

Auditoría independiente (agente revisor, 2026-10-24): números por semilla, identidad de problemas A=F (240×8), overlaps Key-AC 0 (normalizador propio con control positivo, incl. 45 hindsight), pesos pre=NewMLP(semilla) y post-A/F, guía F congelada, fingerprints por semilla, y rejuicio acotado de todos los cambios (113+99 ganadas, 9+8 perdidas) con ambas redes sin reentrenar — todo reproducido, cero discrepancias. Rejuicio con guardia 900MiB/110s por semilla (medido RSS ≤512, ≤63s). Reproducción funcional con Go 1.26.6; binario no byte-reproducible (ejecutor Go 1.26.10).
