# A1 pilot-101 — paquete de persistencia

Ejecución A1 (protocolo nuevo, no P3/G1), seed 101, schedule [2,3,4,5,6,7], 40/ronda, caps 100/100.
Banco G2 (digest f58161c5…), prior_keys 1739. 6/6 etapas COMPLETED, residual 0, budget 229s, RSS máx 453 MiB.

Resultado: pre 41 → A 66 (+25/-0), F 60 (+19/-0), d=+6. n=1, sin criterio estadístico.
Efecto total de guía adaptativa vs guía inicial congelada; incluye mediadores (resueltos, muestras, hindsight). No SGD-only, no igual cómputo, no autojuego. Disjunción estructural módulo Key.

Contenido:
- report.out: reporte completo (arrays por brazo, banco pre/post, mediadores, overlaps).
- <etapa>.json/.guard/.log + status_<etapa>: 6 etapas (pre-g2, train-A, train-F, post-A, post-F, report).
- weights_A.json / weights_F.json: pesos post-entrenamiento de cada brazo.
- binary.sha256: hash del binario ejecutor (97060cbd…).
- budget_used_s: 229.
- HASHES.txt: sha256 de cada fichero (autoexcluido).
- TRANSFORMACIONES.txt: registro de transformaciones de persistencia.

Auditoría independiente (agente revisor, 2026-10-24): números, overlaps Key-AC (0/0/0, normalizador propio con control positivo, incl. hindsight), identidad de problemas A=F, pesos pre/post, guía F congelada, fingerprint y rejuicio acotado de los casos ganados con ambas redes — todo reproducido. Rejuicio ejecutado con guardia 240s/1200MiB (por encima del plan 110s/900MiB; medido 64s/561MiB, residual 0; se conserva registro honesto, no se repite). Reproducción funcional con Go 1.26.6; binario no byte-reproducible (ejecutor Go 1.26.10).
