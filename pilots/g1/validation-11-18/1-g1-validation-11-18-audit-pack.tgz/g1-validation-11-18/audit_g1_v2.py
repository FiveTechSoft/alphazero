import json,sys
def parse(s,i=0):
    if s.startswith('neg(',i):
        a,i=parse(s,i+4); assert s[i]==')'; return ('neg',a),i+1
    if s.startswith('add(',i) or s.startswith('mul(',i):
        op=s[i:i+3]; a,i=parse(s,i+4); assert s[i]==','; b,i=parse(s,i+1); assert s[i]==')'; return (op,a,b),i+1
    if s[i]=='c':
        j=i+1
        if s[j]=='-': j+=1
        while j<len(s) and s[j].isdigit(): j+=1
        return ('c',int(s[i+1:j])),j
    if s[i]=='v': return ('v',s[i+1]),i+2
    raise ValueError(s)
def norm(t):
    if t[0] in('add','mul'):
        out=[];st=[t]
        while st:
            x=st.pop()
            if x[0]==t[0]: st+= [x[2],x[1]]
            else: out.append(norm(x))
        return (t[0],tuple(sorted(out,key=repr)))
    if t[0]=='neg': return ('neg',norm(t[1]))
    return t
def N(s):
    t,i=parse(s); assert i==len(s); return repr(norm(t))
bank=json.load(open('<RUTA_LOCAL>/pilots/g1/BANK-G1.json'))
bn=set()
for c in bank['cases']: bn.add(N(c['Start'])); bn.add(N(c['Target']))
rep=json.load(open(sys.argv[1]+'/report.out'))
tl=rep['train_log']
bad=0
for pr in tl['RenderedProblems']:
    a,b=pr.split('|',1)
    if N(a) in bn or N(b) in bn: bad+=1
hk=tl.get('HindsightKeptRendered') or []
badh=0
for pr in hk:
    a,b=pr.split('|',1)
    if N(a) in bn or N(b) in bn: badh+=1
print("bank cases",len(bank['cases']),"bank exprs",len(bn),"train problems",len(tl['RenderedProblems']),"overlap",bad,"hindsight kept",len(hk),"hindsight overlap",badh)
print("report overlap",rep['train_eval_overlap'])
print("rounds",[(r['Round'],r['Level'],r['Solved'],r['Problems'],r['HindsightKept'],r['HindsightDropped'],r['Attempts'],r.get('KeyRejected',0)) for r in tl['Rounds']])
b=rep['banks'][0]
print({k:b[k] for k in('name','cases','bank_digest','pre_solved','post_solved','delta','solved_to_unsolved','unsolved_to_solved','per_level_pre_post_n')})
print(rep['weights_sha256_pre'][:12],rep['weights_sha256_post'][:12],rep['final_level'],rep['seconds_by_phase'])
print(rep['g1']['bank_digest'],rep['g1']['prior_keys'])
