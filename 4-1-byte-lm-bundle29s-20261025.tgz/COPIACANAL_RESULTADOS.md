# COPIACANAL v1 — Resultados (2026-10-25)

Ejecutado según COPIACANAL_PROTOCOLO_v1.md + adendo v1.1. Diagnóstico del motor de aprendizaje básico desde cero; NO producto final ni RSI. Todo local CPU.

## Artefactos congelados (pre-ejecución)
- dst5_train.txt sha16 e4f92cfdba3f2462 (84 = 28 palabras × 3 ops, TODAS las ops en cada palabra)
- dst5_held18.txt sha16 b875e4dd36b518f1 (6 palabras nuevas × 3) — PRIMARIO (palabras nuevas, lote 1)
- dst5_newword18.txt sha16 5a1a0f746703dd2c (otras 6 × 3) — secundario (otro lote de desarrollo)
- master_mix5.txt sha16 20f7faac70f3cb12 (84 dst5 + 84 naturales sub500); man_mix5 e5481633fdc5f0f9; seq_comp5 7e77523dfdabb6a4 (índices byte-idénticos a COMPOSICION, declarado; contenido vía master_mix5)
- Fixtures pre-run: 0 targets held/nw presentes como target train; 0 equivalencias entre ops; 0 colisiones reales (clave proxy) vs sub500/heldout100/finales/dst4.
- Ops dst5: COPIA=identidad, DUPLICA=repetición de palabra (w+w), INVIERTE=reverso. Ninguna requiere sustitución de letras.

## ERRATA (declarada, sin alterar historial)
1. El scoring en vivo usó dst4_score.py, cuyo oráculo DUPLICA es el de dst_gen (duplicado por carácter: "abcq"→"aabbccqq"). dst5 define DUPLICA como repetición de palabra ("abcq"→"abcqabcq"). Colisión de nombre entre experimentos, declarada. Re-score completo con dst5_score.py (auto-test oráculo 84/84, 18/18, 18/18). El PRIMARIO (held18 0/18) es idéntico con ambos oráculos; solo cambian los conteos train84.
2. El runner no hizo tee; la línea FIN/RSSMAX de C1 no se conserva (ciclo_cop/run.log lo declara). Conteos exactos recomputados desde generaciones archivadas.
3. Etiquetas "held24/newword36" del eco en vivo eran cosméticas (ficheros reales: held18/newword18).

## Resultados (exact match, oráculo dst5 corregido)

| bloque | train84 | held18 (primario) | newword18 | bpb heldout natural |
|---|---|---|---|---|
| C1 | 0/84 | 0/18 | 0/18 | — (bpb C1 no conservado) |
| C2 | 3/84 | 0/18 | 0/18 | 3.6451 |
| C3 | 10/84 | 0/18 | 0/18 | 3.5651 |
| C4 | 36/84 | 0/18 | 0/18 | 3.5382 |
| C5 | 42/84 | 0/18 | 0/18 | 3.4999 |
| C6 | 45/84 (COPIA 17/28, DUPLICA 15/28, INVIERTE 13/28) | 0/18 | 0/18 | 3.4617 |

## CERCANIA v1.1 (offline, gens archivadas, control permutado descriptivo semilla 20261025)
C6 real vs control: train84 lev 0.341 vs 0.972, pos_ok 0.659 vs 0.039, prefijo 3.35 vs 0.04 (ajuste real, no artefacto); held18 lev 0.889 vs 0.986, pos_ok 0.083 vs 0.017, prefijo 0.0 vs 0.0; newword18 lev 0.924 vs 0.986, pos_ok 0.063 vs 0.0, prefijo 0.167 vs 0.0. En reservadas/nuevas las salidas quedan lejos de cualquier target; diferencias pequeñas real-vs-control, sin lectura causal.

## Ejecución y guardas
6/6 ledgers completed; steps/cursor/seq_sha verificados por bloque; 0 fallos, 0 retries; wall 88s (tope 180); RSS máx 25,1 MiB (tope 900); main/champion intactos; FINAL-2 no tocado; sin adopción. Oráculo solo evalúa gens archivadas; nunca alimenta inferencia.

## Lectura (criterio predeclarado: ≥6/18 sí / ≤2 no / 3-5 ambiguo; convención)
- Primario C6: held18 = 0/18 → NO se mide transferencia a palabras nuevas. Secundario newword18 = 0/18.
- Ajuste a lo practicado: 45/84 en C6, con las tres operaciones aprendidas en palabras practicadas (incluida DUPLICA de longitud doble: 15/28). En dst4, DUPLICA quedó en 0/10: diferencia descriptiva entre experimentos (cambia la op, el dataset y el reparto; NO aislamiento causal).
- Fallo descriptivo conjunto de copia y transformación ante palabras nuevas en este régimen; nada más.

Captura OpenCode: tui_cop1.png (TUI real, proveedor local, comando archivado, sesión sin llamadas a modelo).
